// frontend/src/App.jsx
import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Layout, ConfigProvider, theme, message } from 'antd';
import { useAuth } from './contexts/AuthContext';
import { useTheme } from './contexts/ThemeContext';

// Layout components
import Sidebar from './components/Layout/Sidebar';
import Header from './components/Layout/Header';
import LoadingSpinner from './components/Common/LoadingSpinner';

// Authentication pages
import LoginPage from './pages/Auth/LoginPage';
import SetupPage from './pages/Auth/SetupPage';

// Main pages
import Dashboard from './pages/Dashboard/Dashboard';
import ItemsPage from './pages/Items/ItemsPage';
import CustomersPage from './pages/Customers/CustomersPage';
import SuppliersPage from './pages/Suppliers/SuppliersPage';
import SalesPage from './pages/Sales/SalesPage';
import PurchasePage from './pages/Purchase/PurchasePage';
import StockPage from './pages/Stock/StockPage';
import PaymentsPage from './pages/Payments/PaymentsPage';
import ReportsPage from './pages/Reports/ReportsPage';
import SettingsPage from './pages/Settings/SettingsPage';
import POSPage from './pages/POS/POSPage';

// Error boundary
import ErrorBoundary from './components/Common/ErrorBoundary';

// Styles
import './App.css';

const { Content } = Layout;

function App() {
  const { user, loading, checkAuthStatus } = useAuth();
  const { isDarkMode } = useTheme();
  const [collapsed, setCollapsed] = useState(false);
  const [messageApi, contextHolder] = message.useMessage();

  useEffect(() => {
    checkAuthStatus();
  }, []);

  // Configure theme
  const themeConfig = {
    algorithm: isDarkMode ? theme.darkAlgorithm : theme.defaultAlgorithm,
    token: {
      colorPrimary: '#1890ff',
      borderRadius: 8,
      fontSize: 14,
    },
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <ConfigProvider theme={themeConfig}>
      <ErrorBoundary>
        <div className="App">
          {contextHolder}
          <Router>
            {!user ? (
              <Routes>
                <Route path="/login" element={<LoginPage />} />
                <Route path="/setup" element={<SetupPage />} />
                <Route path="*" element={<Navigate to="/login" />} />
              </Routes>
            ) : (
              <Layout style={{ minHeight: '100vh' }}>
                <Sidebar collapsed={collapsed} />
                <Layout>
                  <Header 
                    collapsed={collapsed}
                    onToggle={() => setCollapsed(!collapsed)}
                  />
                  <Content style={{ 
                    margin: '16px',
                    padding: '16px',
                    background: isDarkMode ? '#1f1f1f' : '#f0f2f5',
                    borderRadius: '8px',
                    overflow: 'auto'
                  }}>
                    <Routes>
                      <Route path="/" element={<Dashboard />} />
                      <Route path="/dashboard" element={<Dashboard />} />
                      <Route path="/items/*" element={<ItemsPage />} />
                      <Route path="/customers/*" element={<CustomersPage />} />
                      <Route path="/suppliers/*" element={<SuppliersPage />} />
                      <Route path="/sales/*" element={<SalesPage />} />
                      <Route path="/purchase/*" element={<PurchasePage />} />
                      <Route path="/stock/*" element={<StockPage />} />
                      <Route path="/payments/*" element={<PaymentsPage />} />
                      <Route path="/reports/*" element={<ReportsPage />} />
                      <Route path="/pos" element={<POSPage />} />
                      <Route path="/settings/*" element={<SettingsPage />} />
                      <Route path="*" element={<Navigate to="/dashboard" />} />
                    </Routes>
                  </Content>
                </Layout>
              </Layout>
            )}
          </Router>
        </div>
      </ErrorBoundary>
    </ConfigProvider>
  );
}

export default App;