// frontend/src/services/apiClient.js
import axios from 'axios';
import { message } from 'antd';

// API Configuration
const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000/api';
const REQUEST_TIMEOUT = 10000; // 10 seconds

class ApiClient {
  constructor() {
    this.client = axios.create({
      baseURL: API_BASE_URL,
      timeout: REQUEST_TIMEOUT,
      headers: {
        'Content-Type': 'application/json',
      },
    });

    this.setupInterceptors();
  }

  setupInterceptors() {
    // Request interceptor
    this.client.interceptors.request.use(
      (config) => {
        // Add timestamp to prevent caching
        config.params = {
          ...config.params,
          _t: Date.now(),
        };

        // Log requests in development
        if (process.env.NODE_ENV === 'development') {
          console.log(`🚀 ${config.method?.toUpperCase()} ${config.url}`, {
            data: config.data,
            params: config.params,
          });
        }

        return config;
      },
      (error) => {
        console.error('Request interceptor error:', error);
        return Promise.reject(error);
      }
    );

    // Response interceptor
    this.client.interceptors.response.use(
      (response) => {
        // Log responses in development
        if (process.env.NODE_ENV === 'development') {
          console.log(`✅ ${response.config.method?.toUpperCase()} ${response.config.url}`, {
            status: response.status,
            data: response.data,
          });
        }

        return response;
      },
      (error) => {
        // Handle common errors
        this.handleError(error);
        return Promise.reject(error);
      }
    );
  }

  handleError(error) {
    const { response, message: errorMessage } = error;

    // Network errors
    if (!response) {
      message.error('Network error. Please check your connection.');
      console.error('Network error:', errorMessage);
      return;
    }

    const { status, data } = response;

    // Log errors in development
    if (process.env.NODE_ENV === 'development') {
      console.error(`❌ ${error.config?.method?.toUpperCase()} ${error.config?.url}`, {
        status,
        data,
      });
    }

    // Handle specific HTTP status codes
    switch (status) {
      case 401:
        // Unauthorized - clear token and redirect to login
        this.clearAuthToken();
        localStorage.removeItem('token');
        window.location.href = '/login';
        message.error('Session expired. Please login again.');
        break;

      case 403:
        message.error('You do not have permission to perform this action.');
        break;

      case 404:
        message.error('Resource not found.');
        break;

      case 422:
        // Validation errors
        if (data?.detail) {
          if (Array.isArray(data.detail)) {
            data.detail.forEach(err => {
              message.error(`${err.loc?.join(' ')} - ${err.msg}`);
            });
          } else {
            message.error(data.detail);
          }
        }
        break;

      case 429:
        message.error('Too many requests. Please try again later.');
        break;

      case 500:
        message.error('Server error. Please try again later.');
        break;

      default:
        const errorMsg = data?.detail || data?.message || 'An unexpected error occurred';
        message.error(errorMsg);
        break;
    }
  }

  // Set authentication token
  setAuthToken(token) {
    if (token) {
      this.client.defaults.headers.common['Authorization'] = `Bearer ${token}`;
    }
  }

  // Clear authentication token
  clearAuthToken() {
    delete this.client.defaults.headers.common['Authorization'];
  }

  // HTTP Methods
  async get(url, config = {}) {
    return this.client.get(url, config);
  }

  async post(url, data = {}, config = {}) {
    return this.client.post(url, data, config);
  }

  async put(url, data = {}, config = {}) {
    return this.client.put(url, data, config);
  }

  async patch(url, data = {}, config = {}) {
    return this.client.patch(url, data, config);
  }

  async delete(url, config = {}) {
    return this.client.delete(url, config);
  }

  // File upload
  async upload(url, formData, config = {}) {
    return this.client.post(url, formData, {
      ...config,
      headers: {
        'Content-Type': 'multipart/form-data',
        ...config.headers,
      },
    });
  }

  // File download
  async download(url, config = {}) {
    return this.client.get(url, {
      ...config,
      responseType: 'blob',
    });
  }
}

// API Endpoints organized by module
export const API_ENDPOINTS = {
  // Authentication
  AUTH: {
    LOGIN: '/auth/login',
    LOGOUT: '/auth/logout',
    ME: '/auth/me',
    CHANGE_PASSWORD: '/auth/change-password',
    USERS: '/auth/users',
    ROLES: '/auth/roles',
  },

  // Items
  ITEMS: {
    BASE: '/items',
    CATEGORIES: '/items/categories',
    BRANDS: '/items/brands',
    IMPORT: '/items/import-excel',
    EXPORT: '/items/export-excel',
    LOW_STOCK: '/items/low-stock',
    VALUATION: '/items/stock-valuation',
  },

  // Customers
  CUSTOMERS: {
    BASE: '/customers',
    GROUPS: '/customers/groups',
  },

  // Suppliers
  SUPPLIERS: {
    BASE: '/suppliers',
    GROUPS: '/suppliers/groups',
  },

  // Sales
  SALES: {
    ORDERS: '/sales/orders',
    INVOICES: '/sales/invoices',
    POS: '/sales/pos',
    ANALYTICS: '/sales/analytics',
  },

  // Purchase
  PURCHASE: {
    ORDERS: '/purchases/orders',
    INVOICES: '/purchases/invoices',
    ANALYTICS: '/purchases/analytics',
  },

  // Stock
  STOCK: {
    MOVEMENTS: '/stock/movements',
    ADJUSTMENTS: '/stock/adjustments',
    TRANSFERS: '/stock/transfers',
    LOCATIONS: '/stock/locations',
  },

  // Payments
  PAYMENTS: {
    BASE: '/payments',
    METHODS: '/payments/methods',
    ANALYTICS: '/payments/analytics',
  },

  // Reports
  REPORTS: {
    SALES: '/reports/sales',
    STOCK: '/reports/stock',
    FINANCIAL: '/reports/financial',
    DASHBOARD: '/reports/dashboard',
  },
};

// Service classes for different modules
export class AuthService {
  constructor(apiClient) {
    this.api = apiClient;
  }

  login(credentials) {
    return this.api.post(API_ENDPOINTS.AUTH.LOGIN, credentials);
  }

  logout() {
    return this.api.post(API_ENDPOINTS.AUTH.LOGOUT);
  }

  getProfile() {
    return this.api.get(API_ENDPOINTS.AUTH.ME);
  }

  changePassword(data) {
    return this.api.post(API_ENDPOINTS.AUTH.CHANGE_PASSWORD, data);
  }

  getUsers(params = {}) {
    return this.api.get(API_ENDPOINTS.AUTH.USERS, { params });
  }

  getRoles() {
    return this.api.get(API_ENDPOINTS.AUTH.ROLES);
  }
}

export class ItemService {
  constructor(apiClient) {
    this.api = apiClient;
  }

  getItems(params = {}) {
    return this.api.get(API_ENDPOINTS.ITEMS.BASE, { params });
  }

  getItem(id) {
    return this.api.get(`${API_ENDPOINTS.ITEMS.BASE}/${id}`);
  }

  createItem(data) {
    return this.api.post(API_ENDPOINTS.ITEMS.BASE, data);
  }

  updateItem(id, data) {
    return this.api.put(`${API_ENDPOINTS.ITEMS.BASE}/${id}`, data);
  }

  deleteItem(id) {
    return this.api.delete(`${API_ENDPOINTS.ITEMS.BASE}/${id}`);
  }

  getCategories() {
    return this.api.get(API_ENDPOINTS.ITEMS.CATEGORIES);
  }

  getBrands() {
    return this.api.get(API_ENDPOINTS.ITEMS.BRANDS);
  }

  importFromExcel(file) {
    const formData = new FormData();
    formData.append('file', file);
    return this.api.upload(API_ENDPOINTS.ITEMS.IMPORT, formData);
  }

  exportToExcel() {
    return this.api.download(API_ENDPOINTS.ITEMS.EXPORT);
  }

  getLowStockItems() {
    return this.api.get(API_ENDPOINTS.ITEMS.LOW_STOCK);
  }
}

export class SalesService {
  constructor(apiClient) {
    this.api = apiClient;
  }

  getOrders(params = {}) {
    return this.api.get(API_ENDPOINTS.SALES.ORDERS, { params });
  }

  createOrder(data) {
    return this.api.post(API_ENDPOINTS.SALES.ORDERS, data);
  }

  getInvoices(params = {}) {
    return this.api.get(API_ENDPOINTS.SALES.INVOICES, { params });
  }

  createInvoice(data) {
    return this.api.post(API_ENDPOINTS.SALES.INVOICES, data);
  }

  createPOSSale(data) {
    return this.api.post(`${API_ENDPOINTS.SALES.POS}/quick-sale`, data);
  }

  getDailySummary() {
    return this.api.get(`${API_ENDPOINTS.SALES.POS}/today-summary`);
  }
}

// Create singleton instance
const apiClient = new ApiClient();

// Export services
export const authService = new AuthService(apiClient);
export const itemService = new ItemService(apiClient);
export const salesService = new SalesService(apiClient);

export default apiClient;