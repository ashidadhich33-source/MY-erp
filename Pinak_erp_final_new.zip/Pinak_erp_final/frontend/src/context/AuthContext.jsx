// frontend/src/contexts/AuthContext.jsx
import React, { createContext, useContext, useState, useCallback } from 'react';
import { message } from 'antd';
import apiClient from '../services/apiClient';

const AuthContext = createContext();

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // Check if user is authenticated
  const checkAuthStatus = useCallback(async () => {
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        setLoading(false);
        return;
      }

      // Set token in API client
      apiClient.setAuthToken(token);

      // Get user profile
      const response = await apiClient.get('/auth/me');
      setUser(response.data);
    } catch (error) {
      console.error('Auth check failed:', error);
      localStorage.removeItem('token');
      apiClient.clearAuthToken();
    } finally {
      setLoading(false);
    }
  }, []);

  // Login
  const login = async (credentials) => {
    try {
      setLoading(true);
      const response = await apiClient.post('/auth/login', credentials);
      
      const { access_token, token_type } = response.data;
      
      // Store token
      localStorage.setItem('token', access_token);
      apiClient.setAuthToken(access_token);
      
      // Get user profile
      const userResponse = await apiClient.get('/auth/me');
      setUser(userResponse.data);
      
      message.success('Login successful!');
      return true;
    } catch (error) {
      const errorMessage = error.response?.data?.detail || 'Login failed';
      message.error(errorMessage);
      return false;
    } finally {
      setLoading(false);
    }
  };

  // Logout
  const logout = useCallback(async () => {
    try {
      await apiClient.post('/auth/logout');
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      localStorage.removeItem('token');
      apiClient.clearAuthToken();
      setUser(null);
      message.success('Logged out successfully');
    }
  }, []);

  // Change password
  const changePassword = async (passwordData) => {
    try {
      await apiClient.post('/auth/change-password', passwordData);
      message.success('Password changed successfully');
      return true;
    } catch (error) {
      const errorMessage = error.response?.data?.detail || 'Failed to change password';
      message.error(errorMessage);
      return false;
    }
  };

  // Check permissions
  const hasPermission = useCallback((permission) => {
    if (!user) return false;
    if (user.is_superuser) return true;
    
    // Check if user has the specific permission through roles
    return user.roles?.some(role => 
      role.permissions?.some(p => p.name === permission)
    );
  }, [user]);

  // Check roles
  const hasRole = useCallback((roleName) => {
    if (!user) return false;
    return user.roles?.some(role => role.name === roleName);
  }, [user]);

  const value = {
    user,
    loading,
    login,
    logout,
    checkAuthStatus,
    changePassword,
    hasPermission,
    hasRole,
    isAuthenticated: !!user,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthContext;