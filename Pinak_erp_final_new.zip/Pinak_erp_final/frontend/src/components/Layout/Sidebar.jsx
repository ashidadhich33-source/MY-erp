// frontend/src/components/Layout/Sidebar.jsx
import React, { useState, useEffect } from 'react';
import { Layout, Menu, Badge } from 'antd';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  DashboardOutlined,
  ShoppingCartOutlined,
  UserOutlined,
  TeamOutlined,
  InboxOutlined,
  SwapOutlined,
  CreditCardOutlined,
  BarChartOutlined,
  SettingOutlined,
  ShopOutlined,
  FileTextOutlined,
  WarningOutlined,
} from '@ant-design/icons';
import { useAuth } from '../../contexts/AuthContext';
import { itemService } from '../../services/apiClient';

const { Sider } = Layout;

const Sidebar = ({ collapsed }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const { hasPermission } = useAuth();
  const [lowStockCount, setLowStockCount] = useState(0);

  // Get current selected menu key based on path
  const getSelectedKey = () => {
    const path = location.pathname;
    if (path.startsWith('/dashboard')) return 'dashboard';
    if (path.startsWith('/items')) return 'items';
    if (path.startsWith('/customers')) return 'customers';
    if (path.startsWith('/suppliers')) return 'suppliers';
    if (path.startsWith('/sales')) return 'sales';
    if (path.startsWith('/purchase')) return 'purchase';
    if (path.startsWith('/stock')) return 'stock';
    if (path.startsWith('/payments')) return 'payments';
    if (path.startsWith('/reports')) return 'reports';
    if (path.startsWith('/pos')) return 'pos';
    if (path.startsWith('/settings')) return 'settings';
    return 'dashboard';
  };

  // Fetch low stock count
  useEffect(() => {
    if (hasPermission('items.view')) {
      itemService.getLowStockItems()
        .then(response => {
          setLowStockCount(response.data.total_count || 0);
        })
        .catch(error => {
          console.error('Failed to fetch low stock count:', error);
        });
    }
  }, [hasPermission]);

  // Menu items configuration
  const menuItems = [
    {
      key: 'dashboard',
      icon: <DashboardOutlined />,
      label: 'Dashboard',
      path: '/dashboard',
      permission: null, // Available to all authenticated users
    },
    {
      key: 'pos',
      icon: <ShopOutlined />,
      label: 'Point of Sale',
      path: '/pos',
      permission: 'sales.create',
    },
    {
      type: 'divider',
    },
    {
      key: 'items',
      icon: <InboxOutlined />,
      label: 'Items',
      path: '/items',
      permission: 'items.view',
      badge: lowStockCount > 0 ? lowStockCount : null,
    },
    {
      key: 'customers',
      icon: <UserOutlined />,
      label: 'Customers',
      path: '/customers',
      permission: 'customers.view',
    },
    {
      key: 'suppliers',
      icon: <TeamOutlined />,
      label: 'Suppliers',
      path: '/suppliers',
      permission: 'suppliers.view',
    },
    {
      type: 'divider',
    },
    {
      key: 'sales',
      icon: <ShoppingCartOutlined />,
      label: 'Sales',
      path: '/sales',
      permission: 'sales.view',
    },
    {
      key: 'purchase',
      icon: <FileTextOutlined />,
      label: 'Purchase',
      path: '/purchase',
      permission: 'purchases.view',
    },
    {
      key: 'stock',
      icon: <SwapOutlined />,
      label: 'Stock',
      path: '/stock',
      permission: 'stock.view',
    },
    {
      key: 'payments',
      icon: <CreditCardOutlined />,
      label: 'Payments',
      path: '/payments',
      permission: null, // Available to all authenticated users
    },
    {
      type: 'divider',
    },
    {
      key: 'reports',
      icon: <BarChartOutlined />,
      label: 'Reports',
      path: '/reports',
      permission: 'reports.sales', // At least one report permission
    },
    {
      key: 'settings',
      icon: <SettingOutlined />,
      label: 'Settings',
      path: '/settings',
      permission: 'settings.view',
    },
  ];

  // Filter menu items based on permissions
  const getVisibleMenuItems = () => {
    return menuItems
      .filter(item => {
        if (item.type === 'divider') return true;
        if (!item.permission) return true; // No permission required
        return hasPermission(item.permission);
      })
      .map(item => {
        if (item.type === 'divider') {
          return { type: 'divider' };
        }

        const menuItem = {
          key: item.key,
          icon: item.icon,
          label: item.label,
          onClick: () => navigate(item.path),
        };

        // Add badge for items with alerts
        if (item.badge && item.badge > 0) {
          menuItem.label = (
            <span style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              {item.label}
              <Badge 
                count={item.badge} 
                size="small" 
                style={{ backgroundColor: '#ff4d4f' }}
                title={`${item.badge} items with low stock`}
              />
            </span>
          );
        }

        return menuItem;
      });
  };

  return (
    <Sider
      collapsible
      collapsed={collapsed}
      trigger={null}
      width={260}
      theme="dark"
      style={{
        overflow: 'auto',
        height: '100vh',
        position: 'fixed',
        left: 0,
        top: 0,
        bottom: 0,
        zIndex: 100,
      }}
    >
      {/* Logo */}
      <div style={{
        height: '64px',
        padding: '16px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: collapsed ? 'center' : 'flex-start',
        borderBottom: '1px solid #303030',
        marginBottom: '8px',
      }}>
        <div style={{
          color: '#fff',
          fontSize: collapsed ? '18px' : '20px',
          fontWeight: 'bold',
          textAlign: 'center',
        }}>
          {collapsed ? 'ERP' : 'ERP System'}
        </div>
      </div>

      {/* Navigation Menu */}
      <Menu
        theme="dark"
        mode="inline"
        selectedKeys={[getSelectedKey()]}
        items={getVisibleMenuItems()}
        style={{
          borderRight: 0,
          height: 'calc(100vh - 72px)',
        }}
      />

      {/* Low Stock Alert (when collapsed) */}
      {collapsed && lowStockCount > 0 && (
        <div style={{
          position: 'absolute',
          bottom: '16px',
          left: '50%',
          transform: 'translateX(-50%)',
          cursor: 'pointer',
        }}
        onClick={() => navigate('/items?filter=low_stock')}
        >
          <Badge count={lowStockCount} size="small">
            <WarningOutlined style={{ color: '#ff4d4f', fontSize: '20px' }} />
          </Badge>
        </div>
      )}
    </Sider>
  );
};

export default Sidebar;