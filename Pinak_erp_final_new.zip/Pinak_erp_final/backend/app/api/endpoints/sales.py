# backend/app/api/endpoints/sales.py
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from sqlalchemy import or_, and_, desc
from typing import Optional, List
from pydantic import BaseModel, validator
from decimal import Decimal
from datetime import datetime, date

from ...database import get_db
from ...models.sales import SalesOrder, SalesOrderItem, SalesInvoice, SalesInvoiceItem
from ...models.customer import Customer
from ...models.item import Item
from ...models.user import User
from ...core.security import get_current_user, require_permission
from ...services.stock_service import StockService
from ...services.gst_service import GSTService

router = APIRouter()

# Pydantic schemas
class SalesOrderItemRequest(BaseModel):
    item_id: int
    quantity: Decimal
    unit_price: Decimal
    discount_percent: Decimal = 0
    remarks: Optional[str] = None

    @validator('quantity')
    def quantity_must_be_positive(cls, v):
        if v <= 0:
            raise ValueError('Quantity must be greater than zero')
        return v

    @validator('unit_price')
    def unit_price_must_be_positive(cls, v):
        if v <= 0:
            raise ValueError('Unit price must be greater than zero')
        return v

class SalesOrderRequest(BaseModel):
    customer_id: int
    delivery_date: Optional[date] = None
    items: List[SalesOrderItemRequest]
    discount_percent: Decimal = 0
    remarks: Optional[str] = None

    @validator('items')
    def items_must_not_be_empty(cls, v):
        if not v:
            raise ValueError('Order must have at least one item')
        return v

class SalesInvoiceItemRequest(BaseModel):
    item_id: int
    quantity: Decimal
    unit_price: Decimal
    discount_percent: Decimal = 0
    serial_numbers: Optional[str] = None
    batch_number: Optional[str] = None

    @validator('quantity')
    def quantity_must_be_positive(cls, v):
        if v <= 0:
            raise ValueError('Quantity must be greater than zero')
        return v

    @validator('unit_price')
    def unit_price_must_be_positive(cls, v):
        if v <= 0:
            raise ValueError('Unit price must be greater than zero')
        return v

class SalesInvoiceRequest(BaseModel):
    customer_id: int
    order_id: Optional[int] = None
    due_date: Optional[date] = None
    items: List[SalesInvoiceItemRequest]
    discount_amount: Decimal = 0
    round_off: Decimal = 0
    remarks: Optional[str] = None
    terms_conditions: Optional[str] = None
    is_pos_sale: bool = False

    @validator('items')
    def items_must_not_be_empty(cls, v):
        if not v:
            raise ValueError('Invoice must have at least one item')
        return v

class SalesOrderItemResponse(BaseModel):
    id: int
    item_id: int
    item_code: str
    item_name: str
    quantity: Decimal
    unit_price: Decimal
    discount_percent: Decimal
    discount_amount: Decimal
    line_total: Decimal
    tax_rate: Decimal
    tax_amount: Decimal
    delivered_quantity: Decimal
    pending_quantity: Decimal

    class Config:
        from_attributes = True

class SalesOrderResponse(BaseModel):
    id: int
    order_number: str
    order_date: datetime
    delivery_date: Optional[date]
    customer_id: int
    customer_name: str
    customer_mobile: Optional[str]
    status: str
    subtotal: Decimal
    discount_amount: Decimal
    discount_percent: Decimal
    tax_amount: Decimal
    total_amount: Decimal
    remarks: Optional[str]
    items: List[SalesOrderItemResponse] = []

    class Config:
        from_attributes = True

class SalesInvoiceItemResponse(BaseModel):
    id: int
    item_id: int
    item_code: str
    item_name: str
    hsn_code: Optional[str]
    quantity: Decimal
    unit_price: Decimal
    discount_percent: Decimal
    discount_amount: Decimal
    line_total: Decimal
    cgst_rate: Decimal
    sgst_rate: Decimal
    igst_rate: Decimal
    cgst_amount: Decimal
    sgst_amount: Decimal
    igst_amount: Decimal
    tax_amount: Decimal
    serial_numbers: Optional[str]
    batch_number: Optional[str]

    class Config:
        from_attributes = True

class SalesInvoiceResponse(BaseModel):
    id: int
    invoice_number: str
    invoice_date: datetime
    due_date: Optional[date]
    customer_id: int
    customer_name: str
    customer_address: Optional[str]
    customer_gst: Optional[str]
    customer_mobile: Optional[str]
    order_id: Optional[int]
    reference_number: Optional[str]
    status: str
    payment_status: str
    subtotal: Decimal
    discount_amount: Decimal
    tax_amount: Decimal
    round_off: Decimal
    total_amount: Decimal
    paid_amount: Decimal
    balance_amount: Decimal
    remarks: Optional[str]
    terms_conditions: Optional[str]
    is_pos_sale: bool
    items: List[SalesInvoiceItemResponse] = []

    class Config:
        from_attributes = True

# Helper functions
def generate_order_number(db: Session) -> str:
    """Generate unique sales order number"""
    today = datetime.now()
    prefix = f"SO{today.strftime('%Y%m%d')}"
    
    last_order = db.query(SalesOrder).filter(
        SalesOrder.order_number.like(f"{prefix}%")
    ).order_by(desc(SalesOrder.order_number)).first()
    
    if last_order:
        try:
            last_seq = int(last_order.order_number[-4:])
            next_seq = last_seq + 1
        except:
            next_seq = 1
    else:
        next_seq = 1
    
    return f"{prefix}{next_seq:04d}"

def generate_invoice_number(db: Session) -> str:
    """Generate unique sales invoice number"""
    today = datetime.now()
    prefix = f"INV{today.strftime('%Y%m%d')}"
    
    last_invoice = db.query(SalesInvoice).filter(
        SalesInvoice.invoice_number.like(f"{prefix}%")
    ).order_by(desc(SalesInvoice.invoice_number)).first()
    
    if last_invoice:
        try:
            last_seq = int(last_invoice.invoice_number[-4:])
            next_seq = last_seq + 1
        except:
            next_seq = 1
    else:
        next_seq = 1
    
    return f"{prefix}{next_seq:04d}"

# Sales Order endpoints
@router.get("/orders", response_model=List[SalesOrderResponse])
async def get_sales_orders(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    search: Optional[str] = Query(None),
    customer_id: Optional[int] = Query(None),
    status: Optional[str] = Query(None),
    date_from: Optional[date] = Query(None),
    date_to: Optional[date] = Query(None),
    current_user: User = Depends(require_permission("sales.view")),
    db: Session = Depends(get_db)
):
    """Get sales orders with filtering"""
    
    query = db.query(SalesOrder)
    
    # Apply filters
    if search:
        search_filter = or_(
            SalesOrder.order_number.ilike(f"%{search}%"),
            SalesOrder.customer_name.ilike(f"%{search}%"),
            SalesOrder.customer_mobile.ilike(f"%{search}%")
        )
        query = query.filter(search_filter)
    
    if customer_id:
        query = query.filter(SalesOrder.customer_id == customer_id)
    
    if status:
        query = query.filter(SalesOrder.status == status)
    
    if date_from:
        query = query.filter(SalesOrder.order_date >= datetime.combine(date_from, datetime.min.time()))
    
    if date_to:
        query = query.filter(SalesOrder.order_date <= datetime.combine(date_to, datetime.max.time()))
    
    orders = query.order_by(desc(SalesOrder.order_date)).offset(skip).limit(limit).all()
    
    return [SalesOrderResponse.from_orm(order) for order in orders]

@router.get("/orders/{order_id}", response_model=SalesOrderResponse)
async def get_sales_order(
    order_id: int,
    current_user: User = Depends(require_permission("sales.view")),
    db: Session = Depends(get_db)
):
    """Get sales order by ID"""
    
    order = db.query(SalesOrder).filter(SalesOrder.id == order_id).first()
    if not order:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Sales order not found"
        )
    
    return SalesOrderResponse.from_orm(order)

@router.post("/orders", response_model=SalesOrderResponse)
async def create_sales_order(
    order_data: SalesOrderRequest,
    current_user: User = Depends(require_permission("sales.create")),
    db: Session = Depends(get_db)
):
    """Create new sales order"""
    
    # Validate customer
    customer = db.query(Customer).filter(Customer.id == order_data.customer_id).first()
    if not customer:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Customer not found"
        )
    
    # Validate items and check stock availability
    stock_service = StockService()
    for item_data in order_data.items:
        item = db.query(Item).filter(Item.id == item_data.item_id).first()
        if not item:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Item with ID {item_data.item_id} not found"
            )
        
        # Check stock availability
        if item.track_inventory:
            current_stock = stock_service.get_item_stock(db, item.id)
            if current_stock < item_data.quantity and not item.allow_negative_stock:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Insufficient stock for item {item.name}. Available: {current_stock}"
                )
    
    # Generate order number
    order_number = generate_order_number(db)
    
    # Create sales order
    db_order = SalesOrder(
        order_number=order_number,
        customer_id=order_data.customer_id,
        customer_name=customer.name,
        customer_mobile=customer.mobile,
        delivery_date=order_data.delivery_date,
        discount_percent=order_data.discount_percent,
        remarks=order_data.remarks,
        created_by=current_user.id
    )
    
    db.add(db_order)
    db.flush()  # Get order ID
    
    # Create order items
    gst_service = GSTService()
    
    for item_data in order_data.items:
        item = db.query(Item).filter(Item.id == item_data.item_id).first()
        
        # Calculate line total and tax
        base_amount = item_data.quantity * item_data.unit_price
        discount_amount = base_amount * (item_data.discount_percent / 100)
        line_total = base_amount - discount_amount
        
        # Calculate tax based on item's GST rate
        tax_rate = item.gst_rate or Decimal('0')
        tax_amount = gst_service.calculate_tax(line_total, tax_rate, customer.gst_number is not None)
        
        order_item = SalesOrderItem(
            order_id=db_order.id,
            item_id=item.id,
            item_code=item.barcode,
            item_name=item.name,
            quantity=item_data.quantity,
            unit_price=item_data.unit_price,
            discount_percent=item_data.discount_percent,
            discount_amount=discount_amount,
            line_total=line_total,
            tax_rate=tax_rate,
            tax_amount=tax_amount['total_tax'],
            pending_quantity=item_data.quantity
        )
        
        db.add(order_item)
        
        # Reserve stock
        if item.track_inventory:
            stock_service.reserve_stock(db, item.id, item_data.quantity)
    
    # Calculate order totals
    db_order.calculate_totals()
    
    db.commit()
    db.refresh(db_order)
    
    return SalesOrderResponse.from_orm(db_order)

@router.put("/orders/{order_id}/status")
async def update_order_status(
    order_id: int,
    new_status: str = Query(..., regex="^(pending|confirmed|shipped|delivered|cancelled)$"),
    current_user: User = Depends(require_permission("sales.edit")),
    db: Session = Depends(get_db)
):
    """Update sales order status"""
    
    order = db.query(SalesOrder).filter(SalesOrder.id == order_id).first()
    if not order:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Sales order not found"
        )
    
    # Release reserved stock if order is cancelled
    if new_status == "cancelled" and order.status != "cancelled":
        stock_service = StockService()
        for item in order.order_items:
            if item.pending_quantity > 0:
                stock_service.release_reserved_stock(db, item.item_id, item.pending_quantity)
    
    order.status = new_status
    order.updated_by = current_user.id
    
    db.commit()
    
    return {"message": f"Order status updated to {new_status}"}

# Sales Invoice endpoints
@router.get("/invoices", response_model=List[SalesInvoiceResponse])
async def get_sales_invoices(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    search: Optional[str] = Query(None),
    customer_id: Optional[int] = Query(None),
    status: Optional[str] = Query(None),
    payment_status: Optional[str] = Query(None),
    date_from: Optional[date] = Query(None),
    date_to: Optional[date] = Query(None),
    pos_sales_only: bool = Query(False),
    current_user: User = Depends(require_permission("sales.view")),
    db: Session = Depends(get_db)
):
    """Get sales invoices with filtering"""
    
    query = db.query(SalesInvoice)
    
    # Apply filters
    if search:
        search_filter = or_(
            SalesInvoice.invoice_number.ilike(f"%{search}%"),
            SalesInvoice.customer_name.ilike(f"%{search}%"),
            SalesInvoice.customer_mobile.ilike(f"%{search}%")
        )
        query = query.filter(search_filter)
    
    if customer_id:
        query = query.filter(SalesInvoice.customer_id == customer_id)
    
    if status:
        query = query.filter(SalesInvoice.status == status)
    
    if payment_status:
        query = query.filter(SalesInvoice.payment_status == payment_status)
    
    if date_from:
        query = query.filter(SalesInvoice.invoice_date >= datetime.combine(date_from, datetime.min.time()))
    
    if date_to:
        query = query.filter(SalesInvoice.invoice_date <= datetime.combine(date_to, datetime.max.time()))
    
    if pos_sales_only:
        query = query.filter(SalesInvoice.is_pos_sale == True)
    
    invoices = query.order_by(desc(SalesInvoice.invoice_date)).offset(skip).limit(limit).all()
    
    return [SalesInvoiceResponse.from_orm(invoice) for invoice in invoices]

@router.get("/invoices/{invoice_id}", response_model=SalesInvoiceResponse)
async def get_sales_invoice(
    invoice_id: int,
    current_user: User = Depends(require_permission("sales.view")),
    db: Session = Depends(get_db)
):
    """Get sales invoice by ID"""
    
    invoice = db.query(SalesInvoice).filter(SalesInvoice.id == invoice_id).first()
    if not invoice:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Sales invoice not found"
        )
    
    return SalesInvoiceResponse.from_orm(invoice)

@router.post("/invoices", response_model=SalesInvoiceResponse)
async def create_sales_invoice(
    invoice_data: SalesInvoiceRequest,
    current_user: User = Depends(require_permission("sales.create")),
    db: Session = Depends(get_db)
):
    """Create new sales invoice"""
    
    # Validate customer
    customer = db.query(Customer).filter(Customer.id == invoice_data.customer_id).first()
    if not customer:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Customer not found"
        )
    
    # Check credit limit
    if customer.is_credit_limit_exceeded(invoice_data.discount_amount):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Customer credit limit exceeded"
        )
    
    # Validate items and check stock availability
    stock_service = StockService()
    for item_data in invoice_data.items:
        item = db.query(Item).filter(Item.id == item_data.item_id).first()
        if not item:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Item with ID {item_data.item_id} not found"
            )
        
        # Check stock availability
        if item.track_inventory:
            current_stock = stock_service.get_item_stock(db, item.id)
            if current_stock < item_data.quantity and not item.allow_negative_stock:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Insufficient stock for item {item.name}. Available: {current_stock}"
                )
    
    # Generate invoice number
    invoice_number = generate_invoice_number(db)
    
    # Prepare customer address
    customer_address = f"{customer.address_line1 or ''}\n{customer.address_line2 or ''}\n{customer.city or ''}, {customer.state or ''} {customer.postal_code or ''}".strip()
    
    # Create sales invoice
    db_invoice = SalesInvoice(
        invoice_number=invoice_number,
        customer_id=invoice_data.customer_id,
        customer_name=customer.name,
        customer_address=customer_address,
        customer_gst=customer.gst_number,
        customer_mobile=customer.mobile,
        order_id=invoice_data.order_id,
        due_date=invoice_data.due_date,
        discount_amount=invoice_data.discount_amount,
        round_off=invoice_data.round_off,
        remarks=invoice_data.remarks,
        terms_conditions=invoice_data.terms_conditions,
        is_pos_sale=invoice_data.is_pos_sale,
        cashier_id=current_user.id if invoice_data.is_pos_sale else None,
        created_by=current_user.id
    )
    
    db.add(db_invoice)
    db.flush()  # Get invoice ID
    
    # Create invoice items and update stock
    gst_service = GSTService()
    
    for item_data in invoice_data.items:
        item = db.query(Item).filter(Item.id == item_data.item_id).first()
        
        # Calculate line total
        base_amount = item_data.quantity * item_data.unit_price
        discount_amount = base_amount * (item_data.discount_percent / 100)
        line_total = base_amount - discount_amount
        
        # Calculate GST
        tax_rates = gst_service.calculate_gst_breakdown(
            line_total, 
            item.gst_rate or Decimal('0'), 
            customer.gst_number is not None
        )
        
        invoice_item = SalesInvoiceItem(
            invoice_id=db_invoice.id,
            item_id=item.id,
            item_code=item.barcode,
            item_name=item.name,
            hsn_code=item.hsn_code,
            quantity=item_data.quantity,
            unit_price=item_data.unit_price,
            discount_percent=item_data.discount_percent,
            discount_amount=discount_amount,
            line_total=line_total,
            cgst_rate=tax_rates['cgst_rate'],
            sgst_rate=tax_rates['sgst_rate'],
            igst_rate=tax_rates['igst_rate'],
            serial_numbers=item_data.serial_numbers,
            batch_number=item_data.batch_number
        )
        
        # Calculate tax amounts
        invoice_item.calculate_tax()
        db.add(invoice_item)
        
        # Update stock - reduce quantity
        if item.track_inventory:
            stock_service.add_stock_movement(
                db=db,
                item_id=item.id,
                location_id=None,  # Use main location
                movement_type="out",
                quantity=item_data.quantity,
                unit_cost=item.landed_cost or item.purchase_rate,
                reference_type="sales_invoice",
                reference_id=db_invoice.id,
                reference_number=invoice_number,
                remarks=f"Sale to {customer.name}"
            )
    
    # Calculate invoice totals
    db_invoice.calculate_totals()
    
    # Update customer statistics
    customer.total_sales_amount += db_invoice.total_amount
    customer.total_transactions += 1
    customer.last_sale_date = db_invoice.invoice_date
    
    if not customer.first_sale_date:
        customer.first_sale_date = db_invoice.invoice_date
    
    db.commit()
    db.refresh(db_invoice)
    
    return SalesInvoiceResponse.from_orm(db_invoice)

@router.put("/invoices/{invoice_id}/payment-status")
async def update_invoice_payment_status(
    invoice_id: int,
    payment_status: str = Query(..., regex="^(pending|partial|paid)$"),
    paid_amount: Optional[Decimal] = Query(None),
    current_user: User = Depends(require_permission("sales.edit")),
    db: Session = Depends(get_db)
):
    """Update invoice payment status"""
    
    invoice = db.query(SalesInvoice).filter(SalesInvoice.id == invoice_id).first()
    if not invoice:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Sales invoice not found"
        )
    
    if paid_amount is not None:
        if paid_amount < 0:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Paid amount cannot be negative"
            )
        
        if paid_amount > invoice.total_amount:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Paid amount cannot exceed total amount"
            )
        
        invoice.paid_amount = paid_amount
        invoice.balance_amount = invoice.total_amount - paid_amount
        
        # Auto-determine payment status based on amount
        if paid_amount == 0:
            payment_status = "pending"
        elif paid_amount >= invoice.total_amount:
            payment_status = "paid"
        else:
            payment_status = "partial"
    
    invoice.payment_status = payment_status
    invoice.updated_by = current_user.id
    
    db.commit()
    
    return {"message": f"Invoice payment status updated to {payment_status}"}

# POS specific endpoints
@router.post("/pos/quick-sale", response_model=SalesInvoiceResponse)
async def create_pos_quick_sale(
    customer_mobile: Optional[str] = Query(None),
    items: List[SalesInvoiceItemRequest] = [],
    payment_amount: Decimal = Query(..., gt=0),
    current_user: User = Depends(require_permission("sales.create")),
    db: Session = Depends(get_db)
):
    """Create quick POS sale with automatic customer creation if needed"""
    
    # Find or create walk-in customer
    if customer_mobile:
        customer = db.query(Customer).filter(Customer.mobile == customer_mobile).first()
        if not customer:
            # Create new customer
            from ..customers import generate_customer_code
            customer_code = generate_customer_code(db, "retail")
            customer = Customer(
                customer_code=customer_code,
                name=f"Customer {customer_mobile}",
                mobile=customer_mobile,
                customer_type="retail",
                created_by=current_user.id
            )
            db.add(customer)
            db.flush()
    else:
        # Use default walk-in customer
        customer = db.query(Customer).filter(Customer.customer_code == "WALKIN").first()
        if not customer:
            customer = Customer(
                customer_code="WALKIN",
                name="Walk-in Customer",
                customer_type="retail",
                created_by=current_user.id
            )
            db.add(customer)
            db.flush()
    
    # Create POS invoice
    invoice_request = SalesInvoiceRequest(
        customer_id=customer.id,
        items=items,
        is_pos_sale=True
    )
    
    invoice = await create_sales_invoice(invoice_request, current_user, db)
    
    # Auto-mark as paid if payment amount covers total
    if payment_amount >= invoice.total_amount:
        await update_invoice_payment_status(
            invoice.id, 
            "paid", 
            payment_amount, 
            current_user, 
            db
        )
    
    return invoice

@router.get("/pos/today-summary")
async def get_pos_today_summary(
    current_user: User = Depends(require_permission("sales.view")),
    db: Session = Depends(get_db)
):
    """Get today's POS sales summary"""
    
    today = date.today()
    start_of_day = datetime.combine(today, datetime.min.time())
    end_of_day = datetime.combine(today, datetime.max.time())
    
    # Get today's POS invoices
    pos_invoices = db.query(SalesInvoice).filter(
        and_(
            SalesInvoice.is_pos_sale == True,
            SalesInvoice.invoice_date >= start_of_day,
            SalesInvoice.invoice_date <= end_of_day,
            SalesInvoice.cashier_id == current_user.id
        )
    ).all()
    
    total_sales = sum(invoice.total_amount for invoice in pos_invoices)
    total_transactions = len(pos_invoices)
    cash_sales = sum(invoice.total_amount for invoice in pos_invoices if invoice.payment_status == "paid")
    pending_amount = sum(invoice.balance_amount for invoice in pos_invoices)
    
    return {
        "date": today,
        "cashier": current_user.full_name,
        "total_transactions": total_transactions,
        "total_sales": total_sales,
        "cash_sales": cash_sales,
        "pending_amount": pending_amount,
        "average_bill_value": total_sales / total_transactions if total_transactions > 0 else 0
    }

# Analytics endpoints
@router.get("/analytics/daily-sales")
async def get_daily_sales_analytics(
    date_from: date = Query(...),
    date_to: date = Query(...),
    current_user: User = Depends(require_permission("sales.view")),
    db: Session = Depends(get_db)
):
    """Get daily sales analytics"""
    
    from sqlalchemy import func, extract
    
    # Get daily sales data
    daily_sales = db.query(
        func.date(SalesInvoice.invoice_date).label('sale_date'),
        func.count(SalesInvoice.id).label('transaction_count'),
        func.sum(SalesInvoice.total_amount).label('total_amount'),
        func.sum(SalesInvoice.tax_amount).label('total_tax'),
        func.avg(SalesInvoice.total_amount).label('average_bill')
    ).filter(
        and_(
            SalesInvoice.invoice_date >= datetime.combine(date_from, datetime.min.time()),
            SalesInvoice.invoice_date <= datetime.combine(date_to, datetime.max.time()),
            SalesInvoice.status != 'cancelled'
        )
    ).group_by(
        func.date(SalesInvoice.invoice_date)
    ).all()
    
    return {
        "period": {"from": date_from, "to": date_to},
        "daily_data": [
            {
                "date": str(row.sale_date),
                "transactions": row.transaction_count,
                "total_amount": float(row.total_amount or 0),
                "total_tax": float(row.total_tax or 0),
                "average_bill": float(row.average_bill or 0)
            }
            for row in daily_sales
        ],
        "summary": {
            "total_days": len(daily_sales),
            "total_transactions": sum(row.transaction_count for row in daily_sales),
            "total_amount": sum(float(row.total_amount or 0) for row in daily_sales),
            "total_tax": sum(float(row.total_tax or 0) for row in daily_sales)
        }
    }

@router.get("/analytics/top-customers")
async def get_top_customers(
    limit: int = Query(10, ge=1, le=100),
    period_days: int = Query(30, ge=1),
    current_user: User = Depends(require_permission("sales.view")),
    db: Session = Depends(get_db)
):
    """Get top customers by sales amount"""
    
    from datetime import timedelta
    
    start_date = datetime.now() - timedelta(days=period_days)
    
    top_customers = db.query(
        SalesInvoice.customer_id,
        SalesInvoice.customer_name,
        func.count(SalesInvoice.id).label('transaction_count'),
        func.sum(SalesInvoice.total_amount).label('total_amount'),
        func.avg(SalesInvoice.total_amount).label('average_bill'),
        func.max(SalesInvoice.invoice_date).label('last_purchase')
    ).filter(
        and_(
            SalesInvoice.invoice_date >= start_date,
            SalesInvoice.status != 'cancelled'
        )
    ).group_by(
        SalesInvoice.customer_id,
        SalesInvoice.customer_name
    ).order_by(
        func.sum(SalesInvoice.total_amount).desc()
    ).limit(limit).all()
    
    return {
        "period_days": period_days,
        "customers": [
            {
                "customer_id": row.customer_id,
                "customer_name": row.customer_name,
                "transaction_count": row.transaction_count,
                "total_amount": float(row.total_amount),
                "average_bill": float(row.average_bill),
                "last_purchase": row.last_purchase
            }
            for row in top_customers
        ]
    }

@router.get("/analytics/top-items")
async def get_top_selling_items(
    limit: int = Query(10, ge=1, le=100),
    period_days: int = Query(30, ge=1),
    current_user: User = Depends(require_permission("sales.view")),
    db: Session = Depends(get_db)
):
    """Get top selling items by quantity"""
    
    from datetime import timedelta
    
    start_date = datetime.now() - timedelta(days=period_days)
    
    top_items = db.query(
        SalesInvoiceItem.item_id,
        SalesInvoiceItem.item_name,
        func.sum(SalesInvoiceItem.quantity).label('total_quantity'),
        func.sum(SalesInvoiceItem.line_total).label('total_amount'),
        func.count(SalesInvoiceItem.id).label('transaction_count'),
        func.avg(SalesInvoiceItem.unit_price).label('average_price')
    ).join(
        SalesInvoice, SalesInvoiceItem.invoice_id == SalesInvoice.id
    ).filter(
        and_(
            SalesInvoice.invoice_date >= start_date,
            SalesInvoice.status != 'cancelled'
        )
    ).group_by(
        SalesInvoiceItem.item_id,
        SalesInvoiceItem.item_name
    ).order_by(
        func.sum(SalesInvoiceItem.quantity).desc()
    ).limit(limit).all()
    
    return {
        "period_days": period_days,
        "items": [
            {
                "item_id": row.item_id,
                "item_name": row.item_name,
                "total_quantity": float(row.total_quantity),
                "total_amount": float(row.total_amount),
                "transaction_count": row.transaction_count,
                "average_price": float(row.average_price)
            }
            for row in top_items
        ]
    }

@router.get("/analytics/payment-status-summary")
async def get_payment_status_summary(
    current_user: User = Depends(require_permission("sales.view")),
    db: Session = Depends(get_db)
):
    """Get summary of invoices by payment status"""
    
    payment_summary = db.query(
        SalesInvoice.payment_status,
        func.count(SalesInvoice.id).label('invoice_count'),
        func.sum(SalesInvoice.total_amount).label('total_amount'),
        func.sum(SalesInvoice.balance_amount).label('total_balance')
    ).filter(
        SalesInvoice.status != 'cancelled'
    ).group_by(
        SalesInvoice.payment_status
    ).all()
    
    return {
        "summary": [
            {
                "payment_status": row.payment_status,
                "invoice_count": row.invoice_count,
                "total_amount": float(row.total_amount or 0),
                "total_balance": float(row.total_balance or 0)
            }
            for row in payment_summary
        ],
        "totals": {
            "total_invoices": sum(row.invoice_count for row in payment_summary),
            "total_amount": sum(float(row.total_amount or 0) for row in payment_summary),
            "total_outstanding": sum(float(row.total_balance or 0) for row in payment_summary)
        }
    }