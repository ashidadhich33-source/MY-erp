import sqlite3
import os

def fix_company_columns():
    # Path to your database
    db_path = './erp_system.db'
    
    if not os.path.exists(db_path):
        print(f"Database not found at {db_path}")
        return
    
    print(f"Connecting to database: {db_path}")
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # First, check what columns currently exist
    cursor.execute("PRAGMA table_info(companies)")
    existing_columns = cursor.fetchall()
    column_names = [col[1] for col in existing_columns]
    
    print("\nCurrent columns in companies table:")
    for col in existing_columns:
        print(f"  - {col[1]} ({col[2]})")
    
    # List of columns that should exist
    required_columns = {
        'display_name': 'VARCHAR(200)',
        'pan': 'VARCHAR(10)',
        'city': 'VARCHAR(100)',
        'state': 'VARCHAR(100)',
        'pincode': 'VARCHAR(6)',
        'phone': 'VARCHAR(15)',
        'email': 'VARCHAR(200)',
        'website': 'VARCHAR(200)',
        'bank_name': 'VARCHAR(200)',
        'bank_account': 'VARCHAR(50)',
        'bank_ifsc': 'VARCHAR(11)'
    }
    
    # Add missing columns
    print("\nChecking for missing columns...")
    columns_added = []
    
    for column_name, column_type in required_columns.items():
        if column_name not in column_names:
            try:
                alter_query = f"ALTER TABLE companies ADD COLUMN {column_name} {column_type}"
                cursor.execute(alter_query)
                columns_added.append(column_name)
                print(f"✓ Added column: {column_name}")
            except sqlite3.OperationalError as e:
                print(f"✗ Error adding {column_name}: {e}")
        else:
            print(f"  Column {column_name} already exists")
    
    if columns_added:
        conn.commit()
        print(f"\n✅ Successfully added {len(columns_added)} columns: {', '.join(columns_added)}")
    else:
        print("\n✅ All required columns already exist")
    
    # Verify final structure
    cursor.execute("PRAGMA table_info(companies)")
    final_columns = cursor.fetchall()
    
    print("\nFinal table structure:")
    for col in final_columns:
        print(f"  - {col[1]} ({col[2]})")
    
    conn.close()
    print("\n✅ Database fix complete!")

if __name__ == "__main__":
    fix_company_columns()