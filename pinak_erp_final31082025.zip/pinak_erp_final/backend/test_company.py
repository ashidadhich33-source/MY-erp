"""
Test the company endpoint directly
Save as: backend/test_company.py
Run: python test_company.py
"""
from app.database import SessionLocal, engine
from app.models import Company
from sqlalchemy import text, inspect

print("Testing Company Table and Model")
print("="*60)

# 1. Test raw SQL
print("1. Raw SQL Test:")
try:
    with engine.connect() as conn:
        result = conn.execute(text("SELECT * FROM companies LIMIT 1"))
        columns = result.keys()
        print(f"   Columns found: {list(columns)}")
        
        # Check for specific columns
        if 'display_name' in columns:
            print("   ✓ display_name column exists in SQL query")
        else:
            print("   ✗ display_name column NOT found in SQL query")
except Exception as e:
    print(f"   Error: {e}")

print()

# 2. Test SQLAlchemy Inspector
print("2. SQLAlchemy Inspector Test:")
try:
    inspector = inspect(engine)
    columns = inspector.get_columns('companies')
    column_names = [col['name'] for col in columns]
    print(f"   Columns detected: {len(column_names)}")
    
    required = ['display_name', 'city', 'state', 'pincode', 'pan', 'email', 'website', 'bank_name', 'bank_account', 'bank_ifsc']
    for col in required:
        if col in column_names:
            print(f"   ✓ {col}")
        else:
            print(f"   ✗ {col} MISSING")
except Exception as e:
    print(f"   Error: {e}")

print()

# 3. Test ORM Model
print("3. ORM Model Test:")
db = SessionLocal()
try:
    # Try to query using the model
    companies = db.query(Company).all()
    print(f"   ✓ Query successful! Found {len(companies)} companies")
    
    # Try to access the new fields
    if companies:
        company = companies[0]
        print(f"   Company: {company.name}")
        try:
            print(f"   Display Name: {company.display_name or 'Not set'}")
            print(f"   City: {company.city or 'Not set'}")
            print(f"   State: {company.state or 'Not set'}")
        except AttributeError as e:
            print(f"   ✗ Error accessing fields: {e}")
    
    # Try to create a test company with all fields
    print("\n4. Create Test Company:")
    test_company = Company(
        name="Test Company",
        display_name="Test Display",
        gstin="08AALFB1637R1ZW",
        pan="AALFB1637R",
        address="Test Address",
        city="Test City",
        state="Test State",
        pincode="123456",
        phone="9876543210",
        email="test@test.com",
        website="www.test.com",
        bank_name="Test Bank",
        bank_account="12345678",
        bank_ifsc="TEST0123456",
        active=True,
        created_by="test"
    )
    db.add(test_company)
    db.commit()
    print("   ✓ Test company created successfully with all fields!")
    
    # Delete the test company
    db.delete(test_company)
    db.commit()
    print("   ✓ Test company deleted")
    
except Exception as e:
    print(f"   ✗ Error: {e}")
    import traceback
    traceback.print_exc()
finally:
    db.close()

print("\n" + "="*60)
print("SUMMARY:")
print("="*60)
print("If all tests pass, the database and models are correctly configured.")
print("If there are errors, they will indicate what needs to be fixed.")