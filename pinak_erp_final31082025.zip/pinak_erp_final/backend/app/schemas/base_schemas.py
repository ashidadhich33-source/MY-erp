"""
Base Pydantic schemas for request/response validation
"""
from pydantic import BaseModel, Field, validator
from typing import Optional, List, Any
from datetime import datetime, date
from decimal import Decimal

class BaseResponse(BaseModel):
    """Base response model"""
    success: bool = True
    message: Optional[str] = None
    data: Optional[Any] = None

class PaginationParams(BaseModel):
    """Pagination parameters"""
    page: int = Field(1, ge=1)
    page_size: int = Field(50, ge=1, le=100)

class PaginatedResponse(BaseModel):
    """Paginated response"""
    items: List[Any]
    total: int
    page: int
    page_size: int
    total_pages: int

# ============== AUTH SCHEMAS ==============

class LoginRequest(BaseModel):
    username: str
    password: str

class LoginResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: dict

class ChangePasswordRequest(BaseModel):
    old_password: str
    new_password: str = Field(..., min_length=6)

# ============== USER SCHEMAS ==============

class UserCreate(BaseModel):
    username: str = Field(..., min_length=3, max_length=50)
    display_name: str = Field(..., max_length=100)
    password: str = Field(..., min_length=6)
    email: Optional[str] = None
    mobile: Optional[str] = Field(None, pattern=r'^\d{10,15}$')
    role: str = Field("operator")
    company_id: Optional[int] = None

class UserUpdate(BaseModel):
    display_name: Optional[str] = None
    email: Optional[str] = None
    mobile: Optional[str] = None
    role: Optional[str] = None
    active: Optional[bool] = None

class UserResponse(BaseModel):
    id: int
    username: str
    display_name: Optional[str]
    email: Optional[str]
    mobile: Optional[str]
    role: Optional[str]
    active: bool
    company_id: Optional[int]
    created_at: datetime
    
    class Config:
        orm_mode = True

class PermissionUpdate(BaseModel):
    menu_key: str
    can_view: bool = False
    can_create: bool = False
    can_edit: bool = False
    can_import: bool = False
    can_export: bool = False
    can_print: bool = False
    can_modify_past: bool = False
    is_admin: bool = False

# ============== COMPANY SCHEMAS ==============

class CompanyCreate(BaseModel):
    name: str = Field(..., max_length=200)
    display_name: Optional[str] = Field(None, max_length=200)
    gstin: Optional[str] = Field(None, pattern=r'^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$')
    pan: Optional[str] = Field(None, pattern=r'^[A-Z]{5}[0-9]{4}[A-Z]{1}$')
    address: Optional[str] = None
    city: Optional[str] = Field(None, max_length=100)
    state: Optional[str] = Field(None, max_length=100)
    pincode: Optional[str] = Field(None, pattern=r'^\d{6}$')
    phone: Optional[str] = Field(None, pattern=r'^\d{10,15}$')
    email: Optional[str] = None
    website: Optional[str] = None
    bank_name: Optional[str] = Field(None, max_length=200)
    bank_account: Optional[str] = Field(None, max_length=50)
    bank_ifsc: Optional[str] = Field(None, max_length=11)
    logo_base64: Optional[str] = None  # Changed from logo_path to logo_base64
    active: bool = True

class CompanyUpdate(BaseModel):
    name: Optional[str] = None
    display_name: Optional[str] = None
    gstin: Optional[str] = None
    pan: Optional[str] = None
    address: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    pincode: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    website: Optional[str] = None
    bank_name: Optional[str] = None
    bank_account: Optional[str] = None
    bank_ifsc: Optional[str] = None
    logo_base64: Optional[str] = None  # Changed from logo_path to logo_base64
    active: Optional[bool] = None

class CompanyResponse(BaseModel):
    id: int
    name: str
    display_name: Optional[str]
    gstin: Optional[str]
    pan: Optional[str]
    address: Optional[str]
    city: Optional[str]
    state: Optional[str]
    pincode: Optional[str]
    phone: Optional[str]
    email: Optional[str]
    website: Optional[str]
    bank_name: Optional[str]
    bank_account: Optional[str]
    bank_ifsc: Optional[str]
    logo_base64: Optional[str]  # Changed from logo_path to logo_base64
    active: bool
    created_at: datetime
    
    class Config:
        orm_mode = True

# ============== ITEM SCHEMAS ==============

class ItemCreate(BaseModel):
    barcode: str = Field(..., max_length=50)
    style_code: str = Field(..., max_length=100)
    color: Optional[str] = Field(None, max_length=50)
    size: Optional[str] = Field(None, max_length=20)
    hsn: Optional[str] = Field(None, max_length=20)
    mrp_incl: Decimal = Field(..., ge=0, decimal_places=2)
    purchase_rate_basic: Optional[Decimal] = Field(None, ge=0, decimal_places=2)
    brand: Optional[str] = Field(None, max_length=100)
    gender: Optional[str] = Field(None, max_length=20)
    category: Optional[str] = Field(None, max_length=100)
    sub_category: Optional[str] = Field(None, max_length=100)

class ItemUpdate(BaseModel):
    style_code: Optional[str] = None
    color: Optional[str] = None
    size: Optional[str] = None
    hsn: Optional[str] = None
    mrp_incl: Optional[Decimal] = None
    purchase_rate_basic: Optional[Decimal] = None
    brand: Optional[str] = None
    gender: Optional[str] = None
    category: Optional[str] = None
    sub_category: Optional[str] = None
    status: Optional[str] = None

class ItemResponse(BaseModel):
    barcode: str
    style_code: str
    color: Optional[str]
    size: Optional[str]
    hsn: Optional[str]
    mrp_incl: Decimal
    purchase_rate_basic: Optional[Decimal]
    brand: Optional[str]
    gender: Optional[str]
    category: Optional[str]
    sub_category: Optional[str]
    status: str
    stock_qty: Optional[Decimal] = 0
    created_at: datetime
    
    class Config:
        orm_mode = True

class ItemImportRequest(BaseModel):
    items: List[ItemCreate]

class ItemImportResponse(BaseModel):
    created: int
    updated: int
    errors: List[dict]

# ============== STOCK SCHEMAS ==============

class StockUpdate(BaseModel):
    barcode: str
    qty: Decimal = Field(..., ge=0, decimal_places=2)

class StockResponse(BaseModel):
    barcode: str
    qty_on_hand: Decimal
    item: ItemResponse
    last_sale_date: Optional[datetime]
    last_purchase_date: Optional[datetime]
    
    class Config:
        orm_mode = True

class OpeningStockRequest(BaseModel):
    stocks: List[StockUpdate]

# ============== CUSTOMER SCHEMAS ==============

class CustomerCreate(BaseModel):
    mobile: str = Field(..., pattern=r'^\d{10}$')
    name: str = Field(..., max_length=100)
    email: Optional[str] = None
    kid1_name: Optional[str] = None
    kid1_dob: Optional[date] = None
    kid2_name: Optional[str] = None
    kid2_dob: Optional[date] = None
    kid3_name: Optional[str] = None
    kid3_dob: Optional[date] = None
    address: Optional[str] = None
    city: Optional[str] = None

class CustomerUpdate(BaseModel):
    name: Optional[str] = None
    email: Optional[str] = None
    kid1_name: Optional[str] = None
    kid1_dob: Optional[date] = None
    kid2_name: Optional[str] = None
    kid2_dob: Optional[date] = None
    kid3_name: Optional[str] = None
    kid3_dob: Optional[date] = None
    address: Optional[str] = None
    city: Optional[str] = None

class CustomerResponse(BaseModel):
    mobile: str
    name: str
    email: Optional[str]
    kid1_name: Optional[str]
    kid1_dob: Optional[date]
    kid2_name: Optional[str]
    kid2_dob: Optional[date]
    kid3_name: Optional[str]
    kid3_dob: Optional[date]
    address: Optional[str]
    city: Optional[str]
    lifetime_purchase: Decimal
    points_balance: Decimal
    loyalty_grade_id: Optional[int]
    last_visit_date: Optional[datetime]
    
    class Config:
        orm_mode = True

# ============== SUPPLIER SCHEMAS ==============

class SupplierCreate(BaseModel):
    name: str = Field(..., max_length=200)
    gstin: Optional[str] = Field(None, pattern=r'^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$')
    email: Optional[str] = None
    phone: Optional[str] = Field(None, pattern=r'^\d{10,15}$')
    location_type: str = Field(..., pattern=r'^(local|inter)$')
    address: Optional[str] = None

class SupplierUpdate(BaseModel):
    name: Optional[str] = None
    gstin: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    location_type: Optional[str] = None
    address: Optional[str] = None
    active: Optional[bool] = None

class SupplierResponse(BaseModel):
    id: int
    name: str
    gstin: Optional[str]
    email: Optional[str]
    phone: Optional[str]
    location_type: str
    address: Optional[str]
    active: bool
    created_at: datetime
    
    class Config:
        orm_mode = True