"""
Pydantic schemas for sales module
"""
from pydantic import BaseModel, Field, validator
from typing import Optional, List
from datetime import datetime, date
from decimal import Decimal

class BaseResponse(BaseModel):
    success: bool = True
    message: Optional[str] = None
    data: Optional[dict] = None

# ============== SALE/POS SCHEMAS ==============

class SaleItemCreate(BaseModel):
    barcode: str = Field(..., max_length=50)
    qty: Decimal = Field(..., gt=0, decimal_places=2)
    disc_pct: Decimal = Field(0, ge=0, le=100, decimal_places=2)

class SalePaymentCreate(BaseModel):
    payment_mode_id: int
    amount: Decimal = Field(..., gt=0, decimal_places=2)
    reference_no: Optional[str] = None

class SaleCreate(BaseModel):
    series_id: int
    bill_date: Optional[datetime] = None
    customer_mobile: Optional[str] = Field(None, pattern=r'^\d{10}$')
    staff_id: Optional[int] = None
    agent_id: Optional[int] = None
    coupon_code: Optional[str] = None
    redeem_points: Decimal = Field(0, ge=0)
    redeem_value: Decimal = Field(0, ge=0)
    return_credit_id: Optional[int] = None
    return_credit_used_value: Decimal = Field(0, ge=0)
    items: List[SaleItemCreate]
    payments: List[SalePaymentCreate]
    
    @validator('items')
    def validate_items(cls, v):
        if not v:
            raise ValueError('At least one item is required')
        return v
    
    @validator('payments')
    def validate_payments(cls, v):
        if not v:
            raise ValueError('At least one payment is required')
        return v

class SaleItemResponse(BaseModel):
    id: int
    barcode: str
    style_code: str
    color: Optional[str]
    size: Optional[str]
    qty: Decimal
    mrp_incl: Decimal
    disc_pct: Decimal
    line_inclusive: Decimal
    gst_rate: Decimal
    cgst_rate: Decimal
    sgst_rate: Decimal
    igst_rate: Decimal
    hsn: Optional[str]
    base_excl: Decimal
    tax_amt_info: Decimal
    returned_qty: Decimal
    
    class Config:
        orm_mode = True

class SalePaymentResponse(BaseModel):
    id: int
    payment_mode_id: int
    amount: Decimal
    settlement_type: str
    reference_no: Optional[str]
    
    class Config:
        orm_mode = True

class SaleResponse(BaseModel):
    id: int
    series_id: int
    bill_no: str
    bill_date: datetime
    customer_mobile: Optional[str]
    staff_id: Optional[int]
    agent_id: Optional[int]
    tax_region: str
    gross_incl: Decimal
    discount_incl: Decimal
    coupon_incl: Decimal
    coupon_code: Optional[str]
    base_excl: Decimal
    tax_amt_info: Decimal
    redeem_points: Decimal
    redeem_value: Decimal
    return_credit_id: Optional[int]
    return_credit_used_value: Decimal
    earned_points: Decimal
    final_payable: Decimal
    round_off: Decimal
    is_locked: bool
    is_exported: bool
    created_at: datetime
    created_by: str
    items: List[SaleItemResponse] = []
    payments: List[SalePaymentResponse] = []
    
    class Config:
        orm_mode = True

# ============== SALE RETURN SCHEMAS ==============

class SaleReturnItemCreate(BaseModel):
    sale_item_id: int
    return_qty: Decimal = Field(..., gt=0, decimal_places=2)

class SaleReturnCreate(BaseModel):
    sr_series_id: int
    sr_date: Optional[datetime] = None
    original_sale_id: Optional[int] = None
    customer_mobile: Optional[str] = Field(None, pattern=r'^\d{10}$')
    reason: str
    items: List[SaleReturnItemCreate]
    
    @validator('items')
    def validate_items(cls, v):
        if not v:
            raise ValueError('At least one item is required')
        return v

class SaleReturnItemResponse(BaseModel):
    id: int
    sale_id: Optional[int]
    sale_item_id: Optional[int]
    barcode: str
    style_code: str
    color: Optional[str]
    size: Optional[str]
    hsn: Optional[str]
    gst_rate: Decimal
    unit_mrp_incl: Decimal
    disc_pct_at_sale: Decimal
    return_qty: Decimal
    line_inclusive: Decimal
    base_excl_info: Decimal
    tax_info: Decimal
    
    class Config:
        orm_mode = True

class SaleReturnResponse(BaseModel):
    id: int
    sr_series_id: int
    sr_no: str
    sr_date: datetime
    original_sale_id: Optional[int]
    customer_mobile: Optional[str]
    tax_region: str
    total_incl: Decimal
    reason: str
    created_at: datetime
    created_by: str
    items: List[SaleReturnItemResponse] = []
    
    class Config:
        orm_mode = True

class ReturnCreditResponse(BaseModel):
    id: int
    rc_no: str
    customer_mobile: Optional[str]
    sale_return_id: Optional[int]
    rc_amount_incl: Decimal
    used_amount: Decimal
    status: str
    created_at: datetime
    closed_at: Optional[datetime]
    
    class Config:
        orm_mode = True

# ============== POS SPECIFIC SCHEMAS ==============

class POSSearchResponse(BaseModel):
    found: bool
    item: Optional[dict] = None
    items: Optional[List[dict]] = None
    message: Optional[str] = None

class SaleLineSelectResponse(BaseModel):
    sale_id: int
    sale_item_id: int
    bill_no: str
    bill_date: datetime
    customer_mobile: Optional[str]
    customer_name: Optional[str]
    barcode: str
    style_code: str
    color: Optional[str]
    size: Optional[str]
    unit_mrp_incl: float
    disc_pct: float
    line_amount_incl: float
    gst_rate: float
    hsn: Optional[str]
    sold_qty: float
    already_returned: float
    returnable_qty: float

class PaymentDialogRequest(BaseModel):
    bill_amount: Decimal
    customer_mobile: Optional[str] = None
    coupon_code: Optional[str] = None
    redeem_points: Decimal = Field(0, ge=0)
    return_credit_id: Optional[int] = None
    payments: List[SalePaymentCreate]

class PaymentDialogResponse(BaseModel):
    gross_amount: Decimal
    discount_amount: Decimal
    coupon_discount: Decimal
    net_amount: Decimal
    redeem_value: Decimal
    return_credit_value: Decimal
    final_payable: Decimal
    round_off: Decimal
    payment_valid: bool
    message: Optional[str] = None

class ModifyBillRequest(BaseModel):
    bill_no: str
    clone_as_return: bool = False
    modifications: Optional[dict] = None