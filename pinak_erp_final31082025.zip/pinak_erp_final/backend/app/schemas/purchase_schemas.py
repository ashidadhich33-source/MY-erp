"""
Pydantic schemas for purchase module
"""
from pydantic import BaseModel, Field, validator
from typing import Optional, List
from datetime import datetime, date
from decimal import Decimal
from enum import Enum

class BaseResponse(BaseModel):
    success: bool = True
    message: Optional[str] = None
    data: Optional[dict] = None

# ============== PURCHASE BILL SCHEMAS ==============

class PurchaseBillItemCreate(BaseModel):
    barcode: str = Field(..., max_length=50)
    qty: Decimal = Field(..., gt=0, decimal_places=2)
    basic_rate: Decimal = Field(..., ge=0, decimal_places=2)

class PurchaseBillItemResponse(BaseModel):
    id: int
    barcode: str
    style_code: str
    size: Optional[str]
    hsn: Optional[str]
    qty: Decimal
    basic_rate: Decimal
    gst_rate: Decimal
    cgst_rate: Decimal
    sgst_rate: Decimal
    igst_rate: Decimal
    line_taxable: Decimal
    cgst_amount: Decimal
    sgst_amount: Decimal
    igst_amount: Decimal
    line_total: Decimal
    mrp: Optional[Decimal]
    
    class Config:
        orm_mode = True

class PurchaseBillCreate(BaseModel):
    pb_series_id: int
    pb_date: Optional[datetime] = None
    payment_mode: str = Field("cash", pattern=r'^(cash|credit)$')
    supplier_id: int
    supplier_bill_no: Optional[str] = None
    supplier_bill_date: Optional[date] = None
    reverse_charge: bool = False
    items: List[PurchaseBillItemCreate]
    
    @validator('items')
    def validate_items(cls, v):
        if not v:
            raise ValueError('At least one item is required')
        return v

class PurchaseBillResponse(BaseModel):
    id: int
    pb_series_id: int
    pb_no: str
    pb_date: datetime
    payment_mode: str
    supplier_id: int
    tax_region: str
    supplier_bill_no: Optional[str]
    supplier_bill_date: Optional[date]
    reverse_charge: bool
    total_taxable: Decimal
    total_cgst: Decimal
    total_sgst: Decimal
    total_igst: Decimal
    grand_total: Decimal
    created_at: datetime
    created_by: str
    items: List[PurchaseBillItemResponse] = []
    
    class Config:
        orm_mode = True

# ============== PURCHASE RETURN SCHEMAS ==============

class PurchaseReturnItemCreate(BaseModel):
    barcode: str = Field(..., max_length=50)
    qty: Decimal = Field(..., gt=0, decimal_places=2)
    basic_rate: Decimal = Field(..., ge=0, decimal_places=2)
    override_stock_check: bool = False

class PurchaseReturnItemResponse(BaseModel):
    id: int
    barcode: str
    style_code: str
    size: Optional[str]
    hsn: Optional[str]
    qty: Decimal
    basic_rate: Decimal
    gst_rate: Decimal
    cgst_rate: Decimal
    sgst_rate: Decimal
    igst_rate: Decimal
    line_taxable: Decimal
    cgst_amount: Decimal
    sgst_amount: Decimal
    igst_amount: Decimal
    line_total: Decimal
    mrp: Optional[Decimal]
    
    class Config:
        orm_mode = True

class PurchaseReturnCreate(BaseModel):
    pr_series_id: int
    pr_date: Optional[datetime] = None
    supplier_id: int
    supplier_bill_no: Optional[str] = None
    supplier_bill_date: Optional[date] = None
    reason: str
    items: List[PurchaseReturnItemCreate]
    
    @validator('items')
    def validate_items(cls, v):
        if not v:
            raise ValueError('At least one item is required')
        return v

class PurchaseReturnResponse(BaseModel):
    id: int
    pr_series_id: int
    pr_no: str
    pr_date: datetime
    supplier_id: int
    tax_region: str
    supplier_bill_no: Optional[str]
    supplier_bill_date: Optional[date]
    reason: str
    total_taxable: Decimal
    total_cgst: Decimal
    total_sgst: Decimal
    total_igst: Decimal
    grand_total: Decimal
    created_at: datetime
    created_by: str
    items: List[PurchaseReturnItemResponse] = []
    
    class Config:
        orm_mode = True