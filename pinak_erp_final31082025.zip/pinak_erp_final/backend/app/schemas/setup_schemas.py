"""
Pydantic schemas for setup module
"""
from pydantic import BaseModel, Field, validator
from typing import Optional, List
from datetime import datetime, date
from decimal import Decimal
from enum import Enum

class BaseResponse(BaseModel):
    success: bool = True
    message: Optional[str] = None
    data: Optional[dict] = None

# ============== LOYALTY GRADE SCHEMAS ==============

class LoyaltyGradeCreate(BaseModel):
    name: str = Field(..., max_length=50)
    amount_from: Decimal = Field(..., ge=0, decimal_places=2)
    amount_to: Decimal = Field(..., ge=0, decimal_places=2)
    earn_pct: Decimal = Field(..., ge=0, le=100, decimal_places=2)
    
    @validator('amount_to')
    def validate_amount_range(cls, v, values):
        if 'amount_from' in values and v <= values['amount_from']:
            raise ValueError('amount_to must be greater than amount_from')
        return v

class LoyaltyGradeUpdate(BaseModel):
    name: Optional[str] = None
    amount_from: Optional[Decimal] = None
    amount_to: Optional[Decimal] = None
    earn_pct: Optional[Decimal] = None
    active: Optional[bool] = None

class LoyaltyGradeResponse(BaseModel):
    id: int
    name: str
    amount_from: Decimal
    amount_to: Decimal
    earn_pct: Decimal
    active: bool
    created_at: datetime
    
    class Config:
        orm_mode = True

# ============== COUPON SCHEMAS ==============

class CouponTypeEnum(str, Enum):
    percent = "percent"
    flat = "flat"

class CouponCreate(BaseModel):
    code: Optional[str] = Field(None, max_length=50)
    type: CouponTypeEnum
    value: Decimal = Field(..., ge=0, decimal_places=2)
    max_cap: Optional[Decimal] = Field(None, ge=0, decimal_places=2)
    valid_from: datetime
    valid_to: datetime
    min_bill: Decimal = Field(0, ge=0, decimal_places=2)
    bound_mobile: Optional[str] = Field(None, pattern=r'^\d{10}$')
    sent_by_staff_id: Optional[int] = None
    
    @validator('valid_to')
    def validate_dates(cls, v, values):
        if 'valid_from' in values and v <= values['valid_from']:
            raise ValueError('valid_to must be after valid_from')
        return v
    
    @validator('max_cap')
    def validate_max_cap(cls, v, values):
        if 'type' in values and values['type'] == 'flat' and v is not None:
            raise ValueError('max_cap is only applicable for percentage coupons')
        return v

class CouponUpdate(BaseModel):
    active: Optional[bool] = None
    valid_to: Optional[datetime] = None
    min_bill: Optional[Decimal] = None

class CouponResponse(BaseModel):
    id: int
    code: str
    type: str
    value: Decimal
    max_cap: Optional[Decimal]
    valid_from: datetime
    valid_to: datetime
    min_bill: Decimal
    bound_mobile: Optional[str]
    active: bool
    sent_by_staff_id: Optional[int]
    used_count: int
    created_at: datetime
    
    class Config:
        orm_mode = True

# ============== BILL SERIES SCHEMAS ==============

class BillSeriesCreate(BaseModel):
    code: str = Field(..., max_length=20)
    description: Optional[str] = Field(None, max_length=200)
    prefix: str = Field(..., max_length=20)
    next_number: int = Field(1, ge=1)
    zero_pad_width: int = Field(6, ge=1, le=10)
    financial_year: Optional[str] = Field(None, max_length=10)
    default_tax_region: Optional[str] = Field(None, pattern=r'^(local|inter)$')
    company_id: Optional[int] = None

class BillSeriesUpdate(BaseModel):
    description: Optional[str] = None
    next_number: Optional[int] = None
    active: Optional[bool] = None

class BillSeriesResponse(BaseModel):
    id: int
    code: str
    description: Optional[str]
    prefix: str
    next_number: int
    zero_pad_width: int
    financial_year: Optional[str]
    default_tax_region: Optional[str]
    active: bool
    company_id: Optional[int]
    created_at: datetime
    
    class Config:
        orm_mode = True

# ============== STAFF SCHEMAS ==============

class StaffCreate(BaseModel):
    code: str = Field(..., max_length=50)
    name: str = Field(..., max_length=100)
    mobile: Optional[str] = Field(None, pattern=r'^\d{10,15}$')
    role: Optional[str] = Field(None, max_length=50)
    target_amount: Optional[Decimal] = Field(None, ge=0, decimal_places=2)
    incentive_pct: Optional[Decimal] = Field(None, ge=0, le=100, decimal_places=2)

class StaffUpdate(BaseModel):
    name: Optional[str] = None
    mobile: Optional[str] = None
    role: Optional[str] = None
    target_amount: Optional[Decimal] = None
    incentive_pct: Optional[Decimal] = None
    active: Optional[bool] = None

class StaffResponse(BaseModel):
    id: int
    code: str
    name: str
    mobile: Optional[str]
    role: Optional[str]
    target_amount: Optional[Decimal]
    incentive_pct: Optional[Decimal]
    active: bool
    created_at: datetime
    
    class Config:
        orm_mode = True

# ============== EXPENSE HEAD SCHEMAS ==============

class ExpenseHeadCreate(BaseModel):
    name: str = Field(..., max_length=100)
    description: Optional[str] = Field(None, max_length=200)

class ExpenseHeadResponse(BaseModel):
    id: int
    name: str
    description: Optional[str]
    active: bool
    created_at: datetime
    
    class Config:
        orm_mode = True

# ============== PAYMENT MODE SCHEMAS ==============

class SettlementTypeEnum(str, Enum):
    cash = "cash"
    bank = "bank"
    supplier = "supplier"

class PaymentModeCreate(BaseModel):
    name: str = Field(..., max_length=100)
    settlement_type: SettlementTypeEnum
    bank_account_id: Optional[int] = None
    supplier_id: Optional[int] = None
    display_order: int = Field(0, ge=0)
    
    @validator('bank_account_id')
    def validate_bank_account(cls, v, values):
        if 'settlement_type' in values and values['settlement_type'] == 'bank' and not v:
            raise ValueError('bank_account_id required for bank settlement type')
        return v
    
    @validator('supplier_id')
    def validate_supplier(cls, v, values):
        if 'settlement_type' in values and values['settlement_type'] == 'supplier' and not v:
            raise ValueError('supplier_id required for supplier settlement type')
        return v

class PaymentModeUpdate(BaseModel):
    name: Optional[str] = None
    settlement_type: Optional[SettlementTypeEnum] = None
    bank_account_id: Optional[int] = None
    supplier_id: Optional[int] = None
    display_order: Optional[int] = None
    active: Optional[bool] = None

class PaymentModeResponse(BaseModel):
    id: int
    name: str
    settlement_type: str
    bank_account_id: Optional[int]
    supplier_id: Optional[int]
    display_order: int
    active: bool
    created_at: datetime
    
    class Config:
        orm_mode = True

# ============== WHATSAPP CONFIG SCHEMAS ==============

class WhatsAppConfigCreate(BaseModel):
    access_token: str = Field(..., max_length=500)
    phone_number_id: str = Field(..., max_length=100)
    business_account_id: str = Field(..., max_length=100)
    otp_template: Optional[str] = None
    invoice_template: Optional[str] = None
    coupon_template: Optional[str] = None

class WhatsAppConfigResponse(BaseModel):
    id: int
    phone_number_id: str
    business_account_id: str
    otp_template: Optional[str]
    invoice_template: Optional[str]
    coupon_template: Optional[str]
    active: bool
    created_at: datetime
    
    class Config:
        orm_mode = True