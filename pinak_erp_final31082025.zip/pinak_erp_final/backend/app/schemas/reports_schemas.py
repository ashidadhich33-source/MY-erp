"""
Pydantic schemas for reports module
"""
from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime, date
from decimal import Decimal

class BaseReportResponse(BaseModel):
    success: bool = True
    data: List[dict]
    summary: Optional[dict] = None

# ============== SALE & RETURN REPORT SCHEMAS ==============

class SaleReturnReportRequest(BaseModel):
    from_date: Optional[date] = None
    to_date: Optional[date] = None
    item_filter: Optional[str] = None  # Style code filter
    brand_filter: Optional[str] = None
    series_filter: Optional[int] = None  # Bill series ID
    staff_filter: Optional[int] = None  # Staff ID
    export_format: Optional[str] = Field(None, pattern=r'^(json|excel)$')

class SaleReturnReportResponse(BaseReportResponse):
    pass

# ============== CUSTOMER REPORT SCHEMAS ==============

class CustomerReportRequest(BaseModel):
    from_date: Optional[date] = None
    to_date: Optional[date] = None
    loyalty_grade_id: Optional[int] = None
    min_lifetime_purchase: Optional[Decimal] = None
    has_kids: Optional[bool] = None
    inactive_months: Optional[int] = None
    export_format: Optional[str] = Field(None, pattern=r'^(json|excel)$')

class CustomerReportResponse(BaseReportResponse):
    total_customers: int
    total_lifetime_value: float

# ============== HSN REPORT SCHEMAS ==============

class HSNReportRequest(BaseModel):
    from_date: Optional[date] = None
    to_date: Optional[date] = None
    hsn_code: Optional[str] = None
    export_format: Optional[str] = Field(None, pattern=r'^(json|excel)$')

class HSNReportResponse(BaseReportResponse):
    pass

# ============== STAFF REPORT SCHEMAS ==============

class StaffReportRequest(BaseModel):
    from_date: Optional[date] = None
    to_date: Optional[date] = None
    staff_id: Optional[int] = None
    active_only: bool = True
    export_format: Optional[str] = Field(None, pattern=r'^(json|excel)$')

class StaffReportResponse(BaseReportResponse):
    pass

# ============== BILL WISE REPORT SCHEMAS ==============

class BillWiseReportRequest(BaseModel):
    from_date: Optional[date] = None
    to_date: Optional[date] = None
    min_amount: Optional[Decimal] = None
    max_amount: Optional[Decimal] = None
    customer_mobile: Optional[str] = None
    export_format: Optional[str] = Field(None, pattern=r'^(json|excel)$')

class BillWiseReportResponse(BaseReportResponse):
    total_bills: int
    total_amount: float

# ============== PAYMENT MODE REPORT SCHEMAS ==============

class PaymentModeReportRequest(BaseModel):
    from_date: Optional[date] = None
    to_date: Optional[date] = None
    payment_mode_id: Optional[int] = None
    settlement_type: Optional[str] = Field(None, pattern=r'^(cash|bank|supplier)$')
    export_format: Optional[str] = Field(None, pattern=r'^(json|excel)$')

class PaymentModeReportResponse(BaseReportResponse):
    summary: dict  # cash_in_hand, bank_collections, supplier_collections

# ============== EXPENSES REPORT SCHEMAS ==============

class ExpenseReportRequest(BaseModel):
    from_date: Optional[date] = None
    to_date: Optional[date] = None
    expense_head_id: Optional[int] = None
    payment_mode: Optional[str] = Field(None, pattern=r'^(cash|bank)$')
    export_format: Optional[str] = Field(None, pattern=r'^(json|excel)$')

class ExpenseReportResponse(BaseReportResponse):
    summary: dict  # total_expenses, cash_expenses, bank_expenses, net_cash_in_hand

# ============== PURCHASE REPORT SCHEMAS ==============

class PurchaseReportRequest(BaseModel):
    from_date: Optional[date] = None
    to_date: Optional[date] = None
    supplier_id: Optional[int] = None
    include_returns: bool = True
    export_format: Optional[str] = Field(None, pattern=r'^(json|excel)$')

class PurchaseReportResponse(BaseReportResponse):
    summary: dict  # total_purchases, total_returns, net_purchases

# ============== DASHBOARD SCHEMAS ==============

class DashboardRequest(BaseModel):
    period: str = Field("today", pattern=r'^(today|week|month|year)$')

class DashboardResponse(BaseModel):
    sales_summary: dict
    purchase_summary: dict
    stock_summary: dict
    customer_summary: dict
    cash_flow_summary: dict
    top_products: List[dict]
    top_customers: List[dict]
    recent_bills: List[dict]