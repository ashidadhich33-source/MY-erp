"""
Main FastAPI application
FIXED VERSION with proper CORS and routing
"""
from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException
import logging
from contextlib import asynccontextmanager

from app.config import settings
from app.database import init_db
from app.api.endpoints import (
    auth, setup, setup_complete, items, 
    sales_complete, sales_return, 
    purchases_complete, 
    reports_complete, reports_additional
)

# Setup logging
logging.basicConfig(
    level=logging.INFO if not settings.DEBUG else logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(settings.LOG_DIR / "app.log"),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup and shutdown events"""
    # Startup
    logger.info(f"Starting {settings.APP_NAME} v{settings.APP_VERSION}")
    
    # Initialize database
    try:
        init_db()
        logger.info("Database initialized successfully")
    except Exception as e:
        logger.error(f"Database initialization failed: {e}")
    
    # Create default admin user if not exists
    try:
        from app.services.user_service import create_default_admin
        create_default_admin()
        logger.info("Default admin check completed")
    except Exception as e:
        logger.error(f"Default admin creation failed: {e}")
    
    yield
    
    # Shutdown
    logger.info("Shutting down application")

# Create FastAPI app
app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description="Retail Apparel ERP System with POS, Inventory, Sales & Reports",
    lifespan=lifespan,
    docs_url="/docs" if settings.DEBUG else None,
    redoc_url="/redoc" if settings.DEBUG else None,
)

# CORS middleware - FIXED with proper configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "http://localhost:8000",
        "http://127.0.0.1:8000",
        "file://",  # For Electron apps
    ],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"],
    allow_headers=["*"],
    expose_headers=["*"],
)

# Global exception handlers
@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    """Handle validation errors"""
    logger.warning(f"Validation error on {request.url}: {exc.errors()}")
    return JSONResponse(
        status_code=422,
        content={
            "detail": exc.errors(),
            "message": "Validation failed"
        }
    )

@app.exception_handler(StarletteHTTPException)
async def http_exception_handler(request: Request, exc: StarletteHTTPException):
    """Handle HTTP exceptions"""
    logger.warning(f"HTTP {exc.status_code} on {request.url}: {exc.detail}")
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "detail": exc.detail,
            "status_code": exc.status_code
        }
    )

@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    """Handle general exceptions"""
    logger.error(f"Unhandled exception on {request.url}: {str(exc)}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={
            "detail": "Internal server error",
            "message": str(exc) if settings.DEBUG else "Something went wrong"
        }
    )

# Health check endpoint
@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "debug": settings.DEBUG
    }

# Root endpoint
@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "message": f"Welcome to {settings.APP_NAME}",
        "version": settings.APP_VERSION,
        "docs": "/docs" if settings.DEBUG else "disabled",
        "api": f"{settings.API_V1_STR}/"
    }

# Include routers with proper prefixes - FIXED
app.include_router(
    auth.router, 
    prefix=f"{settings.API_V1_STR}/auth", 
    tags=["Authentication"]
)

app.include_router(
    setup.router, 
    prefix=f"{settings.API_V1_STR}/setup", 
    tags=["Setup - Basic"]
)

app.include_router(
    setup_complete.router, 
    prefix=f"{settings.API_V1_STR}/setup", 
    tags=["Setup - Complete"]
)

app.include_router(
    items.router, 
    prefix=f"{settings.API_V1_STR}/items", 
    tags=["Items Management"]
)

app.include_router(
    sales_complete.router, 
    prefix=f"{settings.API_V1_STR}/sales", 
    tags=["Sales & POS"]
)

app.include_router(
    sales_return.router, 
    prefix=f"{settings.API_V1_STR}/sales", 
    tags=["Sales Returns"]
)

app.include_router(
    purchases_complete.router, 
    prefix=f"{settings.API_V1_STR}/purchases", 
    tags=["Purchases"]
)

app.include_router(
    reports_complete.router, 
    prefix=f"{settings.API_V1_STR}/reports", 
    tags=["Reports - Main"]
)

app.include_router(
    reports_additional.router, 
    prefix=f"{settings.API_V1_STR}/reports", 
    tags=["Reports - Additional"]
)

# Request logging middleware
@app.middleware("http")
async def log_requests(request: Request, call_next):
    """Log all requests"""
    start_time = time.time()
    
    # Log request
    logger.info(f"-> {request.method} {request.url.path}")
    if request.query_params:
        logger.debug(f"  Query: {dict(request.query_params)}")
    
    # Process request
    response = await call_next(request)
    
    # Log response
    process_time = time.time() - start_time
    logger.info(f"<- {response.status_code} ({process_time:.3f}s)")
    
    # Add timing header
    response.headers["X-Process-Time"] = str(process_time)
    
    return response

# Print routes on startup (debug mode only)
if settings.DEBUG:
    import time
    
    @app.on_event("startup")
    async def print_routes():
        """Print all available routes for debugging"""
        routes = []
        for route in app.routes:
            if hasattr(route, "methods") and hasattr(route, "path"):
                methods = ", ".join(sorted(route.methods))
                routes.append(f"  {methods:20} {route.path}")
        
        logger.info("Available API routes:")
        logger.info("\n" + "\n".join(sorted(routes)))
        logger.info(f"\nServer running at: http://{settings.HOST}:{settings.PORT}")
        logger.info(f"API Documentation: http://{settings.HOST}:{settings.PORT}/docs")

# Add startup message
@app.on_event("startup")
async def startup_message():
    """Print startup message"""
    logger.info("=" * 60)
    logger.info(f"🚀 {settings.APP_NAME} v{settings.APP_VERSION}")
    logger.info(f"🌐 Server: http://{settings.HOST}:{settings.PORT}")
    logger.info(f"📚 API Docs: http://{settings.HOST}:{settings.PORT}/docs")
    logger.info(f"🔧 Debug Mode: {settings.DEBUG}")
    logger.info("=" * 60)