"""
Business constants and configurations
"""
from enum import Enum

# GST Configuration
GST_SLABS = {
    "LOW": {
        "threshold": 999.99,  # MRP <= 999.99
        "rate": 5.0,
        "cgst": 2.5,
        "sgst": 2.5
    },
    "HIGH": {
        "threshold": 1000.00,  # MRP >= 1000.00
        "rate": 12.0,
        "cgst": 6.0,
        "sgst": 6.0
    }
}

# Menu Structure
MENU_STRUCTURE = {
    "setup": {
        "title": "Setup",
        "expandable": True,
        "children": {
            "item_master": {
                "title": "Item Master",
                "expandable": True,
                "children": {
                    "create_item": {"title": "Create Item Master"},
                    "inventory_mgmt": {
                        "title": "Inventory Management",
                        "expandable": True,
                        "children": {
                            "opening_stock": {"title": "Opening Stock"},
                            "stock_adjustment": {"title": "Stock Adjustment"}
                        }
                    }
                }
            },
            "suppliers": {"title": "Setup Suppliers"},
            "users": {
                "title": "Setup Users",
                "expandable": True,
                "children": {
                    "create_user": {"title": "Create User"},
                    "assign_access": {"title": "Assign Access of Menu Bar"}
                }
            },
            "company": {"title": "Setup Company"},
            "customer": {"title": "Setup Customer"},
            "loyalty_grade": {"title": "Setup Loyalty Grade"},
            "coupons": {"title": "Setup Coupons"},
            "whatsapp": {"title": "Setup WhatsApp Cloud API"},
            "bill_series": {"title": "Setup Bill Series"},
            "staff": {
                "title": "Setup Staff",
                "expandable": True,
                "children": {
                    "staff_master": {"title": "Staff"},
                    "targets": {"title": "Setup Targets & Incentives"}
                }
            },
            "expense_head": {"title": "Setup Expense Head"},
            "payment_mode": {"title": "Setup Payment Mode"}
        }
    },
    "purchases": {
        "title": "Purchases",
        "expandable": True,
        "children": {
            "purchase_bill": {"title": "Purchase Bill"},
            "purchase_return": {"title": "Purchase Return"}
        }
    },
    "sales": {
        "title": "Sales",
        "expandable": True,
        "children": {
            "sale_bill": {"title": "Sale Bill (POS)"},
            "sale_returns": {"title": "Sale Returns"}
        }
    },
    "reports": {
        "title": "Reports",
        "expandable": True,
        "children": {
            "sale_return_report": {"title": "Sale & Sale Return Report (Detailed)"},
            "pending": {
                "title": "Pending (for later)",
                "expandable": True,
                "children": {
                    "customer_report": {"title": "Customer Report"},
                    "customer_wise_sale": {"title": "Customer Wise Sale Report"},
                    "inactive_3m": {"title": "Inactive Customers >3 months"},
                    "inactive_6m": {"title": "Inactive Customers >6 months"},
                    "inactive_12m": {"title": "Inactive Customers >12 months"},
                    "kids_bday_current": {"title": "This Month Kids' Birthday"},
                    "kids_bday_next": {"title": "Upcoming Month Kids' Birthday"},
                    "purchase_return_report": {"title": "Purchase & Purchase Return Report"},
                    "hsn_wise_sale": {"title": "HSN Wise Sale Report"},
                    "staff_wise_sale": {"title": "Staff Wise Sale Report"},
                    "bill_wise_sale": {"title": "Bill Wise Sale Report"},
                    "payment_mode_sale": {"title": "Payment Mode Wise Sale Report"},
                    "expenses_report": {"title": "Expenses Report"}
                }
            }
        }
    }
}

# Permissions List
PERMISSIONS = [
    "view",
    "create",
    "edit",
    "import",
    "export",
    "print",
    "modify_past",
    "admin"
]

# Default Roles
DEFAULT_ROLES = {
    "admin": "Administrator",
    "manager": "Manager",
    "operator": "Operator",
    "viewer": "Viewer"
}

# Error Messages
ERROR_MESSAGES = {
    "BARCODE_NOT_FOUND": "Barcode not found in Item Master",
    "INSUFFICIENT_STOCK": "Only {qty} available in stock",
    "COUPON_INVALID": "Coupon is invalid or expired",
    "COUPON_MIN_BILL": "Minimum bill amount of ₹{amount} required",
    "COUPON_BOUND": "This coupon is not valid for this mobile number",
    "COUPON_EXPIRED": "Coupon has expired",
    "COUPON_ALREADY_USED": "Coupon has already been used",
    "PAYMENT_IMBALANCE": "Tender split must equal ₹{amount}",
    "BILL_LOCKED": "Bill is locked for editing",
    "OTP_REQUIRED": "Enter OTP sent to {mobile} to redeem points",
    "OTP_INVALID": "Invalid OTP",
    "MOBILE_REQUIRED": "Mobile number is required",
    "RETURN_EXCEED": "Return quantity exceeds sold quantity",
    "NO_PERMISSION": "You don't have permission for this action"
}

# Success Messages
SUCCESS_MESSAGES = {
    "SAVE": "Saved successfully",
    "UPDATE": "Updated successfully",
    "DELETE": "Deleted successfully",
    "IMPORT": "Imported {count} records successfully",
    "EXPORT": "Exported successfully",
    "PRINT": "Document sent to printer",
    "OTP_SENT": "OTP sent to {mobile}",
    "COUPON_SENT": "Coupon sent to {mobile}",
    "INVOICE_SENT": "Invoice sent via WhatsApp"
}

# File Upload Settings
ALLOWED_EXTENSIONS = {
    "excel": [".xlsx", ".xls"],
    "image": [".jpg", ".jpeg", ".png", ".gif"],
    "pdf": [".pdf"]
}

MAX_FILE_SIZE = 10 * 1024 * 1024  # 10 MB

# Pagination
DEFAULT_PAGE = 1
DEFAULT_PAGE_SIZE = 50
MAX_PAGE_SIZE = 100

# OTP Settings
OTP_LENGTH = 6
OTP_EXPIRY_MINUTES = 10

# Round Off Options
ROUND_OFF_OPTIONS = [0.01, 0.50, 1.00]

# Return Policy
RETURN_WINDOW_DAYS = 7  # Days within which returns are allowed

# Points System
POINTS_PER_RUPEE = 1  # 1 point per rupee of purchase