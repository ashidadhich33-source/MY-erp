"""
Base model class with common fields
"""
from sqlalchemy import Column, DateTime, String, Integer
from datetime import datetime
from app.database import Base

class TimestampMixin:
    """Mixin for adding timestamp fields"""
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = Column(String(100))
    updated_by = Column(String(100))