"""
All database models for ERP System
Complete implementation following the specification
"""
from sqlalchemy import (
    Column, String, Integer, Numeric, Boolean, DateTime, Date, 
    ForeignKey, Text, Enum, UniqueConstraint, Index, CheckConstraint
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from datetime import datetime
import enum
from app.database import Base
from app.models.base import TimestampMixin

# Enums
class LocationType(enum.Enum):
    LOCAL = "local"
    INTER = "inter"

class PaymentMode(enum.Enum):
    CASH = "cash"
    CREDIT = "credit"

class SettlementType(enum.Enum):
    CASH = "cash"
    BANK = "bank"
    SUPPLIER = "supplier"

class CouponType(enum.Enum):
    PERCENT = "percent"
    FLAT = "flat"

class CreditStatus(enum.Enum):
    OPEN = "open"
    CLOSED = "closed"
    PARTIAL = "partial"

# ============== COMPANY & USER MODELS ==============

class Company(Base, TimestampMixin):
    __tablename__ = "companies"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(200), nullable=False, unique=True)
    display_name = Column(String(200))
    gstin = Column(String(15))
    pan = Column(String(10))
    address = Column(Text)
    city = Column(String(100))
    state = Column(String(100))
    pincode = Column(String(6))
    phone = Column(String(15))
    email = Column(String(200))
    website = Column(String(200))
    bank_name = Column(String(200))
    bank_account = Column(String(50))
    bank_ifsc = Column(String(11))
    logo_base64 = Column(Text)  # Changed from logo_path
    active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    created_by = Column(String(100))
    updated_by = Column(String(100))
    
    # Relationships
    users = relationship("User", back_populates="company")
    bill_series = relationship("BillSeries", back_populates="company")  # ADD THIS LINE

class User(Base, TimestampMixin):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, nullable=False)
    display_name = Column(String(100))
    mobile = Column(String(15))
    email = Column(String(100))
    password_hash = Column(String(255), nullable=False)
    role = Column(String(50))
    active = Column(Boolean, default=True)
    company_id = Column(Integer, ForeignKey("companies.id"))
    
    # Relationships
    company = relationship("Company", back_populates="users")
    permissions = relationship("UserPermission", back_populates="user", cascade="all, delete-orphan")

class UserPermission(Base):
    __tablename__ = "user_permissions"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    menu_key = Column(String(100), nullable=False)
    can_view = Column(Boolean, default=False)
    can_create = Column(Boolean, default=False)
    can_edit = Column(Boolean, default=False)
    can_import = Column(Boolean, default=False)
    can_export = Column(Boolean, default=False)
    can_print = Column(Boolean, default=False)
    can_modify_past = Column(Boolean, default=False)
    is_admin = Column(Boolean, default=False)
    
    # Relationships
    user = relationship("User", back_populates="permissions")
    
    __table_args__ = (
        UniqueConstraint('user_id', 'menu_key', name='_user_menu_uc'),
    )

# ============== ITEM & STOCK MODELS ==============

class Item(Base, TimestampMixin):
    __tablename__ = "items"
    
    barcode = Column(String(50), primary_key=True)
    style_code = Column(String(100), nullable=False, index=True)
    color = Column(String(50))
    size = Column(String(20))
    hsn = Column(String(20))
    mrp_incl = Column(Numeric(10, 2), nullable=False)
    purchase_rate_basic = Column(Numeric(10, 2))
    brand = Column(String(100), index=True)
    gender = Column(String(20))
    category = Column(String(100), index=True)
    sub_category = Column(String(100))
    status = Column(String(20), default='active')
    
    # Relationships
    stock = relationship("Stock", back_populates="item", uselist=False, cascade="all, delete-orphan")
    sale_items = relationship("SaleItem", back_populates="item")
    purchase_items = relationship("PurchaseBillItem", back_populates="item")
    
    __table_args__ = (
        Index('idx_item_style_brand', 'style_code', 'brand'),
    )

class Stock(Base, TimestampMixin):
    __tablename__ = "stock"
    
    barcode = Column(String(50), ForeignKey("items.barcode"), primary_key=True)
    qty_on_hand = Column(Numeric(10, 2), default=0, nullable=False)
    last_purchase_rate = Column(Numeric(10, 2))
    last_sale_date = Column(DateTime)
    last_purchase_date = Column(DateTime)
    
    # Relationships
    item = relationship("Item", back_populates="stock")
    
    __table_args__ = (
        CheckConstraint('qty_on_hand >= 0', name='check_positive_stock'),
    )

# ============== CUSTOMER & LOYALTY MODELS ==============

class Customer(Base, TimestampMixin):
    __tablename__ = "customers"
    
    mobile = Column(String(10), primary_key=True)
    name = Column(String(100), nullable=False)
    email = Column(String(100))
    kid1_name = Column(String(100))
    kid1_dob = Column(Date)
    kid2_name = Column(String(100))
    kid2_dob = Column(Date)
    kid3_name = Column(String(100))
    kid3_dob = Column(Date)
    address = Column(Text)
    city = Column(String(100))
    lifetime_purchase = Column(Numeric(12, 2), default=0)
    points_balance = Column(Numeric(10, 2), default=0)
    loyalty_grade_id = Column(Integer, ForeignKey("loyalty_grades.id"))
    last_visit_date = Column(DateTime)
    
    # Relationships
    loyalty_grade = relationship("LoyaltyGrade")
    sales = relationship("Sale", back_populates="customer")
    return_credits = relationship("ReturnCredit", back_populates="customer")
    coupons = relationship("Coupon", back_populates="customer")

class LoyaltyGrade(Base, TimestampMixin):
    __tablename__ = "loyalty_grades"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(50), unique=True, nullable=False)
    amount_from = Column(Numeric(10, 2), nullable=False)
    amount_to = Column(Numeric(10, 2), nullable=False)
    earn_pct = Column(Numeric(5, 2), nullable=False)
    active = Column(Boolean, default=True)
    
    __table_args__ = (
        CheckConstraint('amount_to > amount_from', name='check_amount_range'),
    )

class Coupon(Base, TimestampMixin):
    __tablename__ = "coupons"
    
    id = Column(Integer, primary_key=True, index=True)
    code = Column(String(50), unique=True, nullable=False)
    type = Column(Enum(CouponType), nullable=False)
    value = Column(Numeric(10, 2), nullable=False)
    max_cap = Column(Numeric(10, 2))
    valid_from = Column(DateTime, nullable=False)
    valid_to = Column(DateTime, nullable=False)
    min_bill = Column(Numeric(10, 2), default=0)
    bound_mobile = Column(String(10), ForeignKey("customers.mobile"))
    active = Column(Boolean, default=True)
    sent_by_staff_id = Column(Integer, ForeignKey("staff.id"))
    used_count = Column(Integer, default=0)
    
    # Relationships
    customer = relationship("Customer", back_populates="coupons")
    staff = relationship("Staff")
    
    __table_args__ = (
        Index('idx_coupon_validity', 'valid_from', 'valid_to'),
    )

# ============== SUPPLIER MODEL ==============

class Supplier(Base, TimestampMixin):
    __tablename__ = "suppliers"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(200), nullable=False)
    gstin = Column(String(20))  # Made optional
    email = Column(String(100))
    phone = Column(String(15))
    location_type = Column(String(20), default="local")  # Changed from Enum to String for simplicity
    address = Column(Text)
    city = Column(String(100))  # Added
    state = Column(String(100))  # Added
    pincode = Column(String(10))  # Added
    contact_person = Column(String(100))  # Added
    active = Column(Boolean, default=True)
    
    # Relationships
    purchase_bills = relationship("PurchaseBill", back_populates="supplier")
    purchase_returns = relationship("PurchaseReturn", back_populates="supplier")

# ============== STAFF MODEL ==============

class Staff(Base, TimestampMixin):
    __tablename__ = "staff"
    
    id = Column(Integer, primary_key=True, index=True)
    code = Column(String(50), unique=True, nullable=False)
    name = Column(String(100), nullable=False)
    mobile = Column(String(15))
    role = Column(String(50))
    active = Column(Boolean, default=True)
    target_amount = Column(Numeric(10, 2))
    incentive_pct = Column(Numeric(5, 2))
    
    # Relationships
    sales = relationship("Sale", back_populates="staff")

# ============== PAYMENT MODE MODEL ==============

class PaymentModeConfig(Base, TimestampMixin):
    __tablename__ = "payment_modes"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), unique=True, nullable=False)
    settlement_type = Column(Enum(SettlementType), nullable=False)
    bank_account_id = Column(Integer)
    supplier_id = Column(Integer, ForeignKey("suppliers.id"))
    active = Column(Boolean, default=True)
    display_order = Column(Integer, default=0)

# ============== BILL SERIES MODEL ==============

class BillSeries(Base, TimestampMixin):
    __tablename__ = "bill_series"
    
    id = Column(Integer, primary_key=True, index=True)
    code = Column(String(20), unique=True, nullable=False)
    description = Column(String(200))
    prefix = Column(String(20), nullable=False)
    next_number = Column(Integer, default=1, nullable=False)
    zero_pad_width = Column(Integer, default=6)
    financial_year = Column(String(10))
    default_tax_region = Column(Enum(LocationType))
    active = Column(Boolean, default=True)
    display_order = Column(Integer, default=0)  # ADD THIS LINE
    company_id = Column(Integer, ForeignKey("companies.id"))
    
    # Relationships - Remove back_populates
    company = relationship("Company")  # Remove back_populates="bill_series"

# ============== SALES MODELS ==============

class Sale(Base, TimestampMixin):
    __tablename__ = "sales"
    
    id = Column(Integer, primary_key=True, index=True)
    series_id = Column(Integer, ForeignKey("bill_series.id"))
    bill_no = Column(String(50), unique=True, nullable=False, index=True)
    bill_date = Column(DateTime, nullable=False, index=True)
    customer_mobile = Column(String(10), ForeignKey("customers.mobile"))
    staff_id = Column(Integer, ForeignKey("staff.id"))
    agent_id = Column(Integer)
    tax_region = Column(Enum(LocationType), default=LocationType.LOCAL)
    
    # Amounts (all inclusive)
    gross_incl = Column(Numeric(12, 2), nullable=False)
    discount_incl = Column(Numeric(12, 2), default=0)
    coupon_incl = Column(Numeric(12, 2), default=0)
    coupon_code = Column(String(50))
    
    # Tax info (extracted for display)
    base_excl = Column(Numeric(12, 2))
    tax_amt_info = Column(Numeric(12, 2))
    
    # Loyalty
    redeem_points = Column(Numeric(10, 2), default=0)
    redeem_value = Column(Numeric(10, 2), default=0)
    earned_points = Column(Numeric(10, 2), default=0)
    
    # Return Credit
    return_credit_id = Column(Integer, ForeignKey("return_credits.id"))
    return_credit_used_value = Column(Numeric(10, 2), default=0)
    
    # Final
    final_payable = Column(Numeric(12, 2), nullable=False)
    round_off = Column(Numeric(5, 2), default=0)
    
    # Status
    is_locked = Column(Boolean, default=False)
    is_exported = Column(Boolean, default=False)
    
    # Relationships
    customer = relationship("Customer", back_populates="sales")
    staff = relationship("Staff", back_populates="sales")
    items = relationship("SaleItem", back_populates="sale", cascade="all, delete-orphan")
    payments = relationship("SalePayment", back_populates="sale", cascade="all, delete-orphan")
    sale_returns = relationship("SaleReturn", back_populates="original_sale")
    
    __table_args__ = (
        Index('idx_sale_date_customer', 'bill_date', 'customer_mobile'),
    )

class SaleItem(Base):
    __tablename__ = "sale_items"
    
    id = Column(Integer, primary_key=True, index=True)
    sale_id = Column(Integer, ForeignKey("sales.id"), nullable=False)
    barcode = Column(String(50), ForeignKey("items.barcode"), nullable=False)
    style_code = Column(String(100), nullable=False)
    color = Column(String(50))
    size = Column(String(20))
    qty = Column(Numeric(10, 2), nullable=False)
    mrp_incl = Column(Numeric(10, 2), nullable=False)
    disc_pct = Column(Numeric(5, 2), default=0)
    line_inclusive = Column(Numeric(12, 2), nullable=False)
    gst_rate = Column(Numeric(5, 2), nullable=False)
    cgst_rate = Column(Numeric(5, 2))
    sgst_rate = Column(Numeric(5, 2))
    igst_rate = Column(Numeric(5, 2))
    hsn = Column(String(20))
    base_excl = Column(Numeric(12, 2))
    tax_amt_info = Column(Numeric(12, 2))
    returned_qty = Column(Numeric(10, 2), default=0)
    
    # Relationships
    sale = relationship("Sale", back_populates="items")
    item = relationship("Item", back_populates="sale_items")
    return_items = relationship("SaleReturnItem", back_populates="original_sale_item")

class SalePayment(Base):
    __tablename__ = "sale_payments"
    
    id = Column(Integer, primary_key=True, index=True)
    sale_id = Column(Integer, ForeignKey("sales.id"), nullable=False)
    payment_mode_id = Column(Integer, ForeignKey("payment_modes.id"), nullable=False)
    amount = Column(Numeric(12, 2), nullable=False)
    settlement_type = Column(Enum(SettlementType))
    bank_account_id = Column(Integer)
    supplier_id = Column(Integer, ForeignKey("suppliers.id"))
    reference_no = Column(String(100))
    
    # Relationships
    sale = relationship("Sale", back_populates="payments")
    payment_mode = relationship("PaymentModeConfig")

# ============== SALES RETURN MODELS ==============

class SaleReturn(Base, TimestampMixin):
    __tablename__ = "sale_returns"
    
    id = Column(Integer, primary_key=True, index=True)
    sr_series_id = Column(Integer, ForeignKey("bill_series.id"))
    sr_no = Column(String(50), unique=True, nullable=False)
    sr_date = Column(DateTime, nullable=False, index=True)
    original_sale_id = Column(Integer, ForeignKey("sales.id"))
    customer_mobile = Column(String(10), ForeignKey("customers.mobile"))
    tax_region = Column(Enum(LocationType), default=LocationType.LOCAL)
    total_incl = Column(Numeric(12, 2), nullable=False)
    reason = Column(Text)
    
    # Relationships
    original_sale = relationship("Sale", back_populates="sale_returns")
    customer = relationship("Customer")
    items = relationship("SaleReturnItem", back_populates="sale_return", cascade="all, delete-orphan")
    return_credit = relationship("ReturnCredit", back_populates="sale_return", uselist=False)

class SaleReturnItem(Base):
    __tablename__ = "sale_return_items"
    
    id = Column(Integer, primary_key=True, index=True)
    sale_return_id = Column(Integer, ForeignKey("sale_returns.id"), nullable=False)
    sale_id = Column(Integer, ForeignKey("sales.id"))
    sale_item_id = Column(Integer, ForeignKey("sale_items.id"))
    barcode = Column(String(50), ForeignKey("items.barcode"), nullable=False)
    style_code = Column(String(100), nullable=False)
    color = Column(String(50))
    size = Column(String(20))
    hsn = Column(String(20))
    gst_rate = Column(Numeric(5, 2), nullable=False)
    unit_mrp_incl = Column(Numeric(10, 2), nullable=False)
    disc_pct_at_sale = Column(Numeric(5, 2), default=0)
    return_qty = Column(Numeric(10, 2), nullable=False)
    line_inclusive = Column(Numeric(12, 2), nullable=False)
    base_excl_info = Column(Numeric(12, 2))
    tax_info = Column(Numeric(12, 2))
    
    # Relationships
    sale_return = relationship("SaleReturn", back_populates="items")
    original_sale_item = relationship("SaleItem", back_populates="return_items")

class ReturnCredit(Base, TimestampMixin):
    __tablename__ = "return_credits"
    
    id = Column(Integer, primary_key=True, index=True)
    rc_no = Column(String(50), unique=True, nullable=False)
    customer_mobile = Column(String(10), ForeignKey("customers.mobile"))
    sale_return_id = Column(Integer, ForeignKey("sale_returns.id"), unique=True)
    rc_amount_incl = Column(Numeric(12, 2), nullable=False)
    used_amount = Column(Numeric(12, 2), default=0)
    status = Column(Enum(CreditStatus), default=CreditStatus.OPEN)
    closed_at = Column(DateTime)
    
    # Relationships
    customer = relationship("Customer", back_populates="return_credits")
    sale_return = relationship("SaleReturn", back_populates="return_credit")
    
    __table_args__ = (
        Index('idx_rc_status_customer', 'status', 'customer_mobile'),
    )

# ============== PURCHASE MODELS ==============

class PurchaseBill(Base, TimestampMixin):
    __tablename__ = "purchase_bills"
    
    id = Column(Integer, primary_key=True, index=True)
    pb_series_id = Column(Integer, ForeignKey("bill_series.id"))
    pb_no = Column(String(50), unique=True, nullable=False)
    pb_date = Column(DateTime, nullable=False, index=True)
    payment_mode = Column(Enum(PaymentMode), default=PaymentMode.CASH)
    supplier_id = Column(Integer, ForeignKey("suppliers.id"), nullable=False)
    tax_region = Column(Enum(LocationType))
    supplier_bill_no = Column(String(100))
    supplier_bill_date = Column(Date)
    reverse_charge = Column(Boolean, default=False)
    
    # Amounts (exclusive)
    total_taxable = Column(Numeric(12, 2), nullable=False)
    total_cgst = Column(Numeric(12, 2), default=0)
    total_sgst = Column(Numeric(12, 2), default=0)
    total_igst = Column(Numeric(12, 2), default=0)
    grand_total = Column(Numeric(12, 2), nullable=False)
    
    # Relationships
    supplier = relationship("Supplier", back_populates="purchase_bills")
    items = relationship("PurchaseBillItem", back_populates="purchase_bill", cascade="all, delete-orphan")

class PurchaseBillItem(Base):
    __tablename__ = "purchase_bill_items"
    
    id = Column(Integer, primary_key=True, index=True)
    purchase_bill_id = Column(Integer, ForeignKey("purchase_bills.id"), nullable=False)
    barcode = Column(String(50), ForeignKey("items.barcode"), nullable=False)
    style_code = Column(String(100), nullable=False)
    size = Column(String(20))
    hsn = Column(String(20))
    qty = Column(Numeric(10, 2), nullable=False)
    basic_rate = Column(Numeric(10, 2), nullable=False)
    gst_rate = Column(Numeric(5, 2), nullable=False)
    cgst_rate = Column(Numeric(5, 2))
    sgst_rate = Column(Numeric(5, 2))
    igst_rate = Column(Numeric(5, 2))
    line_taxable = Column(Numeric(12, 2), nullable=False)
    cgst_amount = Column(Numeric(12, 2), default=0)
    sgst_amount = Column(Numeric(12, 2), default=0)
    igst_amount = Column(Numeric(12, 2), default=0)
    line_total = Column(Numeric(12, 2), nullable=False)
    mrp = Column(Numeric(10, 2))
    
    # Relationships
    purchase_bill = relationship("PurchaseBill", back_populates="items")
    item = relationship("Item", back_populates="purchase_items")

class PurchaseReturn(Base, TimestampMixin):
    __tablename__ = "purchase_returns"
    
    id = Column(Integer, primary_key=True, index=True)
    pr_series_id = Column(Integer, ForeignKey("bill_series.id"))
    pr_no = Column(String(50), unique=True, nullable=False)
    pr_date = Column(DateTime, nullable=False)
    supplier_id = Column(Integer, ForeignKey("suppliers.id"), nullable=False)
    tax_region = Column(Enum(LocationType))
    supplier_bill_no = Column(String(100))
    supplier_bill_date = Column(Date)
    reason = Column(Text)
    
    # Amounts (exclusive)
    total_taxable = Column(Numeric(12, 2), nullable=False)
    total_cgst = Column(Numeric(12, 2), default=0)
    total_sgst = Column(Numeric(12, 2), default=0)
    total_igst = Column(Numeric(12, 2), default=0)
    grand_total = Column(Numeric(12, 2), nullable=False)
    
    # Relationships
    supplier = relationship("Supplier", back_populates="purchase_returns")
    items = relationship("PurchaseReturnItem", back_populates="purchase_return", cascade="all, delete-orphan")

class PurchaseReturnItem(Base):
    __tablename__ = "purchase_return_items"
    
    id = Column(Integer, primary_key=True, index=True)
    purchase_return_id = Column(Integer, ForeignKey("purchase_returns.id"), nullable=False)
    barcode = Column(String(50), ForeignKey("items.barcode"), nullable=False)
    style_code = Column(String(100), nullable=False)
    size = Column(String(20))
    hsn = Column(String(20))
    qty = Column(Numeric(10, 2), nullable=False)
    basic_rate = Column(Numeric(10, 2), nullable=False)
    gst_rate = Column(Numeric(5, 2), nullable=False)
    cgst_rate = Column(Numeric(5, 2))
    sgst_rate = Column(Numeric(5, 2))
    igst_rate = Column(Numeric(5, 2))
    line_taxable = Column(Numeric(12, 2), nullable=False)
    cgst_amount = Column(Numeric(12, 2), default=0)
    sgst_amount = Column(Numeric(12, 2), default=0)
    igst_amount = Column(Numeric(12, 2), default=0)
    line_total = Column(Numeric(12, 2), nullable=False)
    mrp = Column(Numeric(10, 2))
    
    # Relationships
    purchase_return = relationship("PurchaseReturn", back_populates="items")

# ============== EXPENSE MODEL ==============

class ExpenseHead(Base, TimestampMixin):
    __tablename__ = "expense_heads"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), unique=True, nullable=False)
    description = Column(String(200))
    active = Column(Boolean, default=True)

class Expense(Base, TimestampMixin):
    __tablename__ = "expenses"
    
    id = Column(Integer, primary_key=True, index=True)
    date = Column(Date, nullable=False, index=True)
    head_id = Column(Integer, ForeignKey("expense_heads.id"), nullable=False)
    amount = Column(Numeric(12, 2), nullable=False)
    mode = Column(String(20), default='cash')
    note = Column(Text)
    
    # Relationships
    head = relationship("ExpenseHead")

# ============== WHATSAPP CONFIG ==============

class WhatsAppConfig(Base, TimestampMixin):
    __tablename__ = "whatsapp_config"
    
    id = Column(Integer, primary_key=True, index=True)
    access_token = Column(String(500))
    phone_number_id = Column(String(100))
    business_account_id = Column(String(100))
    otp_template = Column(Text)
    invoice_template = Column(Text)
    coupon_template = Column(Text)
    active = Column(Boolean, default=True)
    
# Export all models for easier imports
__all__ = [
    # Enums
    'LocationType', 'PaymentMode', 'SettlementType', 'CouponType', 'CreditStatus',
    # Models
    'Company', 'User', 'UserPermission',
    'Item', 'Stock',
    'Customer', 'LoyaltyGrade', 'Coupon',
    'Supplier', 'Staff', 'PaymentModeConfig', 'BillSeries',
    'Sale', 'SaleItem', 'SalePayment',
    'SaleReturn', 'SaleReturnItem', 'ReturnCredit',
    'PurchaseBill', 'PurchaseBillItem',
    'PurchaseReturn', 'PurchaseReturnItem',
    'ExpenseHead', 'Expense',
    'WhatsAppConfig'
]