"""
Application configuration
"""
from pathlib import Path
import os
from typing import Optional
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class Settings:
    """Application settings"""
    
    # App Info
    APP_NAME: str = "PIANK ERP System"
    APP_VERSION: str = "1.0.0"
    
    # Security - FIXED FOR PYDANTIC V1
    SECRET_KEY: str = os.getenv("SECRET_KEY", "your-secret-key-change-this-in-production-minimum-32-characters")
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "10080"))  # 7 days
    
    # Server
    SERVER_HOST: str = os.getenv("SERVER_HOST", "127.0.0.1")
    SERVER_PORT: int = int(os.getenv("SERVER_PORT", "8000"))
    
    # API
    API_V1_STR: str = "/api/v1"
    
    # Database
    BASE_DIR: Path = Path(__file__).resolve().parent.parent.parent
    DATABASE_TYPE: str = os.getenv("DATABASE_TYPE", "sqlite")
    DATABASE_PATH: str = os.getenv("DATABASE_PATH", "database/erp_system.db")
    DATABASE_DIR: Path = BASE_DIR / "database"
    DATABASE_URL: Optional[str] = None
    
    # Directories
    UPLOAD_DIR: Path = BASE_DIR / "uploads"
    LOG_DIR: Path = BASE_DIR / "logs"
    BACKUP_DIR: Path = BASE_DIR / "backups"
    
    # WhatsApp Configuration
    WHATSAPP_API_URL: str = "https://graph.facebook.com/v17.0"
    WHATSAPP_ACCESS_TOKEN: str = os.getenv("WHATSAPP_ACCESS_TOKEN", "")
    WHATSAPP_PHONE_NUMBER_ID: str = os.getenv("WHATSAPP_PHONE_NUMBER_ID", "")
    WHATSAPP_BUSINESS_ACCOUNT_ID: str = os.getenv("WHATSAPP_BUSINESS_ACCOUNT_ID", "")
    
    # Development
    DEBUG: bool = os.getenv("DEBUG", "True").lower() == "true"
    
    # CORS - Fixed for security
    CORS_ORIGINS: list = ["http://localhost:3000", "http://127.0.0.1:3000"]
    if os.getenv("ADDITIONAL_CORS_ORIGINS"):
        CORS_ORIGINS.extend(os.getenv("ADDITIONAL_CORS_ORIGINS").split(","))
    
    def __init__(self):
        """Initialize settings"""
        self._setup_directories()
        self._setup_database_url()
    
    def _setup_directories(self):
        """Create necessary directories if they don't exist"""
        for directory in [self.UPLOAD_DIR, self.LOG_DIR, self.BACKUP_DIR, self.DATABASE_DIR]:
            directory.mkdir(parents=True, exist_ok=True)
    
    def _setup_database_url(self):
        """Setup database URL based on database type"""
        if not self.DATABASE_URL:
            if self.DATABASE_TYPE == "sqlite":
                db_path = self.BASE_DIR / self.DATABASE_PATH
                self.DATABASE_URL = f"sqlite:///{db_path}"
            elif self.DATABASE_TYPE == "postgresql":
                # PostgreSQL configuration
                db_user = os.getenv("DB_USER", "postgres")
                db_pass = os.getenv("DB_PASSWORD", "postgres")
                db_host = os.getenv("DB_HOST", "localhost")
                db_port = os.getenv("DB_PORT", "5432")
                db_name = os.getenv("DB_NAME", "piank_erp")
                self.DATABASE_URL = f"postgresql://{db_user}:{db_pass}@{db_host}:{db_port}/{db_name}"

# Create single instance
settings = Settings()