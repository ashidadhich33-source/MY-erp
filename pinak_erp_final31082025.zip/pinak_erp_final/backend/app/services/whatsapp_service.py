"""
WhatsApp Cloud API integration service
"""
import httpx
import random
import string
import logging
from typing import Optional, Dict, Any
from datetime import datetime, timedelta

from app.config import settings
from app.database import SessionLocal

logger = logging.getLogger(__name__)

# OTP storage (in production, use Redis or database)
otp_storage: Dict[str, Dict[str, Any]] = {}

def get_whatsapp_config():
    """Get active WhatsApp configuration from database"""
    from app.models import WhatsAppConfig
    
    db = SessionLocal()
    try:
        config = db.query(WhatsAppConfig).filter(WhatsAppConfig.active == True).first()
        return config
    finally:
        db.close()

async def send_whatsapp_message(
    mobile: str,
    template_name: str,
    template_params: list = None
) -> bool:
    """Send WhatsApp message using template"""
    config = get_whatsapp_config()
    if not config:
        logger.error("WhatsApp not configured")
        return False
    
    # Format mobile number (add country code if not present)
    if not mobile.startswith('+'):
        mobile = '+91' + mobile  # Default to India
    
    url = f"{settings.WHATSAPP_API_URL}/{config.phone_number_id}/messages"
    
    headers = {
        "Authorization": f"Bearer {config.access_token}",
        "Content-Type": "application/json"
    }
    
    payload = {
        "messaging_product": "whatsapp",
        "to": mobile,
        "type": "template",
        "template": {
            "name": template_name,
            "language": {
                "code": "en"
            }
        }
    }
    
    if template_params:
        payload["template"]["components"] = [
            {
                "type": "body",
                "parameters": [
                    {"type": "text", "text": str(param)}
                    for param in template_params
                ]
            }
        ]
    
    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(url, json=payload, headers=headers)
            
            if response.status_code == 200:
                logger.info(f"WhatsApp message sent to {mobile}")
                return True
            else:
                logger.error(f"WhatsApp API error: {response.text}")
                return False
    except Exception as e:
        logger.error(f"Error sending WhatsApp: {str(e)}")
        return False

def generate_otp(length: int = 6) -> str:
    """Generate random OTP"""
    return ''.join(random.choices(string.digits, k=length))

async def send_otp_whatsapp(mobile: str) -> str:
    """Send OTP via WhatsApp and return OTP"""
    otp = generate_otp()
    
    # Store OTP with expiry
    otp_storage[mobile] = {
        "otp": otp,
        "created_at": datetime.utcnow(),
        "attempts": 0
    }
    
    # Send via WhatsApp
    success = await send_whatsapp_message(
        mobile=mobile,
        template_name="otp_template",
        template_params=[otp]
    )
    
    if success:
        logger.info(f"OTP {otp} sent to {mobile}")
        return otp
    else:
        # Remove from storage if failed
        otp_storage.pop(mobile, None)
        return None

def verify_otp(mobile: str, otp: str) -> bool:
    """Verify OTP"""
    if mobile not in otp_storage:
        return False
    
    stored = otp_storage[mobile]
    
    # Check expiry (10 minutes)
    if datetime.utcnow() - stored["created_at"] > timedelta(minutes=10):
        otp_storage.pop(mobile, None)
        return False
    
    # Check attempts (max 3)
    if stored["attempts"] >= 3:
        otp_storage.pop(mobile, None)
        return False
    
    stored["attempts"] += 1
    
    # Verify OTP
    if stored["otp"] == otp:
        otp_storage.pop(mobile, None)
        return True
    
    return False

async def send_invoice_whatsapp(
    mobile: str,
    bill_no: str,
    amount: float,
    pdf_url: Optional[str] = None,
    points_earned: float = 0,
    points_redeemed: float = 0,
    points_balance: float = 0
) -> bool:
    """Send invoice via WhatsApp"""
    params = [
        bill_no,
        f"₹{amount:,.2f}",
        f"{points_earned:.0f}",
        f"{points_redeemed:.0f}",
        f"{points_balance:.0f}"
    ]
    
    success = await send_whatsapp_message(
        mobile=mobile,
        template_name="invoice_template",
        template_params=params
    )
    
    return success

async def send_coupon_whatsapp(
    mobile: str,
    coupon_code: str,
    discount_value: str,
    valid_till: str
) -> bool:
    """Send coupon via WhatsApp"""
    params = [
        coupon_code,
        discount_value,
        valid_till
    ]
    
    success = await send_whatsapp_message(
        mobile=mobile,
        template_name="coupon_template",
        template_params=params
    )
    
    return success

async def send_test_message(mobile: str) -> bool:
    """Send test WhatsApp message"""
    return await send_whatsapp_message(
        mobile=mobile,
        template_name="test_template",
        template_params=["ERP System", datetime.now().strftime("%d-%m-%Y %H:%M")]
    )