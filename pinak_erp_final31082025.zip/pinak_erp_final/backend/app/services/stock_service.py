"""
Stock management service
"""
from sqlalchemy.orm import Session
from decimal import Decimal
from typing import Optional, List, Dict
from datetime import datetime

from app.models import Stock, Item
import logging

logger = logging.getLogger(__name__)

class StockService:
    """Service for stock management operations"""
    
    @staticmethod
    def get_stock(db: Session, barcode: str) -> Optional[Stock]:
        """Get stock for a barcode"""
        return db.query(Stock).filter(Stock.barcode == barcode).first()
    
    @staticmethod
    def update_stock(
        db: Session,
        barcode: str,
        qty_change: Decimal,
        operation: str = "add",
        update_date: bool = True,
        last_rate: Optional[Decimal] = None
    ) -> Stock:
        """
        Update stock quantity
        operation: 'add', 'subtract', 'set'
        """
        stock = StockService.get_stock(db, barcode)
        
        if not stock:
            # Create new stock entry
            stock = Stock(barcode=barcode, qty_on_hand=Decimal("0"))
            db.add(stock)
        
        if operation == "add":
            stock.qty_on_hand += qty_change
            if update_date:
                stock.last_purchase_date = datetime.now()
            if last_rate:
                stock.last_purchase_rate = last_rate
        elif operation == "subtract":
            stock.qty_on_hand -= qty_change
            if update_date:
                stock.last_sale_date = datetime.now()
        elif operation == "set":
            stock.qty_on_hand = qty_change
        
        # Ensure stock doesn't go negative
        if stock.qty_on_hand < 0:
            stock.qty_on_hand = Decimal("0")
        
        db.flush()
        return stock
    
    @staticmethod
    def check_stock_availability(
        db: Session,
        barcode: str,
        required_qty: Decimal
    ) -> tuple[bool, Decimal]:
        """
        Check if required quantity is available
        Returns: (is_available, current_qty)
        """
        stock = StockService.get_stock(db, barcode)
        current_qty = stock.qty_on_hand if stock else Decimal("0")
        is_available = current_qty >= required_qty
        return is_available, current_qty
    
    @staticmethod
    def bulk_update_stock(
        db: Session,
        updates: List[Dict[str, any]]
    ) -> List[Dict[str, any]]:
        """
        Bulk update stock for multiple items
        updates: List of dicts with keys: barcode, qty, operation
        """
        results = []
        
        for update in updates:
            try:
                stock = StockService.update_stock(
                    db=db,
                    barcode=update["barcode"],
                    qty_change=update["qty"],
                    operation=update.get("operation", "set")
                )
                results.append({
                    "barcode": update["barcode"],
                    "success": True,
                    "new_qty": stock.qty_on_hand
                })
            except Exception as e:
                results.append({
                    "barcode": update["barcode"],
                    "success": False,
                    "error": str(e)
                })
        
        return results
    
    @staticmethod
    def get_low_stock_items(
        db: Session,
        threshold: Decimal = Decimal("10")
    ) -> List[Stock]:
        """Get items with stock below threshold"""
        return db.query(Stock).filter(Stock.qty_on_hand < threshold).all()
    
    @staticmethod
    def get_stock_value_report(db: Session) -> Dict[str, Decimal]:
        """Calculate total stock value"""
        stocks = db.query(Stock).join(Item).all()
        
        total_qty = Decimal("0")
        total_value_at_cost = Decimal("0")
        total_value_at_mrp = Decimal("0")
        
        for stock in stocks:
            if stock.qty_on_hand > 0:
                total_qty += stock.qty_on_hand
                if stock.item:
                    if stock.last_purchase_rate:
                        total_value_at_cost += stock.qty_on_hand * stock.last_purchase_rate
                    if stock.item.mrp_incl:
                        total_value_at_mrp += stock.qty_on_hand * stock.item.mrp_incl
        
        return {
            "total_items": len(stocks),
            "total_qty": total_qty,
            "total_value_at_cost": total_value_at_cost,
            "total_value_at_mrp": total_value_at_mrp,
            "expected_profit": total_value_at_mrp - total_value_at_cost
        }
    
    @staticmethod
    def adjust_stock_for_sale(
        db: Session,
        items: List[Dict[str, any]]
    ) -> List[Dict[str, any]]:
        """
        Adjust stock for sale items
        items: List of dicts with barcode and qty
        """
        results = []
        
        for item in items:
            is_available, current_qty = StockService.check_stock_availability(
                db, item["barcode"], item["qty"]
            )
            
            if not is_available:
                results.append({
                    "barcode": item["barcode"],
                    "success": False,
                    "error": f"Insufficient stock. Available: {current_qty}"
                })
            else:
                stock = StockService.update_stock(
                    db=db,
                    barcode=item["barcode"],
                    qty_change=item["qty"],
                    operation="subtract"
                )
                results.append({
                    "barcode": item["barcode"],
                    "success": True,
                    "new_qty": stock.qty_on_hand
                })
        
        return results
    
    @staticmethod
    def restore_stock_for_return(
        db: Session,
        items: List[Dict[str, any]]
    ) -> List[Dict[str, any]]:
        """
        Restore stock for returned items
        items: List of dicts with barcode and qty
        """
        results = []
        
        for item in items:
            stock = StockService.update_stock(
                db=db,
                barcode=item["barcode"],
                qty_change=item["qty"],
                operation="add",
                update_date=False  # Don't update purchase date for returns
            )
            results.append({
                "barcode": item["barcode"],
                "success": True,
                "new_qty": stock.qty_on_hand
            })
        
        return results