"""
Excel processing service for import/export operations
"""
import pandas as pd
import io
from typing import List, Dict, Any
from decimal import Decimal

def parse_excel_items(content: bytes) -> List[Dict[str, Any]]:
    """Parse Excel file content and return items data"""
    df = pd.read_excel(io.BytesIO(content))
    
    # Required columns
    required_cols = ['barcode', 'style_code', 'mrp_incl']
    
    # Normalize column names (lowercase, strip spaces)
    df.columns = df.columns.str.lower().str.strip()
    
    # Check required columns
    missing_cols = [col for col in required_cols if col not in df.columns]
    if missing_cols:
        raise ValueError(f"Missing required columns: {missing_cols}")
    
    # Process data
    items = []
    for _, row in df.iterrows():
        item = {
            'barcode': str(row['barcode']).strip(),
            'style_code': str(row['style_code']).strip(),
            'mrp_incl': Decimal(str(row['mrp_incl']))
        }
        
        # Optional fields
        optional_fields = [
            'color', 'size', 'hsn', 'purchase_rate_basic',
            'brand', 'gender', 'category', 'sub_category'
        ]
        
        for field in optional_fields:
            if field in df.columns and pd.notna(row[field]):
                if field == 'purchase_rate_basic':
                    item[field] = Decimal(str(row[field]))
                else:
                    item[field] = str(row[field]).strip()
        
        items.append(item)
    
    return items

def export_items_to_excel(items: List[Dict[str, Any]]) -> bytes:
    """Export items data to Excel format"""
    df = pd.DataFrame(items)
    
    # Create Excel file in memory
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
        df.to_excel(writer, sheet_name='Items', index=False)
        
        # Format columns
        workbook = writer.book
        worksheet = writer.sheets['Items']
        
        # Set column widths
        for i, col in enumerate(df.columns):
            column_width = max(df[col].astype(str).map(len).max(), len(col)) + 2
            worksheet.set_column(i, i, min(column_width, 50))
    
    output.seek(0)
    return output.read()

def parse_excel_stock(content: bytes) -> List[Dict[str, Any]]:
    """Parse Excel file for stock updates (BARCODE, QTY)"""
    df = pd.read_excel(io.BytesIO(content))
    
    # Check required columns
    if 'BARCODE' not in df.columns or 'QTY' not in df.columns:
        raise ValueError("Excel must have BARCODE and QTY columns")
    
    stocks = []
    for _, row in df.iterrows():
        stocks.append({
            'barcode': str(row['BARCODE']).strip(),
            'qty': Decimal(str(row['QTY']))
        })
    
    return stocks