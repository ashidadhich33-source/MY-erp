"""
GST calculation service for sales and purchases
"""
from decimal import Decimal, ROUND_HALF_UP
from typing import Dict, Tuple, Optional
from enum import Enum

from app.core.constants import GST_SLABS
from app.config import settings

class TaxRegion(Enum):
    LOCAL = "local"
    INTER = "inter"

class GSTCalculator:
    """GST calculation utilities"""
    
    @staticmethod
    def get_gst_rate_by_price(price: Decimal, is_inclusive: bool = True) -> Decimal:
        """
        Get GST rate based on price threshold
        For sales (inclusive): MRP <= 999 → 5%, MRP >= 1000 → 12%
        For purchases (exclusive): Basic <= 999.99 → 5%, Basic >= 1000 → 12%
        """
        threshold = Decimal(str(GST_SLABS["LOW"]["threshold"]))
        
        if price <= threshold:
            return Decimal(str(GST_SLABS["LOW"]["rate"]))
        else:
            return Decimal(str(GST_SLABS["HIGH"]["rate"]))
    
    @staticmethod
    def split_gst_rate(gst_rate: Decimal, region: TaxRegion) -> Dict[str, Decimal]:
        """Split GST rate into CGST/SGST or IGST based on region"""
        if region == TaxRegion.LOCAL:
            half_rate = gst_rate / 2
            return {
                "cgst_rate": half_rate,
                "sgst_rate": half_rate,
                "igst_rate": Decimal("0")
            }
        else:
            return {
                "cgst_rate": Decimal("0"),
                "sgst_rate": Decimal("0"),
                "igst_rate": gst_rate
            }
    
    @staticmethod
    def calculate_exclusive_tax(
        taxable_amount: Decimal,
        gst_rate: Decimal,
        region: TaxRegion = TaxRegion.LOCAL
    ) -> Dict[str, Decimal]:
        """
        Calculate tax on exclusive amount (for purchases)
        Returns: taxable_amount, cgst, sgst, igst, total_tax, total_amount
        """
        tax_amount = (taxable_amount * gst_rate / 100).quantize(
            Decimal("0.01"), rounding=ROUND_HALF_UP
        )
        
        rates = GSTCalculator.split_gst_rate(gst_rate, region)
        
        if region == TaxRegion.LOCAL:
            cgst = (taxable_amount * rates["cgst_rate"] / 100).quantize(
                Decimal("0.01"), rounding=ROUND_HALF_UP
            )
            sgst = (taxable_amount * rates["sgst_rate"] / 100).quantize(
                Decimal("0.01"), rounding=ROUND_HALF_UP
            )
            igst = Decimal("0")
        else:
            cgst = Decimal("0")
            sgst = Decimal("0")
            igst = tax_amount
        
        return {
            "taxable_amount": taxable_amount,
            "cgst_amount": cgst,
            "sgst_amount": sgst,
            "igst_amount": igst,
            "total_tax": tax_amount,
            "total_amount": taxable_amount + tax_amount,
            "cgst_rate": rates["cgst_rate"],
            "sgst_rate": rates["sgst_rate"],
            "igst_rate": rates["igst_rate"]
        }
    
    @staticmethod
    def calculate_inclusive_tax(
        inclusive_amount: Decimal,
        gst_rate: Decimal,
        region: TaxRegion = TaxRegion.LOCAL
    ) -> Dict[str, Decimal]:
        """
        Calculate tax from inclusive amount (for sales)
        Returns: base_amount, cgst, sgst, igst, total_tax, inclusive_amount
        """
        # Extract base amount from inclusive
        base_amount = (inclusive_amount * 100 / (100 + gst_rate)).quantize(
            Decimal("0.01"), rounding=ROUND_HALF_UP
        )
        
        total_tax = inclusive_amount - base_amount
        
        rates = GSTCalculator.split_gst_rate(gst_rate, region)
        
        if region == TaxRegion.LOCAL:
            cgst = (total_tax / 2).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
            sgst = total_tax - cgst  # Ensure total matches
            igst = Decimal("0")
        else:
            cgst = Decimal("0")
            sgst = Decimal("0")
            igst = total_tax
        
        return {
            "base_amount": base_amount,
            "cgst_amount": cgst,
            "sgst_amount": sgst,
            "igst_amount": igst,
            "total_tax": total_tax,
            "inclusive_amount": inclusive_amount,
            "cgst_rate": rates["cgst_rate"],
            "sgst_rate": rates["sgst_rate"],
            "igst_rate": rates["igst_rate"]
        }
    
    @staticmethod
    def calculate_line_total_exclusive(
        qty: Decimal,
        basic_rate: Decimal,
        gst_rate: Optional[Decimal] = None,
        region: TaxRegion = TaxRegion.LOCAL
    ) -> Dict[str, Decimal]:
        """Calculate line total for purchases (exclusive)"""
        # Auto-determine GST rate if not provided
        if gst_rate is None:
            gst_rate = GSTCalculator.get_gst_rate_by_price(basic_rate, is_inclusive=False)
        
        taxable = qty * basic_rate
        tax_calc = GSTCalculator.calculate_exclusive_tax(taxable, gst_rate, region)
        
        return {
            "qty": qty,
            "basic_rate": basic_rate,
            "gst_rate": gst_rate,
            "line_taxable": tax_calc["taxable_amount"],
            "cgst_amount": tax_calc["cgst_amount"],
            "sgst_amount": tax_calc["sgst_amount"],
            "igst_amount": tax_calc["igst_amount"],
            "line_total": tax_calc["total_amount"],
            "cgst_rate": tax_calc["cgst_rate"],
            "sgst_rate": tax_calc["sgst_rate"],
            "igst_rate": tax_calc["igst_rate"]
        }
    
    @staticmethod
    def calculate_line_total_inclusive(
        qty: Decimal,
        mrp: Decimal,
        discount_pct: Decimal = Decimal("0"),
        gst_rate: Optional[Decimal] = None,
        region: TaxRegion = TaxRegion.LOCAL
    ) -> Dict[str, Decimal]:
        """Calculate line total for sales (inclusive)"""
        # Auto-determine GST rate if not provided
        if gst_rate is None:
            gst_rate = GSTCalculator.get_gst_rate_by_price(mrp, is_inclusive=True)
        
        # Apply discount
        discounted_mrp = mrp * (1 - discount_pct / 100)
        line_inclusive = qty * discounted_mrp
        
        tax_calc = GSTCalculator.calculate_inclusive_tax(line_inclusive, gst_rate, region)
        
        return {
            "qty": qty,
            "mrp": mrp,
            "discount_pct": discount_pct,
            "gst_rate": gst_rate,
            "line_inclusive": tax_calc["inclusive_amount"],
            "base_amount": tax_calc["base_amount"],
            "cgst_amount": tax_calc["cgst_amount"],
            "sgst_amount": tax_calc["sgst_amount"],
            "igst_amount": tax_calc["igst_amount"],
            "total_tax": tax_calc["total_tax"],
            "cgst_rate": tax_calc["cgst_rate"],
            "sgst_rate": tax_calc["sgst_rate"],
            "igst_rate": tax_calc["igst_rate"]
        }
    
    @staticmethod
    def recalculate_after_bill_discount(
        original_inclusive: Decimal,
        bill_discount: Decimal,
        gst_rate: Decimal,
        region: TaxRegion = TaxRegion.LOCAL
    ) -> Dict[str, Decimal]:
        """Recalculate tax after applying bill-level discount/coupon"""
        new_inclusive = original_inclusive - bill_discount
        return GSTCalculator.calculate_inclusive_tax(new_inclusive, gst_rate, region)
    
    @staticmethod
    def round_off_amount(amount: Decimal, round_to: Decimal = Decimal("0.01")) -> Tuple[Decimal, Decimal]:
        """
        Round off amount and return rounded amount with round off value
        round_to can be 0.01, 0.50, or 1.00
        """
        if round_to == Decimal("0.01"):
            rounded = amount.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        elif round_to == Decimal("0.50"):
            # Round to nearest 0.50
            rounded = (amount * 2).quantize(Decimal("1"), rounding=ROUND_HALF_UP) / 2
        else:  # 1.00
            rounded = amount.quantize(Decimal("1"), rounding=ROUND_HALF_UP)
        
        round_off = rounded - amount
        return rounded, round_off