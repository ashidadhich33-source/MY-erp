"""
Loyalty points and grade management service
"""
from sqlalchemy.orm import Session
from decimal import Decimal
from typing import Optional
import logging

from app.models import Customer, LoyaltyGrade
from app.config import settings

logger = logging.getLogger(__name__)

class LoyaltyService:
    """Service for loyalty points and grade management"""
    
    @staticmethod
    def calculate_points_earned(
        db: Session,
        customer: Customer,
        base_amount: Decimal
    ) -> Decimal:
        """
        Calculate points earned for a purchase
        Points are calculated on base amount (exclusive of tax) after all discounts
        """
        if not customer or not customer.loyalty_grade_id:
            return Decimal("0")
        
        grade = db.query(LoyaltyGrade).filter(
            LoyaltyGrade.id == customer.loyalty_grade_id
        ).first()
        
        if not grade or not grade.active:
            return Decimal("0")
        
        # Calculate points based on grade earn percentage
        points = base_amount * (grade.earn_pct / 100)
        
        # Round to nearest integer
        points = points.quantize(Decimal("1"))
        
        logger.info(
            f"Customer {customer.mobile} earned {points} points "
            f"on ₹{base_amount} at {grade.earn_pct}% rate"
        )
        
        return points
    
    @staticmethod
    def check_grade_upgrade(db: Session, customer: Customer) -> bool:
        """
        Check if customer qualifies for grade upgrade based on lifetime purchase
        Auto-upgrade if threshold crossed
        """
        if not customer:
            return False
        
        current_grade = None
        if customer.loyalty_grade_id:
            current_grade = db.query(LoyaltyGrade).filter(
                LoyaltyGrade.id == customer.loyalty_grade_id
            ).first()
        
        # Find applicable grade based on lifetime purchase
        new_grade = db.query(LoyaltyGrade).filter(
            LoyaltyGrade.active == True,
            LoyaltyGrade.amount_from <= customer.lifetime_purchase,
            LoyaltyGrade.amount_to >= customer.lifetime_purchase
        ).first()
        
        if not new_grade:
            # Check if customer exceeds all grades (premium customer)
            highest_grade = db.query(LoyaltyGrade).filter(
                LoyaltyGrade.active == True
            ).order_by(LoyaltyGrade.amount_to.desc()).first()
            
            if highest_grade and customer.lifetime_purchase > highest_grade.amount_to:
                new_grade = highest_grade
        
        # Upgrade if new grade is different and better
        if new_grade and (
            not current_grade or 
            new_grade.id != current_grade.id
        ):
            # Check if it's actually an upgrade (higher earn rate)
            if not current_grade or new_grade.earn_pct > current_grade.earn_pct:
                customer.loyalty_grade_id = new_grade.id
                logger.info(
                    f"Customer {customer.mobile} upgraded from "
                    f"{current_grade.name if current_grade else 'None'} "
                    f"to {new_grade.name}"
                )
                return True
        
        return False
    
    @staticmethod
    def calculate_redemption_value(
        points: Decimal,
        conversion_rate: Optional[Decimal] = None
    ) -> Decimal:
        """
        Calculate monetary value of points for redemption
        Default: 1 point = 1 rupee
        """
        if conversion_rate is None:
            conversion_rate = Decimal(str(settings.POINTS_CONVERSION_RATE))
        
        return points * conversion_rate
    
    @staticmethod
    def validate_redemption(
        db: Session,
        customer: Customer,
        points_to_redeem: Decimal,
        bill_amount: Decimal
    ) -> tuple[bool, str]:
        """
        Validate if points can be redeemed
        Returns: (is_valid, message)
        """
        if not customer:
            return False, "Customer not found"
        
        if points_to_redeem <= 0:
            return False, "Invalid redemption amount"
        
        if customer.points_balance < points_to_redeem:
            return False, f"Insufficient points. Available: {customer.points_balance}"
        
        redemption_value = LoyaltyService.calculate_redemption_value(points_to_redeem)
        
        if redemption_value > bill_amount:
            return False, "Redemption value exceeds bill amount"
        
        return True, f"Valid redemption of {points_to_redeem} points = ₹{redemption_value}"
    
    @staticmethod
    def get_customer_loyalty_summary(db: Session, customer: Customer) -> dict:
        """Get complete loyalty summary for a customer"""
        if not customer:
            return {
                "has_loyalty": False,
                "points_balance": 0,
                "lifetime_purchase": 0,
                "grade": None,
                "earn_rate": 0
            }
        
        grade = None
        if customer.loyalty_grade_id:
            grade = db.query(LoyaltyGrade).filter(
                LoyaltyGrade.id == customer.loyalty_grade_id
            ).first()
        
        return {
            "has_loyalty": True,
            "mobile": customer.mobile,
            "name": customer.name,
            "points_balance": float(customer.points_balance),
            "lifetime_purchase": float(customer.lifetime_purchase),
            "grade": grade.name if grade else None,
            "earn_rate": float(grade.earn_pct) if grade else 0,
            "next_grade": LoyaltyService.get_next_grade_info(db, customer)
        }
    
    @staticmethod
    def get_next_grade_info(db: Session, customer: Customer) -> Optional[dict]:
        """Get information about next loyalty grade"""
        if not customer:
            return None
        
        # Find next grade
        next_grade = db.query(LoyaltyGrade).filter(
            LoyaltyGrade.active == True,
            LoyaltyGrade.amount_from > customer.lifetime_purchase
        ).order_by(LoyaltyGrade.amount_from).first()
        
        if next_grade:
            amount_needed = next_grade.amount_from - customer.lifetime_purchase
            return {
                "grade_name": next_grade.name,
                "amount_needed": float(amount_needed),
                "earn_rate": float(next_grade.earn_pct)
            }
        
        return None
    
    @staticmethod
    def assign_default_grade(db: Session, customer: Customer) -> bool:
        """Assign default (lowest) grade to new customer"""
        if not customer or customer.loyalty_grade_id:
            return False
        
        # Find lowest grade
        default_grade = db.query(LoyaltyGrade).filter(
            LoyaltyGrade.active == True
        ).order_by(LoyaltyGrade.amount_from).first()
        
        if default_grade:
            customer.loyalty_grade_id = default_grade.id
            logger.info(f"Assigned default grade {default_grade.name} to {customer.mobile}")
            return True
        
        return False