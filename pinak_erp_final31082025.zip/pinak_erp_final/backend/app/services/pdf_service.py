"""
PDF generation service for bills and reports
"""
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib.enums import TA_CENTER, TA_RIGHT, TA_LEFT
from reportlab.pdfgen import canvas
from io import BytesIO
from decimal import Decimal
from datetime import datetime
import os

from app.config import settings

def format_currency(amount):
    """Format amount as Indian currency"""
    return f"₹{amount:,.2f}"

def generate_purchase_bill_pdf(bill) -> bytes:
    """Generate PDF for purchase bill"""
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4)
    story = []
    styles = getSampleStyleSheet()
    
    # Title
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=20,
        textColor=colors.HexColor('#2c3e50'),
        alignment=TA_CENTER
    )
    story.append(Paragraph("PURCHASE BILL", title_style))
    story.append(Spacer(1, 12))
    
    # Company info (if available)
    if bill.supplier.name:
        company_info = f"""
        <b>Supplier:</b> {bill.supplier.name}<br/>
        <b>GSTIN:</b> {bill.supplier.gstin or 'N/A'}<br/>
        <b>Phone:</b> {bill.supplier.phone or 'N/A'}<br/>
        """
        story.append(Paragraph(company_info, styles['Normal']))
        story.append(Spacer(1, 12))
    
    # Bill details
    bill_info = [
        ['Bill No:', bill.pb_no, 'Date:', bill.pb_date.strftime('%d-%m-%Y')],
        ['Supplier Bill No:', bill.supplier_bill_no or '-', 'Payment:', bill.payment_mode.upper()],
        ['Tax Region:', bill.tax_region.value.upper(), 'Reverse Charge:', 'Yes' if bill.reverse_charge else 'No']
    ]
    
    bill_table = Table(bill_info, colWidths=[1.5*inch, 2*inch, 1.5*inch, 2*inch])
    bill_table.setStyle(TableStyle([
        ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
        ('FONTNAME', (2, 0), (2, -1), 'Helvetica-Bold'),
    ]))
    story.append(bill_table)
    story.append(Spacer(1, 20))
    
    # Items table
    items_data = [['Sr', 'Barcode', 'Style Code', 'Size', 'HSN', 'Qty', 'Rate', 'Taxable', 'GST%', 'Total']]
    
    for idx, item in enumerate(bill.items, 1):
        items_data.append([
            str(idx),
            item.barcode,
            item.style_code,
            item.size or '-',
            item.hsn or '-',
            f"{item.qty:.2f}",
            format_currency(item.basic_rate),
            format_currency(item.line_taxable),
            f"{item.gst_rate}%",
            format_currency(item.line_total)
        ])
    
    items_table = Table(items_data, colWidths=[0.4*inch, 1*inch, 1.2*inch, 0.5*inch, 0.7*inch, 0.6*inch, 0.8*inch, 1*inch, 0.6*inch, 1*inch])
    items_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 10),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('FONTSIZE', (0, 1), (-1, -1), 9),
    ]))
    story.append(items_table)
    story.append(Spacer(1, 20))
    
    # Summary
    summary_data = [
        ['', 'Total Taxable:', format_currency(bill.total_taxable)],
        ['', 'CGST:', format_currency(bill.total_cgst)],
        ['', 'SGST:', format_currency(bill.total_sgst)],
        ['', 'IGST:', format_currency(bill.total_igst)],
        ['', 'Grand Total:', format_currency(bill.grand_total)]
    ]
    
    summary_table = Table(summary_data, colWidths=[4*inch, 1.5*inch, 1.5*inch])
    summary_table.setStyle(TableStyle([
        ('ALIGN', (1, 0), (-1, -1), 'RIGHT'),
        ('FONTNAME', (1, -1), (-1, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 11),
        ('LINEBELOW', (1, -2), (-1, -2), 1, colors.black),
    ]))
    story.append(summary_table)
    
    # Build PDF
    doc.build(story)
    buffer.seek(0)
    return buffer.read()

def generate_purchase_return_pdf(pr) -> bytes:
    """Generate PDF for purchase return (debit note)"""
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4)
    story = []
    styles = getSampleStyleSheet()
    
    # Title
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=20,
        textColor=colors.HexColor('#c0392b'),
        alignment=TA_CENTER
    )
    story.append(Paragraph("DEBIT NOTE", title_style))
    story.append(Spacer(1, 12))
    
    # Similar structure to purchase bill
    # ... (abbreviated for space, follows same pattern)
    
    doc.build(story)
    buffer.seek(0)
    return buffer.read()

def generate_sale_bill_pdf(sale) -> bytes:
    """Generate PDF for sale bill (80mm thermal printer format)"""
    # Thermal printer width is typically 80mm (about 3.15 inches)
    buffer = BytesIO()
    width = 3.15 * inch
    height = 11 * inch  # Dynamic height
    
    c = canvas.Canvas(buffer, pagesize=(width, height))
    y = height - 0.5 * inch
    
    # Company header
    c.setFont("Helvetica-Bold", 12)
    c.drawCentredString(width/2, y, "YOUR STORE NAME")
    y -= 15
    
    c.setFont("Helvetica", 8)
    if sale.bill_no:
        c.drawString(10, y, f"Bill No: {sale.bill_no}")
        c.drawRightString(width-10, y, sale.bill_date.strftime('%d-%m-%Y %H:%M'))
        y -= 12
    
    # Customer info
    if sale.customer_mobile:
        c.drawString(10, y, f"Customer: {sale.customer.name if sale.customer else sale.customer_mobile}")
        y -= 12
        if sale.customer and sale.customer.loyalty_grade:
            c.drawString(10, y, f"Grade: {sale.customer.loyalty_grade.name}")
            c.drawRightString(width-10, y, f"Points: {sale.customer.points_balance:.0f}")
            y -= 12
    
    # Line separator
    y -= 5
    c.line(10, y, width-10, y)
    y -= 10
    
    # Items
    c.setFont("Helvetica", 7)
    for item in sale.items:
        # Item description
        c.drawString(10, y, f"{item.style_code}")
        y -= 10
        c.drawString(15, y, f"{item.color or ''} {item.size or ''}")
        c.drawRightString(width-10, y, f"{item.qty:.0f} x {item.mrp_incl:.2f}")
        y -= 10
        if item.disc_pct > 0:
            c.drawString(15, y, f"Disc: {item.disc_pct}%")
        c.drawRightString(width-10, y, format_currency(item.line_inclusive))
        y -= 12
    
    # Line separator
    y -= 3
    c.line(10, y, width-10, y)
    y -= 10
    
    # Totals
    c.setFont("Helvetica", 8)
    c.drawString(10, y, "Gross Total:")
    c.drawRightString(width-10, y, format_currency(sale.gross_incl))
    y -= 12
    
    if sale.discount_incl > 0:
        c.drawString(10, y, "Discount:")
        c.drawRightString(width-10, y, f"-{format_currency(sale.discount_incl)}")
        y -= 12
    
    if sale.coupon_incl > 0:
        c.drawString(10, y, f"Coupon ({sale.coupon_code}):")
        c.drawRightString(width-10, y, f"-{format_currency(sale.coupon_incl)}")
        y -= 12
    
    if sale.redeem_value > 0:
        c.drawString(10, y, f"Points Redeemed:")
        c.drawRightString(width-10, y, f"-{format_currency(sale.redeem_value)}")
        y -= 12
    
    if sale.return_credit_used_value > 0:
        c.drawString(10, y, "Return Credit:")
        c.drawRightString(width-10, y, f"-{format_currency(sale.return_credit_used_value)}")
        y -= 12
    
    # Final amount
    c.setFont("Helvetica-Bold", 10)
    c.drawString(10, y, "Net Payable:")
    c.drawRightString(width-10, y, format_currency(sale.final_payable))
    y -= 15
    
    # Tax info
    c.setFont("Helvetica", 6)
    c.drawString(10, y, f"(Incl. GST: {format_currency(sale.tax_amt_info)})")
    y -= 12
    
    # Payment mode
    c.setFont("Helvetica", 8)
    for payment in sale.payments:
        c.drawString(10, y, f"{payment.payment_mode.name}:")
        c.drawRightString(width-10, y, format_currency(payment.amount))
        y -= 10
    
    # Loyalty summary
    if sale.customer:
        y -= 5
        c.line(10, y, width-10, y)
        y -= 10
        c.setFont("Helvetica", 7)
        c.drawString(10, y, f"Points Earned: {sale.earned_points:.0f}")
        y -= 10
        c.drawString(10, y, f"Balance Points: {sale.customer.points_balance:.0f}")
        y -= 12
    
    # Footer
    y -= 10
    c.setFont("Helvetica", 6)
    c.drawCentredString(width/2, y, "Thank you for shopping with us!")
    y -= 10
    c.drawCentredString(width/2, y, "Goods once sold cannot be returned")
    
    c.save()
    buffer.seek(0)
    return buffer.read()