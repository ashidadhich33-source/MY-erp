"""
User management service
"""
from sqlalchemy.orm import Session
from typing import Optional
import logging

from app.database import SessionLocal
from app.models import User, Company, UserPermission
from app.core.security import get_password_hash, verify_password

logger = logging.getLogger(__name__)

def create_user(
    db: Session,
    username: str,
    password: str,
    display_name: str,
    role: str = "operator",
    company_id: Optional[int] = None,
    email: Optional[str] = None,
    mobile: Optional[str] = None
) -> User:
    """Create a new user"""
    # Check if username exists
    existing = db.query(User).filter(User.username == username).first()
    if existing:
        raise ValueError(f"Username {username} already exists")
    
    # Create user
    db_user = User(
        username=username,
        password_hash=get_password_hash(password),
        display_name=display_name,
        role=role,
        company_id=company_id,
        email=email,
        mobile=mobile,
        active=True
    )
    
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    
    # Add default permissions based on role
    if role == "admin":
        _add_admin_permissions(db, db_user.id)
    elif role == "manager":
        _add_manager_permissions(db, db_user.id)
    else:
        _add_operator_permissions(db, db_user.id)
    
    return db_user

def _add_admin_permissions(db: Session, user_id: int):
    """Add all permissions for admin"""
    menu_keys = [
        "setup.item_master", "setup.suppliers", "setup.customers",
        "setup.users", "setup.company", "setup.loyalty",
        "purchases.purchase_bill", "purchases.purchase_return",
        "sales.sale_bill", "sales.sale_returns",
        "reports.sales", "reports.purchase", "reports.stock"
    ]
    
    for menu_key in menu_keys:
        perm = UserPermission(
            user_id=user_id,
            menu_key=menu_key,
            can_view=True,
            can_create=True,
            can_edit=True,
            can_import=True,
            can_export=True,
            can_print=True,
            can_modify_past=True,
            is_admin=True
        )
        db.add(perm)
    db.commit()

def _add_manager_permissions(db: Session, user_id: int):
    """Add manager permissions"""
    menu_keys = [
        "setup.item_master", "setup.customers",
        "purchases.purchase_bill",
        "sales.sale_bill", "sales.sale_returns",
        "reports.sales", "reports.stock"
    ]
    
    for menu_key in menu_keys:
        perm = UserPermission(
            user_id=user_id,
            menu_key=menu_key,
            can_view=True,
            can_create=True,
            can_edit=True,
            can_export=True,
            can_print=True
        )
        db.add(perm)
    db.commit()

def _add_operator_permissions(db: Session, user_id: int):
    """Add operator permissions"""
    menu_keys = ["sales.sale_bill", "reports.sales"]
    
    for menu_key in menu_keys:
        perm = UserPermission(
            user_id=user_id,
            menu_key=menu_key,
            can_view=True,
            can_create=True,
            can_print=True
        )
        db.add(perm)
    db.commit()

def create_default_admin():
    """Create default admin user if not exists"""
    db = SessionLocal()
    try:
        # Check if any user exists
        user_count = db.query(User).count()
        if user_count == 0:
            logger.info("Creating default admin user...")
            
            # Create default company first (FIXED - removed mobile field)
            company = db.query(Company).first()
            if not company:
                company = Company(
                    name="PIANK Fashion Store",
                    display_name="PIANK Fashion Store",
                    gstin="",
                    phone="",  # Changed from mobile to phone
                    address="",
                    active=True,
                    created_by="system"
                )
                db.add(company)
                db.commit()
                db.refresh(company)
            
            # Create admin user
            admin = create_user(
                db=db,
                username="admin",
                password="admin123",
                display_name="Administrator",
                role="admin",
                company_id=company.id,
                email="admin@piank.com",
                mobile="9999999999"  # Add a default mobile for the user
            )
            
            logger.info(f"Default admin user created: {admin.username}")
            logger.info("Username: admin")
            logger.info("Password: admin123")
    except Exception as e:
        logger.error(f"Error creating default admin: {e}")
        db.rollback()
    finally:
        db.close()

def authenticate_user(db: Session, username: str, password: str) -> Optional[User]:
    """Authenticate user with username and password"""
    user = db.query(User).filter(User.username == username).first()
    if not user:
        return None
    if not verify_password(password, user.password_hash):
        return None
    if not user.active:
        return None
    return user

def get_user_permissions(db: Session, user_id: int) -> dict:
    """Get user permissions as dictionary"""
    permissions = db.query(UserPermission).filter(UserPermission.user_id == user_id).all()
    
    perm_dict = {}
    for perm in permissions:
        perm_dict[perm.menu_key] = {
            "can_view": perm.can_view,
            "can_create": perm.can_create,
            "can_edit": perm.can_edit,
            "can_import": perm.can_import,
            "can_export": perm.can_export,
            "can_print": perm.can_print,
            "can_modify_past": perm.can_modify_past,
            "is_admin": perm.is_admin
        }
    
    return perm_dict