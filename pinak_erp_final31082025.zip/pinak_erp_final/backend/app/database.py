"""
Database connection and session management
"""
from sqlalchemy import create_engine, MetaData
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from typing import Generator
from app.config import settings

# Create engine
engine = create_engine(
    settings.DATABASE_URL,
    connect_args={"check_same_thread": False} if settings.DATABASE_TYPE == "sqlite" else {},
    pool_pre_ping=True,
    echo=settings.DEBUG
)

# Session factory
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Metadata instance for migrations
metadata = MetaData()

# Base class for models
Base = declarative_base(metadata=metadata)

def get_db() -> Generator[Session, None, None]:
    """
    Dependency to get database session
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def init_db():
    """
    Initialize database - create all tables
    """
    # Import all model classes here to ensure they are registered
    # Since all models are defined in app/models/__init__.py, we import them as classes
    from app.models import (
        Company, User, Item, Stock, Customer,
        Supplier, Sale, PurchaseBill, LoyaltyGrade, PaymentModeConfig,
        UserPermission, SaleItem, SalePayment, Staff, BillSeries,
        SaleReturn, SaleReturnItem, ReturnCredit, PurchaseReturn,
        PurchaseBillItem, PurchaseReturnItem, ExpenseHead, Expense,
        WhatsAppConfig, Coupon
    )
    
    Base.metadata.create_all(bind=engine)
    print("Database tables created successfully!")

def drop_all_tables():
    """
    Drop all tables - use with caution!
    """
    Base.metadata.drop_all(bind=engine)
    print("All database tables dropped!")