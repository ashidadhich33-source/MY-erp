"""
Sales Return module - Return Credit only, no refunds
"""
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import List, Optional
from datetime import datetime, timedelta
from decimal import Decimal

from app.database import get_db
from app.models import (
    Sale, SaleItem, SaleReturn, SaleReturnItem, ReturnCredit,
    Customer, Item, Stock, BillSeries, LocationType, CreditStatus
)
from app.api.deps import get_current_active_user, PermissionChecker
from app.schemas.sales_schemas import (
    SaleReturnCreate, SaleReturnResponse, SaleReturnItemCreate,
    ReturnCreditResponse, SaleLineSelectResponse, BaseResponse
)
from app.services.gst_service import GSTCalculator, TaxRegion
from app.services.stock_service import StockService
from app.config import settings

router = APIRouter()

# Return window configuration (days)
RETURN_WINDOW_DAYS = getattr(settings, 'RETURN_WINDOW_DAYS', 7)

@router.post("/returns/search-lines")
def search_sale_lines_for_return(
    barcode: str,
    from_date: Optional[datetime] = None,
    current_user = Depends(PermissionChecker("sales.sale_returns", "view")),
    db: Session = Depends(get_db)
):
    """Search sale lines containing barcode within return window"""
    # Set date range
    if not from_date:
        from_date = datetime.now() - timedelta(days=RETURN_WINDOW_DAYS)
    
    # Find all sale items with this barcode
    query = db.query(SaleItem).join(Sale).filter(
        SaleItem.barcode == barcode,
        Sale.bill_date >= from_date
    )
    
    sale_items = query.order_by(Sale.bill_date.desc()).all()
    
    if not sale_items:
        return {
            "found": False,
            "message": f"No sales found for barcode {barcode} in return window"
        }
    
    # Build response with returnable quantities
    lines = []
    for item in sale_items:
        # Calculate already returned quantity
        already_returned = db.query(func.sum(SaleReturnItem.return_qty)).filter(
            SaleReturnItem.sale_item_id == item.id
        ).scalar() or Decimal("0")
        
        returnable_qty = item.qty - already_returned
        
        if returnable_qty > 0:
            lines.append({
                "sale_id": item.sale_id,
                "sale_item_id": item.id,
                "bill_no": item.sale.bill_no,
                "bill_date": item.sale.bill_date.isoformat(),
                "customer_mobile": item.sale.customer_mobile,
                "customer_name": item.sale.customer.name if item.sale.customer else None,
                "barcode": item.barcode,
                "style_code": item.style_code,
                "color": item.color,
                "size": item.size,
                "unit_mrp_incl": float(item.mrp_incl),
                "disc_pct": float(item.disc_pct),
                "line_amount_incl": float(item.line_inclusive),
                "gst_rate": float(item.gst_rate),
                "hsn": item.hsn,
                "sold_qty": float(item.qty),
                "already_returned": float(already_returned),
                "returnable_qty": float(returnable_qty)
            })
    
    return {
        "found": True,
        "lines": lines
    }

@router.post("/returns/create", response_model=SaleReturnResponse)
def create_sale_return(
    sr: SaleReturnCreate,
    current_user = Depends(PermissionChecker("sales.sale_returns", "create")),
    db: Session = Depends(get_db)
):
    """Create a sale return (generates return credit only)"""
    try:
        # Get return series
        series = db.query(BillSeries).filter(BillSeries.id == sr.sr_series_id).first()
        if not series:
            raise HTTPException(status_code=404, detail="Return series not found")
        
        # Generate return number
        sr_no = f"{series.prefix}{str(series.next_number).zfill(series.zero_pad_width)}"
        
        # Create return header
        db_return = SaleReturn(
            sr_series_id=sr.sr_series_id,
            sr_no=sr_no,
            sr_date=sr.sr_date or datetime.now(),
            original_sale_id=sr.original_sale_id,
            customer_mobile=sr.customer_mobile,
            tax_region=LocationType.LOCAL,
            total_incl=Decimal("0"),
            reason=sr.reason,
            created_by=current_user.username
        )
        db.add(db_return)
        db.flush()
        
        # Process return items
        total_return_amount = Decimal("0")
        
        for item_data in sr.items:
            # Validate original sale item
            sale_item = db.query(SaleItem).filter(
                SaleItem.id == item_data.sale_item_id
            ).first()
            
            if not sale_item:
                raise HTTPException(status_code=404, detail="Original sale item not found")
            
            # Check returnable quantity
            already_returned = db.query(func.sum(SaleReturnItem.return_qty)).filter(
                SaleReturnItem.sale_item_id == sale_item.id
            ).scalar() or Decimal("0")
            
            returnable_qty = sale_item.qty - already_returned
            
            if item_data.return_qty > returnable_qty:
                raise HTTPException(
                    status_code=400,
                    detail=f"Return quantity exceeds returnable quantity for {sale_item.barcode}"
                )
            
            # Calculate return amount (based on original sale line amount, ignoring coupon/points)
            unit_return_amount = sale_item.line_inclusive / sale_item.qty
            line_return_amount = unit_return_amount * item_data.return_qty
            
            # Extract tax info (for display only)
            tax_calc = GSTCalculator.calculate_inclusive_tax(
                line_return_amount,
                sale_item.gst_rate,
                TaxRegion.LOCAL
            )
            
            # Create return item
            db_item = SaleReturnItem(
                sale_return_id=db_return.id,
                sale_id=sale_item.sale_id,
                sale_item_id=sale_item.id,
                barcode=sale_item.barcode,
                style_code=sale_item.style_code,
                color=sale_item.color,
                size=sale_item.size,
                hsn=sale_item.hsn,
                gst_rate=sale_item.gst_rate,
                unit_mrp_incl=sale_item.mrp_incl,
                disc_pct_at_sale=sale_item.disc_pct,
                return_qty=item_data.return_qty,
                line_inclusive=line_return_amount,
                base_excl_info=tax_calc["base_amount"],
                tax_info=tax_calc["total_tax"]
            )
            db.add(db_item)
            
            # Update original sale item returned quantity
            sale_item.returned_qty = already_returned + item_data.return_qty
            
            # Restore stock
            StockService.update_stock(
                db,
                sale_item.barcode,
                item_data.return_qty,
                "add",
                update_date=False
            )
            
            total_return_amount += line_return_amount
        
        # Update return total
        db_return.total_incl = total_return_amount
        
        # Create Return Credit
        rc_no = f"RC-{sr_no}"  # Return Credit number based on return number
        
        db_rc = ReturnCredit(
            rc_no=rc_no,
            customer_mobile=sr.customer_mobile,
            sale_return_id=db_return.id,
            rc_amount_incl=total_return_amount,
            used_amount=Decimal("0"),
            status=CreditStatus.OPEN,
            created_by=current_user.username
        )
        db.add(db_rc)
        
        # Update series
        series.next_number += 1
        
        # Note: Loyalty points are NOT affected by returns as per specification
        
        db.commit()
        db.refresh(db_return)
        
        return db_return
        
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/returns", response_model=List[SaleReturnResponse])
def list_sale_returns(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=100),
    from_date: Optional[datetime] = None,
    to_date: Optional[datetime] = None,
    customer_mobile: Optional[str] = None,
    current_user = Depends(PermissionChecker("sales.sale_returns", "view")),
    db: Session = Depends(get_db)
):
    """List sale returns"""
    query = db.query(SaleReturn)
    
    if from_date:
        query = query.filter(SaleReturn.sr_date >= from_date)
    if to_date:
        query = query.filter(SaleReturn.sr_date <= to_date)
    if customer_mobile:
        query = query.filter(SaleReturn.customer_mobile == customer_mobile)
    
    returns = query.order_by(SaleReturn.sr_date.desc()).offset(skip).limit(limit).all()
    return returns

@router.get("/returns/{return_id}", response_model=SaleReturnResponse)
def get_sale_return(
    return_id: int,
    current_user = Depends(PermissionChecker("sales.sale_returns", "view")),
    db: Session = Depends(get_db)
):
    """Get sale return details"""
    sr = db.query(SaleReturn).filter(SaleReturn.id == return_id).first()
    if not sr:
        raise HTTPException(status_code=404, detail="Sale return not found")
    return sr

@router.get("/return-credits", response_model=List[ReturnCreditResponse])
def list_return_credits(
    status: Optional[str] = Query(None, pattern=r'^(open|closed|partial)$'),
    customer_mobile: Optional[str] = None,
    current_user = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """List return credits"""
    query = db.query(ReturnCredit)
    
    if status:
        query = query.filter(ReturnCredit.status == CreditStatus[status.upper()])
    if customer_mobile:
        query = query.filter(ReturnCredit.customer_mobile == customer_mobile)
    
    credits = query.order_by(ReturnCredit.created_at.desc()).all()
    return credits

@router.get("/return-credits/{rc_id}", response_model=ReturnCreditResponse)
def get_return_credit(
    rc_id: int,
    current_user = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Get return credit details"""
    rc = db.query(ReturnCredit).filter(ReturnCredit.id == rc_id).first()
    if not rc:
        raise HTTPException(status_code=404, detail="Return credit not found")
    return rc

@router.post("/return-credits/{rc_id}/use", response_model=BaseResponse)
def use_return_credit(
    rc_id: int,
    amount: Decimal = Query(..., gt=0),
    sale_id: Optional[int] = None,
    current_user = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Mark return credit as used (partial or full)"""
    rc = db.query(ReturnCredit).filter(ReturnCredit.id == rc_id).first()
    if not rc:
        raise HTTPException(status_code=404, detail="Return credit not found")
    
    if rc.status == CreditStatus.CLOSED:
        raise HTTPException(status_code=400, detail="Return credit already closed")
    
    available = rc.rc_amount_incl - rc.used_amount
    if amount > available:
        raise HTTPException(
            status_code=400,
            detail=f"Amount exceeds available credit. Available: ₹{available}"
        )
    
    # Update used amount
    rc.used_amount += amount
    
    # Update status
    if rc.used_amount >= rc.rc_amount_incl:
        rc.status = CreditStatus.CLOSED
        rc.closed_at = datetime.now()
    else:
        rc.status = CreditStatus.PARTIAL
    
    db.commit()
    
    return BaseResponse(
        success=True,
        message=f"Return credit updated. Remaining: ₹{rc.rc_amount_incl - rc.used_amount}"
    )

@router.get("/returns/print/{return_id}")
def print_sale_return(
    return_id: int,
    current_user = Depends(PermissionChecker("sales.sale_returns", "print")),
    db: Session = Depends(get_db)
):
    """Print sale return slip (80mm format)"""
    sr = db.query(SaleReturn).filter(SaleReturn.id == return_id).first()
    if not sr:
        raise HTTPException(status_code=404, detail="Sale return not found")
    
    # Generate 80mm format return slip
    # ... (implement PDF generation)
    
    return {
        "success": True,
        "message": "Return slip sent to printer",
        "rc_no": sr.return_credit.rc_no if sr.return_credit else None,
        "rc_amount": float(sr.return_credit.rc_amount_incl) if sr.return_credit else 0
    }