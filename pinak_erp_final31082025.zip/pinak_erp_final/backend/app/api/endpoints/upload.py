from fastapi import APIRouter, UploadFile, File, Depends, HTTPException
from typing import Optional
import os
import shutil
from pathlib import Path
import uuid
from app.api.deps import get_current_active_user
from app.models import User

router = APIRouter()

# Create uploads directory if it doesn't exist
UPLOAD_DIR = Path("./uploads/logos")
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

# Allowed file extensions
ALLOWED_EXTENSIONS = {".png", ".jpg", ".jpeg", ".gif", ".bmp"}

@router.post("/upload/logo")
async def upload_company_logo(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_active_user)
):
    """Upload company logo"""
    try:
        # Validate file extension
        file_ext = Path(file.filename).suffix.lower()
        if file_ext not in ALLOWED_EXTENSIONS:
            raise HTTPException(
                status_code=400,
                detail=f"File type not allowed. Allowed types: {', '.join(ALLOWED_EXTENSIONS)}"
            )
        
        # Validate file size (max 5MB)
        contents = await file.read()
        if len(contents) > 5 * 1024 * 1024:
            raise HTTPException(status_code=400, detail="File size exceeds 5MB")
        
        # Generate unique filename
        unique_filename = f"{uuid.uuid4()}{file_ext}"
        file_path = UPLOAD_DIR / unique_filename
        
        # Save file
        with open(file_path, "wb") as f:
            f.write(contents)
        
        # Return the file path relative to the upload directory
        return {
            "success": True,
            "filename": unique_filename,
            "path": f"/uploads/logos/{unique_filename}"
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/uploads/logos/{filename}")
async def get_logo(filename: str):
    """Serve uploaded logo files"""
    file_path = UPLOAD_DIR / filename
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="File not found")
    
    from fastapi.responses import FileResponse
    return FileResponse(file_path)