"""
Additional reports - Purchase, Payment Mode, Expenses, Bill-wise
"""
from fastapi import APIRouter, Depends, Query
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from sqlalchemy import func, and_, or_
from typing import Optional
from datetime import datetime, date
from decimal import Decimal
import pandas as pd
import io

from app.database import get_db
from app.models import (
    Sale, SalePayment, PurchaseBill, PurchaseBillItem,
    PurchaseReturn, PurchaseReturnItem, PaymentModeConfig,
    Expense, ExpenseHead, Supplier, Item, BillSeries
)
from app.api.deps import get_current_active_user, PermissionChecker
from app.schemas.reports_schemas import (
    PurchaseReportRequest, PaymentModeReportRequest,
    ExpenseReportRequest, BillWiseReportRequest
)

router = APIRouter()

# ============== PURCHASE & PURCHASE RETURN REPORT ==============

@router.post("/purchase-return-report")
def generate_purchase_return_report(
    request: PurchaseReportRequest,
    current_user = Depends(PermissionChecker("reports.purchase_return_report", "view")),
    db: Session = Depends(get_db)
):
    """Generate Purchase & Purchase Return Report"""
    # Purchase Bills Query
    purchase_query = db.query(
        PurchaseBillItem.id,
        PurchaseBill.pb_date.label("date"),
        PurchaseBill.pb_no.label("bill_no"),
        Supplier.name.label("supplier_name"),
        PurchaseBillItem.barcode,
        PurchaseBillItem.style_code,
        PurchaseBillItem.size,
        PurchaseBillItem.hsn,
        PurchaseBillItem.qty,
        PurchaseBillItem.basic_rate,
        PurchaseBillItem.line_taxable,
        PurchaseBillItem.cgst_amount,
        PurchaseBillItem.sgst_amount,
        PurchaseBillItem.igst_amount,
        PurchaseBillItem.line_total,
        Item.brand,
        Item.category
    ).join(
        PurchaseBill, PurchaseBillItem.purchase_bill_id == PurchaseBill.id
    ).join(
        Supplier, PurchaseBill.supplier_id == Supplier.id
    ).join(
        Item, PurchaseBillItem.barcode == Item.barcode
    )
    
    # Apply filters
    if request.from_date:
        purchase_query = purchase_query.filter(PurchaseBill.pb_date >= request.from_date)
    if request.to_date:
        purchase_query = purchase_query.filter(PurchaseBill.pb_date <= request.to_date)
    if request.supplier_id:
        purchase_query = purchase_query.filter(PurchaseBill.supplier_id == request.supplier_id)
    
    purchases = purchase_query.all()
    
    # Purchase Returns Query (negative values)
    return_query = db.query(
        PurchaseReturnItem.id,
        PurchaseReturn.pr_date.label("date"),
        PurchaseReturn.pr_no.label("bill_no"),
        Supplier.name.label("supplier_name"),
        PurchaseReturnItem.barcode,
        PurchaseReturnItem.style_code,
        PurchaseReturnItem.size,
        PurchaseReturnItem.hsn,
        (-PurchaseReturnItem.qty).label("qty"),  # Negative
        PurchaseReturnItem.basic_rate,
        (-PurchaseReturnItem.line_taxable).label("line_taxable"),  # Negative
        (-PurchaseReturnItem.cgst_amount).label("cgst_amount"),  # Negative
        (-PurchaseReturnItem.sgst_amount).label("sgst_amount"),  # Negative
        (-PurchaseReturnItem.igst_amount).label("igst_amount"),  # Negative
        (-PurchaseReturnItem.line_total).label("line_total"),  # Negative
        Item.brand,
        Item.category
    ).join(
        PurchaseReturn, PurchaseReturnItem.purchase_return_id == PurchaseReturn.id
    ).join(
        Supplier, PurchaseReturn.supplier_id == Supplier.id
    ).join(
        Item, PurchaseReturnItem.barcode == Item.barcode
    )
    
    # Apply same filters
    if request.from_date:
        return_query = return_query.filter(PurchaseReturn.pr_date >= request.from_date)
    if request.to_date:
        return_query = return_query.filter(PurchaseReturn.pr_date <= request.to_date)
    if request.supplier_id:
        return_query = return_query.filter(PurchaseReturn.supplier_id == request.supplier_id)
    
    returns = return_query.all()
    
    # Combine data
    report_data = []
    
    for row in purchases:
        report_data.append({
            "date": row.date.strftime("%d-%m-%Y"),
            "bill_no": row.bill_no,
            "type": "PURCHASE",
            "supplier": row.supplier_name,
            "barcode": row.barcode,
            "style_code": row.style_code,
            "size": row.size or "-",
            "hsn": row.hsn or "-",
            "qty": float(row.qty),
            "basic_rate": float(row.basic_rate),
            "taxable": float(row.line_taxable),
            "cgst": float(row.cgst_amount),
            "sgst": float(row.sgst_amount),
            "igst": float(row.igst_amount),
            "total": float(row.line_total),
            "brand": row.brand or "-",
            "category": row.category or "-"
        })
    
    for row in returns:
        report_data.append({
            "date": row.date.strftime("%d-%m-%Y"),
            "bill_no": row.bill_no,
            "type": "RETURN",
            "supplier": row.supplier_name,
            "barcode": row.barcode,
            "style_code": row.style_code,
            "size": row.size or "-",
            "hsn": row.hsn or "-",
            "qty": float(row.qty),  # Already negative
            "basic_rate": float(row.basic_rate),
            "taxable": float(row.line_taxable),  # Already negative
            "cgst": float(row.cgst_amount),  # Already negative
            "sgst": float(row.sgst_amount),  # Already negative
            "igst": float(row.igst_amount),  # Already negative
            "total": float(row.line_total),  # Already negative
            "brand": row.brand or "-",
            "category": row.category or "-"
        })
    
    # Sort by date
    report_data.sort(key=lambda x: x["date"])
    
    if request.export_format == "excel":
        return export_purchase_report_excel(report_data)
    
    return {
        "success": True,
        "data": report_data,
        "summary": {
            "total_purchases": sum(r["total"] for r in report_data if r["type"] == "PURCHASE"),
            "total_returns": sum(r["total"] for r in report_data if r["type"] == "RETURN"),
            "net_purchases": sum(r["total"] for r in report_data)
        }
    }

# ============== BILL WISE SALE REPORT ==============

@router.post("/bill-wise-sale")
def generate_bill_wise_sale_report(
    request: BillWiseReportRequest,
    current_user = Depends(PermissionChecker("reports.bill_wise_sale", "view")),
    db: Session = Depends(get_db)
):
    """Generate bill-wise sale summary"""
    query = db.query(
        Sale.bill_no,
        Sale.bill_date,
        Sale.customer_mobile,
        func.sum(SaleItem.qty).label("total_qty"),
        Sale.gross_incl,
        Sale.discount_incl,
        Sale.coupon_incl,
        Sale.tax_amt_info,
        Sale.redeem_value,
        Sale.return_credit_used_value,
        Sale.final_payable
    ).join(
        SaleItem, Sale.id == SaleItem.sale_id
    ).group_by(Sale.id)
    
    if request.from_date:
        query = query.filter(Sale.bill_date >= request.from_date)
    if request.to_date:
        query = query.filter(Sale.bill_date <= request.to_date)
    if request.min_amount:
        query = query.filter(Sale.final_payable >= request.min_amount)
    if request.max_amount:
        query = query.filter(Sale.final_payable <= request.max_amount)
    
    results = query.all()
    
    report_data = []
    for row in results:
        report_data.append({
            "bill_no": row.bill_no,
            "bill_date": row.bill_date.strftime("%d-%m-%Y %H:%M"),
            "customer": row.customer_mobile or "WALK-IN",
            "items": int(row.total_qty),
            "gross": float(row.gross_incl),
            "discount": float(row.discount_incl),
            "coupon": float(row.coupon_incl),
            "tax": float(row.tax_amt_info),
            "points_used": float(row.redeem_value),
            "credit_used": float(row.return_credit_used_value),
            "net_amount": float(row.final_payable)
        })
    
    if request.export_format == "excel":
        return export_bill_wise_excel(report_data)
    
    return {
        "success": True,
        "data": report_data,
        "total_bills": len(report_data),
        "total_amount": sum(r["net_amount"] for r in report_data)
    }

# ============== PAYMENT MODE WISE SALE REPORT ==============

@router.post("/payment-mode-wise")
def generate_payment_mode_report(
    request: PaymentModeReportRequest,
    current_user = Depends(PermissionChecker("reports.payment_mode_sale", "view")),
    db: Session = Depends(get_db)
):
    """Generate payment mode wise collection report"""
    query = db.query(
        PaymentModeConfig.name.label("payment_mode"),
        PaymentModeConfig.settlement_type,
        func.count(SalePayment.id).label("transaction_count"),
        func.sum(SalePayment.amount).label("total_amount")
    ).join(
        SalePayment, PaymentModeConfig.id == SalePayment.payment_mode_id
    ).join(
        Sale, SalePayment.sale_id == Sale.id
    ).group_by(PaymentModeConfig.id)
    
    if request.from_date:
        query = query.filter(Sale.bill_date >= request.from_date)
    if request.to_date:
        query = query.filter(Sale.bill_date <= request.to_date)
    
    results = query.all()
    
    # Calculate settlement-wise totals
    cash_total = Decimal("0")
    bank_total = Decimal("0")
    supplier_total = Decimal("0")
    
    report_data = []
    for row in results:
        amount = float(row.total_amount)
        report_data.append({
            "payment_mode": row.payment_mode,
            "settlement_type": row.settlement_type.value,
            "transactions": row.transaction_count,
            "amount": amount
        })
        
        if row.settlement_type.value == "cash":
            cash_total += row.total_amount
        elif row.settlement_type.value == "bank":
            bank_total += row.total_amount
        elif row.settlement_type.value == "supplier":
            supplier_total += row.total_amount
    
    if request.export_format == "excel":
        return export_payment_mode_excel(report_data)
    
    return {
        "success": True,
        "data": report_data,
        "summary": {
            "cash_in_hand": float(cash_total),
            "bank_collections": float(bank_total),
            "supplier_collections": float(supplier_total),
            "total_collections": float(cash_total + bank_total + supplier_total)
        }
    }

# ============== EXPENSES REPORT ==============

@router.post("/expenses-report")
def generate_expenses_report(
    request: ExpenseReportRequest,
    current_user = Depends(PermissionChecker("reports.expenses_report", "view")),
    db: Session = Depends(get_db)
):
    """Generate expenses report"""
    query = db.query(
        Expense.date,
        ExpenseHead.name.label("expense_head"),
        Expense.amount,
        Expense.mode,
        Expense.note,
        Expense.created_by
    ).join(
        ExpenseHead, Expense.head_id == ExpenseHead.id
    )
    
    if request.from_date:
        query = query.filter(Expense.date >= request.from_date)
    if request.to_date:
        query = query.filter(Expense.date <= request.to_date)
    if request.expense_head_id:
        query = query.filter(Expense.head_id == request.expense_head_id)
    if request.payment_mode:
        query = query.filter(Expense.mode == request.payment_mode)
    
    expenses = query.order_by(Expense.date.desc()).all()
    
    report_data = []
    cash_expenses = Decimal("0")
    bank_expenses = Decimal("0")
    
    for expense in expenses:
        report_data.append({
            "date": expense.date.strftime("%d-%m-%Y"),
            "head": expense.expense_head,
            "amount": float(expense.amount),
            "mode": expense.mode,
            "note": expense.note or "-",
            "created_by": expense.created_by
        })
        
        if expense.mode == "cash":
            cash_expenses += expense.amount
        else:
            bank_expenses += expense.amount
    
    if request.export_format == "excel":
        return export_expenses_excel(report_data)
    
    # Calculate cash flow
    # Cash in hand = POS cash collections - cash expenses
    cash_sales = db.query(func.sum(SalePayment.amount)).join(
        PaymentModeConfig
    ).filter(
        PaymentModeConfig.settlement_type == "cash"
    )
    
    if request.from_date:
        cash_sales = cash_sales.join(Sale).filter(Sale.bill_date >= request.from_date)
    if request.to_date:
        cash_sales = cash_sales.join(Sale).filter(Sale.bill_date <= request.to_date)
    
    total_cash_sales = cash_sales.scalar() or Decimal("0")
    
    return {
        "success": True,
        "data": report_data,
        "summary": {
            "total_expenses": float(cash_expenses + bank_expenses),
            "cash_expenses": float(cash_expenses),
            "bank_expenses": float(bank_expenses),
            "cash_collections": float(total_cash_sales),
            "net_cash_in_hand": float(total_cash_sales - cash_expenses)
        }
    }

# ============== Export Helper Functions ==============

def export_purchase_report_excel(data):
    """Export purchase report to Excel"""
    df = pd.DataFrame(data)
    output = io.BytesIO()
    
    with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
        df.to_excel(writer, sheet_name='Purchase Report', index=False)
    
    output.seek(0)
    return StreamingResponse(
        output,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={
            "Content-Disposition": f"attachment; filename=purchase_report_{datetime.now().strftime('%Y%m%d')}.xlsx"
        }
    )

def export_bill_wise_excel(data):
    """Export bill-wise report to Excel"""
    df = pd.DataFrame(data)
    output = io.BytesIO()
    
    with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
        df.to_excel(writer, sheet_name='Bill Wise Report', index=False)
    
    output.seek(0)
    return StreamingResponse(
        output,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={
            "Content-Disposition": f"attachment; filename=bill_wise_report_{datetime.now().strftime('%Y%m%d')}.xlsx"
        }
    )

def export_payment_mode_excel(data):
    """Export payment mode report to Excel"""
    df = pd.DataFrame(data)
    output = io.BytesIO()
    
    with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
        df.to_excel(writer, sheet_name='Payment Mode Report', index=False)
    
    output.seek(0)
    return StreamingResponse(
        output,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={
            "Content-Disposition": f"attachment; filename=payment_mode_report_{datetime.now().strftime('%Y%m%d')}.xlsx"
        }
    )

def export_expenses_excel(data):
    """Export expenses report to Excel"""
    df = pd.DataFrame(data)
    output = io.BytesIO()
    
    with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
        df.to_excel(writer, sheet_name='Expenses Report', index=False)
    
    output.seek(0)
    return StreamingResponse(
        output,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={
            "Content-Disposition": f"attachment; filename=expenses_report_{datetime.now().strftime('%Y%m%d')}.xlsx"
        }
    )