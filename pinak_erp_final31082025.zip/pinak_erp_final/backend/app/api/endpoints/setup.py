"""
Setup module endpoints for master data management
FIXED VERSION with proper routing and error handling
Updated with base64 logo storage support
"""
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import List, Optional
import base64
import re

from app.database import get_db
from app.models import (
    Company, User, UserPermission, Supplier, Customer
)
from app.schemas.base_schemas import (
    BaseResponse, PaginatedResponse,
    CompanyCreate, CompanyUpdate, CompanyResponse,
    UserCreate, UserUpdate, UserResponse, PermissionUpdate,
    SupplierCreate, SupplierUpdate, SupplierResponse,
    CustomerCreate, CustomerUpdate, CustomerResponse
)
from app.api.deps import get_current_active_user, require_admin, PermissionChecker
from app.services.user_service import create_user
from app.core.security import get_password_hash

router = APIRouter()

# ============== HELPER FUNCTIONS ==============

def validate_base64_image(base64_string: str) -> bool:
    """Validate if string is a valid base64 image"""
    if not base64_string:
        return True  # Optional field
    
    # Check if it has the data URL prefix
    image_pattern = r'^data:image/(jpeg|jpg|png|gif|bmp|webp);base64,'
    if not re.match(image_pattern, base64_string):
        return False
    
    # Extract the base64 part
    try:
        base64_data = base64_string.split(',')[1]
        # Try to decode to verify it's valid base64
        base64.b64decode(base64_data)
        
        # Check file size (limit to 2MB)
        file_size = len(base64_data) * 3 / 4  # Approximate size in bytes
        if file_size > 2 * 1024 * 1024:  # 2MB limit
            raise ValueError("Image size exceeds 2MB limit")
        
        return True
    except Exception:
        return False

# ============== COMPANY ENDPOINTS ==============

@router.post("/companies", response_model=CompanyResponse)
def create_company(
    company: CompanyCreate,
    current_user: User = Depends(require_admin),
    db: Session = Depends(get_db)
):
    """Create a new company with logo"""
    try:
        # Validate logo if provided
        if hasattr(company, 'logo_base64') and company.logo_base64:
            if not validate_base64_image(company.logo_base64):
                raise HTTPException(
                    status_code=400, 
                    detail="Invalid logo format. Please provide a valid base64 image (max 2MB)"
                )
        
        db_company = Company(
            **company.dict(),
            created_by=current_user.username
        )
        db.add(db_company)
        db.commit()
        db.refresh(db_company)
        return db_company
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/companies", response_model=List[CompanyResponse])
def list_companies(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=100),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """List all companies"""
    try:
        companies = db.query(Company).offset(skip).limit(limit).all()
        return companies
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/companies/{company_id}", response_model=CompanyResponse)
def get_company(
    company_id: int,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Get company details"""
    try:
        company = db.query(Company).filter(Company.id == company_id).first()
        if not company:
            raise HTTPException(status_code=404, detail="Company not found")
        return company
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.put("/companies/{company_id}", response_model=CompanyResponse)
def update_company(
    company_id: int,
    company_update: CompanyUpdate,
    current_user: User = Depends(require_admin),
    db: Session = Depends(get_db)
):
    """Update company details including logo"""
    try:
        company = db.query(Company).filter(Company.id == company_id).first()
        if not company:
            raise HTTPException(status_code=404, detail="Company not found")
        
        # Validate logo if provided in update
        if hasattr(company_update, 'logo_base64') and company_update.logo_base64:
            if not validate_base64_image(company_update.logo_base64):
                raise HTTPException(
                    status_code=400, 
                    detail="Invalid logo format. Please provide a valid base64 image (max 2MB)"
                )
        
        update_data = company_update.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(company, field, value)
        
        company.updated_by = current_user.username
        db.commit()
        db.refresh(company)
        return company
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

# ============== USER ENDPOINTS ==============

@router.post("/users", response_model=UserResponse)
def create_new_user(
    user_data: UserCreate,
    current_user: User = Depends(require_admin),
    db: Session = Depends(get_db)
):
    """Create a new user"""
    try:
        user = create_user(
            db=db,
            username=user_data.username,
            password=user_data.password,
            display_name=user_data.display_name,
            email=user_data.email,
            mobile=user_data.mobile,
            role=user_data.role,
            company_id=user_data.company_id or current_user.company_id,
            created_by=current_user.username
        )
        return user
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/users", response_model=List[UserResponse])
def list_users(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=100),
    current_user: User = Depends(require_admin),
    db: Session = Depends(get_db)
):
    """List all users"""
    try:
        users = db.query(User).offset(skip).limit(limit).all()
        return users
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/users/{user_id}", response_model=UserResponse)
def get_user(
    user_id: int,
    current_user: User = Depends(require_admin),
    db: Session = Depends(get_db)
):
    """Get user details"""
    try:
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        return user
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.put("/users/{user_id}", response_model=UserResponse)
def update_user(
    user_id: int,
    user_update: UserUpdate,
    current_user: User = Depends(require_admin),
    db: Session = Depends(get_db)
):
    """Update user details"""
    try:
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        update_data = user_update.dict(exclude_unset=True)
        
        # Handle password update
        if 'password' in update_data:
            update_data['password_hash'] = get_password_hash(update_data['password'])
            del update_data['password']
        
        for field, value in update_data.items():
            setattr(user, field, value)
        
        user.updated_by = current_user.username
        db.commit()
        db.refresh(user)
        return user
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/users/{user_id}/permissions")
def get_user_permissions(
    user_id: int,
    current_user: User = Depends(require_admin),
    db: Session = Depends(get_db)
):
    """Get user permissions"""
    try:
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        permissions = db.query(UserPermission).filter(UserPermission.user_id == user_id).all()
        permission_dict = {}
        for perm in permissions:
            permission_dict[perm.permission] = {
                'view': perm.view,
                'create': perm.create,
                'edit': perm.edit,
                'delete': perm.delete
            }
        
        return {"permissions": permission_dict}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.put("/users/{user_id}/permissions")
def update_user_permissions(
    user_id: int,
    permissions_data: dict,
    current_user: User = Depends(require_admin),
    db: Session = Depends(get_db)
):
    """Update user permissions"""
    try:
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        # Clear existing permissions
        db.query(UserPermission).filter(UserPermission.user_id == user_id).delete()
        
        # Add new permissions
        for permission, access in permissions_data.get('permissions', {}).items():
            db_permission = UserPermission(
                user_id=user_id,
                permission=permission,
                view=access.get('view', False),
                create=access.get('create', False),
                edit=access.get('edit', False),
                delete=access.get('delete', False),
                created_by=current_user.username
            )
            db.add(db_permission)
        
        db.commit()
        return {"success": True, "message": "Permissions updated successfully"}
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

# ============== SUPPLIER ENDPOINTS ==============

@router.post("/suppliers", response_model=SupplierResponse)
def create_supplier(
    supplier: SupplierCreate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Create a new supplier"""
    try:
        # Convert location_type to string if needed
        supplier_data = supplier.dict()
        if 'location_type' in supplier_data:
            loc_type = supplier_data['location_type']
            if loc_type not in ['local', 'inter-state']:
                supplier_data['location_type'] = 'local'
        
        db_supplier = Supplier(
            **supplier_data,
            created_by=current_user.username
        )
        db.add(db_supplier)
        db.commit()
        db.refresh(db_supplier)
        return db_supplier
    except Exception as e:
        db.rollback()
        print(f"[ERROR] in create_supplier: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/suppliers")
def list_suppliers(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=100),
    active_only: bool = Query(True),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """List all suppliers"""
    try:
        query = db.query(Supplier)
        if active_only:
            query = query.filter(Supplier.active == True)
        suppliers = query.offset(skip).limit(limit).all()
        
        # Convert SQLAlchemy objects to dictionaries
        suppliers_list = []
        for supplier in suppliers:
            # Handle location_type - could be enum or string
            location_type = supplier.location_type
            if hasattr(location_type, 'value'):
                location_type = location_type.value
            elif location_type:
                location_type = str(location_type)
            else:
                location_type = 'local'
            
            suppliers_list.append({
                "id": supplier.id,
                "name": supplier.name or '',
                "gstin": supplier.gstin or '',
                "email": supplier.email or '',
                "phone": supplier.phone or '',
                "location_type": location_type,
                "active": supplier.active if supplier.active is not None else True,
                "address": supplier.address or '',
                "city": supplier.city or '',
                "state": supplier.state or '',
                "pincode": supplier.pincode or '',
                "contact_person": supplier.contact_person or '',
                "created_at": supplier.created_at.isoformat() if supplier.created_at else None,
                "updated_at": supplier.updated_at.isoformat() if supplier.updated_at else None
            })
        
        # Return in the format expected by frontend
        return {"suppliers": suppliers_list}
        
    except Exception as e:
        print(f"[ERROR] in list_suppliers: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/suppliers/{supplier_id}", response_model=SupplierResponse)
def get_supplier(
    supplier_id: int,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Get supplier details"""
    try:
        supplier = db.query(Supplier).filter(Supplier.id == supplier_id).first()
        if not supplier:
            raise HTTPException(status_code=404, detail="Supplier not found")
        return supplier
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.put("/suppliers/{supplier_id}")
def update_supplier(
    supplier_id: int,
    supplier_update: dict,  # Accept dict to get all fields
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Update supplier details"""
    try:
        # Debug: Print what we received
        print(f"\n[DEBUG] Updating supplier {supplier_id}")
        print(f"[DEBUG] Received data: {supplier_update}")
        print(f"[DEBUG] Contact person value: {supplier_update.get('contact_person', 'NOT PROVIDED')}")
        
        supplier = db.query(Supplier).filter(Supplier.id == supplier_id).first()
        if not supplier:
            raise HTTPException(status_code=404, detail="Supplier not found")
        
        # Update each field explicitly
        if 'name' in supplier_update:
            supplier.name = supplier_update['name']
        if 'gstin' in supplier_update:
            supplier.gstin = supplier_update['gstin']
        if 'email' in supplier_update:
            supplier.email = supplier_update['email']
        if 'phone' in supplier_update:
            supplier.phone = supplier_update['phone']
        if 'location_type' in supplier_update:
            supplier.location_type = supplier_update['location_type']
        if 'address' in supplier_update:
            supplier.address = supplier_update['address']
        if 'city' in supplier_update:
            supplier.city = supplier_update['city']
        if 'state' in supplier_update:
            supplier.state = supplier_update['state']
        if 'pincode' in supplier_update:
            supplier.pincode = supplier_update['pincode']
        if 'contact_person' in supplier_update:
            supplier.contact_person = supplier_update['contact_person']
            print(f"[DEBUG] Setting contact_person to: {supplier_update['contact_person']}")
        if 'active' in supplier_update:
            supplier.active = supplier_update['active']
        
        supplier.updated_by = current_user.username
        
        # Debug: Print before commit
        print(f"[DEBUG] Before commit - contact_person: {supplier.contact_person}")
        
        db.commit()
        db.refresh(supplier)
        
        # Debug: Print after commit
        print(f"[DEBUG] After commit - contact_person: {supplier.contact_person}")
        
        # Return the updated supplier
        return {
            "id": supplier.id,
            "name": supplier.name,
            "gstin": supplier.gstin,
            "email": supplier.email,
            "phone": supplier.phone,
            "location_type": supplier.location_type,
            "address": supplier.address,
            "city": supplier.city,
            "state": supplier.state,
            "pincode": supplier.pincode,
            "contact_person": supplier.contact_person,
            "active": supplier.active,
            "created_at": supplier.created_at.isoformat() if supplier.created_at else None,
            "updated_at": supplier.updated_at.isoformat() if supplier.updated_at else None
        }
        
    except Exception as e:
        db.rollback()
        print(f"[ERROR] in update_supplier: {str(e)}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))

@router.delete("/suppliers/{supplier_id}")
def delete_supplier(
    supplier_id: int,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Delete supplier"""
    try:
        supplier = db.query(Supplier).filter(Supplier.id == supplier_id).first()
        if not supplier:
            raise HTTPException(status_code=404, detail="Supplier not found")
        
        db.delete(supplier)
        db.commit()
        return {"success": True, "message": "Supplier deleted successfully"}
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

# ============== CUSTOMER ENDPOINTS ==============

@router.post("/customers", response_model=CustomerResponse)
def create_customer(
    customer: CustomerCreate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Create a new customer"""
    try:
        # Check if mobile exists
        existing = db.query(Customer).filter(Customer.mobile == customer.mobile).first()
        if existing:
            raise HTTPException(status_code=400, detail="Customer with this mobile number already exists")
        
        db_customer = Customer(
            **customer.dict(),
            created_by=current_user.username
        )
        db.add(db_customer)
        db.commit()
        db.refresh(db_customer)
        return db_customer
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/customers", response_model=List[CustomerResponse])
def list_customers(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=100),
    search: Optional[str] = Query(None),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """List all customers"""
    try:
        query = db.query(Customer)
        
        # REMOVED: active_only filter since Customer model has no 'active' field
        
        if search:
            query = query.filter(
                (Customer.name.ilike(f"%{search}%")) |
                (Customer.mobile.ilike(f"%{search}%")) |
                (Customer.email.ilike(f"%{search}%"))
            )
        customers = query.offset(skip).limit(limit).all()
        return customers
    except Exception as e:
        print(f"Customer fetch error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/customers/search")
def search_customer(
    mobile: str = Query(..., regex=r'^\d{10}$'),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Search customer by mobile number"""
    try:
        customer = db.query(Customer).filter(Customer.mobile == mobile).first()
        if not customer:
            return {"found": False, "message": "Customer not found"}
        
        return {
            "found": True,
            "customer": customer,
            "loyalty_points": customer.points_balance,  # Use points_balance from model
            "current_grade": customer.loyalty_grade.name if customer.loyalty_grade else "Regular"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.put("/customers/{mobile}", response_model=CustomerResponse)
def update_customer(
    mobile: str,
    customer_update: CustomerUpdate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Update customer details"""
    try:
        customer = db.query(Customer).filter(Customer.mobile == mobile).first()
        if not customer:
            raise HTTPException(status_code=404, detail="Customer not found")
        
        update_data = customer_update.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(customer, field, value)
        
        customer.updated_by = current_user.username
        db.commit()
        db.refresh(customer)
        return customer
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/customers/{mobile}/history")
def get_customer_history(
    mobile: str,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Get customer purchase history"""
    try:
        customer = db.query(Customer).filter(Customer.mobile == mobile).first()
        if not customer:
            raise HTTPException(status_code=404, detail="Customer not found")
        
        return {
            "customer": customer,
            "stats": {
                "total_purchases": 0,
                "total_amount": float(customer.lifetime_purchase) if customer.lifetime_purchase else 0,
                "last_purchase_date": customer.last_visit_date,
                "loyalty_points": float(customer.points_balance) if customer.points_balance else 0,
                "current_grade": customer.loyalty_grade.name if customer.loyalty_grade else "Regular"
            },
            "recent_purchases": []
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))