"""
Purchase module endpoints - Complete implementation
"""
from fastapi import APIRouter, Depends, HTTPException, status, Query, UploadFile, File
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import List, Optional
from datetime import datetime, date
from decimal import Decimal
import pandas as pd
import io

from app.database import get_db
from app.models import (
    PurchaseBill, PurchaseBillItem, PurchaseReturn, PurchaseReturnItem,
    Item, Stock, Supplier, BillSeries, LocationType, PaymentMode
)
from app.api.deps import get_current_active_user, PermissionChecker
from app.schemas.purchase_schemas import (
    PurchaseBillCreate, PurchaseBillResponse, PurchaseBillItemCreate,
    PurchaseReturnCreate, PurchaseReturnResponse, PurchaseReturnItemCreate,
    BaseResponse
)
from app.services.gst_service import GSTCalculator, TaxRegion
from app.services.stock_service import StockService
from app.services.pdf_service import generate_purchase_bill_pdf, generate_purchase_return_pdf

router = APIRouter()

# ============== PURCHASE BILL ENDPOINTS ==============

@router.post("/bills", response_model=PurchaseBillResponse)
def create_purchase_bill(
    bill: PurchaseBillCreate,
    current_user = Depends(PermissionChecker("purchases.purchase_bill", "create")),
    db: Session = Depends(get_db)
):
    """Create a new purchase bill"""
    # Validate supplier
    supplier = db.query(Supplier).filter(Supplier.id == bill.supplier_id).first()
    if not supplier:
        raise HTTPException(status_code=404, detail="Supplier not found")
    
    # Get bill series and generate number
    series = db.query(BillSeries).filter(BillSeries.id == bill.pb_series_id).first()
    if not series:
        raise HTTPException(status_code=404, detail="Bill series not found")
    
    # Generate bill number
    pb_no = f"{series.prefix}{str(series.next_number).zfill(series.zero_pad_width)}"
    
    # Determine tax region from supplier
    tax_region = LocationType(supplier.location_type)
    region = TaxRegion.LOCAL if tax_region == LocationType.LOCAL else TaxRegion.INTER
    
    # Create bill header
    db_bill = PurchaseBill(
        pb_series_id=bill.pb_series_id,
        pb_no=pb_no,
        pb_date=bill.pb_date or datetime.now(),
        payment_mode=bill.payment_mode,
        supplier_id=bill.supplier_id,
        tax_region=tax_region,
        supplier_bill_no=bill.supplier_bill_no,
        supplier_bill_date=bill.supplier_bill_date,
        reverse_charge=bill.reverse_charge,
        total_taxable=Decimal("0"),
        total_cgst=Decimal("0"),
        total_sgst=Decimal("0"),
        total_igst=Decimal("0"),
        grand_total=Decimal("0"),
        created_by=current_user.username
    )
    db.add(db_bill)
    db.flush()
    
    # Process items
    total_taxable = Decimal("0")
    total_cgst = Decimal("0")
    total_sgst = Decimal("0")
    total_igst = Decimal("0")
    
    for item_data in bill.items:
        # Validate item
        item = db.query(Item).filter(Item.barcode == item_data.barcode).first()
        if not item:
            raise HTTPException(status_code=404, detail=f"Item {item_data.barcode} not found")
        
        # Calculate GST
        calc = GSTCalculator.calculate_line_total_exclusive(
            qty=item_data.qty,
            basic_rate=item_data.basic_rate,
            gst_rate=None,  # Auto-determine
            region=region
        )
        
        # Create bill item
        db_item = PurchaseBillItem(
            purchase_bill_id=db_bill.id,
            barcode=item_data.barcode,
            style_code=item.style_code,
            size=item.size,
            hsn=item.hsn,
            qty=item_data.qty,
            basic_rate=item_data.basic_rate,
            gst_rate=calc["gst_rate"],
            cgst_rate=calc["cgst_rate"],
            sgst_rate=calc["sgst_rate"],
            igst_rate=calc["igst_rate"],
            line_taxable=calc["line_taxable"],
            cgst_amount=calc["cgst_amount"],
            sgst_amount=calc["sgst_amount"],
            igst_amount=calc["igst_amount"],
            line_total=calc["line_total"],
            mrp=item.mrp_incl
        )
        db.add(db_item)
        
        # Update stock
        stock = db.query(Stock).filter(Stock.barcode == item_data.barcode).first()
        if not stock:
            stock = Stock(barcode=item_data.barcode, qty_on_hand=Decimal("0"))
            db.add(stock)
        
        stock.qty_on_hand += item_data.qty
        stock.last_purchase_rate = item_data.basic_rate
        stock.last_purchase_date = datetime.now()
        
        # Update item purchase rate
        item.purchase_rate_basic = item_data.basic_rate
        
        # Accumulate totals
        total_taxable += calc["line_taxable"]
        total_cgst += calc["cgst_amount"]
        total_sgst += calc["sgst_amount"]
        total_igst += calc["igst_amount"]
    
    # Update bill totals
    db_bill.total_taxable = total_taxable
    db_bill.total_cgst = total_cgst
    db_bill.total_sgst = total_sgst
    db_bill.total_igst = total_igst
    db_bill.grand_total = total_taxable + total_cgst + total_sgst + total_igst
    
    # Update series next number
    series.next_number += 1
    
    db.commit()
    db.refresh(db_bill)
    
    return db_bill

@router.get("/bills", response_model=List[PurchaseBillResponse])
def list_purchase_bills(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=100),
    from_date: Optional[date] = None,
    to_date: Optional[date] = None,
    supplier_id: Optional[int] = None,
    current_user = Depends(PermissionChecker("purchases.purchase_bill", "view")),
    db: Session = Depends(get_db)
):
    """List purchase bills with filters"""
    query = db.query(PurchaseBill)
    
    if from_date:
        query = query.filter(PurchaseBill.pb_date >= from_date)
    if to_date:
        query = query.filter(PurchaseBill.pb_date <= to_date)
    if supplier_id:
        query = query.filter(PurchaseBill.supplier_id == supplier_id)
    
    bills = query.order_by(PurchaseBill.pb_date.desc()).offset(skip).limit(limit).all()
    return bills

@router.get("/bills/{bill_id}", response_model=PurchaseBillResponse)
def get_purchase_bill(
    bill_id: int,
    current_user = Depends(PermissionChecker("purchases.purchase_bill", "view")),
    db: Session = Depends(get_db)
):
    """Get purchase bill details"""
    bill = db.query(PurchaseBill).filter(PurchaseBill.id == bill_id).first()
    if not bill:
        raise HTTPException(status_code=404, detail="Purchase bill not found")
    return bill

@router.post("/bills/import", response_model=BaseResponse)
async def import_purchase_bill_items(
    bill_id: int,
    file: UploadFile = File(...),
    current_user = Depends(PermissionChecker("purchases.purchase_bill", "import")),
    db: Session = Depends(get_db)
):
    """Import purchase bill items from Excel (BARCODE, QTY columns)"""
    # Validate bill exists
    bill = db.query(PurchaseBill).filter(PurchaseBill.id == bill_id).first()
    if not bill:
        raise HTTPException(status_code=404, detail="Purchase bill not found")
    
    if not file.filename.endswith(('.xlsx', '.xls')):
        raise HTTPException(status_code=400, detail="Invalid file format")
    
    content = await file.read()
    
    try:
        df = pd.read_excel(io.BytesIO(content))
        
        # Validate columns
        if 'BARCODE' not in df.columns or 'QTY' not in df.columns:
            raise ValueError("Excel must have BARCODE and QTY columns")
        
        # Group by barcode and sum quantities
        df_grouped = df.groupby('BARCODE')['QTY'].sum().reset_index()
        
        imported = 0
        errors = []
        
        for _, row in df_grouped.iterrows():
            try:
                barcode = str(row['BARCODE']).strip()
                qty = Decimal(str(row['QTY']))
                
                # Find item
                item = db.query(Item).filter(Item.barcode == barcode).first()
                if not item:
                    errors.append(f"Barcode {barcode} not found")
                    continue
                
                # Check if already exists in bill
                existing = db.query(PurchaseBillItem).filter(
                    PurchaseBillItem.purchase_bill_id == bill_id,
                    PurchaseBillItem.barcode == barcode
                ).first()
                
                if existing:
                    # Add to existing quantity
                    existing.qty += qty
                    # Recalculate amounts
                    calc = GSTCalculator.calculate_line_total_exclusive(
                        qty=existing.qty,
                        basic_rate=existing.basic_rate,
                        gst_rate=existing.gst_rate,
                        region=TaxRegion.LOCAL if bill.tax_region == LocationType.LOCAL else TaxRegion.INTER
                    )
                    existing.line_taxable = calc["line_taxable"]
                    existing.cgst_amount = calc["cgst_amount"]
                    existing.sgst_amount = calc["sgst_amount"]
                    existing.igst_amount = calc["igst_amount"]
                    existing.line_total = calc["line_total"]
                else:
                    # Create new item with default purchase rate
                    basic_rate = item.purchase_rate_basic or Decimal("0")
                    
                    calc = GSTCalculator.calculate_line_total_exclusive(
                        qty=qty,
                        basic_rate=basic_rate,
                        region=TaxRegion.LOCAL if bill.tax_region == LocationType.LOCAL else TaxRegion.INTER
                    )
                    
                    new_item = PurchaseBillItem(
                        purchase_bill_id=bill_id,
                        barcode=barcode,
                        style_code=item.style_code,
                        size=item.size,
                        hsn=item.hsn,
                        qty=qty,
                        basic_rate=basic_rate,
                        gst_rate=calc["gst_rate"],
                        cgst_rate=calc["cgst_rate"],
                        sgst_rate=calc["sgst_rate"],
                        igst_rate=calc["igst_rate"],
                        line_taxable=calc["line_taxable"],
                        cgst_amount=calc["cgst_amount"],
                        sgst_amount=calc["sgst_amount"],
                        igst_amount=calc["igst_amount"],
                        line_total=calc["line_total"],
                        mrp=item.mrp_incl
                    )
                    db.add(new_item)
                
                imported += 1
                
            except Exception as e:
                errors.append(f"Error processing {barcode}: {str(e)}")
        
        # Recalculate bill totals
        items = db.query(PurchaseBillItem).filter(
            PurchaseBillItem.purchase_bill_id == bill_id
        ).all()
        
        bill.total_taxable = sum(item.line_taxable for item in items)
        bill.total_cgst = sum(item.cgst_amount for item in items)
        bill.total_sgst = sum(item.sgst_amount for item in items)
        bill.total_igst = sum(item.igst_amount for item in items)
        bill.grand_total = bill.total_taxable + bill.total_cgst + bill.total_sgst + bill.total_igst
        
        db.commit()
        
        message = f"Imported {imported} items"
        if errors:
            message += f". Errors: {len(errors)}"
        
        return BaseResponse(
            success=True,
            message=message,
            data={"errors": errors[:10]} if errors else None
        )
        
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Error processing file: {str(e)}")

@router.get("/bills/{bill_id}/print")
def print_purchase_bill(
    bill_id: int,
    current_user = Depends(PermissionChecker("purchases.purchase_bill", "print")),
    db: Session = Depends(get_db)
):
    """Generate purchase bill PDF"""
    bill = db.query(PurchaseBill).filter(PurchaseBill.id == bill_id).first()
    if not bill:
        raise HTTPException(status_code=404, detail="Purchase bill not found")
    
    pdf_bytes = generate_purchase_bill_pdf(bill)
    
    return StreamingResponse(
        io.BytesIO(pdf_bytes),
        media_type="application/pdf",
        headers={
            "Content-Disposition": f"attachment; filename=PB_{bill.pb_no}.pdf"
        }
    )

# ============== PURCHASE RETURN ENDPOINTS ==============

@router.post("/returns", response_model=PurchaseReturnResponse)
def create_purchase_return(
    pr: PurchaseReturnCreate,
    current_user = Depends(PermissionChecker("purchases.purchase_return", "create")),
    db: Session = Depends(get_db)
):
    """Create a purchase return"""
    # Validate supplier
    supplier = db.query(Supplier).filter(Supplier.id == pr.supplier_id).first()
    if not supplier:
        raise HTTPException(status_code=404, detail="Supplier not found")
    
    # Get return series and generate number
    series = db.query(BillSeries).filter(BillSeries.id == pr.pr_series_id).first()
    if not series:
        raise HTTPException(status_code=404, detail="Return series not found")
    
    pr_no = f"{series.prefix}{str(series.next_number).zfill(series.zero_pad_width)}"
    
    # Determine tax region
    tax_region = LocationType(supplier.location_type)
    region = TaxRegion.LOCAL if tax_region == LocationType.LOCAL else TaxRegion.INTER
    
    # Create return header
    db_return = PurchaseReturn(
        pr_series_id=pr.pr_series_id,
        pr_no=pr_no,
        pr_date=pr.pr_date or datetime.now(),
        supplier_id=pr.supplier_id,
        tax_region=tax_region,
        supplier_bill_no=pr.supplier_bill_no,
        supplier_bill_date=pr.supplier_bill_date,
        reason=pr.reason,
        total_taxable=Decimal("0"),
        total_cgst=Decimal("0"),
        total_sgst=Decimal("0"),
        total_igst=Decimal("0"),
        grand_total=Decimal("0"),
        created_by=current_user.username
    )
    db.add(db_return)
    db.flush()
    
    # Process items
    total_taxable = Decimal("0")
    total_cgst = Decimal("0")
    total_sgst = Decimal("0")
    total_igst = Decimal("0")
    
    for item_data in pr.items:
        # Validate item
        item = db.query(Item).filter(Item.barcode == item_data.barcode).first()
        if not item:
            raise HTTPException(status_code=404, detail=f"Item {item_data.barcode} not found")
        
        # Check stock (optional - can be overridden)
        stock = db.query(Stock).filter(Stock.barcode == item_data.barcode).first()
        if stock and stock.qty_on_hand < item_data.qty:
            if not item_data.override_stock_check:
                raise HTTPException(
                    status_code=400,
                    detail=f"Insufficient stock for {item_data.barcode}. Available: {stock.qty_on_hand}"
                )
        
        # Calculate GST
        calc = GSTCalculator.calculate_line_total_exclusive(
            qty=item_data.qty,
            basic_rate=item_data.basic_rate,
            gst_rate=None,
            region=region
        )
        
        # Create return item
        db_item = PurchaseReturnItem(
            purchase_return_id=db_return.id,
            barcode=item_data.barcode,
            style_code=item.style_code,
            size=item.size,
            hsn=item.hsn,
            qty=item_data.qty,
            basic_rate=item_data.basic_rate,
            gst_rate=calc["gst_rate"],
            cgst_rate=calc["cgst_rate"],
            sgst_rate=calc["sgst_rate"],
            igst_rate=calc["igst_rate"],
            line_taxable=calc["line_taxable"],
            cgst_amount=calc["cgst_amount"],
            sgst_amount=calc["sgst_amount"],
            igst_amount=calc["igst_amount"],
            line_total=calc["line_total"],
            mrp=item.mrp_incl
        )
        db.add(db_item)
        
        # Decrease stock
        if stock:
            stock.qty_on_hand -= item_data.qty
        
        # Accumulate totals
        total_taxable += calc["line_taxable"]
        total_cgst += calc["cgst_amount"]
        total_sgst += calc["sgst_amount"]
        total_igst += calc["igst_amount"]
    
    # Update return totals
    db_return.total_taxable = total_taxable
    db_return.total_cgst = total_cgst
    db_return.total_sgst = total_sgst
    db_return.total_igst = total_igst
    db_return.grand_total = total_taxable + total_cgst + total_sgst + total_igst
    
    # Update series
    series.next_number += 1
    
    db.commit()
    db.refresh(db_return)
    
    return db_return

@router.get("/returns", response_model=List[PurchaseReturnResponse])
def list_purchase_returns(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=100),
    from_date: Optional[date] = None,
    to_date: Optional[date] = None,
    supplier_id: Optional[int] = None,
    current_user = Depends(PermissionChecker("purchases.purchase_return", "view")),
    db: Session = Depends(get_db)
):
    """List purchase returns"""
    query = db.query(PurchaseReturn)
    
    if from_date:
        query = query.filter(PurchaseReturn.pr_date >= from_date)
    if to_date:
        query = query.filter(PurchaseReturn.pr_date <= to_date)
    if supplier_id:
        query = query.filter(PurchaseReturn.supplier_id == supplier_id)
    
    returns = query.order_by(PurchaseReturn.pr_date.desc()).offset(skip).limit(limit).all()
    return returns

@router.get("/returns/{return_id}/print")
def print_purchase_return(
    return_id: int,
    current_user = Depends(PermissionChecker("purchases.purchase_return", "print")),
    db: Session = Depends(get_db)
):
    """Generate purchase return (debit note) PDF"""
    pr = db.query(PurchaseReturn).filter(PurchaseReturn.id == return_id).first()
    if not pr:
        raise HTTPException(status_code=404, detail="Purchase return not found")
    
    pdf_bytes = generate_purchase_return_pdf(pr)
    
    return StreamingResponse(
        io.BytesIO(pdf_bytes),
        media_type="application/pdf",
        headers={
            "Content-Disposition": f"attachment; filename=DN_{pr.pr_no}.pdf"
        }
    )