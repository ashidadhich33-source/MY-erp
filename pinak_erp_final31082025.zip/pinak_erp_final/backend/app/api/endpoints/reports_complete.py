"""
Reports module endpoints - Complete implementation
"""
from fastapi import APIRouter, Depends, Query, Response, Path
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from sqlalchemy import func, and_, or_, case, extract
from typing import List, Optional
from datetime import datetime, date, timedelta
from decimal import Decimal
import pandas as pd
import io
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter

from app.database import get_db
from app.models import (
    Sale, SaleItem, SalePayment, SaleReturn, SaleReturnItem,
    Customer, Item, Staff, Supplier, PurchaseBill, PurchaseBillItem,
    PurchaseReturn, PurchaseReturnItem, PaymentModeConfig, Expense,
    ExpenseHead, LoyaltyGrade, BillSeries
)
from app.api.deps import get_current_active_user, PermissionChecker
from app.schemas.reports_schemas import (
    SaleReturnReportRequest, SaleReturnReportResponse,
    CustomerReportRequest, CustomerReportResponse,
    HSNReportRequest, StaffReportRequest, BillWiseReportRequest,
    PaymentModeReportRequest, ExpenseReportRequest,
    PurchaseReportRequest, BaseReportResponse
)

router = APIRouter()

# ============== SALE & SALE RETURN REPORT (DETAILED) ==============

@router.post("/sale-return-detailed")
def generate_sale_return_detailed_report(
    request: SaleReturnReportRequest,
    current_user = Depends(PermissionChecker("reports.sale_return_report", "view")),
    db: Session = Depends(get_db)
):
    """
    Generate Sale & Sale Return Report (Detailed)
    As per spec: Sales positive, Returns negative
    Payment columns only on SNo=1 per Sale Bill
    """
    # Build query for sales
    sales_query = db.query(
        SaleItem.id,
        Sale.bill_date,
        Sale.bill_no,
        Staff.name.label("staff_name"),
        SaleItem.barcode,
        SaleItem.style_code,
        SaleItem.size,
        SaleItem.qty,
        SaleItem.mrp_incl,
        (SaleItem.qty * SaleItem.mrp_incl * SaleItem.disc_pct / 100).label("discount_amount"),
        SaleItem.cgst_rate,
        SaleItem.sgst_rate,
        SaleItem.igst_rate,
        SaleItem.line_inclusive.label("amount"),
        Item.brand,
        Item.purchase_rate_basic.label("basic_rate"),
        Item.gender,
        Item.category,
        Item.sub_category,
        Sale.id.label("sale_id")
    ).join(
        Sale, SaleItem.sale_id == Sale.id
    ).join(
        Item, SaleItem.barcode == Item.barcode
    ).outerjoin(
        Staff, Sale.staff_id == Staff.id
    )
    
    # Apply filters
    if request.from_date:
        sales_query = sales_query.filter(Sale.bill_date >= request.from_date)
    if request.to_date:
        sales_query = sales_query.filter(Sale.bill_date <= request.to_date)
    if request.item_filter:
        sales_query = sales_query.filter(Item.style_code.contains(request.item_filter))
    if request.brand_filter:
        sales_query = sales_query.filter(Item.brand == request.brand_filter)
    if request.series_filter:
        sales_query = sales_query.filter(Sale.series_id == request.series_filter)
    if request.staff_filter:
        sales_query = sales_query.filter(Sale.staff_id == request.staff_filter)
    
    sales_data = sales_query.order_by(Sale.bill_date, Sale.bill_no).all()
    
    # Build query for returns (negative values)
    returns_query = db.query(
        SaleReturnItem.id,
        SaleReturn.sr_date.label("bill_date"),
        SaleReturn.sr_no.label("bill_no"),
        func.literal("RETURN").label("staff_name"),
        SaleReturnItem.barcode,
        SaleReturnItem.style_code,
        SaleReturnItem.size,
        (-SaleReturnItem.return_qty).label("qty"),  # Negative
        SaleReturnItem.unit_mrp_incl.label("mrp_incl"),
        (-SaleReturnItem.return_qty * SaleReturnItem.unit_mrp_incl * 
         SaleReturnItem.disc_pct_at_sale / 100).label("discount_amount"),  # Negative
        (SaleReturnItem.gst_rate / 2).label("cgst_rate"),
        (SaleReturnItem.gst_rate / 2).label("sgst_rate"),
        func.literal(0).label("igst_rate"),
        (-SaleReturnItem.line_inclusive).label("amount"),  # Negative
        Item.brand,
        Item.purchase_rate_basic.label("basic_rate"),
        Item.gender,
        Item.category,
        Item.sub_category,
        func.literal(None).label("sale_id")
    ).join(
        SaleReturn, SaleReturnItem.sale_return_id == SaleReturn.id
    ).join(
        Item, SaleReturnItem.barcode == Item.barcode
    )
    
    # Apply same filters for returns
    if request.from_date:
        returns_query = returns_query.filter(SaleReturn.sr_date >= request.from_date)
    if request.to_date:
        returns_query = returns_query.filter(SaleReturn.sr_date <= request.to_date)
    if request.item_filter:
        returns_query = returns_query.filter(Item.style_code.contains(request.item_filter))
    if request.brand_filter:
        returns_query = returns_query.filter(Item.brand == request.brand_filter)
    
    returns_data = returns_query.all()
    
    # Combine and format data
    report_data = []
    
    # Process sales
    current_bill_no = None
    sno_within_bill = 0
    
    for row in sales_data:
        if row.bill_no != current_bill_no:
            current_bill_no = row.bill_no
            sno_within_bill = 1
            # Get payment details for first line of bill
            payments = db.query(SalePayment).join(
                PaymentModeConfig
            ).filter(
                SalePayment.sale_id == row.sale_id
            ).all()
            
            cash_amount = sum(p.amount for p in payments 
                            if p.payment_mode.name.upper() == "CASH")
            card_amount = sum(p.amount for p in payments 
                            if p.payment_mode.name.upper() in ["CARD", "CREDIT CARD", "DEBIT CARD"])
            other_amount = sum(p.amount for p in payments 
                             if p.payment_mode.name.upper() not in ["CASH", "CARD", "CREDIT CARD", "DEBIT CARD"])
        else:
            sno_within_bill += 1
            cash_amount = 0
            card_amount = 0
            other_amount = 0
        
        report_data.append({
            "bill_date": row.bill_date.strftime("%d-%m-%Y"),
            "sno": sno_within_bill,
            "bill_no": row.bill_no,
            "staff": row.staff_name or "-",
            "barcode": row.barcode,
            "style_code": row.style_code,
            "size": row.size or "-",
            "qty": float(row.qty),
            "mrp": float(row.mrp_incl),
            "discount_amount": float(row.discount_amount),
            "cgst": float(row.cgst_rate),
            "sgst": float(row.sgst_rate) if row.sgst_rate else float(row.igst_rate),
            "amount": float(row.amount),
            "brand": row.brand or "-",
            "basic_rate": float(row.basic_rate) if row.basic_rate else 0,
            "gender": row.gender or "-",
            "category": row.category or "-",
            "sub_category": row.sub_category or "-",
            "cash": float(cash_amount) if sno_within_bill == 1 else 0,
            "card": float(card_amount) if sno_within_bill == 1 else 0,
            "other": float(other_amount) if sno_within_bill == 1 else 0
        })
    
    # Process returns (all negative values)
    for row in returns_data:
        report_data.append({
            "bill_date": row.bill_date.strftime("%d-%m-%Y"),
            "sno": 1,
            "bill_no": row.bill_no,
            "staff": "RETURN",
            "barcode": row.barcode,
            "style_code": row.style_code,
            "size": row.size or "-",
            "qty": float(row.qty),  # Already negative
            "mrp": float(row.mrp_incl),
            "discount_amount": float(row.discount_amount),  # Already negative
            "cgst": float(row.cgst_rate),
            "sgst": float(row.sgst_rate),
            "amount": float(row.amount),  # Already negative
            "brand": row.brand or "-",
            "basic_rate": float(row.basic_rate) if row.basic_rate else 0,
            "gender": row.gender or "-",
            "category": row.category or "-",
            "sub_category": row.sub_category or "-",
            "cash": 0,
            "card": 0,
            "other": 0
        })
    
    # Sort by date and bill number
    report_data.sort(key=lambda x: (x["bill_date"], x["bill_no"]))
    
    # Generate Excel if requested
    if request.export_format == "excel":
        return export_sale_return_report_excel(report_data)
    
    return {
        "success": True,
        "data": report_data,
        "summary": {
            "total_sales": sum(r["amount"] for r in report_data if r["amount"] > 0),
            "total_returns": sum(r["amount"] for r in report_data if r["amount"] < 0),
            "net_sales": sum(r["amount"] for r in report_data),
            "total_cash": sum(r["cash"] for r in report_data),
            "total_card": sum(r["card"] for r in report_data),
            "total_other": sum(r["other"] for r in report_data)
        }
    }

def export_sale_return_report_excel(data):
    """Export Sale & Return report to Excel"""
    wb = Workbook()
    ws = wb.active
    ws.title = "Sale Return Report"
    
    # Headers
    headers = [
        "BILL DATE", "SNo", "BILL NO", "STAFF", "BARCODE", "STYLE CODE",
        "SIZE", "QTY", "MRP", "DISCOUNT AMOUNT", "CGST", "SGST/IGST",
        "AMOUNT", "BRAND", "BASIC RATE", "GENDER", "CATEGORY", "SUB CATEGORY",
        "CASH", "CARD", "OTHER PAYMENT MODE"
    ]
    
    # Style for headers
    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
    
    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.font = header_font
        cell.fill = header_fill
    
    # Data rows
    for row_idx, row_data in enumerate(data, 2):
        ws.cell(row=row_idx, column=1, value=row_data["bill_date"])
        ws.cell(row=row_idx, column=2, value=row_data["sno"])
        ws.cell(row=row_idx, column=3, value=row_data["bill_no"])
        ws.cell(row=row_idx, column=4, value=row_data["staff"])
        ws.cell(row=row_idx, column=5, value=row_data["barcode"])
        ws.cell(row=row_idx, column=6, value=row_data["style_code"])
        ws.cell(row=row_idx, column=7, value=row_data["size"])
        ws.cell(row=row_idx, column=8, value=row_data["qty"])
        ws.cell(row=row_idx, column=9, value=row_data["mrp"])
        ws.cell(row=row_idx, column=10, value=row_data["discount_amount"])
        ws.cell(row=row_idx, column=11, value=row_data["cgst"])
        ws.cell(row=row_idx, column=12, value=row_data["sgst"])
        ws.cell(row=row_idx, column=13, value=row_data["amount"])
        ws.cell(row=row_idx, column=14, value=row_data["brand"])
        ws.cell(row=row_idx, column=15, value=row_data["basic_rate"])
        ws.cell(row=row_idx, column=16, value=row_data["gender"])
        ws.cell(row=row_idx, column=17, value=row_data["category"])
        ws.cell(row=row_idx, column=18, value=row_data["sub_category"])
        ws.cell(row=row_idx, column=19, value=row_data["cash"])
        ws.cell(row=row_idx, column=20, value=row_data["card"])
        ws.cell(row=row_idx, column=21, value=row_data["other"])
    
    # Auto-adjust column widths
    for column in ws.columns:
        max_length = 0
        column_letter = get_column_letter(column[0].column)
        for cell in column:
            if cell.value:
                max_length = max(max_length, len(str(cell.value)))
        ws.column_dimensions[column_letter].width = min(max_length + 2, 50)
    
    # Save to BytesIO
    output = io.BytesIO()
    wb.save(output)
    output.seek(0)
    
    return StreamingResponse(
        output,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={
            "Content-Disposition": f"attachment; filename=sale_return_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
        }
    )

# ============== CUSTOMER REPORTS ==============

@router.post("/customer-report")
def generate_customer_report(
    request: CustomerReportRequest,
    current_user = Depends(PermissionChecker("reports.customer_report", "view")),
    db: Session = Depends(get_db)
):
    """Generate customer report with filters"""
    query = db.query(Customer).outerjoin(LoyaltyGrade)
    
    # Apply filters
    if request.loyalty_grade_id:
        query = query.filter(Customer.loyalty_grade_id == request.loyalty_grade_id)
    if request.min_lifetime_purchase:
        query = query.filter(Customer.lifetime_purchase >= request.min_lifetime_purchase)
    if request.has_kids:
        query = query.filter(
            or_(
                Customer.kid1_name != None,
                Customer.kid2_name != None,
                Customer.kid3_name != None
            )
        )
    
    customers = query.all()
    
    report_data = []
    for customer in customers:
        report_data.append({
            "mobile": customer.mobile,
            "name": customer.name,
            "email": customer.email or "-",
            "city": customer.city or "-",
            "lifetime_purchase": float(customer.lifetime_purchase),
            "points_balance": float(customer.points_balance),
            "loyalty_grade": customer.loyalty_grade.name if customer.loyalty_grade else "-",
            "last_visit": customer.last_visit_date.strftime("%d-%m-%Y") if customer.last_visit_date else "-",
            "kids": sum(1 for k in [customer.kid1_name, customer.kid2_name, customer.kid3_name] if k)
        })
    
    if request.export_format == "excel":
        return export_customer_report_excel(report_data)
    
    return {
        "success": True,
        "data": report_data,
        "total_customers": len(report_data),
        "total_lifetime_value": sum(c["lifetime_purchase"] for c in report_data)
    }

@router.post("/customer-wise-sale")
def generate_customer_wise_sale_report(
    request: CustomerReportRequest,
    current_user = Depends(PermissionChecker("reports.customer_wise_sale", "view")),
    db: Session = Depends(get_db)
):
    """Generate customer-wise sale summary"""
    query = db.query(
        Customer.mobile,
        Customer.name,
        func.count(Sale.id).label("total_bills"),
        func.sum(Sale.final_payable).label("total_amount"),
        func.max(Sale.bill_date).label("last_purchase")
    ).join(
        Sale, Customer.mobile == Sale.customer_mobile
    ).group_by(Customer.mobile, Customer.name)
    
    if request.from_date:
        query = query.filter(Sale.bill_date >= request.from_date)
    if request.to_date:
        query = query.filter(Sale.bill_date <= request.to_date)
    
    results = query.all()
    
    report_data = []
    for row in results:
        report_data.append({
            "mobile": row.mobile,
            "name": row.name,
            "total_bills": row.total_bills,
            "total_amount": float(row.total_amount),
            "last_purchase": row.last_purchase.strftime("%d-%m-%Y"),
            "avg_bill_value": float(row.total_amount / row.total_bills)
        })
    
    if request.export_format == "excel":
        return export_customer_wise_sale_excel(report_data)
    
    return {
        "success": True,
        "data": report_data
    }

@router.get("/inactive-customers/{months}")
def get_inactive_customers(
    months: int = Path(..., ge=3, le=12),  # Changed from Query to Path
    current_user = Depends(PermissionChecker("reports", "view")),
    db: Session = Depends(get_db)
):
    """Get customers inactive for specified months (3, 6, or 12)"""
    cutoff_date = datetime.now() - timedelta(days=months * 30)
    
    customers = db.query(Customer).filter(
        or_(
            Customer.last_visit_date < cutoff_date,
            Customer.last_visit_date == None
        )
    ).all()
    
    return {
        "success": True,
        "inactive_months": months,
        "customers": [
            {
                "mobile": c.mobile,
                "name": c.name,
                "email": c.email,
                "last_visit": c.last_visit_date.strftime("%d-%m-%Y") if c.last_visit_date else "Never",
                "lifetime_purchase": float(c.lifetime_purchase),
                "points_balance": float(c.points_balance)
            }
            for c in customers
        ],
        "total_count": len(customers)
    }

@router.get("/kids-birthday/{period}")
def get_kids_birthday_report(
    period: str = Path(..., pattern=r'^(current|next)$'),
    current_user = Depends(PermissionChecker("reports", "view")),
    db: Session = Depends(get_db)
):
    """Get kids' birthday report for current or next month"""
    current_month = datetime.now().month
    target_month = current_month if period == "current" else (current_month % 12) + 1
    
    # Query customers with kids having birthday in target month
    customers_with_birthdays = []
    
    customers = db.query(Customer).filter(
        or_(
            Customer.kid1_dob != None,
            Customer.kid2_dob != None,
            Customer.kid3_dob != None
        )
    ).all()
    
    for customer in customers:
        kids_birthdays = []
        
        if customer.kid1_dob and customer.kid1_dob.month == target_month:
            kids_birthdays.append({
                "name": customer.kid1_name,
                "dob": customer.kid1_dob.strftime("%d-%m-%Y"),
                "day": customer.kid1_dob.day
            })
        
        if customer.kid2_dob and customer.kid2_dob.month == target_month:
            kids_birthdays.append({
                "name": customer.kid2_name,
                "dob": customer.kid2_dob.strftime("%d-%m-%Y"),
                "day": customer.kid2_dob.day
            })
        
        if customer.kid3_dob and customer.kid3_dob.month == target_month:
            kids_birthdays.append({
                "name": customer.kid3_name,
                "dob": customer.kid3_dob.strftime("%d-%m-%Y"),
                "day": customer.kid3_dob.day
            })
        
        if kids_birthdays:
            customers_with_birthdays.append({
                "customer_mobile": customer.mobile,
                "customer_name": customer.name,
                "customer_email": customer.email,
                "kids": kids_birthdays
            })
    
    return {
        "success": True,
        "period": period,
        "month": target_month,
        "data": customers_with_birthdays,
        "total_birthdays": sum(len(c["kids"]) for c in customers_with_birthdays)
    }

# ============== HSN WISE SALE REPORT ==============

@router.post("/hsn-wise-sale")
def generate_hsn_wise_sale_report(
    request: HSNReportRequest,
    current_user = Depends(PermissionChecker("reports.hsn_wise_sale", "view")),
    db: Session = Depends(get_db)
):
    """Generate HSN-wise sale report"""
    query = db.query(
        SaleItem.hsn,
        func.sum(SaleItem.qty).label("total_qty"),
        func.sum(SaleItem.line_inclusive).label("total_amount"),
        func.sum(SaleItem.base_excl).label("total_taxable"),
        func.sum(SaleItem.tax_amt_info).label("total_tax")
    ).join(Sale).filter(
        SaleItem.hsn != None
    ).group_by(SaleItem.hsn)
    
    if request.from_date:
        query = query.filter(Sale.bill_date >= request.from_date)
    if request.to_date:
        query = query.filter(Sale.bill_date <= request.to_date)
    
    results = query.all()
    
    report_data = []
    for row in results:
        report_data.append({
            "hsn": row.hsn,
            "total_qty": float(row.total_qty),
            "total_amount": float(row.total_amount),
            "total_taxable": float(row.total_taxable),
            "total_tax": float(row.total_tax),
            "avg_tax_rate": float((row.total_tax / row.total_taxable * 100)) if row.total_taxable else 0
        })
    
    if request.export_format == "excel":
        return export_hsn_report_excel(report_data)
    
    return {
        "success": True,
        "data": report_data
    }

# ============== STAFF WISE SALE REPORT ==============

@router.post("/staff-wise-sale")
def generate_staff_wise_sale_report(
    request: StaffReportRequest,
    current_user = Depends(PermissionChecker("reports.staff_wise_sale", "view")),
    db: Session = Depends(get_db)
):
    """Generate staff-wise sale report with targets"""
    query = db.query(
        Staff.id,
        Staff.code,
        Staff.name,
        Staff.target_amount,
        func.count(Sale.id).label("total_bills"),
        func.sum(Sale.final_payable).label("total_sales"),
        func.sum(Sale.earned_points).label("points_given")
    ).outerjoin(
        Sale, Staff.id == Sale.staff_id
    ).group_by(Staff.id)
    
    if request.from_date:
        query = query.filter(Sale.bill_date >= request.from_date)
    if request.to_date:
        query = query.filter(Sale.bill_date <= request.to_date)
    if request.active_only:
        query = query.filter(Staff.active == True)
    
    results = query.all()
    
    report_data = []
    for row in results:
        achievement_pct = 0
        if row.target_amount and row.total_sales:
            achievement_pct = float((row.total_sales / row.target_amount) * 100)
        
        report_data.append({
            "staff_id": row.id,
            "staff_code": row.code,
            "staff_name": row.name,
            "target_amount": float(row.target_amount) if row.target_amount else 0,
            "total_bills": row.total_bills or 0,
            "total_sales": float(row.total_sales) if row.total_sales else 0,
            "achievement_pct": achievement_pct,
            "points_given": float(row.points_given) if row.points_given else 0
        })
    
    if request.export_format == "excel":
        return export_staff_report_excel(report_data)
    
    return {
        "success": True,
        "data": report_data
    }

# ============== Helper Functions for Excel Export ==============

def export_customer_report_excel(data):
    """Export customer report to Excel"""
    df = pd.DataFrame(data)
    output = io.BytesIO()
    
    with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
        df.to_excel(writer, sheet_name='Customer Report', index=False)
        
        workbook = writer.book
        worksheet = writer.sheets['Customer Report']
        
        # Format columns
        money_format = workbook.add_format({'num_format': '₹#,##0.00'})
        worksheet.set_column('E:E', 15, money_format)  # lifetime_purchase
        worksheet.set_column('F:F', 12, money_format)  # points_balance
    
    output.seek(0)
    
    return StreamingResponse(
        output,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={
            "Content-Disposition": f"attachment; filename=customer_report_{datetime.now().strftime('%Y%m%d')}.xlsx"
        }
    )

def export_customer_wise_sale_excel(data):
    """Export customer-wise sale to Excel"""
    df = pd.DataFrame(data)
    output = io.BytesIO()
    
    with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
        df.to_excel(writer, sheet_name='Customer Sales', index=False)
    
    output.seek(0)
    
    return StreamingResponse(
        output,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={
            "Content-Disposition": f"attachment; filename=customer_wise_sale_{datetime.now().strftime('%Y%m%d')}.xlsx"
        }
    )

def export_hsn_report_excel(data):
    """Export HSN report to Excel"""
    df = pd.DataFrame(data)
    output = io.BytesIO()
    
    with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
        df.to_excel(writer, sheet_name='HSN Report', index=False)
    
    output.seek(0)
    
    return StreamingResponse(
        output,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={
            "Content-Disposition": f"attachment; filename=hsn_report_{datetime.now().strftime('%Y%m%d')}.xlsx"
        }
    )

def export_staff_report_excel(data):
    """Export staff report to Excel"""
    df = pd.DataFrame(data)
    output = io.BytesIO()
    
    with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
        df.to_excel(writer, sheet_name='Staff Report', index=False)
    
    output.seek(0)
    
    return StreamingResponse(
        output,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={
            "Content-Disposition": f"attachment; filename=staff_report_{datetime.now().strftime('%Y%m%d')}.xlsx"
        }
    )