"""
Items management endpoints
"""
from fastapi import APIRouter, Depends, HTTPException, status, Query, UploadFile, File
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from typing import List, Optional
import pandas as pd
import io
from datetime import datetime

from app.database import get_db
from app.models import Item, Stock
from app.schemas.base_schemas import (
    BaseResponse, ItemCreate, ItemUpdate, ItemResponse,
    ItemImportRequest, ItemImportResponse, StockUpdate,
    StockResponse, OpeningStockRequest
)
from app.api.deps import get_current_active_user, PermissionChecker
from app.services.excel_service import parse_excel_items, export_items_to_excel

router = APIRouter()

# ============== ITEM MASTER ENDPOINTS ==============

@router.post("/", response_model=ItemResponse)
def create_item(
    item: ItemCreate,
    current_user = Depends(PermissionChecker("setup.item_master.create_item", "create")),
    db: Session = Depends(get_db)
):
    """Create a new item"""
    # Check if barcode exists
    existing = db.query(Item).filter(Item.barcode == item.barcode).first()
    if existing:
        raise HTTPException(status_code=400, detail="Barcode already exists")
    
    # Create item
    db_item = Item(
        **item.dict(),
        status="active",
        created_by=current_user.username
    )
    db.add(db_item)
    
    # Create stock entry
    db_stock = Stock(
        barcode=item.barcode,
        qty_on_hand=0,
        last_purchase_rate=item.purchase_rate_basic
    )
    db.add(db_stock)
    
    db.commit()
    db.refresh(db_item)
    
    # Add stock info to response
    db_item.stock_qty = 0
    return db_item

@router.get("/", response_model=List[ItemResponse])
def list_items(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    search: Optional[str] = None,
    brand: Optional[str] = None,
    category: Optional[str] = None,
    status: Optional[str] = None,
    current_user = Depends(PermissionChecker("setup.item_master.create_item", "view")),
    db: Session = Depends(get_db)
):
    """List items with filters"""
    query = db.query(Item).join(Stock, isouter=True)
    
    # Apply filters
    if search:
        query = query.filter(
            (Item.barcode.contains(search)) |
            (Item.style_code.contains(search))
        )
    if brand:
        query = query.filter(Item.brand == brand)
    if category:
        query = query.filter(Item.category == category)
    if status:
        query = query.filter(Item.status == status)
    
    items = query.offset(skip).limit(limit).all()
    
    # Add stock quantity to response
    for item in items:
        item.stock_qty = item.stock.qty_on_hand if item.stock else 0
    
    return items

@router.get("/barcode/{barcode}", response_model=ItemResponse)
def get_item_by_barcode(
    barcode: str,
    current_user = Depends(PermissionChecker("setup.item_master.create_item", "view")),
    db: Session = Depends(get_db)
):
    """Get item by barcode"""
    item = db.query(Item).filter(Item.barcode == barcode).first()
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    
    item.stock_qty = item.stock.qty_on_hand if item.stock else 0
    return item

@router.put("/barcode/{barcode}", response_model=ItemResponse)
def update_item(
    barcode: str,
    item_update: ItemUpdate,
    current_user = Depends(PermissionChecker("setup.item_master.create_item", "edit")),
    db: Session = Depends(get_db)
):
    """Update item details"""
    item = db.query(Item).filter(Item.barcode == barcode).first()
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    
    update_data = item_update.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(item, field, value)
    
    item.updated_by = current_user.username
    db.commit()
    db.refresh(item)
    
    item.stock_qty = item.stock.qty_on_hand if item.stock else 0
    return item

# ============== EXCEL IMPORT/EXPORT ==============

@router.post("/import/excel", response_model=ItemImportResponse)
async def import_items_excel(
    file: UploadFile = File(...),
    current_user = Depends(PermissionChecker("setup.item_master.create_item", "import")),
    db: Session = Depends(get_db)
):
    """Import items from Excel file"""
    if not file.filename.endswith(('.xlsx', '.xls')):
        raise HTTPException(status_code=400, detail="Invalid file format. Use .xlsx or .xls")
    
    # Read file content
    content = await file.read()
    
    try:
        # Parse Excel
        items_data = parse_excel_items(content)
        
        created = 0
        updated = 0
        errors = []
        
        for idx, item_data in enumerate(items_data, 1):
            try:
                # Check if barcode exists
                existing = db.query(Item).filter(Item.barcode == item_data['barcode']).first()
                
                if existing:
                    # Update existing item
                    for field, value in item_data.items():
                        if field != 'barcode' and value is not None:
                            setattr(existing, field, value)
                    existing.updated_by = current_user.username
                    updated += 1
                else:
                    # Create new item
                    new_item = Item(
                        **item_data,
                        status="active",
                        created_by=current_user.username
                    )
                    db.add(new_item)
                    
                    # Create stock entry
                    new_stock = Stock(
                        barcode=item_data['barcode'],
                        qty_on_hand=0
                    )
                    db.add(new_stock)
                    created += 1
                    
            except Exception as e:
                errors.append({
                    "row": idx,
                    "barcode": item_data.get('barcode'),
                    "error": str(e)
                })
        
        db.commit()
        
        return ItemImportResponse(
            created=created,
            updated=updated,
            errors=errors
        )
        
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Error processing file: {str(e)}")

@router.get("/export/excel")
def export_items_excel(
    current_user = Depends(PermissionChecker("setup.item_master.create_item", "export")),
    db: Session = Depends(get_db)
):
    """Export items to Excel"""
    items = db.query(Item).all()
    
    # Convert to DataFrame
    data = []
    for item in items:
        data.append({
            "barcode": item.barcode,
            "style_code": item.style_code,
            "color": item.color,
            "size": item.size,
            "hsn": item.hsn,
            "mrp_incl": float(item.mrp_incl) if item.mrp_incl else 0,
            "purchase_rate_basic": float(item.purchase_rate_basic) if item.purchase_rate_basic else 0,
            "brand": item.brand,
            "gender": item.gender,
            "category": item.category,
            "sub_category": item.sub_category,
            "status": item.status,
            "stock_qty": float(item.stock.qty_on_hand) if item.stock else 0
        })
    
    df = pd.DataFrame(data)
    
    # Create Excel file
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
        df.to_excel(writer, sheet_name='Items', index=False)
    
    output.seek(0)
    
    return StreamingResponse(
        output,
        media_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        headers={"Content-Disposition": f"attachment; filename=items_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"}
    )

@router.get("/export/sample")
def export_sample_excel(
    current_user = Depends(get_current_active_user)
):
    """Export sample Excel template for import"""
    # Create sample data
    sample_data = {
        "barcode": ["ABC123", "DEF456"],
        "style_code": ["STYLE001", "STYLE002"],
        "color": ["Red", "Blue"],
        "size": ["M", "L"],
        "hsn": ["6109", "6109"],
        "mrp_incl": [999.00, 1499.00],
        "purchase_rate_basic": [450.00, 700.00],
        "brand": ["Brand A", "Brand B"],
        "gender": ["Male", "Female"],
        "category": ["Shirt", "Dress"],
        "sub_category": ["Casual", "Party"]
    }
    
    df = pd.DataFrame(sample_data)
    
    # Create Excel file
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
        df.to_excel(writer, sheet_name='Sample Items', index=False)
        
        # Add instructions sheet
        instructions = pd.DataFrame({
            "Instructions": [
                "1. Barcode is mandatory and must be unique",
                "2. Style Code is mandatory",
                "3. MRP (inclusive) is mandatory",
                "4. Other fields are optional",
                "5. Do not change column names",
                "6. Delete sample data before importing actual data"
            ]
        })
        instructions.to_excel(writer, sheet_name='Instructions', index=False)
    
    output.seek(0)
    
    return StreamingResponse(
        output,
        media_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        headers={"Content-Disposition": "attachment; filename=items_import_template.xlsx"}
    )

# ============== STOCK MANAGEMENT ==============

@router.post("/stock/opening", response_model=BaseResponse)
def update_opening_stock(
    request: OpeningStockRequest,
    current_user = Depends(PermissionChecker("setup.item_master.inventory_mgmt.opening_stock", "create")),
    db: Session = Depends(get_db)
):
    """Update opening stock for items"""
    updated = 0
    errors = []
    
    for stock_update in request.stocks:
        try:
            # Find item
            item = db.query(Item).filter(Item.barcode == stock_update.barcode).first()
            if not item:
                errors.append(f"Barcode {stock_update.barcode} not found")
                continue
            
            # Update stock
            stock = db.query(Stock).filter(Stock.barcode == stock_update.barcode).first()
            if not stock:
                stock = Stock(barcode=stock_update.barcode)
                db.add(stock)
            
            stock.qty_on_hand = stock_update.qty
            updated += 1
            
        except Exception as e:
            errors.append(f"Error updating {stock_update.barcode}: {str(e)}")
    
    db.commit()
    
    message = f"Updated {updated} items"
    if errors:
        message += f". Errors: {', '.join(errors)}"
    
    return BaseResponse(
        success=True if updated > 0 else False,
        message=message
    )

@router.post("/stock/import/excel", response_model=BaseResponse)
async def import_opening_stock_excel(
    file: UploadFile = File(...),
    current_user = Depends(PermissionChecker("setup.item_master.inventory_mgmt.opening_stock", "import")),
    db: Session = Depends(get_db)
):
    """Import opening stock from Excel (BARCODE, QTY columns)"""
    if not file.filename.endswith(('.xlsx', '.xls')):
        raise HTTPException(status_code=400, detail="Invalid file format. Use .xlsx or .xls")
    
    content = await file.read()
    
    try:
        df = pd.read_excel(io.BytesIO(content))
        
        # Validate columns
        if 'BARCODE' not in df.columns or 'QTY' not in df.columns:
            raise ValueError("Excel must have BARCODE and QTY columns")
        
        updated = 0
        errors = []
        
        for idx, row in df.iterrows():
            try:
                barcode = str(row['BARCODE']).strip()
                qty = float(row['QTY'])
                
                # Find item
                item = db.query(Item).filter(Item.barcode == barcode).first()
                if not item:
                    errors.append(f"Row {idx+2}: Barcode {barcode} not found")
                    continue
                
                # Update stock
                stock = db.query(Stock).filter(Stock.barcode == barcode).first()
                if not stock:
                    stock = Stock(barcode=barcode)
                    db.add(stock)
                
                stock.qty_on_hand = qty
                updated += 1
                
            except Exception as e:
                errors.append(f"Row {idx+2}: {str(e)}")
        
        db.commit()
        
        message = f"Imported {updated} rows - Total QTY updated"
        if errors:
            message += f". Errors: {len(errors)}"
        
        return BaseResponse(
            success=True if updated > 0 else False,
            message=message,
            data={"errors": errors[:10]} if errors else None
        )
        
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Error processing file: {str(e)}")

@router.get("/stock", response_model=List[StockResponse])
def get_stock_status(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    low_stock_only: bool = Query(False),
    current_user = Depends(PermissionChecker("setup.item_master.inventory_mgmt", "view")),
    db: Session = Depends(get_db)
):
    """Get stock status"""
    query = db.query(Stock).join(Item)
    
    if low_stock_only:
        query = query.filter(Stock.qty_on_hand < 10)  # Configurable threshold
    
    stocks = query.offset(skip).limit(limit).all()
    return stocks