"""
Complete setup module endpoints - All master data management
FIXED VERSION with proper routing and error handling
"""
from fastapi import APIRouter, Depends, HTTPException, status, Query, UploadFile, File
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import List, Optional, Dict, Any  # Added Dict and Any
from datetime import datetime, timedelta
import pandas as pd  # Added for Excel handling
import io  # Added for file handling
import random
import string

from app.database import get_db
from app.models import (
    Item, Stock,  # Added Item and Stock models
    LoyaltyGrade, Coupon, BillSeries, Staff, ExpenseHead,
    PaymentModeConfig, WhatsAppConfig, Customer, User,
    # Add these for stock movements endpoint:
    Sale, SaleItem,
    PurchaseBill, PurchaseBillItem,
    SaleReturn, SaleReturnItem
)
from app.api.deps import get_current_active_user, require_admin, PermissionChecker
from app.schemas.setup_schemas import (
    LoyaltyGradeCreate, LoyaltyGradeUpdate, LoyaltyGradeResponse,
    CouponCreate, CouponUpdate, CouponResponse,
    BillSeriesCreate, BillSeriesUpdate, BillSeriesResponse,
    StaffCreate, StaffUpdate, StaffResponse,
    ExpenseHeadCreate, ExpenseHeadResponse,
    PaymentModeCreate, PaymentModeUpdate, PaymentModeResponse,
    WhatsAppConfigCreate, WhatsAppConfigResponse,
    BaseResponse
)

router = APIRouter()

# ============== OPENING STOCK ENDPOINTS ==============

@router.get("/opening-stock")
def get_opening_stock(
    skip: int = Query(0, ge=0),
    limit: int = Query(5000, ge=1, le=10000),
    search: Optional[str] = None,
    current_user = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Get all items with their current stock for opening stock management"""
    try:
        # Count total items first
        total_items = db.query(Item).count()
        
        if total_items == 0:
            return {
                "success": True,
                "items": [],
                "total": 0,
                "message": "No items found. Please create items in Item Master first."
            }
        
        # Get all items
        query = db.query(Item)
        
        # Apply search filter if provided
        if search and search.strip():
            search_filter = f"%{search.strip()}%"
            query = query.filter(
                (Item.barcode.ilike(search_filter)) |
                (Item.style_code.ilike(search_filter)) |
                (Item.brand.ilike(search_filter)) |
                (Item.color.ilike(search_filter)) |
                (Item.size.ilike(search_filter))
            )
        
        # Get items with pagination
        items_list = query.offset(skip).limit(limit).all()
        
        # Format response
        result_items = []
        for item in items_list:
            # Get stock for this item
            stock = db.query(Stock).filter(Stock.barcode == item.barcode).first()
            
            item_dict = {
                "barcode": item.barcode,
                "style_code": item.style_code or "",
                "color": item.color or "",
                "size": item.size or "",
                "brand": item.brand or "",
                "category": item.category or "",
                "sub_category": item.sub_category or "",
                "hsn": item.hsn or "",
                "mrp_incl": float(item.mrp_incl) if item.mrp_incl else 0.0,
                "purchase_rate_basic": float(item.purchase_rate_basic) if item.purchase_rate_basic else 0.0,
                "qty": int(stock.qty_on_hand) if stock and stock.qty_on_hand else 0
            }
            
            result_items.append(item_dict)
        
        return {
            "success": True,
            "items": result_items,
            "total": len(result_items)
        }
        
    except Exception as e:
        print(f"[ERROR] in get_opening_stock: {str(e)}")
        return {
            "success": False,
            "items": [],
            "total": 0,
            "error": str(e)
        }

@router.post("/opening-stock/bulk-update")
def bulk_update_opening_stock(
    request: Dict[str, Any],
    current_user = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Bulk update opening stock quantities"""
    try:
        updates = request.get("updates", [])
        
        if not updates:
            return {
                "success": False,
                "message": "No updates provided"
            }
        
        updated_count = 0
        created_count = 0
        errors = []
        
        for update in updates:
            try:
                barcode = update.get("barcode")
                qty = int(update.get("qty", 0))
                
                if not barcode:
                    errors.append("Missing barcode in update")
                    continue
                
                # Verify item exists
                item = db.query(Item).filter(Item.barcode == barcode).first()
                if not item:
                    errors.append(f"Item with barcode {barcode} not found")
                    continue
                
                # Check if stock record exists
                stock = db.query(Stock).filter(Stock.barcode == barcode).first()
                
                if not stock:
                    # Create new stock record
                    stock = Stock(
                        barcode=barcode,
                        qty_on_hand=qty,
                        last_purchase_date=datetime.now(),
                        last_purchase_rate=float(item.purchase_rate_basic) if item.purchase_rate_basic else 0.0,
                        created_by=current_user.username,
                        created_at=datetime.now()
                    )
                    db.add(stock)
                    created_count += 1
                else:
                    # Update existing stock
                    stock.qty_on_hand = qty
                    stock.last_updated = datetime.now()
                    stock.updated_by = current_user.username
                    updated_count += 1
                
            except Exception as e:
                errors.append(f"Error updating {barcode}: {str(e)}")
        
        # Commit all changes
        db.commit()
        
        total_processed = updated_count + created_count
        message = f"Successfully processed {total_processed} items "
        message += f"({created_count} created, {updated_count} updated)"
        
        if errors:
            message += f". {len(errors)} errors occurred"
        
        return {
            "success": total_processed > 0,
            "message": message,
            "data": {"errors": errors[:5]} if errors else None
        }
        
    except Exception as e:
        db.rollback()
        return {
            "success": False,
            "message": f"Failed to update stock: {str(e)}"
        }

@router.post("/opening-stock/import")
async def import_opening_stock_excel(
    file: UploadFile = File(...),
    current_user = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Import opening stock from Excel file"""
    if not file.filename.endswith(('.xlsx', '.xls')):
        raise HTTPException(status_code=400, detail="Invalid file format. Use .xlsx or .xls")
    
    try:
        content = await file.read()
        
        # Read Excel file
        df = pd.read_excel(io.BytesIO(content))
        
        # Convert column names to uppercase for consistency
        df.columns = df.columns.str.strip().str.upper()
        
        # Check for required columns
        if 'BARCODE' not in df.columns or 'QTY' not in df.columns:
            return {
                "success": False,
                "message": "Excel file must have BARCODE and QTY columns"
            }
        
        updated_count = 0
        created_count = 0
        errors = []
        
        # Process each row
        for idx, row in df.iterrows():
            try:
                barcode = str(row['BARCODE']).strip() if pd.notna(row['BARCODE']) else None
                qty = int(float(row['QTY'])) if pd.notna(row['QTY']) else 0
                
                if not barcode:
                    errors.append(f"Row {idx+2}: Missing barcode")
                    continue
                
                # Check if item exists
                item = db.query(Item).filter(Item.barcode == barcode).first()
                if not item:
                    errors.append(f"Row {idx+2}: Barcode '{barcode}' not found")
                    continue
                
                # Update or create stock
                stock = db.query(Stock).filter(Stock.barcode == barcode).first()
                
                if not stock:
                    stock = Stock(
                        barcode=barcode,
                        qty_on_hand=qty,
                        last_purchase_date=datetime.now(),
                        last_purchase_rate=float(item.purchase_rate_basic) if item.purchase_rate_basic else 0.0,
                        created_by=current_user.username
                    )
                    db.add(stock)
                    created_count += 1
                else:
                    stock.qty_on_hand = qty
                    stock.last_updated = datetime.now()
                    stock.updated_by = current_user.username
                    updated_count += 1
                
            except Exception as e:
                errors.append(f"Row {idx+2}: {str(e)}")
        
        # Commit changes
        db.commit()
        
        total_processed = updated_count + created_count
        message = f"Imported {total_processed} items ({created_count} new, {updated_count} updated)"
        
        if errors:
            message += f". {len(errors)} errors occurred"
        
        return {
            "success": total_processed > 0,
            "message": message,
            "data": {"errors": errors[:10]} if errors else None
        }
        
    except Exception as e:
        db.rollback()
        return {
            "success": False,
            "message": f"Error processing file: {str(e)}"
        }

# ============== LOYALTY GRADE ENDPOINTS ==============

@router.post("/loyalty-grades", response_model=LoyaltyGradeResponse)
def create_loyalty_grade(
    grade: LoyaltyGradeCreate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Create a new loyalty grade"""
    try:
        # Check for overlapping ranges
        existing = db.query(LoyaltyGrade).filter(
            LoyaltyGrade.active == True,
            ((LoyaltyGrade.amount_from <= grade.amount_from) & (LoyaltyGrade.amount_to >= grade.amount_from)) |
            ((LoyaltyGrade.amount_from <= grade.amount_to) & (LoyaltyGrade.amount_to >= grade.amount_to))
        ).first()
        
        if existing:
            raise HTTPException(status_code=400, detail="Amount range overlaps with existing grade")
        
        db_grade = LoyaltyGrade(
            **grade.dict(),
            created_by=current_user.username
        )
        db.add(db_grade)
        db.commit()
        db.refresh(db_grade)
        return db_grade
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/loyalty-grades", response_model=List[LoyaltyGradeResponse])
def list_loyalty_grades(
    active_only: bool = Query(True),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """List all loyalty grades"""
    try:
        query = db.query(LoyaltyGrade)
        if active_only:
            query = query.filter(LoyaltyGrade.active == True)
        grades = query.order_by(LoyaltyGrade.amount_from).all()
        return grades
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.put("/loyalty-grades/{grade_id}", response_model=LoyaltyGradeResponse)
def update_loyalty_grade(
    grade_id: int,
    grade_update: LoyaltyGradeUpdate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Update loyalty grade"""
    try:
        grade = db.query(LoyaltyGrade).filter(LoyaltyGrade.id == grade_id).first()
        if not grade:
            raise HTTPException(status_code=404, detail="Loyalty grade not found")
        
        update_data = grade_update.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(grade, field, value)
        
        grade.updated_by = current_user.username
        db.commit()
        db.refresh(grade)
        return grade
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

# ============== COUPON ENDPOINTS ==============

@router.post("/coupons", response_model=CouponResponse)
def create_coupon(
    coupon: CouponCreate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Create a new coupon"""
    try:
        # Check if coupon code exists
        existing = db.query(Coupon).filter(Coupon.code == coupon.code).first()
        if existing:
            raise HTTPException(status_code=400, detail="Coupon code already exists")
        
        # Generate random code if not provided
        if not coupon.code:
            coupon.code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))
        
        db_coupon = Coupon(
            **coupon.dict(),
            created_by=current_user.username
        )
        db.add(db_coupon)
        db.commit()
        db.refresh(db_coupon)
        return db_coupon
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/coupons", response_model=List[CouponResponse])
def list_coupons(
    active_only: bool = Query(True),
    valid_only: bool = Query(False),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """List all coupons"""
    try:
        query = db.query(Coupon)
        if active_only:
            query = query.filter(Coupon.active == True)
        if valid_only:
            today = datetime.now().date()
            query = query.filter(
                Coupon.valid_from <= today,
                Coupon.valid_till >= today
            )
        coupons = query.order_by(Coupon.created_at.desc()).all()
        return coupons
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.put("/coupons/{coupon_id}", response_model=CouponResponse)
def update_coupon(
    coupon_id: int,
    coupon_update: CouponUpdate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Update coupon"""
    try:
        coupon = db.query(Coupon).filter(Coupon.id == coupon_id).first()
        if not coupon:
            raise HTTPException(status_code=404, detail="Coupon not found")
        
        update_data = coupon_update.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(coupon, field, value)
        
        coupon.updated_by = current_user.username
        db.commit()
        db.refresh(coupon)
        return coupon
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/coupons/validate", response_model=BaseResponse)
def validate_coupon(
    code: str,
    customer_mobile: str,
    bill_amount: float,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Validate coupon for use"""
    try:
        coupon = db.query(Coupon).filter(
            Coupon.code == code,
            Coupon.active == True
        ).first()
        
        if not coupon:
            return BaseResponse(success=False, message="Invalid coupon code")
        
        today = datetime.now().date()
        if coupon.valid_from > today or coupon.valid_till < today:
            return BaseResponse(success=False, message="Coupon has expired")
        
        if coupon.min_bill_amount and bill_amount < coupon.min_bill_amount:
            return BaseResponse(success=False, message=f"Minimum bill amount ₹{coupon.min_bill_amount} required")
        
        if coupon.customer_mobile and coupon.customer_mobile != customer_mobile:
            return BaseResponse(success=False, message="Coupon not valid for this customer")
        
        # Calculate discount
        if coupon.discount_type == "percentage":
            discount = (bill_amount * coupon.discount_value) / 100
            if coupon.max_discount and discount > coupon.max_discount:
                discount = coupon.max_discount
        else:
            discount = coupon.discount_value
        
        return BaseResponse(
            success=True, 
            message="Coupon is valid",
            data={"discount_amount": discount}
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ============== BILL SERIES ENDPOINTS ==============

@router.post("/bill-series", response_model=BillSeriesResponse)
def create_bill_series(
    series: BillSeriesCreate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Create a new bill series"""
    try:
        # Check if series prefix exists
        existing = db.query(BillSeries).filter(
            BillSeries.prefix == series.prefix,
            BillSeries.series_type == series.series_type
        ).first()
        if existing:
            raise HTTPException(status_code=400, detail="Bill series prefix already exists for this type")
        
        db_series = BillSeries(
            **series.dict(),
            created_by=current_user.username
        )
        db.add(db_series)
        db.commit()
        db.refresh(db_series)
        return db_series
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/bill-series", response_model=List[BillSeriesResponse])
def list_bill_series(
    series_type: Optional[str] = Query(None),
    active_only: bool = Query(True),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """List all bill series"""
    try:
        query = db.query(BillSeries)
        if series_type:
            query = query.filter(BillSeries.series_type == series_type)
        if active_only:
            query = query.filter(BillSeries.active == True)
        series = query.order_by(BillSeries.display_order).all()
        return series
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.put("/bill-series/{series_id}", response_model=BillSeriesResponse)
def update_bill_series(
    series_id: int,
    series_update: BillSeriesUpdate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Update bill series"""
    try:
        series = db.query(BillSeries).filter(BillSeries.id == series_id).first()
        if not series:
            raise HTTPException(status_code=404, detail="Bill series not found")
        
        update_data = series_update.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(series, field, value)
        
        series.updated_by = current_user.username
        db.commit()
        db.refresh(series)
        return series
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

# ============== STAFF ENDPOINTS ==============

@router.post("/staff", response_model=StaffResponse)
def create_staff(
    staff: StaffCreate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Create a new staff member"""
    try:
        # Check if staff code exists
        existing = db.query(Staff).filter(Staff.staff_code == staff.staff_code).first()
        if existing:
            raise HTTPException(status_code=400, detail="Staff code already exists")
        
        db_staff = Staff(
            **staff.dict(),
            created_by=current_user.username
        )
        db.add(db_staff)
        db.commit()
        db.refresh(db_staff)
        return db_staff
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/staff", response_model=List[StaffResponse])
def list_staff(
    active_only: bool = Query(True),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """List all staff members"""
    try:
        query = db.query(Staff)
        if active_only:
            query = query.filter(Staff.active == True)
        staff = query.order_by(Staff.name).all()
        return staff
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.put("/staff/{staff_id}", response_model=StaffResponse)
def update_staff(
    staff_id: int,
    staff_update: StaffUpdate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Update staff member"""
    try:
        staff = db.query(Staff).filter(Staff.id == staff_id).first()
        if not staff:
            raise HTTPException(status_code=404, detail="Staff member not found")
        
        update_data = staff_update.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(staff, field, value)
        
        staff.updated_by = current_user.username
        db.commit()
        db.refresh(staff)
        return staff
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

# ============== EXPENSE HEAD ENDPOINTS ==============

@router.post("/expense-heads", response_model=ExpenseHeadResponse)
def create_expense_head(
    expense_head: ExpenseHeadCreate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Create a new expense head"""
    try:
        # Check if name exists
        existing = db.query(ExpenseHead).filter(ExpenseHead.name == expense_head.name).first()
        if existing:
            raise HTTPException(status_code=400, detail="Expense head already exists")
        
        db_head = ExpenseHead(
            **expense_head.dict(),
            created_by=current_user.username
        )
        db.add(db_head)
        db.commit()
        db.refresh(db_head)
        return db_head
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/expense-heads", response_model=List[ExpenseHeadResponse])
def list_expense_heads(
    active_only: bool = Query(True),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """List all expense heads"""
    try:
        query = db.query(ExpenseHead)
        if active_only:
            query = query.filter(ExpenseHead.active == True)
        heads = query.order_by(ExpenseHead.name).all()
        return heads
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ============== PAYMENT MODE ENDPOINTS ==============

@router.post("/payment-modes", response_model=PaymentModeResponse)
def create_payment_mode(
    mode: PaymentModeCreate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Create a new payment mode"""
    try:
        # Check if name exists
        existing = db.query(PaymentModeConfig).filter(PaymentModeConfig.name == mode.name).first()
        if existing:
            raise HTTPException(status_code=400, detail="Payment mode already exists")
        
        db_mode = PaymentModeConfig(
            **mode.dict(),
            created_by=current_user.username
        )
        db.add(db_mode)
        db.commit()
        db.refresh(db_mode)
        return db_mode
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/payment-modes", response_model=List[PaymentModeResponse])
def list_payment_modes(
    active_only: bool = Query(True),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """List all payment modes"""
    try:
        query = db.query(PaymentModeConfig)
        if active_only:
            query = query.filter(PaymentModeConfig.active == True)
        modes = query.order_by(PaymentModeConfig.display_order).all()
        return modes
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.put("/payment-modes/{mode_id}", response_model=PaymentModeResponse)
def update_payment_mode(
    mode_id: int,
    mode_update: PaymentModeUpdate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Update payment mode"""
    try:
        mode = db.query(PaymentModeConfig).filter(PaymentModeConfig.id == mode_id).first()
        if not mode:
            raise HTTPException(status_code=404, detail="Payment mode not found")
        
        update_data = mode_update.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(mode, field, value)
        
        mode.updated_by = current_user.username
        db.commit()
        db.refresh(mode)
        return mode
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

# ============== WHATSAPP CONFIG ENDPOINTS ==============

@router.post("/whatsapp-config", response_model=WhatsAppConfigResponse)
def configure_whatsapp(
    config: WhatsAppConfigCreate,
    current_user: User = Depends(require_admin),
    db: Session = Depends(get_db)
):
    """Configure WhatsApp Cloud API"""
    try:
        # Deactivate existing configs
        db.query(WhatsAppConfig).update({"active": False})
        
        db_config = WhatsAppConfig(
            **config.dict(),
            active=True,
            created_by=current_user.username
        )
        db.add(db_config)
        db.commit()
        db.refresh(db_config)
        return db_config
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/whatsapp-config", response_model=WhatsAppConfigResponse)
def get_whatsapp_config(
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Get active WhatsApp configuration"""
    try:
        config = db.query(WhatsAppConfig).filter(WhatsAppConfig.active == True).first()
        if not config:
            raise HTTPException(status_code=404, detail="WhatsApp not configured")
        return config
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/whatsapp-config/test", response_model=BaseResponse)
async def test_whatsapp(
    mobile: str = Query(..., regex=r'^\d{10}$'),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Send test WhatsApp message"""
    try:
        from app.services.whatsapp_service import send_test_message
        
        success = await send_test_message(mobile)
        if success:
            return BaseResponse(success=True, message="Test message sent successfully")
        else:
            return BaseResponse(success=False, message="Failed to send test message")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ============== STOCK ADJUSTMENT ENDPOINTS ==============

@router.get("/stock-adjustment")
def get_stock_adjustment(
    skip: int = Query(0, ge=0),
    limit: int = Query(5000, ge=1, le=10000),
    search: Optional[str] = None,
    current_user = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Get all items with their current stock for stock adjustment view"""
    try:
        # Simplified query - just get items first
        items = db.query(Item).offset(skip).limit(limit).all()
        
        # Format response
        result_stocks = []
        for item in items:
            # Get stock separately
            stock = db.query(Stock).filter(Stock.barcode == item.barcode).first()
            
            stock_dict = {
                "barcode": item.barcode,
                "style_code": item.style_code,
                "color": item.color,
                "size": item.size,
                "brand": item.brand,
                "category": item.category,
                "mrp_incl": float(item.mrp_incl) if item.mrp_incl else 0,
                "purchase_rate_basic": float(item.purchase_rate_basic) if item.purchase_rate_basic else 0,
                "qty": stock.qty_on_hand if stock else 0,
                "last_purchase_date": None,
                "last_sale_date": None,
                "last_updated": datetime.now().isoformat()
            }
            result_stocks.append(stock_dict)
        
        return {
            "success": True,
            "stocks": result_stocks,
            "total": len(result_stocks)
        }
        
    except Exception as e:
        print(f"[ERROR] in get_stock_adjustment: {str(e)}")
        return {
            "success": False,
            "stocks": [],
            "total": 0,
            "error": str(e)
        }

@router.get("/stock-movements/{barcode}")
def get_stock_movements(
    barcode: str,
    limit: int = Query(50, ge=1, le=200),
    current_user = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Get stock movement history for a specific item"""
    try:
        movements = []
        
        # Since you probably don't have any sales/purchases yet,
        # let's just return an empty list for now
        
        return {
            "success": True,
            "movements": movements,
            "total": len(movements)
        }
        
    except Exception as e:
        print(f"[ERROR] in get_stock_movements: {str(e)}")
        return {
            "success": False,
            "movements": [],
            "error": str(e)
        }