"""
Sales/POS module endpoints - Complete implementation
"""
from fastapi import APIRouter, Depends, HTTPException, status, Query, Body
from sqlalchemy.orm import Session
from sqlalchemy import func, and_, or_
from typing import List, Optional, Dict
from datetime import datetime, date, timedelta
from decimal import Decimal
import logging

from app.database import get_db
from app.models import (
    Sale, SaleItem, SalePayment, SaleReturn, SaleReturnItem, ReturnCredit,
    Customer, Item, Stock, BillSeries, Staff, Coupon, LoyaltyGrade,
    PaymentModeConfig, LocationType, CreditStatus, CouponType
)
from app.api.deps import get_current_active_user, PermissionChecker
from app.schemas.sales_schemas import (
    SaleCreate, SaleResponse, SaleItemCreate, SalePaymentCreate,
    SaleReturnCreate, SaleReturnResponse, ReturnCreditResponse,
    POSSearchResponse, PaymentDialogRequest, PaymentDialogResponse,
    ModifyBillRequest, BaseResponse, SaleLineSelectResponse
)
from app.services.gst_service import GSTCalculator, TaxRegion
from app.services.stock_service import StockService
from app.services.whatsapp_service import send_otp_whatsapp, verify_otp, send_invoice_whatsapp
from app.services.pdf_service import generate_sale_bill_pdf
from app.services.loyalty_service import LoyaltyService
from app.config import settings

router = APIRouter()
logger = logging.getLogger(__name__)

# ============== POS ENDPOINTS ==============

@router.post("/pos/search-item")
def search_item_for_pos(
    barcode: str = Query(None),
    style_code: str = Query(None),
    current_user = Depends(PermissionChecker("sales.sale_bill", "view")),
    db: Session = Depends(get_db)
):
    """Search item by barcode or style code for POS"""
    if not barcode and not style_code:
        raise HTTPException(status_code=400, detail="Provide barcode or style_code")
    
    query = db.query(Item).join(Stock, isouter=True)
    
    if barcode:
        item = query.filter(Item.barcode == barcode).first()
    else:
        # For style code, return all items with that style
        items = query.filter(Item.style_code == style_code).all()
        if items:
            return {
                "found": True,
                "multiple": True,
                "items": [
                    {
                        "barcode": item.barcode,
                        "style_code": item.style_code,
                        "color": item.color,
                        "size": item.size,
                        "mrp_incl": float(item.mrp_incl),
                        "stock_qty": float(item.stock.qty_on_hand) if item.stock else 0,
                        "hsn": item.hsn,
                        "gst_rate": float(GSTCalculator.get_gst_rate_by_price(item.mrp_incl))
                    }
                    for item in items
                ]
            }
        return {"found": False, "message": "No items found"}
    
    if not item:
        return {"found": False, "message": "Item not found"}
    
    # Get GST rate
    gst_rate = GSTCalculator.get_gst_rate_by_price(item.mrp_incl)
    
    return {
        "found": True,
        "multiple": False,
        "item": {
            "barcode": item.barcode,
            "style_code": item.style_code,
            "color": item.color,
            "size": item.size,
            "mrp_incl": float(item.mrp_incl),
            "stock_qty": float(item.stock.qty_on_hand) if item.stock else 0,
            "hsn": item.hsn,
            "gst_rate": float(gst_rate),
            "cgst_rate": float(gst_rate / 2),
            "sgst_rate": float(gst_rate / 2)
        }
    }

@router.post("/pos/search-customer")
def search_customer_for_pos(
    mobile: str = Query(..., pattern=r'^\d{10}$'),
    current_user = Depends(PermissionChecker("sales.sale_bill", "view")),
    db: Session = Depends(get_db)
):
    """Search customer by mobile for POS"""
    customer = db.query(Customer).filter(Customer.mobile == mobile).first()
    
    if not customer:
        return {
            "found": False,
            "mobile": mobile,
            "can_create": True
        }
    
    # Get loyalty grade details
    grade = None
    if customer.loyalty_grade_id:
        grade = db.query(LoyaltyGrade).filter(
            LoyaltyGrade.id == customer.loyalty_grade_id
        ).first()
    
    return {
        "found": True,
        "customer": {
            "mobile": customer.mobile,
            "name": customer.name,
            "email": customer.email,
            "lifetime_purchase": float(customer.lifetime_purchase),
            "points_balance": float(customer.points_balance),
            "loyalty_grade": grade.name if grade else None,
            "earn_rate": float(grade.earn_pct) if grade else 0
        }
    }

@router.post("/pos/create-sale", response_model=SaleResponse)
def create_pos_sale(
    sale: SaleCreate,
    current_user = Depends(PermissionChecker("sales.sale_bill", "create")),
    db: Session = Depends(get_db)
):
    """Create a new POS sale"""
    try:
        # Validate customer if provided
        customer = None
        if sale.customer_mobile:
            customer = db.query(Customer).filter(
                Customer.mobile == sale.customer_mobile
            ).first()
            if not customer:
                raise HTTPException(status_code=404, detail="Customer not found")
        
        # Get bill series
        series = db.query(BillSeries).filter(BillSeries.id == sale.series_id).first()
        if not series:
            raise HTTPException(status_code=404, detail="Bill series not found")
        
        # Generate bill number
        bill_no = f"{series.prefix}{str(series.next_number).zfill(series.zero_pad_width)}"
        
        # Create sale header
        db_sale = Sale(
            series_id=sale.series_id,
            bill_no=bill_no,
            bill_date=sale.bill_date or datetime.now(),
            customer_mobile=sale.customer_mobile,
            staff_id=sale.staff_id,
            agent_id=sale.agent_id,
            tax_region=LocationType.LOCAL,  # Default
            gross_incl=Decimal("0"),
            discount_incl=Decimal("0"),
            coupon_incl=Decimal("0"),
            coupon_code=sale.coupon_code,
            base_excl=Decimal("0"),
            tax_amt_info=Decimal("0"),
            redeem_points=sale.redeem_points or Decimal("0"),
            redeem_value=sale.redeem_value or Decimal("0"),
            return_credit_id=sale.return_credit_id,
            return_credit_used_value=sale.return_credit_used_value or Decimal("0"),
            final_payable=Decimal("0"),
            round_off=Decimal("0"),
            earned_points=Decimal("0"),
            created_by=current_user.username
        )
        db.add(db_sale)
        db.flush()
        
        # Process items
        gross_total = Decimal("0")
        total_discount = Decimal("0")
        total_base = Decimal("0")
        total_tax = Decimal("0")
        
        for item_data in sale.items:
            # Validate item and stock
            item = db.query(Item).filter(Item.barcode == item_data.barcode).first()
            if not item:
                raise HTTPException(status_code=404, detail=f"Item {item_data.barcode} not found")
            
            # Check stock
            is_available, current_stock = StockService.check_stock_availability(
                db, item_data.barcode, item_data.qty
            )
            if not is_available:
                raise HTTPException(
                    status_code=400,
                    detail=f"Only {current_stock} available for {item_data.barcode}"
                )
            
            # Calculate line total with GST
            calc = GSTCalculator.calculate_line_total_inclusive(
                qty=item_data.qty,
                mrp=item.mrp_incl,
                discount_pct=item_data.disc_pct,
                region=TaxRegion.LOCAL
            )
            
            # Create sale item
            db_item = SaleItem(
                sale_id=db_sale.id,
                barcode=item_data.barcode,
                style_code=item.style_code,
                color=item.color,
                size=item.size,
                qty=item_data.qty,
                mrp_incl=item.mrp_incl,
                disc_pct=item_data.disc_pct,
                line_inclusive=calc["line_inclusive"],
                gst_rate=calc["gst_rate"],
                cgst_rate=calc["cgst_rate"],
                sgst_rate=calc["sgst_rate"],
                igst_rate=calc["igst_rate"],
                hsn=item.hsn,
                base_excl=calc["base_amount"],
                tax_amt_info=calc["total_tax"],
                returned_qty=Decimal("0")
            )
            db.add(db_item)
            
            # Update stock
            StockService.update_stock(
                db, item_data.barcode, item_data.qty, "subtract"
            )
            
            # Accumulate totals
            gross_total += item_data.qty * item.mrp_incl
            discount_amount = item_data.qty * item.mrp_incl * (item_data.disc_pct / 100)
            total_discount += discount_amount
            total_base += calc["base_amount"]
            total_tax += calc["total_tax"]
        
        # Apply coupon if provided
        coupon_discount = Decimal("0")
        if sale.coupon_code:
            coupon = db.query(Coupon).filter(
                Coupon.code == sale.coupon_code,
                Coupon.active == True
            ).first()
            
            if coupon:
                # Validate coupon
                now = datetime.utcnow()
                if now < coupon.valid_from or now > coupon.valid_to:
                    raise HTTPException(status_code=400, detail="Coupon expired")
                
                net_amount = gross_total - total_discount
                if net_amount < coupon.min_bill:
                    raise HTTPException(
                        status_code=400,
                        detail=f"Minimum bill of ₹{coupon.min_bill} required"
                    )
                
                if coupon.bound_mobile and coupon.bound_mobile != sale.customer_mobile:
                    raise HTTPException(status_code=400, detail="Coupon not valid for this customer")
                
                # Calculate coupon discount
                if coupon.type == CouponType.PERCENT:
                    coupon_discount = net_amount * (coupon.value / 100)
                    if coupon.max_cap:
                        coupon_discount = min(coupon_discount, coupon.max_cap)
                else:
                    coupon_discount = min(coupon.value, net_amount)
                
                # Update coupon usage
                coupon.used_count += 1
        
        # Calculate final amounts
        db_sale.gross_incl = gross_total
        db_sale.discount_incl = total_discount
        db_sale.coupon_incl = coupon_discount
        
        net_after_discounts = gross_total - total_discount - coupon_discount
        
        # Recalculate tax after coupon (proportionally)
        if coupon_discount > 0 and net_after_discounts > 0:
            tax_ratio = total_tax / (gross_total - total_discount)
            total_tax = net_after_discounts * tax_ratio
            total_base = net_after_discounts - total_tax
        
        db_sale.base_excl = total_base
        db_sale.tax_amt_info = total_tax
        
        # Apply loyalty redemption and return credit
        total_deductions = coupon_discount + sale.redeem_value + sale.return_credit_used_value
        final_payable = net_after_discounts - sale.redeem_value - sale.return_credit_used_value
        
        # Apply rounding
        final_payable, round_off = GSTCalculator.round_off_amount(
            final_payable,
            Decimal(str(settings.GST_ROUND_OFF))
        )
        
        db_sale.final_payable = final_payable
        db_sale.round_off = round_off
        
        # Process payments
        total_payment = Decimal("0")
        for payment_data in sale.payments:
            payment_mode = db.query(PaymentModeConfig).filter(
                PaymentModeConfig.id == payment_data.payment_mode_id
            ).first()
            
            if not payment_mode:
                raise HTTPException(status_code=404, detail="Payment mode not found")
            
            db_payment = SalePayment(
                sale_id=db_sale.id,
                payment_mode_id=payment_data.payment_mode_id,
                amount=payment_data.amount,
                settlement_type=payment_mode.settlement_type,
                bank_account_id=payment_mode.bank_account_id,
                supplier_id=payment_mode.supplier_id,
                reference_no=payment_data.reference_no
            )
            db.add(db_payment)
            total_payment += payment_data.amount
        
        # Validate payment matches payable
        if abs(total_payment - final_payable) > Decimal("0.01"):
            raise HTTPException(
                status_code=400,
                detail=f"Payment mismatch. Required: ₹{final_payable}, Received: ₹{total_payment}"
            )
        
        # Calculate and award loyalty points
        if customer:
            points_earned = LoyaltyService.calculate_points_earned(
                db, customer, db_sale.base_excl
            )
            db_sale.earned_points = points_earned
            
            # Update customer
            customer.points_balance += points_earned - sale.redeem_points
            customer.lifetime_purchase += db_sale.base_excl
            customer.last_visit_date = datetime.now()
            
            # Check for grade upgrade
            LoyaltyService.check_grade_upgrade(db, customer)
            
            # Update loyalty redemption
            if sale.redeem_points > 0:
                customer.points_balance -= sale.redeem_points
        
        # Update return credit if used
        if sale.return_credit_id:
            rc = db.query(ReturnCredit).filter(
                ReturnCredit.id == sale.return_credit_id
            ).first()
            if rc:
                rc.used_amount += sale.return_credit_used_value
                if rc.used_amount >= rc.rc_amount_incl:
                    rc.status = CreditStatus.CLOSED
                    rc.closed_at = datetime.now()
                else:
                    rc.status = CreditStatus.PARTIAL
        
        # Update bill series
        series.next_number += 1
        
        db.commit()
        db.refresh(db_sale)
        
        return db_sale
        
    except Exception as e:
        db.rollback()
        logger.error(f"Error creating sale: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/pos/bills", response_model=List[SaleResponse])
def list_pos_bills(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=100),
    from_date: Optional[date] = None,
    to_date: Optional[date] = None,
    customer_mobile: Optional[str] = None,
    current_user = Depends(PermissionChecker("sales.sale_bill", "view")),
    db: Session = Depends(get_db)
):
    """List POS bills with filters"""
    query = db.query(Sale)
    
    if from_date:
        query = query.filter(Sale.bill_date >= from_date)
    if to_date:
        query = query.filter(Sale.bill_date <= to_date)
    if customer_mobile:
        query = query.filter(Sale.customer_mobile == customer_mobile)
    
    bills = query.order_by(Sale.bill_date.desc()).offset(skip).limit(limit).all()
    return bills

@router.post("/pos/modify-bill", response_model=SaleResponse)
def modify_pos_bill(
    request: ModifyBillRequest,
    current_user = Depends(PermissionChecker("sales.sale_bill", "edit")),
    db: Session = Depends(get_db)
):
    """Modify an existing bill (same day or with admin permission)"""
    # Find bill
    sale = db.query(Sale).filter(Sale.bill_no == request.bill_no).first()
    if not sale:
        raise HTTPException(status_code=404, detail="Bill not found")
    
    # Check if bill is locked
    if sale.is_locked or sale.is_exported:
        raise HTTPException(status_code=403, detail="Bill is locked for editing")
    
    # Check modification permission
    if sale.bill_date.date() != datetime.now().date():
        # Not same day, need admin or modify_past permission
        if current_user.role != "admin":
            checker = PermissionChecker("sales.sale_bill", "modify_past")
            checker(current_user, db)
    
    # If admin wants to clone as return + new sale
    if request.clone_as_return:
        if current_user.role != "admin":
            raise HTTPException(status_code=403, detail="Only admin can clone as return")
        
        # Create sale return for entire bill
        # ... (implement clone logic)
        raise HTTPException(status_code=501, detail="Clone feature not yet implemented")
    
    # Otherwise, allow modification
    # ... (implement modification logic)
    
    return sale

@router.post("/pos/validate-coupon")
def validate_coupon_for_pos(
    code: str,
    bill_amount: float,
    customer_mobile: Optional[str] = None,
    current_user = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Validate coupon for POS"""
    coupon = db.query(Coupon).filter(Coupon.code == code).first()
    
    if not coupon:
        return {"valid": False, "message": "Coupon not found"}
    
    if not coupon.active:
        return {"valid": False, "message": "Coupon is inactive"}
    
    now = datetime.utcnow()
    if now < coupon.valid_from or now > coupon.valid_to:
        return {"valid": False, "message": "Coupon has expired"}
    
    if bill_amount < float(coupon.min_bill):
        return {"valid": False, "message": f"Minimum bill ₹{coupon.min_bill} required"}
    
    if coupon.bound_mobile and coupon.bound_mobile != customer_mobile:
        return {"valid": False, "message": "Coupon not valid for this customer"}
    
    # Calculate discount
    if coupon.type == CouponType.PERCENT:
        discount = bill_amount * (float(coupon.value) / 100)
        if coupon.max_cap:
            discount = min(discount, float(coupon.max_cap))
    else:
        discount = min(float(coupon.value), bill_amount)
    
    return {
        "valid": True,
        "code": coupon.code,
        "type": coupon.type.value,
        "value": float(coupon.value),
        "discount_amount": discount,
        "message": f"Coupon applied: ₹{discount:.2f} off"
    }

@router.post("/pos/send-otp")
async def send_otp_for_redemption(
    mobile: str = Query(..., pattern=r'^\d{10}$'),
    current_user = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Send OTP for points redemption"""
    customer = db.query(Customer).filter(Customer.mobile == mobile).first()
    if not customer:
        raise HTTPException(status_code=404, detail="Customer not found")
    
    if customer.points_balance <= 0:
        raise HTTPException(status_code=400, detail="No points available")
    
    otp = await send_otp_whatsapp(mobile)
    if otp:
        return {
            "success": True,
            "message": f"OTP sent to {mobile}",
            "points_available": float(customer.points_balance)
        }
    else:
        raise HTTPException(status_code=500, detail="Failed to send OTP")

@router.post("/pos/verify-otp")
def verify_otp_for_redemption(
    mobile: str = Query(..., pattern=r'^\d{10}$'),
    otp: str = Query(..., min_length=6, max_length=6),
    current_user = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Verify OTP for points redemption"""
    if verify_otp(mobile, otp):
        customer = db.query(Customer).filter(Customer.mobile == mobile).first()
        return {
            "success": True,
            "verified": True,
            "points_available": float(customer.points_balance) if customer else 0,
            "redemption_value": float(customer.points_balance * settings.POINTS_CONVERSION_RATE) if customer else 0
        }
    else:
        return {
            "success": False,
            "verified": False,
            "message": "Invalid OTP"
        }

@router.get("/pos/return-credits")
def get_available_return_credits(
    customer_mobile: Optional[str] = None,
    current_user = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Get available return credits for a customer"""
    query = db.query(ReturnCredit).filter(
        ReturnCredit.status == CreditStatus.OPEN
    )
    
    if customer_mobile:
        query = query.filter(ReturnCredit.customer_mobile == customer_mobile)
    
    credits = query.all()
    
    return [
        {
            "id": rc.id,
            "rc_no": rc.rc_no,
            "amount": float(rc.rc_amount_incl),
            "used": float(rc.used_amount),
            "available": float(rc.rc_amount_incl - rc.used_amount),
            "customer_mobile": rc.customer_mobile,
            "created_at": rc.created_at
        }
        for rc in credits
    ]

@router.get("/pos/staff")
def get_staff_list(
    active_only: bool = Query(True),
    current_user = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Get staff list for POS"""
    query = db.query(Staff)
    if active_only:
        query = query.filter(Staff.active == True)
    
    staff = query.all()
    return [
        {
            "id": s.id,
            "code": s.code,
            "name": s.name,
            "role": s.role
        }
        for s in staff
    ]

@router.get("/pos/print/{bill_id}")
def print_pos_bill(
    bill_id: int,
    format: str = Query("thermal", pattern=r'^(thermal|a4)$'),
    current_user = Depends(PermissionChecker("sales.sale_bill", "print")),
    db: Session = Depends(get_db)
):
    """Print POS bill in thermal or A4 format"""
    sale = db.query(Sale).filter(Sale.id == bill_id).first()
    if not sale:
        raise HTTPException(status_code=404, detail="Bill not found")
    
    pdf_bytes = generate_sale_bill_pdf(sale)
    
    return {
        "success": True,
        "format": format,
        "pdf_base64": pdf_bytes.hex(),  # Convert to base64 in real implementation
        "message": "Bill sent to printer"
    }

@router.post("/pos/send-invoice")
async def send_invoice_whatsapp_pos(
    bill_id: int,
    current_user = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Send invoice via WhatsApp"""
    sale = db.query(Sale).filter(Sale.id == bill_id).first()
    if not sale:
        raise HTTPException(status_code=404, detail="Bill not found")
    
    if not sale.customer_mobile:
        raise HTTPException(status_code=400, detail="No customer mobile number")
    
    success = await send_invoice_whatsapp(
        mobile=sale.customer_mobile,
        bill_no=sale.bill_no,
        amount=float(sale.final_payable),
        points_earned=float(sale.earned_points),
        points_redeemed=float(sale.redeem_points),
        points_balance=float(sale.customer.points_balance) if sale.customer else 0
    )
    
    if success:
        return {"success": True, "message": "Invoice sent via WhatsApp"}
    else:
        raise HTTPException(status_code=500, detail="Failed to send invoice")