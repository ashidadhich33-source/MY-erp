"""
Script to add missing columns to suppliers table
Save this file as: backend/update_suppliers_table.py
Then run it from the backend directory
"""

import sqlite3
import os
from pathlib import Path

def update_suppliers_table():
    """Add missing columns to suppliers table"""
    
    # Find the database file
    db_path = Path("database/erp_system.db")  # Updated to correct path
    
    if not db_path.exists():
        print(f"Database not found at {db_path}")
        print("Looking for database files...")
        # Try different possible locations
        possible_paths = [
            Path("database/erp_system.db"),
            Path("erp_system.db"),
            Path("../database/erp_system.db"),
            Path("app/database/erp_system.db")
        ]
        
        for possible_path in possible_paths:
            if possible_path.exists():
                db_path = possible_path
                print(f"Found database at: {db_path}")
                break
        
        # Also search for any .db files
        if not db_path.exists():
            for file in Path(".").glob("**/*.db"):
                print(f"Found: {file}")
                db_path = file
                break
    
    if not db_path.exists():
        print("No database file found! Please check your database location.")
        return
    
    print(f"Using database: {db_path}")
    
    # Connect to database
    conn = sqlite3.connect(str(db_path))
    cursor = conn.cursor()
    
    try:
        # Check existing columns
        cursor.execute("PRAGMA table_info(suppliers);")
        existing_columns = [column[1] for column in cursor.fetchall()]
        print(f"Existing columns: {existing_columns}")
        
        # List of columns to add
        columns_to_add = [
            ("city", "VARCHAR(100)"),
            ("state", "VARCHAR(100)"),
            ("pincode", "VARCHAR(10)"),
            ("contact_person", "VARCHAR(100)")
        ]
        
        # Add missing columns
        for column_name, column_type in columns_to_add:
            if column_name not in existing_columns:
                try:
                    alter_query = f"ALTER TABLE suppliers ADD COLUMN {column_name} {column_type};"
                    cursor.execute(alter_query)
                    print(f"✓ Added column: {column_name}")
                except sqlite3.OperationalError as e:
                    if "duplicate column name" in str(e).lower():
                        print(f"  Column {column_name} already exists")
                    else:
                        print(f"✗ Error adding column {column_name}: {e}")
            else:
                print(f"  Column {column_name} already exists")
        
        # Also check and update location_type if it's an enum
        # Convert ENUM to VARCHAR if needed
        cursor.execute("""
            SELECT sql FROM sqlite_master 
            WHERE type='table' AND name='suppliers';
        """)
        table_schema = cursor.fetchone()[0]
        
        if "location_type" in table_schema and "Enum" in table_schema:
            print("\nNote: location_type appears to be an ENUM. You may need to update existing data.")
            # Update existing location_type values if they're stored as integers
            cursor.execute("""
                UPDATE suppliers 
                SET location_type = 'local' 
                WHERE location_type IN ('0', '1', 'LOCAL', 'Local') 
                   OR location_type IS NULL;
            """)
            cursor.execute("""
                UPDATE suppliers 
                SET location_type = 'inter-state' 
                WHERE location_type IN ('2', 'INTER', 'Inter', 'INTER-STATE');
            """)
            print("✓ Updated location_type values")
        
        # Commit changes
        conn.commit()
        print("\n✅ Database updated successfully!")
        
        # Show updated table structure
        cursor.execute("PRAGMA table_info(suppliers);")
        columns = cursor.fetchall()
        print("\nUpdated table structure:")
        for col in columns:
            print(f"  - {col[1]} ({col[2]})")
        
        # Show sample data
        cursor.execute("SELECT COUNT(*) FROM suppliers;")
        count = cursor.fetchone()[0]
        print(f"\nTotal suppliers in database: {count}")
        
        if count > 0:
            cursor.execute("""
                SELECT id, name, location_type, city, state, active 
                FROM suppliers LIMIT 3;
            """)
            rows = cursor.fetchall()
            print("\nSample data:")
            for row in rows:
                print(f"  ID: {row[0]}, Name: {row[1]}, Type: {row[2]}, City: {row[3]}, State: {row[4]}, Active: {row[5]}")
        
    except Exception as e:
        print(f"Error: {e}")
        conn.rollback()
    finally:
        conn.close()

if __name__ == "__main__":
    print("=== Updating Suppliers Table ===")
    update_suppliers_table()
    print("\nNext steps:")
    print("1. Restart your backend server")
    print("2. Refresh your frontend page")
    print("3. The suppliers page should now work!")