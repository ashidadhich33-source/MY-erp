from app.database import SessionLocal, engine
from app.models import User
from app.core.security import get_password_hash

def create_admin_user():
    db = SessionLocal()
    try:
        # Check if admin exists
        existing = db.query(User).filter(User.username == "admin").first()
        if existing:
            # Update password - using the correct field name
            existing.password_hash = get_password_hash("admin123")
            db.commit()
            print("Admin password reset to: admin123")
        else:
            # Create new admin - using the correct field name
            admin = User(
                username="admin",
                password_hash=get_password_hash("admin123"),  # Changed from hashed_password
                display_name="Administrator",
                email="admin@pinak.com",
                role="admin",
                active=True,
                created_by="system"
            )
            db.add(admin)
            db.commit()
            print("Admin user created with password: admin123")
    except Exception as e:
        print(f"Error: {e}")
        db.rollback()
    finally:
        db.close()

if __name__ == "__main__":
    create_admin_user()