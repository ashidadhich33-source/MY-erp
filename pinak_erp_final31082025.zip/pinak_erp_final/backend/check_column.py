"""
Quick script to check if contact_person column exists and add it if missing
Save as: backend/check_column.py
"""

import sqlite3
from pathlib import Path

def check_and_fix_contact_person():
    # Find the database - it's in the parent directory
    db_path = Path("../database/erp_system.db")
    
    if not db_path.exists():
        # Try current directory
        db_path = Path("erp_system.db")
        
    if not db_path.exists():
        # Try looking for any .db file
        print("Looking for database files...")
        for db_file in Path("..").glob("**/*.db"):
            print(f"Found: {db_file}")
            if "erp_system" in str(db_file):
                db_path = db_file
                break
    
    if not db_path.exists():
        print("Database not found! Please specify the correct path.")
        return
    
    conn = sqlite3.connect(str(db_path))
    cursor = conn.cursor()
    
    try:
        # Check columns in suppliers table
        cursor.execute("PRAGMA table_info(suppliers);")
        columns = cursor.fetchall()
        column_names = [col[1] for col in columns]
        
        print("Current columns in suppliers table:")
        for col in columns:
            print(f"  - {col[1]} ({col[2]})")
        
        # Check if contact_person exists
        if 'contact_person' not in column_names:
            print("\n❌ contact_person column is MISSING!")
            print("Adding contact_person column...")
            cursor.execute("ALTER TABLE suppliers ADD COLUMN contact_person VARCHAR(100);")
            conn.commit()
            print("✓ Added contact_person column")
        else:
            print("\n✓ contact_person column exists")
            
            # Check if there's data in the column
            cursor.execute("SELECT id, name, contact_person FROM suppliers;")
            suppliers = cursor.fetchall()
            print(f"\nSuppliers with contact_person data:")
            for s in suppliers:
                print(f"  ID: {s[0]}, Name: {s[1]}, Contact: {s[2]}")
        
    except Exception as e:
        print(f"Error: {e}")
    finally:
        conn.close()

if __name__ == "__main__":
    check_and_fix_contact_person()