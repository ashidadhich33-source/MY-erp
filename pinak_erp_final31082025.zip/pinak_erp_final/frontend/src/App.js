import React, { useState, useEffect } from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import './App.css';

// Screens - Sales & Purchase
import Login from './screens/Login';
import POS from './screens/POS';
import SaleReturn from './screens/SaleReturn';
import Purchase from './screens/Purchase';
import PurchaseReturn from './screens/setup/PurchaseReturn';

// Screens - Setup Module
import Items from './screens/setup/Items';
import OpeningStock from './screens/setup/OpeningStock';
import StockAdjustment from './screens/setup/StockAdjustment';
import Suppliers from './screens/setup/Suppliers';
import CreateUser from './screens/setup/CreateUser';
import UserAccess from './screens/setup/UserAccess';
import Company from './screens/setup/Company';
import Customers from './screens/setup/Customers';
import LoyaltyGrade from './screens/setup/LoyaltyGrade';
import Coupons from './screens/setup/Coupons';
import WhatsAppSetup from './screens/setup/WhatsAppSetup';
import BillSeries from './screens/setup/BillSeries';
import Staff from './screens/setup/Staff';
import TargetsIncentives from './screens/setup/TargetsIncentives';
import ExpenseHead from './screens/setup/ExpenseHead';
import PaymentMode from './screens/setup/PaymentMode';

// Screens - Reports
import SalesReport from './screens/reports/SalesReport';
import CustomerReport from './screens/reports/CustomerReport';
import CustomerWiseSale from './screens/reports/CustomerWiseSale';
import InactiveCustomers from './screens/reports/InactiveCustomers';
import BirthdayReport from './screens/reports/BirthdayReport';
import PurchaseReport from './screens/reports/PurchaseReport';
import HSNReport from './screens/reports/HSNReport';
import StaffReport from './screens/reports/StaffReport';
import BillWiseReport from './screens/reports/BillWiseReport';
import PaymentModeReport from './screens/reports/PaymentModeReport';
import ExpensesReport from './screens/reports/ExpensesReport';
import StockReport from './screens/reports/StockReport';

// Components
import Sidebar from './components/Sidebar';
import Header from './components/Header';

// Context
import { AuthProvider, useAuth } from './context/AuthContext';

function AppContent() {
  const { isAuthenticated } = useAuth();
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  useEffect(() => {
    // Listen for menu navigation from Electron
    if (window.electron) {
      window.electron.receive('navigate', (path) => {
        window.location.hash = path;
      });

      window.electron.receive('menu-new-sale', () => {
        window.location.hash = '/pos';
      });

      // Keyboard shortcuts
      const handleKeyPress = (e) => {
        if (e.key === 'F2') {
          window.location.hash = '/pos';
        } else if (e.key === 'F3') {
          window.location.hash = '/setup/items';
        } else if (e.key === 'F4') {
          window.location.hash = '/purchase';
        } else if (e.key === 'F5' && !e.ctrlKey) {
          e.preventDefault();
          window.location.hash = '/reports/sales';
        }
      };

      window.addEventListener('keydown', handleKeyPress);
      return () => window.removeEventListener('keydown', handleKeyPress);
    }
  }, []);

  if (!isAuthenticated) {
    return <Login />;
  }

  return (
    <div className="app">
      <Header toggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)} />
      <div className="app-body">
        {isSidebarOpen && <Sidebar />}
        <main className={`app-main ${!isSidebarOpen ? 'full-width' : ''}`}>
          <Routes>
            <Route path="/" element={<Navigate to="/pos" />} />
            
            {/* Sales Module */}
            <Route path="/pos" element={<POS />} />
            <Route path="/sale-return" element={<SaleReturn />} />
            
            {/* Purchase Module */}
            <Route path="/purchase" element={<Purchase />} />
            <Route path="/purchase-return" element={<PurchaseReturn />} />
            
            {/* Setup Module */}
            <Route path="/setup/items" element={<Items />} />
            <Route path="/setup/opening-stock" element={<OpeningStock />} />
            <Route path="/setup/stock-adjustment" element={<StockAdjustment />} />
            <Route path="/setup/suppliers" element={<Suppliers />} />
            <Route path="/setup/create-user" element={<CreateUser />} />
            <Route path="/setup/user-access" element={<UserAccess />} />
            <Route path="/setup/company" element={<Company />} />
            <Route path="/setup/customers" element={<Customers />} />
            <Route path="/setup/loyalty-grade" element={<LoyaltyGrade />} />
            <Route path="/setup/coupons" element={<Coupons />} />
            <Route path="/setup/whatsapp" element={<WhatsAppSetup />} />
            <Route path="/setup/bill-series" element={<BillSeries />} />
            <Route path="/setup/staff" element={<Staff />} />
            <Route path="/setup/targets-incentives" element={<TargetsIncentives />} />
            <Route path="/setup/expense-head" element={<ExpenseHead />} />
            <Route path="/setup/payment-mode" element={<PaymentMode />} />
            
            {/* Reports Module */}
            <Route path="/reports/sales" element={<SalesReport />} />
            <Route path="/reports/customer" element={<CustomerReport />} />
            <Route path="/reports/customer-wise-sale" element={<CustomerWiseSale />} />
            <Route path="/reports/inactive-customers" element={<InactiveCustomers />} />
            <Route path="/reports/birthday" element={<BirthdayReport />} />
            <Route path="/reports/purchase" element={<PurchaseReport />} />
            <Route path="/reports/hsn" element={<HSNReport />} />
            <Route path="/reports/staff" element={<StaffReport />} />
            <Route path="/reports/bill-wise" element={<BillWiseReport />} />
            <Route path="/reports/payment-mode" element={<PaymentModeReport />} />
            <Route path="/reports/expenses" element={<ExpensesReport />} />
            <Route path="/reports/stock" element={<StockReport />} />
          </Routes>
        </main>
      </div>
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <Router>
        <AppContent />
        <Toaster 
          position="top-right"
          toastOptions={{
            duration: 3000,
            style: {
              background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
              color: '#fff',
              borderRadius: '12px',
              padding: '16px',
              boxShadow: '0 10px 40px rgba(0,0,0,0.2)',
            },
            success: {
              iconTheme: {
                primary: '#10b981',
                secondary: '#fff',
              },
            },
            error: {
              iconTheme: {
                primary: '#ef4444',
                secondary: '#fff',
              },
            },
          }}
        />
      </Router>
    </AuthProvider>
  );
}

export default App;