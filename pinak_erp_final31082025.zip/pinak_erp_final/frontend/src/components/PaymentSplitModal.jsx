import React, { useState, useEffect } from 'react';
import { 
  FiX, FiDollarSign, FiCreditCard, FiSmartphone, 
  FiCheck, FiAlertCircle, FiPercent
} from 'react-icons/fi';
import toast from 'react-hot-toast';
import './Modals.css';

function PaymentSplitModal({ 
  isOpen, 
  onClose, 
  totalAmount, 
  onConfirm,
  paymentModes = []
}) {
  const [splits, setSplits] = useState({
    cash: 0,
    card: 0,
    upi: 0,
    other: 0
  });
  
  const [remainingAmount, setRemainingAmount] = useState(totalAmount);
  const [errors, setErrors] = useState({});

  // Default payment modes if not provided
  const defaultModes = [
    { id: 'cash', name: 'Cash', icon: '💵', color: 'green' },
    { id: 'card', name: 'Card', icon: '💳', color: 'blue' },
    { id: 'upi', name: 'UPI', icon: '📱', color: 'purple' },
    { id: 'other', name: 'Other', icon: '💰', color: 'orange' }
  ];

  const modes = paymentModes.length > 0 ? paymentModes : defaultModes;

  useEffect(() => {
    const totalPaid = Object.values(splits).reduce((sum, amount) => sum + amount, 0);
    setRemainingAmount(totalAmount - totalPaid);
    
    // Clear errors when amounts are correct
    if (totalPaid === totalAmount) {
      setErrors({});
    }
  }, [splits, totalAmount]);

  // Update split amount
  const updateSplit = (mode, value) => {
    const amount = parseFloat(value) || 0;
    
    // Validate amount
    if (amount < 0) {
      setErrors({ ...errors, [mode]: 'Amount cannot be negative' });
      return;
    }
    
    // Check if total exceeds
    const otherSplits = Object.entries(splits)
      .filter(([key]) => key !== mode)
      .reduce((sum, [, val]) => sum + val, 0);
    
    if (amount + otherSplits > totalAmount) {
      setErrors({ ...errors, [mode]: 'Total exceeds bill amount' });
      return;
    }
    
    // Clear error for this mode
    const newErrors = { ...errors };
    delete newErrors[mode];
    setErrors(newErrors);
    
    setSplits({ ...splits, [mode]: amount });
  };

  // Quick split buttons
  const quickSplit = (mode, percentage) => {
    const amount = (totalAmount * percentage) / 100;
    updateSplit(mode, amount.toFixed(2));
  };

  // Auto-fill remaining
  const autoFillRemaining = (mode) => {
    if (remainingAmount > 0) {
      updateSplit(mode, remainingAmount.toFixed(2));
    }
  };

  // Validate and confirm
  const handleConfirm = () => {
    // Validate total
    const totalPaid = Object.values(splits).reduce((sum, amount) => sum + amount, 0);
    
    if (Math.abs(totalPaid - totalAmount) > 0.01) {
      toast.error('Payment split must equal total amount');
      return;
    }
    
    // Filter out zero amounts
    const finalSplits = Object.entries(splits)
      .filter(([, amount]) => amount > 0)
      .reduce((acc, [mode, amount]) => ({
        ...acc,
        [mode]: amount
      }), {});
    
    if (Object.keys(finalSplits).length === 0) {
      toast.error('Please enter payment amounts');
      return;
    }
    
    onConfirm(finalSplits);
    handleClose();
  };

  // Reset and close
  const handleClose = () => {
    setSplits({ cash: 0, card: 0, upi: 0, other: 0 });
    setErrors({});
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="modal-overlay">
      <div className="modal-content payment-split-modal">
        <div className="modal-header">
          <h2>Split Payment</h2>
          <button className="btn-close" onClick={handleClose}>
            <FiX />
          </button>
        </div>

        <div className="total-amount-display">
          <FiDollarSign className="amount-icon" />
          <div className="amount-info">
            <span className="amount-label">Total Amount</span>
            <span className="amount-value">₹{totalAmount.toLocaleString()}</span>
          </div>
        </div>

        <div className="payment-modes-grid">
          {modes.map(mode => (
            <div key={mode.id} className="payment-mode-card">
              <div className="mode-header">
                <span className="mode-icon">{mode.icon}</span>
                <span className="mode-name">{mode.name}</span>
              </div>
              
              <div className="mode-input-group">
                <span className="currency-symbol">₹</span>
                <input
                  type="number"
                  value={splits[mode.id] || ''}
                  onChange={(e) => updateSplit(mode.id, e.target.value)}
                  placeholder="0.00"
                  step="0.01"
                  className={errors[mode.id] ? 'error' : ''}
                />
              </div>
              
              {errors[mode.id] && (
                <span className="error-message">{errors[mode.id]}</span>
              )}
              
              <div className="quick-actions">
                <button 
                  className="quick-btn"
                  onClick={() => quickSplit(mode.id, 50)}
                  title="50% of total"
                >
                  50%
                </button>
                <button 
                  className="quick-btn"
                  onClick={() => quickSplit(mode.id, 100)}
                  title="100% of total"
                >
                  100%
                </button>
                <button 
                  className="quick-btn fill-btn"
                  onClick={() => autoFillRemaining(mode.id)}
                  disabled={remainingAmount <= 0}
                  title="Fill remaining amount"
                >
                  Fill
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="split-summary">
          <div className="summary-row">
            <span>Total Entered:</span>
            <span className="summary-value">
              ₹{Object.values(splits).reduce((sum, amt) => sum + amt, 0).toFixed(2)}
            </span>
          </div>
          <div className={`summary-row ${remainingAmount === 0 ? 'balanced' : 'unbalanced'}`}>
            <span>Remaining:</span>
            <span className="summary-value">
              ₹{remainingAmount.toFixed(2)}
            </span>
          </div>
        </div>

        {remainingAmount !== 0 && (
          <div className="split-warning">
            <FiAlertCircle />
            <span>
              {remainingAmount > 0 
                ? `Please allocate ₹${remainingAmount.toFixed(2)} more`
                : `Reduce payment by ₹${Math.abs(remainingAmount).toFixed(2)}`
              }
            </span>
          </div>
        )}

        <div className="modal-footer">
          <button 
            className="btn-secondary"
            onClick={handleClose}
          >
            Cancel
          </button>
          <button 
            className="btn-primary"
            onClick={handleConfirm}
            disabled={Math.abs(remainingAmount) > 0.01}
          >
            <FiCheck /> Confirm Payment
          </button>
        </div>
      </div>
    </div>
  );
}

export default PaymentSplitModal;