import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { 
  FiMenu, FiSearch, FiBell, FiLogOut, 
  FiRefreshCw, FiWifi, FiWifiOff,
  FiShoppingCart, FiPackage, FiUsers
} from 'react-icons/fi';
import './Header.css';

function Header({ toggleSidebar }) {
  const { logout } = useAuth();
  const [currentTime, setCurrentTime] = useState(new Date());
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [showNotifications, setShowNotifications] = useState(false);

  useEffect(() => {
    // Update time every second
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    // Check online status
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      clearInterval(timer);
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const handleLogout = () => {
    if (window.confirm('Are you sure you want to logout?')) {
      logout();
    }
  };

  const formatTime = (date) => {
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  const formatDate = (date) => {
    return date.toLocaleDateString('en-US', {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  return (
    <header className="header">
      <div className="header-left">
        <button className="btn-icon" onClick={toggleSidebar}>
          <FiMenu />
        </button>
        
        <div className="search-bar">
          <FiSearch className="search-icon" />
          <input 
            type="text" 
            placeholder="Search items, customers, bills... (Ctrl+K)"
            className="search-input"
          />
        </div>
      </div>
      
      <div className="header-right">
        <div className="header-info">
          <div className="connection-status">
            {isOnline ? (
              <>
                <FiWifi className="status-icon online" />
                <span>Online</span>
              </>
            ) : (
              <>
                <FiWifiOff className="status-icon offline" />
                <span>Offline</span>
              </>
            )}
          </div>
          
          <div className="datetime">
            <div className="time">{formatTime(currentTime)}</div>
            <div className="date">{formatDate(currentTime)}</div>
          </div>
        </div>
        
        <button className="btn-icon btn-sync">
          <FiRefreshCw />
        </button>
        
        <div className="notification-container">
          <button 
            className="btn-icon btn-notification"
            onClick={() => setShowNotifications(!showNotifications)}
          >
            <FiBell />
            <span className="notification-badge">3</span>
          </button>
          
          {showNotifications && (
            <div className="notification-dropdown">
              <div className="notification-header">
                <h4>Notifications</h4>
                <button className="mark-all">Mark all read</button>
              </div>
              <div className="notification-list">
                <div className="notification-item unread">
                  <div className="notification-icon success">
                    <FiShoppingCart />
                  </div>
                  <div className="notification-content">
                    <p>New sale completed - Bill #1234</p>
                    <span className="notification-time">2 mins ago</span>
                  </div>
                </div>
                <div className="notification-item unread">
                  <div className="notification-icon warning">
                    <FiPackage />
                  </div>
                  <div className="notification-content">
                    <p>Low stock alert: 5 items below threshold</p>
                    <span className="notification-time">15 mins ago</span>
                  </div>
                </div>
                <div className="notification-item">
                  <div className="notification-icon info">
                    <FiUsers />
                  </div>
                  <div className="notification-content">
                    <p>New customer registered</p>
                    <span className="notification-time">1 hour ago</span>
                  </div>
                </div>
              </div>
              <div className="notification-footer">
                <button className="view-all">View all notifications</button>
              </div>
            </div>
          )}
        </div>
        
        <button className="btn-icon btn-logout" onClick={handleLogout}>
          <FiLogOut />
        </button>
      </div>
    </header>
  );
}

export default Header;