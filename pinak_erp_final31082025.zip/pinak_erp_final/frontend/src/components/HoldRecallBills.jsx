import React, { useState, useEffect } from 'react';
import './HoldRecallBills.css';
import { formatCurrency, formatDate } from '../services/api';

const HoldRecallBills = ({ 
  onRecall, 
  onDelete,
  onClose,
  currentBill = null 
}) => {
  const [heldBills, setHeldBills] = useState([]);
  const [selectedBill, setSelectedBill] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [showConfirmDelete, setShowConfirmDelete] = useState(null);

  useEffect(() => {
    loadHeldBills();
  }, []);

  const loadHeldBills = () => {
    // Load from localStorage or API
    const saved = localStorage.getItem('heldBills');
    if (saved) {
      try {
        const bills = JSON.parse(saved);
        setHeldBills(bills.sort((a, b) => new Date(b.holdTime) - new Date(a.holdTime)));
      } catch (error) {
        console.error('Error loading held bills:', error);
        setHeldBills([]);
      }
    }
  };

  const saveBillToHold = (bill) => {
    const newBill = {
      id: `HOLD_${Date.now()}`,
      holdTime: new Date().toISOString(),
      status: 'held',
      ...bill
    };

    const updatedBills = [...heldBills, newBill];
    setHeldBills(updatedBills);
    localStorage.setItem('heldBills', JSON.stringify(updatedBills));
    
    return newBill.id;
  };

  const handleRecall = (bill) => {
    if (!bill) return;
    
    // Remove from held bills
    const updatedBills = heldBills.filter(b => b.id !== bill.id);
    setHeldBills(updatedBills);
    localStorage.setItem('heldBills', JSON.stringify(updatedBills));
    
    // Callback to parent component
    onRecall(bill);
    onClose();
  };

  const handleDelete = (billId) => {
    const updatedBills = heldBills.filter(b => b.id !== billId);
    setHeldBills(updatedBills);
    localStorage.setItem('heldBills', JSON.stringify(updatedBills));
    
    setShowConfirmDelete(null);
    if (onDelete) onDelete(billId);
  };

  const getFilteredBills = () => {
    let filtered = [...heldBills];
    
    // Search filter
    if (searchTerm) {
      filtered = filtered.filter(bill => 
        bill.customerName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        bill.customerMobile?.includes(searchTerm) ||
        bill.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        bill.items?.some(item => 
          item.barcode?.includes(searchTerm) ||
          item.styleCode?.toLowerCase().includes(searchTerm.toLowerCase())
        )
      );
    }
    
    // Status filter
    if (filterStatus !== 'all') {
      filtered = filtered.filter(bill => bill.status === filterStatus);
    }
    
    return filtered;
  };

  const calculateBillSummary = (bill) => {
    if (!bill.items || bill.items.length === 0) {
      return { itemCount: 0, totalQty: 0, totalAmount: 0 };
    }
    
    const itemCount = bill.items.length;
    const totalQty = bill.items.reduce((sum, item) => sum + (item.qty || 0), 0);
    const totalAmount = bill.items.reduce((sum, item) => sum + ((item.qty || 0) * (item.mrpIncl || 0)), 0);
    
    return { itemCount, totalQty, totalAmount };
  };

  const formatHoldDuration = (holdTime) => {
    const now = new Date();
    const held = new Date(holdTime);
    const diffMs = now - held;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHours / 24);
    
    if (diffDays > 0) return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
    if (diffHours > 0) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
    if (diffMins > 0) return `${diffMins} minute${diffMins > 1 ? 's' : ''} ago`;
    return 'Just now';
  };

  const filteredBills = getFilteredBills();

  return (
    <div className="hold-recall-modal">
      <div className="hold-recall-content">
        <div className="hold-recall-header">
          <h2>Held Bills</h2>
          <button className="close-btn" onClick={onClose}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
              <path d="M6 6L18 18M6 18L18 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
            </svg>
          </button>
        </div>

        <div className="hold-recall-filters">
          <div className="search-box">
            <svg className="search-icon" width="20" height="20" viewBox="0 0 20 20" fill="none">
              <path d="M9 17A8 8 0 109 1a8 8 0 000 16zM19 19l-4.35-4.35" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
            </svg>
            <input
              type="text"
              placeholder="Search by customer, mobile, or item..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="filter-buttons">
            <button 
              className={filterStatus === 'all' ? 'active' : ''}
              onClick={() => setFilterStatus('all')}
            >
              All ({heldBills.length})
            </button>
            <button 
              className={filterStatus === 'held' ? 'active' : ''}
              onClick={() => setFilterStatus('held')}
            >
              Active ({heldBills.filter(b => b.status === 'held').length})
            </button>
            <button 
              className={filterStatus === 'expired' ? 'active' : ''}
              onClick={() => setFilterStatus('expired')}
            >
              Expired ({heldBills.filter(b => b.status === 'expired').length})
            </button>
          </div>
        </div>

        <div className="held-bills-grid">
          {filteredBills.length === 0 ? (
            <div className="no-bills">
              <svg width="64" height="64" viewBox="0 0 64 64" fill="none">
                <rect x="8" y="12" width="48" height="40" rx="4" stroke="#d1d5db" strokeWidth="2"/>
                <path d="M8 20H56" stroke="#d1d5db" strokeWidth="2"/>
                <circle cx="32" cy="36" r="8" stroke="#d1d5db" strokeWidth="2"/>
                <path d="M32 32V40M28 36H36" stroke="#d1d5db" strokeWidth="2" strokeLinecap="round"/>
              </svg>
              <h3>No Held Bills</h3>
              <p>There are no bills on hold at the moment</p>
            </div>
          ) : (
            filteredBills.map(bill => {
              const summary = calculateBillSummary(bill);
              const isSelected = selectedBill?.id === bill.id;
              
              return (
                <div 
                  key={bill.id}
                  className={`held-bill-card ${isSelected ? 'selected' : ''}`}
                  onClick={() => setSelectedBill(bill)}
                >
                  <div className="bill-card-header">
                    <div className="bill-id">
                      <span className="bill-label">Bill ID</span>
                      <span className="bill-value">{bill.id}</span>
                    </div>
                    <div className="bill-time">
                      <span className="time-ago">{formatHoldDuration(bill.holdTime)}</span>
                    </div>
                  </div>
                  
                  <div className="bill-card-body">
                    {bill.customerName || bill.customerMobile ? (
                      <div className="customer-info">
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                          <circle cx="8" cy="5" r="3" stroke="currentColor" strokeWidth="1.5"/>
                          <path d="M2 14c0-3.314 2.686-6 6-6s6 2.686 6 6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                        </svg>
                        <span>{bill.customerName || bill.customerMobile || 'Walk-in Customer'}</span>
                      </div>
                    ) : (
                      <div className="customer-info">
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                          <path d="M8 2v6l3 3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                          <circle cx="8" cy="8" r="6" stroke="currentColor" strokeWidth="1.5"/>
                        </svg>
                        <span>Walk-in Customer</span>
                      </div>
                    )}
                    
                    <div className="bill-summary">
                      <div className="summary-item">
                        <span className="summary-label">Items</span>
                        <span className="summary-value">{summary.itemCount}</span>
                      </div>
                      <div className="summary-item">
                        <span className="summary-label">Qty</span>
                        <span className="summary-value">{summary.totalQty}</span>
                      </div>
                      <div className="summary-item highlight">
                        <span className="summary-label">Amount</span>
                        <span className="summary-value">{formatCurrency(summary.totalAmount)}</span>
                      </div>
                    </div>
                    
                    {bill.items && bill.items.length > 0 && (
                      <div className="bill-items-preview">
                        {bill.items.slice(0, 2).map((item, idx) => (
                          <div key={idx} className="item-preview">
                            {item.styleCode} - {item.color} - {item.size} ({item.qty})
                          </div>
                        ))}
                        {bill.items.length > 2 && (
                          <div className="more-items">+{bill.items.length - 2} more items</div>
                        )}
                      </div>
                    )}
                  </div>
                  
                  <div className="bill-card-actions">
                    <button 
                      className="action-btn recall-btn"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleRecall(bill);
                      }}
                    >
                      <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                        <path d="M2 8h12m0 0L10 4m4 4l-4 4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                      Recall
                    </button>
                    <button 
                      className="action-btn delete-btn"
                      onClick={(e) => {
                        e.stopPropagation();
                        setShowConfirmDelete(bill.id);
                      }}
                    >
                      <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                        <path d="M6 2h4m-5 2h6m-7 0h8l-.621 8.696A2 2 0 019.383 14H6.617a2 2 0 01-1.996-1.804L4 4z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                      Delete
                    </button>
                  </div>
                  
                  {showConfirmDelete === bill.id && (
                    <div className="confirm-delete" onClick={(e) => e.stopPropagation()}>
                      <p>Delete this held bill?</p>
                      <div className="confirm-actions">
                        <button 
                          className="confirm-yes"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDelete(bill.id);
                          }}
                        >
                          Yes, Delete
                        </button>
                        <button 
                          className="confirm-no"
                          onClick={(e) => {
                            e.stopPropagation();
                            setShowConfirmDelete(null);
                          }}
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {selectedBill && (
          <div className="bill-details-panel">
            <h3>Bill Details</h3>
            <div className="details-content">
              <div className="detail-row">
                <span>Bill ID:</span>
                <strong>{selectedBill.id}</strong>
              </div>
              <div className="detail-row">
                <span>Held At:</span>
                <strong>{formatDate(selectedBill.holdTime)} {new Date(selectedBill.holdTime).toLocaleTimeString()}</strong>
              </div>
              {selectedBill.customerName && (
                <div className="detail-row">
                  <span>Customer:</span>
                  <strong>{selectedBill.customerName}</strong>
                </div>
              )}
              {selectedBill.customerMobile && (
                <div className="detail-row">
                  <span>Mobile:</span>
                  <strong>{selectedBill.customerMobile}</strong>
                </div>
              )}
              
              <div className="items-detail">
                <h4>Items ({selectedBill.items?.length || 0})</h4>
                <div className="items-list">
                  {selectedBill.items?.map((item, idx) => (
                    <div key={idx} className="item-detail">
                      <span>{item.styleCode} - {item.color} - {item.size}</span>
                      <span>{item.qty} × {formatCurrency(item.mrpIncl)}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

// Hold button component for POS screen
export const HoldButton = ({ onClick, disabled = false, billData = null }) => {
  const [isHolding, setIsHolding] = useState(false);
  
  const handleHold = async () => {
    if (disabled || !billData || billData.items.length === 0) return;
    
    setIsHolding(true);
    
    try {
      // Save current bill to hold
      const heldBills = JSON.parse(localStorage.getItem('heldBills') || '[]');
      const newBill = {
        id: `HOLD_${Date.now()}`,
        holdTime: new Date().toISOString(),
        status: 'held',
        ...billData
      };
      
      heldBills.push(newBill);
      localStorage.setItem('heldBills', JSON.stringify(heldBills));
      
      if (onClick) onClick(newBill);
      
      // Show success message
      const notification = document.createElement('div');
      notification.className = 'hold-notification success';
      notification.textContent = 'Bill held successfully';
      document.body.appendChild(notification);
      
      setTimeout(() => {
        document.body.removeChild(notification);
      }, 3000);
      
    } catch (error) {
      console.error('Error holding bill:', error);
      
      // Show error message
      const notification = document.createElement('div');
      notification.className = 'hold-notification error';
      notification.textContent = 'Failed to hold bill';
      document.body.appendChild(notification);
      
      setTimeout(() => {
        document.body.removeChild(notification);
      }, 3000);
    } finally {
      setIsHolding(false);
    }
  };
  
  return (
    <button 
      className={`hold-button ${isHolding ? 'holding' : ''} ${disabled ? 'disabled' : ''}`}
      onClick={handleHold}
      disabled={disabled || isHolding}
      title="Hold current bill"
    >
      {isHolding ? (
        <>
          <div className="spinner"></div>
          <span>Holding...</span>
        </>
      ) : (
        <>
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
            <circle cx="10" cy="10" r="8" stroke="currentColor" strokeWidth="2"/>
            <path d="M8 7v6M12 7v6" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
          </svg>
          <span>Hold Bill</span>
        </>
      )}
    </button>
  );
};

export default HoldRecallBills;