import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './BillModification.css';
import { formatCurrency, formatDate } from '../services/api';
import { API_BASE_URL as API_URL } from '../services/api';
import { toast } from 'react-toastify';
import LoadingOverlay from '../components/LoadingOverlay';
import validationService from '../services/validationService';

const BillModification = ({ billNo, onClose, onSave }) => {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [billData, setBillData] = useState(null);
  const [originalBillData, setOriginalBillData] = useState(null);
  const [modifications, setModifications] = useState([]);
  const [showHistory, setShowHistory] = useState(false);
  const [modificationReason, setModificationReason] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [isVerified, setIsVerified] = useState(false);
  const [changesSummary, setChangesSummary] = useState([]);

  useEffect(() => {
    if (billNo) {
      fetchBillData();
    }
  }, [billNo]);

  useEffect(() => {
    if (billData && originalBillData) {
      calculateChanges();
    }
  }, [billData]);

  const fetchBillData = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${API_URL}/sales/bill/${billNo}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      
      const bill = response.data;
      setBillData(bill);
      setOriginalBillData(JSON.parse(JSON.stringify(bill))); // Deep clone
      
      // Fetch modification history
      fetchModificationHistory();
    } catch (error) {
      toast.error('Failed to fetch bill data');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const fetchModificationHistory = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${API_URL}/sales/bill/${billNo}/history`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setModifications(response.data || []);
    } catch (error) {
      console.error('Failed to fetch modification history:', error);
    }
  };

  const verifyAdminPassword = async () => {
    if (!adminPassword) {
      toast.error('Please enter admin password');
      return;
    }

    try {
      const token = localStorage.getItem('token');
      const response = await axios.post(
        `${API_URL}/auth/verify-admin`,
        { password: adminPassword },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      if (response.data.verified) {
        setIsVerified(true);
        toast.success('Admin verification successful');
      } else {
        toast.error('Invalid admin password');
      }
    } catch (error) {
      toast.error('Admin verification failed');
    }
  };

  const calculateChanges = () => {
    const changes = [];
    
    // Check item changes
    if (billData.items) {
      billData.items.forEach((item, index) => {
        const originalItem = originalBillData.items[index];
        if (originalItem) {
          if (item.qty !== originalItem.qty) {
            changes.push({
              type: 'quantity',
              item: item.styleCode,
              from: originalItem.qty,
              to: item.qty
            });
          }
          if (item.rate !== originalItem.rate) {
            changes.push({
              type: 'rate',
              item: item.styleCode,
              from: formatCurrency(originalItem.rate),
              to: formatCurrency(item.rate)
            });
          }
          if (item.discount !== originalItem.discount) {
            changes.push({
              type: 'discount',
              item: item.styleCode,
              from: `${originalItem.discount}%`,
              to: `${item.discount}%`
            });
          }
        }
      });
      
      // Check for removed items
      originalBillData.items.forEach((originalItem, index) => {
        if (!billData.items.find(item => item.barcode === originalItem.barcode)) {
          changes.push({
            type: 'removed',
            item: originalItem.styleCode,
            from: `${originalItem.qty} units`,
            to: 'Removed'
          });
        }
      });
      
      // Check for added items
      billData.items.forEach((item) => {
        if (!originalBillData.items.find(originalItem => originalItem.barcode === item.barcode)) {
          changes.push({
            type: 'added',
            item: item.styleCode,
            from: 'N/A',
            to: `${item.qty} units`
          });
        }
      });
    }
    
    // Check payment changes
    if (billData.paymentMode !== originalBillData.paymentMode) {
      changes.push({
        type: 'payment',
        item: 'Payment Mode',
        from: originalBillData.paymentMode,
        to: billData.paymentMode
      });
    }
    
    // Check customer changes
    if (billData.customerMobile !== originalBillData.customerMobile) {
      changes.push({
        type: 'customer',
        item: 'Customer',
        from: originalBillData.customerMobile || 'Walk-in',
        to: billData.customerMobile || 'Walk-in'
      });
    }
    
    setChangesSummary(changes);
  };

  const handleItemChange = (index, field, value) => {
    const updatedItems = [...billData.items];
    updatedItems[index][field] = value;
    
    // Recalculate item amount
    if (field === 'qty' || field === 'rate' || field === 'discount') {
      const item = updatedItems[index];
      const qty = parseFloat(item.qty) || 0;
      const rate = parseFloat(item.rate) || 0;
      const discount = parseFloat(item.discount) || 0;
      
      const subtotal = qty * rate;
      const discountAmount = (subtotal * discount) / 100;
      item.amount = subtotal - discountAmount;
    }
    
    setBillData({ ...billData, items: updatedItems });
  };

  const handleRemoveItem = (index) => {
    if (!isVerified) {
      toast.error('Admin verification required');
      return;
    }
    
    if (window.confirm('Are you sure you want to remove this item?')) {
      const updatedItems = billData.items.filter((_, i) => i !== index);
      setBillData({ ...billData, items: updatedItems });
    }
  };

  const handleAddItem = async (barcode) => {
    if (!isVerified) {
      toast.error('Admin verification required');
      return;
    }
    
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${API_URL}/items/${barcode}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      
      const item = response.data;
      const newItem = {
        barcode: item.barcode,
        styleCode: item.styleCode,
        color: item.color,
        size: item.size,
        hsn: item.hsn,
        qty: 1,
        rate: item.mrpIncl,
        discount: 0,
        amount: item.mrpIncl
      };
      
      setBillData({
        ...billData,
        items: [...billData.items, newItem]
      });
      
      toast.success('Item added successfully');
    } catch (error) {
      toast.error('Item not found');
    }
  };

  const calculateTotals = () => {
    if (!billData || !billData.items) {
      return {
        subtotal: 0,
        discount: 0,
        tax: 0,
        grandTotal: 0
      };
    }
    
    const subtotal = billData.items.reduce((sum, item) => {
      const qty = parseFloat(item.qty) || 0;
      const rate = parseFloat(item.rate) || 0;
      return sum + (qty * rate);
    }, 0);
    
    const discount = billData.items.reduce((sum, item) => {
      const qty = parseFloat(item.qty) || 0;
      const rate = parseFloat(item.rate) || 0;
      const discountPct = parseFloat(item.discount) || 0;
      return sum + ((qty * rate * discountPct) / 100);
    }, 0);
    
    const taxableAmount = subtotal - discount;
    const taxRate = billData.taxRegion === 'local' ? 9 : 18; // CGST+SGST or IGST
    const tax = (taxableAmount * taxRate) / 100;
    const grandTotal = taxableAmount + tax;
    
    return {
      subtotal,
      discount,
      tax,
      taxRate,
      grandTotal
    };
  };

  const handleSave = async () => {
    if (!isVerified) {
      toast.error('Admin verification required');
      return;
    }
    
    if (!modificationReason.trim()) {
      toast.error('Please provide a reason for modification');
      return;
    }
    
    if (changesSummary.length === 0) {
      toast.info('No changes detected');
      return;
    }
    
    setSaving(true);
    try {
      const token = localStorage.getItem('token');
      const totals = calculateTotals();
      
      const modificationData = {
        billNo: billData.billNo,
        items: billData.items,
        customerMobile: billData.customerMobile,
        paymentMode: billData.paymentMode,
        totals,
        modificationReason,
        changes: changesSummary,
        modifiedBy: localStorage.getItem('username'),
        modifiedAt: new Date().toISOString()
      };
      
      await axios.post(
        `${API_URL}/sales/bill/${billNo}/modify`,
        modificationData,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      toast.success('Bill modified successfully');
      if (onSave) onSave(modificationData);
      onClose();
    } catch (error) {
      toast.error('Failed to save modifications');
      console.error(error);
    } finally {
      setSaving(false);
    }
  };

  const handleRevert = () => {
    if (window.confirm('Revert all changes? This cannot be undone.')) {
      setBillData(JSON.parse(JSON.stringify(originalBillData)));
      setChangesSummary([]);
      toast.info('Changes reverted');
    }
  };

  if (loading) {
    return <LoadingOverlay show={true} message="Loading bill data..." />;
  }

  if (!billData) {
    return (
      <div className="bill-modification-error">
        <h3>Bill not found</h3>
        <button onClick={onClose}>Close</button>
      </div>
    );
  }

  const totals = calculateTotals();

  return (
    <div className="bill-modification-modal">
      <div className="bill-modification-content">
        <div className="modification-header">
          <div className="header-info">
            <h2>Modify Bill</h2>
            <div className="bill-info">
              <span className="bill-no">{billData.billNo}</span>
              <span className="bill-date">{formatDate(billData.billDate)}</span>
              <span className={`bill-status ${billData.isLocked ? 'locked' : 'open'}`}>
                {billData.isLocked ? 'Locked' : 'Open'}
              </span>
            </div>
          </div>
          <button className="close-btn" onClick={onClose}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
              <path d="M6 6L18 18M6 18L18 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
            </svg>
          </button>
        </div>

        {!isVerified && (
          <div className="admin-verification">
            <div className="verification-box">
              <h3>Admin Verification Required</h3>
              <p>This bill is locked. Enter admin password to modify.</p>
              <div className="password-input">
                <input
                  type="password"
                  placeholder="Admin Password"
                  value={adminPassword}
                  onChange={(e) => setAdminPassword(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && verifyAdminPassword()}
                />
                <button onClick={verifyAdminPassword}>Verify</button>
              </div>
            </div>
          </div>
        )}

        <div className={`modification-body ${!isVerified ? 'disabled' : ''}`}>
          <div className="modification-main">
            {/* Customer Section */}
            <div className="section customer-section">
              <h3>Customer Information</h3>
              <div className="customer-fields">
                <div className="field-group">
                  <label>Mobile Number</label>
                  <input
                    type="text"
                    value={billData.customerMobile || ''}
                    onChange={(e) => setBillData({ ...billData, customerMobile: e.target.value })}
                    placeholder="10-digit mobile"
                    disabled={!isVerified}
                  />
                </div>
                <div className="field-group">
                  <label>Customer Name</label>
                  <input
                    type="text"
                    value={billData.customerName || ''}
                    disabled
                    placeholder="Auto-populated"
                  />
                </div>
              </div>
            </div>

            {/* Items Section */}
            <div className="section items-section">
              <div className="section-header">
                <h3>Bill Items ({billData.items?.length || 0})</h3>
                {isVerified && (
                  <button className="add-item-btn" onClick={() => {
                    const barcode = prompt('Enter barcode:');
                    if (barcode) handleAddItem(barcode);
                  }}>
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                      <path d="M8 4v8M4 8h8" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                    </svg>
                    Add Item
                  </button>
                )}
              </div>
              
              <div className="items-table">
                <table>
                  <thead>
                    <tr>
                      <th>Barcode</th>
                      <th>Item Details</th>
                      <th>Qty</th>
                      <th>Rate</th>
                      <th>Discount %</th>
                      <th>Amount</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {billData.items?.map((item, index) => (
                      <tr key={index} className={item.isModified ? 'modified' : ''}>
                        <td className="barcode-cell">{item.barcode}</td>
                        <td className="item-details">
                          <div className="style-code">{item.styleCode}</div>
                          <div className="item-attributes">
                            {item.color} - {item.size}
                          </div>
                        </td>
                        <td>
                          <input
                            type="number"
                            className="qty-input"
                            value={item.qty}
                            onChange={(e) => handleItemChange(index, 'qty', e.target.value)}
                            min="1"
                            disabled={!isVerified}
                          />
                        </td>
                        <td>
                          <input
                            type="number"
                            className="rate-input"
                            value={item.rate}
                            onChange={(e) => handleItemChange(index, 'rate', e.target.value)}
                            min="0"
                            step="0.01"
                            disabled={!isVerified}
                          />
                        </td>
                        <td>
                          <input
                            type="number"
                            className="discount-input"
                            value={item.discount || 0}
                            onChange={(e) => handleItemChange(index, 'discount', e.target.value)}
                            min="0"
                            max="100"
                            disabled={!isVerified}
                          />
                        </td>
                        <td className="amount-cell">{formatCurrency(item.amount)}</td>
                        <td>
                          {isVerified && (
                            <button 
                              className="remove-btn"
                              onClick={() => handleRemoveItem(index)}
                              title="Remove item"
                            >
                              <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                <path d="M4 4l8 8M12 4l-8 8" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                              </svg>
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Payment Section */}
            <div className="section payment-section">
              <h3>Payment Information</h3>
              <div className="payment-fields">
                <div className="field-group">
                  <label>Payment Mode</label>
                  <select
                    value={billData.paymentMode || 'CASH'}
                    onChange={(e) => setBillData({ ...billData, paymentMode: e.target.value })}
                    disabled={!isVerified}
                  >
                    <option value="CASH">Cash</option>
                    <option value="CARD">Card</option>
                    <option value="UPI">UPI</option>
                    <option value="SPLIT">Split Payment</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Modification Reason */}
            {isVerified && (
              <div className="section reason-section">
                <h3>Modification Reason (Required)</h3>
                <textarea
                  value={modificationReason}
                  onChange={(e) => setModificationReason(e.target.value)}
                  placeholder="Enter detailed reason for modification..."
                  rows="3"
                  required
                />
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="modification-sidebar">
            {/* Changes Summary */}
            <div className="changes-summary">
              <h3>Changes Summary</h3>
              {changesSummary.length === 0 ? (
                <p className="no-changes">No changes detected</p>
              ) : (
                <div className="changes-list">
                  {changesSummary.map((change, index) => (
                    <div key={index} className={`change-item ${change.type}`}>
                      <div className="change-type">{change.type.toUpperCase()}</div>
                      <div className="change-details">
                        <div className="change-item-name">{change.item}</div>
                        <div className="change-values">
                          <span className="from-value">{change.from}</span>
                          <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                            <path d="M4 8h8m0 0L9 5m3 3l-3 3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                          </svg>
                          <span className="to-value">{change.to}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Totals */}
            <div className="bill-totals">
              <h3>Bill Totals</h3>
              <div className="total-row">
                <span>Subtotal:</span>
                <span>{formatCurrency(totals.subtotal)}</span>
              </div>
              <div className="total-row">
                <span>Discount:</span>
                <span>-{formatCurrency(totals.discount)}</span>
              </div>
              <div className="total-row">
                <span>Tax ({totals.taxRate}%):</span>
                <span>{formatCurrency(totals.tax)}</span>
              </div>
              <div className="total-row grand-total">
                <span>Grand Total:</span>
                <span>{formatCurrency(totals.grandTotal)}</span>
              </div>
            </div>

            {/* Modification History */}
            <div className="modification-history">
              <div 
                className="history-header"
                onClick={() => setShowHistory(!showHistory)}
              >
                <h3>Modification History ({modifications.length})</h3>
                <svg 
                  className={`chevron ${showHistory ? 'rotated' : ''}`} 
                  width="16" height="16" viewBox="0 0 16 16" fill="none"
                >
                  <path d="M4 6l4 4 4-4" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                </svg>
              </div>
              
              {showHistory && (
                <div className="history-list">
                  {modifications.length === 0 ? (
                    <p className="no-history">No previous modifications</p>
                  ) : (
                    modifications.map((mod, index) => (
                      <div key={index} className="history-item">
                        <div className="history-date">
                          {formatDate(mod.modifiedAt)}
                        </div>
                        <div className="history-user">By: {mod.modifiedBy}</div>
                        <div className="history-reason">{mod.reason}</div>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        {isVerified && (
          <div className="modification-footer">
            <div className="footer-left">
              <button className="revert-btn" onClick={handleRevert}>
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                  <path d="M3 8a5 5 0 0110 0M3 8l2-2m-2 2l2 2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                </svg>
                Revert Changes
              </button>
            </div>
            <div className="footer-right">
              <button className="cancel-btn" onClick={onClose}>Cancel</button>
              <button 
                className="save-btn" 
                onClick={handleSave}
                disabled={saving || changesSummary.length === 0 || !modificationReason}
              >
                {saving ? 'Saving...' : 'Save Modifications'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default BillModification;