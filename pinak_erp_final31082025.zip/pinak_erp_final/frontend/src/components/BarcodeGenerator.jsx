import React, { useState, useRef, useEffect } from 'react';
import JsBarcode from 'jsbarcode';
import './BarcodeGenerator.css';

const BarcodeGenerator = ({ 
  items = [], // Array of items with barcode, style_code, color, size, mrp_incl
  onClose,
  defaultSettings = {
    labelWidth: 50,
    labelHeight: 25,
    fontSize: 10,
    showPrice: true,
    showStyleCode: true,
    showSize: true,
    pricePrefix: '₹',
    barcodeHeight: 40,
    margin: 5
  }
}) => {
  const [settings, setSettings] = useState(defaultSettings);
  const [selectedItems, setSelectedItems] = useState({});
  const [printQuantities, setPrintQuantities] = useState({});
  const [previewItem, setPreviewItem] = useState(null);
  const [paperSize, setPaperSize] = useState('A4');
  const [labelsPerRow, setLabelsPerRow] = useState(4);
  const printRef = useRef();
  const barcodeRef = useRef();

  useEffect(() => {
    // Initialize quantities
    const quantities = {};
    items.forEach(item => {
      quantities[item.barcode] = 1;
    });
    setPrintQuantities(quantities);
    
    // Select first item for preview
    if (items.length > 0) {
      setPreviewItem(items[0]);
      setSelectedItems({ [items[0].barcode]: true });
    }
  }, [items]);

  useEffect(() => {
    if (previewItem && barcodeRef.current) {
      generateBarcode(barcodeRef.current, previewItem.barcode);
    }
  }, [previewItem, settings]);

  const generateBarcode = (canvas, code) => {
    try {
      JsBarcode(canvas, code, {
        format: "CODE128",
        width: 2,
        height: settings.barcodeHeight,
        displayValue: true,
        fontSize: settings.fontSize,
        margin: 2,
        background: "#ffffff",
        lineColor: "#000000"
      });
    } catch (error) {
      console.error("Error generating barcode:", error);
    }
  };

  const handleSettingChange = (key, value) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const handleQuantityChange = (barcode, qty) => {
    const numQty = parseInt(qty) || 1;
    setPrintQuantities(prev => ({ ...prev, [barcode]: Math.max(1, numQty) }));
  };

  const handleSelectAll = () => {
    const allSelected = items.every(item => selectedItems[item.barcode]);
    if (allSelected) {
      setSelectedItems({});
    } else {
      const selected = {};
      items.forEach(item => {
        selected[item.barcode] = true;
      });
      setSelectedItems(selected);
    }
  };

  const toggleItemSelection = (barcode) => {
    setSelectedItems(prev => ({
      ...prev,
      [barcode]: !prev[barcode]
    }));
  };

  const getSelectedItemsForPrint = () => {
    const itemsForPrint = [];
    items.forEach(item => {
      if (selectedItems[item.barcode]) {
        const quantity = printQuantities[item.barcode] || 1;
        for (let i = 0; i < quantity; i++) {
          itemsForPrint.push(item);
        }
      }
    });
    return itemsForPrint;
  };

  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    const itemsToPrint = getSelectedItemsForPrint();
    
    if (itemsToPrint.length === 0) {
      alert('Please select at least one item to print');
      return;
    }

    const labelsHTML = itemsToPrint.map((item, index) => {
      const canvas = document.createElement('canvas');
      generateBarcode(canvas, item.barcode);
      const barcodeImage = canvas.toDataURL();

      return `
        <div class="label" style="
          width: ${settings.labelWidth}mm;
          height: ${settings.labelHeight}mm;
          padding: ${settings.margin}px;
          display: inline-block;
          border: 1px dashed #ddd;
          margin: 2px;
          text-align: center;
          overflow: hidden;
          page-break-inside: avoid;
        ">
          ${settings.showStyleCode ? `<div style="font-size: ${settings.fontSize - 2}px; font-weight: bold;">${item.style_code}</div>` : ''}
          ${settings.showSize ? `<div style="font-size: ${settings.fontSize - 2}px;">${item.color} - ${item.size}</div>` : ''}
          <img src="${barcodeImage}" style="max-width: 100%; height: auto;" />
          ${settings.showPrice ? `<div style="font-size: ${settings.fontSize}px; font-weight: bold; margin-top: 2px;">${settings.pricePrefix}${item.mrp_incl}</div>` : ''}
        </div>
      `;
    }).join('');

    const printContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Barcode Labels</title>
        <style>
          @page {
            size: ${paperSize};
            margin: 10mm;
          }
          body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
          }
          .container {
            display: flex;
            flex-wrap: wrap;
            gap: 2mm;
          }
          @media print {
            .label {
              break-inside: avoid;
            }
          }
        </style>
      </head>
      <body>
        <div class="container">
          ${labelsHTML}
        </div>
        <script>
          window.onload = function() {
            window.print();
            window.onafterprint = function() {
              window.close();
            };
          };
        </script>
      </body>
      </html>
    `;

    printWindow.document.write(printContent);
    printWindow.document.close();
  };

  const handleExportPDF = () => {
    // This would require a library like jsPDF
    alert('PDF export requires jsPDF library. Please implement based on your needs.');
  };

  return (
    <div className="barcode-generator-modal">
      <div className="barcode-generator-content">
        <div className="generator-header">
          <h2>Barcode Label Generator</h2>
          <button className="close-btn" onClick={onClose}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
              <path d="M6 6L18 18M6 18L18 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
            </svg>
          </button>
        </div>

        <div className="generator-body">
          {/* Left Panel - Item Selection */}
          <div className="selection-panel">
            <div className="panel-header">
              <h3>Select Items</h3>
              <button className="select-all-btn" onClick={handleSelectAll}>
                {items.every(item => selectedItems[item.barcode]) ? 'Deselect All' : 'Select All'}
              </button>
            </div>
            
            <div className="items-list">
              {items.map(item => (
                <div 
                  key={item.barcode} 
                  className={`item-row ${selectedItems[item.barcode] ? 'selected' : ''}`}
                >
                  <label className="item-checkbox">
                    <input
                      type="checkbox"
                      checked={selectedItems[item.barcode] || false}
                      onChange={() => toggleItemSelection(item.barcode)}
                    />
                    <div className="item-info">
                      <div className="item-barcode">{item.barcode}</div>
                      <div className="item-details">
                        {item.style_code} - {item.color} - {item.size}
                      </div>
                      <div className="item-price">₹{item.mrp_incl}</div>
                    </div>
                  </label>
                  <div className="quantity-control">
                    <span>Qty:</span>
                    <input
                      type="number"
                      min="1"
                      max="999"
                      value={printQuantities[item.barcode] || 1}
                      onChange={(e) => handleQuantityChange(item.barcode, e.target.value)}
                      disabled={!selectedItems[item.barcode]}
                    />
                  </div>
                  <button 
                    className="preview-btn"
                    onClick={() => setPreviewItem(item)}
                    title="Preview"
                  >
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                      <path d="M10 12a2 2 0 100-4 2 2 0 000 4z" fill="currentColor"/>
                      <path d="M10 4C5 4 1.73 7.11 1 10c.73 2.89 4 6 9 6s8.27-3.11 9-6c-.73-2.89-4-6-9-6zm0 10a4 4 0 110-8 4 4 0 010 8z" fill="currentColor"/>
                    </svg>
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Center Panel - Preview */}
          <div className="preview-panel">
            <div className="panel-header">
              <h3>Label Preview</h3>
            </div>
            
            {previewItem && (
              <div className="label-preview">
                <div 
                  className="preview-label"
                  style={{
                    width: `${settings.labelWidth * 4}px`,
                    padding: `${settings.margin}px`,
                  }}
                >
                  {settings.showStyleCode && (
                    <div className="preview-style">{previewItem.style_code}</div>
                  )}
                  {settings.showSize && (
                    <div className="preview-size">
                      {previewItem.color} - {previewItem.size}
                    </div>
                  )}
                  <canvas ref={barcodeRef} className="preview-barcode"></canvas>
                  {settings.showPrice && (
                    <div className="preview-price">
                      {settings.pricePrefix}{previewItem.mrp_incl}
                    </div>
                  )}
                </div>
              </div>
            )}

            <div className="preview-stats">
              <div className="stat">
                <span>Selected Items:</span>
                <strong>{Object.keys(selectedItems).filter(k => selectedItems[k]).length}</strong>
              </div>
              <div className="stat">
                <span>Total Labels:</span>
                <strong>{getSelectedItemsForPrint().length}</strong>
              </div>
              <div className="stat">
                <span>Pages Required:</span>
                <strong>{Math.ceil(getSelectedItemsForPrint().length / (labelsPerRow * 10))}</strong>
              </div>
            </div>
          </div>

          {/* Right Panel - Settings */}
          <div className="settings-panel">
            <div className="panel-header">
              <h3>Label Settings</h3>
            </div>
            
            <div className="settings-form">
              <div className="setting-group">
                <label>Paper Size</label>
                <select 
                  value={paperSize} 
                  onChange={(e) => setPaperSize(e.target.value)}
                >
                  <option value="A4">A4</option>
                  <option value="Letter">Letter</option>
                  <option value="Legal">Legal</option>
                </select>
              </div>

              <div className="setting-group">
                <label>Labels Per Row</label>
                <input
                  type="number"
                  min="1"
                  max="10"
                  value={labelsPerRow}
                  onChange={(e) => setLabelsPerRow(parseInt(e.target.value) || 4)}
                />
              </div>

              <div className="setting-group">
                <label>Label Width (mm)</label>
                <input
                  type="number"
                  min="20"
                  max="100"
                  value={settings.labelWidth}
                  onChange={(e) => handleSettingChange('labelWidth', parseInt(e.target.value) || 50)}
                />
              </div>

              <div className="setting-group">
                <label>Label Height (mm)</label>
                <input
                  type="number"
                  min="10"
                  max="50"
                  value={settings.labelHeight}
                  onChange={(e) => handleSettingChange('labelHeight', parseInt(e.target.value) || 25)}
                />
              </div>

              <div className="setting-group">
                <label>Barcode Height</label>
                <input
                  type="range"
                  min="20"
                  max="60"
                  value={settings.barcodeHeight}
                  onChange={(e) => handleSettingChange('barcodeHeight', parseInt(e.target.value))}
                />
                <span>{settings.barcodeHeight}px</span>
              </div>

              <div className="setting-group">
                <label>Font Size</label>
                <input
                  type="range"
                  min="8"
                  max="16"
                  value={settings.fontSize}
                  onChange={(e) => handleSettingChange('fontSize', parseInt(e.target.value))}
                />
                <span>{settings.fontSize}px</span>
              </div>

              <div className="setting-group">
                <label>Margin</label>
                <input
                  type="range"
                  min="0"
                  max="10"
                  value={settings.margin}
                  onChange={(e) => handleSettingChange('margin', parseInt(e.target.value))}
                />
                <span>{settings.margin}px</span>
              </div>

              <div className="setting-group checkbox-group">
                <label>
                  <input
                    type="checkbox"
                    checked={settings.showStyleCode}
                    onChange={(e) => handleSettingChange('showStyleCode', e.target.checked)}
                  />
                  Show Style Code
                </label>
              </div>

              <div className="setting-group checkbox-group">
                <label>
                  <input
                    type="checkbox"
                    checked={settings.showSize}
                    onChange={(e) => handleSettingChange('showSize', e.target.checked)}
                  />
                  Show Size/Color
                </label>
              </div>

              <div className="setting-group checkbox-group">
                <label>
                  <input
                    type="checkbox"
                    checked={settings.showPrice}
                    onChange={(e) => handleSettingChange('showPrice', e.target.checked)}
                  />
                  Show Price
                </label>
              </div>

              <div className="setting-group">
                <label>Price Prefix</label>
                <input
                  type="text"
                  value={settings.pricePrefix}
                  onChange={(e) => handleSettingChange('pricePrefix', e.target.value)}
                  disabled={!settings.showPrice}
                />
              </div>
            </div>
          </div>
        </div>

        <div className="generator-footer">
          <button className="btn-cancel" onClick={onClose}>Cancel</button>
          <div className="action-buttons">
            <button className="btn-export" onClick={handleExportPDF}>
              Export PDF
            </button>
            <button className="btn-print" onClick={handlePrint}>
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                <path d="M5 7V3h10v4M5 13H4a2 2 0 01-2-2V8a2 2 0 012-2h12a2 2 0 012 2v3a2 2 0 01-2 2h-1" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <rect x="5" y="11" width="10" height="6" rx="1" stroke="currentColor" strokeWidth="2"/>
              </svg>
              Print Labels ({getSelectedItemsForPrint().length})
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BarcodeGenerator;