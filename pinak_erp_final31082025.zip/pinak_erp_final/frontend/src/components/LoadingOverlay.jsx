import React from 'react';
import './LoadingOverlay.css';

const LoadingOverlay = ({ 
  show = false, 
  message = "Loading...", 
  type = "spinner", // spinner, dots, bars, pulse
  fullScreen = true,
  blur = true,
  progress = null // For progress bars (0-100)
}) => {
  if (!show) return null;

  const renderLoader = () => {
    switch (type) {
      case 'spinner':
        return (
          <div className="loader-spinner">
            <div className="spinner-ring"></div>
            <div className="spinner-ring"></div>
            <div className="spinner-ring"></div>
          </div>
        );

      case 'dots':
        return (
          <div className="loader-dots">
            <span className="dot"></span>
            <span className="dot"></span>
            <span className="dot"></span>
            <span className="dot"></span>
          </div>
        );

      case 'bars':
        return (
          <div className="loader-bars">
            <span className="bar"></span>
            <span className="bar"></span>
            <span className="bar"></span>
            <span className="bar"></span>
            <span className="bar"></span>
          </div>
        );

      case 'pulse':
        return (
          <div className="loader-pulse">
            <div className="pulse-ring"></div>
            <div className="pulse-center">
              <svg width="40" height="40" viewBox="0 0 40 40" fill="none">
                <path d="M20 5V15L27.5 22.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                <circle cx="20" cy="20" r="18" stroke="currentColor" strokeWidth="2"/>
              </svg>
            </div>
          </div>
        );

      case 'progress':
        return (
          <div className="loader-progress">
            <div className="progress-bar">
              <div 
                className="progress-fill" 
                style={{ width: `${progress || 0}%` }}
              >
                <span className="progress-glow"></span>
              </div>
            </div>
            {progress !== null && (
              <div className="progress-text">{Math.round(progress)}%</div>
            )}
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className={`loading-overlay ${fullScreen ? 'fullscreen' : 'contained'} ${blur ? 'blur' : ''}`}>
      <div className="loading-content">
        {renderLoader()}
        {message && (
          <div className="loading-message">{message}</div>
        )}
      </div>
    </div>
  );
};

// Mini loader for inline use
export const InlineLoader = ({ size = "small", color = "#9333ea" }) => {
  return (
    <div className={`inline-loader ${size}`} style={{ '--loader-color': color }}>
      <span></span>
      <span></span>
      <span></span>
    </div>
  );
};

// Button with loading state
export const LoadingButton = ({ 
  children, 
  loading = false, 
  disabled = false,
  onClick,
  className = "",
  type = "button",
  variant = "primary" // primary, secondary, danger, success
}) => {
  return (
    <button
      type={type}
      className={`loading-button ${variant} ${loading ? 'loading' : ''} ${className}`}
      disabled={disabled || loading}
      onClick={onClick}
    >
      {loading && (
        <div className="button-spinner">
          <span></span>
          <span></span>
          <span></span>
        </div>
      )}
      <span className={loading ? 'button-text-hidden' : 'button-text'}>
        {children}
      </span>
    </button>
  );
};

// Table/List loading skeleton
export const SkeletonLoader = ({ rows = 5, columns = 4, type = "table" }) => {
  if (type === 'table') {
    return (
      <div className="skeleton-table">
        <div className="skeleton-header">
          {[...Array(columns)].map((_, i) => (
            <div key={i} className="skeleton-cell header"></div>
          ))}
        </div>
        {[...Array(rows)].map((_, rowIndex) => (
          <div key={rowIndex} className="skeleton-row">
            {[...Array(columns)].map((_, colIndex) => (
              <div key={colIndex} className="skeleton-cell">
                <div className="skeleton-content"></div>
              </div>
            ))}
          </div>
        ))}
      </div>
    );
  }

  if (type === 'card') {
    return (
      <div className="skeleton-cards">
        {[...Array(rows)].map((_, i) => (
          <div key={i} className="skeleton-card">
            <div className="skeleton-card-header">
              <div className="skeleton-avatar"></div>
              <div className="skeleton-card-title">
                <div className="skeleton-line short"></div>
                <div className="skeleton-line long"></div>
              </div>
            </div>
            <div className="skeleton-card-body">
              <div className="skeleton-line"></div>
              <div className="skeleton-line"></div>
              <div className="skeleton-line short"></div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  return null;
};

// Data loading wrapper
export const DataLoader = ({ loading, error, empty, children, emptyMessage = "No data available" }) => {
  if (loading) {
    return <LoadingOverlay show={true} fullScreen={false} />;
  }

  if (error) {
    return (
      <div className="data-error">
        <svg width="48" height="48" viewBox="0 0 48 48" fill="none">
          <circle cx="24" cy="24" r="22" stroke="#ef4444" strokeWidth="2"/>
          <path d="M24 14V26M24 32V34" stroke="#ef4444" strokeWidth="2" strokeLinecap="round"/>
        </svg>
        <h3>Error Loading Data</h3>
        <p>{error}</p>
      </div>
    );
  }

  if (empty) {
    return (
      <div className="data-empty">
        <svg width="64" height="64" viewBox="0 0 64 64" fill="none">
          <rect x="8" y="20" width="48" height="32" rx="4" stroke="#d1d5db" strokeWidth="2"/>
          <path d="M8 28H56" stroke="#d1d5db" strokeWidth="2"/>
          <circle cx="32" cy="40" r="6" stroke="#d1d5db" strokeWidth="2"/>
        </svg>
        <h3>{emptyMessage}</h3>
      </div>
    );
  }

  return children;
};

export default LoadingOverlay;