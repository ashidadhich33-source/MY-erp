import React, { useState, useEffect, useRef } from 'react';
import './DateRangePicker.css';

const DateRangePicker = ({ 
  startDate, 
  endDate, 
  onDateChange, 
  showQuickRanges = true,
  minDate = null,
  maxDate = null,
  required = false,
  disabled = false,
  placeholder = "Select date range"
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [localStartDate, setLocalStartDate] = useState(startDate || '');
  const [localEndDate, setLocalEndDate] = useState(endDate || '');
  const [selectedRange, setSelectedRange] = useState('custom');
  const dropdownRef = useRef(null);

  useEffect(() => {
    setLocalStartDate(startDate || '');
    setLocalEndDate(endDate || '');
  }, [startDate, endDate]);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const getQuickRangeOptions = () => {
    const today = new Date();
    const options = [];

    // Today
    options.push({
      label: 'Today',
      value: 'today',
      start: formatDate(today),
      end: formatDate(today)
    });

    // Yesterday
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    options.push({
      label: 'Yesterday',
      value: 'yesterday',
      start: formatDate(yesterday),
      end: formatDate(yesterday)
    });

    // This Week
    const weekStart = new Date(today);
    weekStart.setDate(today.getDate() - today.getDay());
    options.push({
      label: 'This Week',
      value: 'this_week',
      start: formatDate(weekStart),
      end: formatDate(today)
    });

    // Last Week
    const lastWeekEnd = new Date(weekStart);
    lastWeekEnd.setDate(lastWeekEnd.getDate() - 1);
    const lastWeekStart = new Date(lastWeekEnd);
    lastWeekStart.setDate(lastWeekEnd.getDate() - 6);
    options.push({
      label: 'Last Week',
      value: 'last_week',
      start: formatDate(lastWeekStart),
      end: formatDate(lastWeekEnd)
    });

    // This Month
    const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
    options.push({
      label: 'This Month',
      value: 'this_month',
      start: formatDate(monthStart),
      end: formatDate(today)
    });

    // Last Month
    const lastMonthEnd = new Date(monthStart);
    lastMonthEnd.setDate(lastMonthEnd.getDate() - 1);
    const lastMonthStart = new Date(lastMonthEnd.getFullYear(), lastMonthEnd.getMonth(), 1);
    options.push({
      label: 'Last Month',
      value: 'last_month',
      start: formatDate(lastMonthStart),
      end: formatDate(lastMonthEnd)
    });

    // This Quarter
    const quarterMonth = Math.floor(today.getMonth() / 3) * 3;
    const quarterStart = new Date(today.getFullYear(), quarterMonth, 1);
    options.push({
      label: 'This Quarter',
      value: 'this_quarter',
      start: formatDate(quarterStart),
      end: formatDate(today)
    });

    // This Year
    const yearStart = new Date(today.getFullYear(), 0, 1);
    options.push({
      label: 'This Year',
      value: 'this_year',
      start: formatDate(yearStart),
      end: formatDate(today)
    });

    // Last 7 Days
    const last7Days = new Date(today);
    last7Days.setDate(today.getDate() - 6);
    options.push({
      label: 'Last 7 Days',
      value: 'last_7_days',
      start: formatDate(last7Days),
      end: formatDate(today)
    });

    // Last 30 Days
    const last30Days = new Date(today);
    last30Days.setDate(today.getDate() - 29);
    options.push({
      label: 'Last 30 Days',
      value: 'last_30_days',
      start: formatDate(last30Days),
      end: formatDate(today)
    });

    // Last 90 Days
    const last90Days = new Date(today);
    last90Days.setDate(today.getDate() - 89);
    options.push({
      label: 'Last 90 Days',
      value: 'last_90_days',
      start: formatDate(last90Days),
      end: formatDate(today)
    });

    // All Time
    options.push({
      label: 'All Time',
      value: 'all_time',
      start: '',
      end: ''
    });

    return options;
  };

  const formatDate = (date) => {
    if (!date) return '';
    const d = new Date(date);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const formatDisplayDate = (dateStr) => {
    if (!dateStr) return '';
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });
  };

  const handleQuickRange = (option) => {
    setLocalStartDate(option.start);
    setLocalEndDate(option.end);
    setSelectedRange(option.value);
    onDateChange(option.start, option.end);
    setIsOpen(false);
  };

  const handleCustomDateChange = () => {
    if (localStartDate && localEndDate) {
      if (new Date(localStartDate) > new Date(localEndDate)) {
        alert('Start date cannot be after end date');
        return;
      }
      setSelectedRange('custom');
      onDateChange(localStartDate, localEndDate);
      setIsOpen(false);
    }
  };

  const getDisplayText = () => {
    if (!localStartDate && !localEndDate) {
      return placeholder;
    }
    
    if (selectedRange !== 'custom') {
      const option = getQuickRangeOptions().find(o => o.value === selectedRange);
      if (option) return option.label;
    }
    
    if (localStartDate === localEndDate) {
      return formatDisplayDate(localStartDate);
    }
    
    return `${formatDisplayDate(localStartDate)} - ${formatDisplayDate(localEndDate)}`;
  };

  const handleClear = (e) => {
    e.stopPropagation();
    setLocalStartDate('');
    setLocalEndDate('');
    setSelectedRange('custom');
    onDateChange('', '');
    setIsOpen(false);
  };

  return (
    <div className="date-range-picker" ref={dropdownRef}>
      <div 
        className={`date-range-display ${disabled ? 'disabled' : ''} ${isOpen ? 'active' : ''}`}
        onClick={() => !disabled && setIsOpen(!isOpen)}
      >
        <div className="date-range-content">
          <svg className="calendar-icon" width="20" height="20" viewBox="0 0 20 20" fill="none">
            <path d="M6 2V5M14 2V5M3 8H17M5 3H15C16.1046 3 17 3.89543 17 5V15C17 16.1046 16.1046 17 15 17H5C3.89543 17 3 16.1046 3 15V5C3 3.89543 3.89543 3 5 3Z" 
                  stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M6.5 11.5H6.51M10 11.5H10.01M13.5 11.5H13.51M6.5 14.5H6.51M10 14.5H10.01M13.5 14.5H13.51" 
                  stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          <span className="date-range-text">{getDisplayText()}</span>
        </div>
        {(localStartDate || localEndDate) && !disabled && (
          <button className="date-range-clear" onClick={handleClear}>
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <path d="M12 4L4 12M4 4L12 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
            </svg>
          </button>
        )}
        <svg className={`dropdown-arrow ${isOpen ? 'rotated' : ''}`} width="20" height="20" viewBox="0 0 20 20" fill="none">
          <path d="M5 7.5L10 12.5L15 7.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      </div>

      {isOpen && (
        <div className="date-range-dropdown">
          {showQuickRanges && (
            <div className="quick-ranges-section">
              <div className="quick-ranges-title">Quick Ranges</div>
              <div className="quick-ranges-grid">
                {getQuickRangeOptions().map(option => (
                  <button
                    key={option.value}
                    className={`quick-range-option ${selectedRange === option.value ? 'active' : ''}`}
                    onClick={() => handleQuickRange(option)}
                  >
                    {option.label}
                  </button>
                ))}
              </div>
            </div>
          )}
          
          <div className="custom-range-section">
            <div className="custom-range-title">Custom Range</div>
            <div className="custom-date-inputs">
              <div className="date-input-wrapper">
                <label className="date-input-label">From</label>
                <input
                  type="date"
                  className="custom-date-input"
                  value={localStartDate}
                  onChange={(e) => setLocalStartDate(e.target.value)}
                  min={minDate}
                  max={maxDate || localEndDate}
                  required={required}
                />
              </div>
              <div className="date-input-wrapper">
                <label className="date-input-label">To</label>
                <input
                  type="date"
                  className="custom-date-input"
                  value={localEndDate}
                  onChange={(e) => setLocalEndDate(e.target.value)}
                  min={localStartDate || minDate}
                  max={maxDate}
                  required={required}
                />
              </div>
            </div>
            <div className="custom-range-actions">
              <button 
                className="btn-cancel"
                onClick={() => setIsOpen(false)}
              >
                Cancel
              </button>
              <button 
                className="btn-apply"
                onClick={handleCustomDateChange}
                disabled={!localStartDate || !localEndDate}
              >
                Apply Range
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DateRangePicker;