import React, { forwardRef } from 'react';
import { format } from 'date-fns';
import './PrintableInvoice.css';

const PrintableInvoice = forwardRef(({ sale, company, isReturn = false }, ref) => {
  if (!sale) return null;

  const calculateTotals = () => {
    let subtotal = 0;
    let totalDiscount = 0;
    let totalGST = 0;

    sale.items?.forEach(item => {
      subtotal += item.mrp * item.quantity;
      totalDiscount += item.discount_amount || 0;
      totalGST += item.gst_amount || 0;
    });

    return {
      subtotal,
      totalDiscount,
      totalGST,
      netAmount: subtotal - totalDiscount + totalGST
    };
  };

  const totals = calculateTotals();

  return (
    <div ref={ref} className="thermal-invoice">
      {/* Header */}
      <div className="invoice-header">
        <h1 className="company-name">{company?.name || 'FASHION STORE'}</h1>
        {company?.address && (
          <p className="company-address">{company.address}</p>
        )}
        {company?.gstin && (
          <p className="company-gstin">GSTIN: {company.gstin}</p>
        )}
        {company?.mobile && (
          <p className="company-mobile">Ph: {company.mobile}</p>
        )}
      </div>

      <div className="divider">================================</div>

      {/* Invoice Type & Number */}
      <div className="invoice-info">
        <h2 className="invoice-type">
          {isReturn ? 'CREDIT NOTE' : 'TAX INVOICE'}
        </h2>
        <p className="invoice-number">
          {isReturn ? `CN No: ${sale.return_no}` : `Bill No: ${sale.bill_no}`}
        </p>
        <p className="invoice-date">
          Date: {format(new Date(sale.bill_date || sale.date), 'dd-MM-yyyy HH:mm')}
        </p>
      </div>

      {/* Customer Details */}
      {sale.customer && (
        <>
          <div className="divider">--------------------------------</div>
          <div className="customer-info">
            <p><strong>Customer:</strong> {sale.customer.name}</p>
            <p><strong>Mobile:</strong> {sale.customer.mobile}</p>
          </div>
        </>
      )}

      <div className="divider">================================</div>

      {/* Items Header */}
      <div className="items-header">
        <span className="col-desc">Description</span>
        <span className="col-qty">Qty</span>
        <span className="col-rate">Rate</span>
        <span className="col-amt">Amount</span>
      </div>
      <div className="divider">--------------------------------</div>

      {/* Items List */}
      <div className="items-list">
        {sale.items?.map((item, index) => (
          <div key={index} className="item-row">
            <div className="item-details">
              <div className="item-name">
                {item.style_code || item.name}
              </div>
              {item.barcode && (
                <div className="item-barcode">({item.barcode})</div>
              )}
              {(item.color || item.size) && (
                <div className="item-variant">
                  {item.color && `Color: ${item.color}`}
                  {item.color && item.size && ', '}
                  {item.size && `Size: ${item.size}`}
                </div>
              )}
              {item.hsn && (
                <div className="item-hsn">HSN: {item.hsn}</div>
              )}
            </div>
            <div className="item-pricing">
              <span className="item-qty">{item.quantity}</span>
              <span className="item-rate">₹{item.mrp}</span>
              <span className="item-amount">₹{(item.mrp * item.quantity).toFixed(2)}</span>
            </div>
            {item.discount_amount > 0 && (
              <div className="item-discount">
                Discount: -₹{item.discount_amount.toFixed(2)}
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="divider">================================</div>

      {/* Totals */}
      <div className="invoice-totals">
        <div className="total-row">
          <span>Subtotal:</span>
          <span>₹{totals.subtotal.toFixed(2)}</span>
        </div>
        {totals.totalDiscount > 0 && (
          <div className="total-row">
            <span>Discount:</span>
            <span>-₹{totals.totalDiscount.toFixed(2)}</span>
          </div>
        )}
        {sale.coupon_code && (
          <div className="total-row">
            <span>Coupon ({sale.coupon_code}):</span>
            <span>-₹{sale.coupon_discount?.toFixed(2)}</span>
          </div>
        )}
        {sale.points_redeemed > 0 && (
          <div className="total-row">
            <span>Points Redeemed:</span>
            <span>-₹{sale.points_value?.toFixed(2)}</span>
          </div>
        )}
        <div className="total-row">
          <span>GST:</span>
          <span>₹{totals.totalGST.toFixed(2)}</span>
        </div>
        <div className="divider">--------------------------------</div>
        <div className="total-row grand-total">
          <span><strong>NET AMOUNT:</strong></span>
          <span><strong>₹{sale.net_amount?.toFixed(2) || totals.netAmount.toFixed(2)}</strong></span>
        </div>
      </div>

      {/* Payment Details */}
      {sale.payment_mode && (
        <>
          <div className="divider">--------------------------------</div>
          <div className="payment-info">
            <p>Payment Mode: {sale.payment_mode}</p>
            {sale.cash_amount > 0 && (
              <>
                <p>Cash Received: ₹{sale.cash_amount}</p>
                <p>Change: ₹{sale.change_amount || 0}</p>
              </>
            )}
          </div>
        </>
      )}

      {/* Loyalty Points */}
      {sale.customer && (sale.points_earned > 0 || sale.points_balance >= 0) && (
        <>
          <div className="divider">--------------------------------</div>
          <div className="loyalty-info">
            {sale.points_earned > 0 && (
              <p>Points Earned: {sale.points_earned}</p>
            )}
            <p>Points Balance: {sale.points_balance || 0}</p>
          </div>
        </>
      )}

      {/* GST Summary */}
      {totals.totalGST > 0 && (
        <>
          <div className="divider">--------------------------------</div>
          <div className="gst-summary">
            <p className="section-title">GST Summary</p>
            {sale.gst_summary?.map((gst, index) => (
              <div key={index} className="gst-row">
                <span>{gst.rate}%</span>
                <span>Taxable: ₹{gst.taxable}</span>
                <span>GST: ₹{gst.amount}</span>
              </div>
            ))}
          </div>
        </>
      )}

      <div className="divider">================================</div>

      {/* Footer */}
      <div className="invoice-footer">
        <p className="thank-you">Thank You! Visit Again</p>
        {sale.staff_name && (
          <p className="served-by">Served by: {sale.staff_name}</p>
        )}
        {!isReturn && (
          <p className="return-policy">
            Exchange within 7 days with bill
          </p>
        )}
      </div>

      {/* Barcode */}
      <div className="invoice-barcode">
        <Barcode 
          value={sale.bill_no || sale.return_no || '000000'}
          width={1}
          height={40}
          fontSize={10}
          displayValue={false}
        />
      </div>

      <div className="divider">================================</div>
      <p className="powered-by">Powered by PIANK ERP</p>
    </div>
  );
});

PrintableInvoice.displayName = 'PrintableInvoice';

export default PrintableInvoice;