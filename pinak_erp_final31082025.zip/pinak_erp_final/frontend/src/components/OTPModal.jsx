import React, { useState, useEffect, useRef } from 'react';
import { FiX, FiShield, FiPhone, FiCheck, FiAlertCircle } from 'react-icons/fi';
import toast from 'react-hot-toast';
import axios from 'axios';
import './Modals.css';

const API_URL = 'http://localhost:8000/api/v1';

function OTPModal({ 
  isOpen, 
  onClose, 
  mobile, 
  points, 
  onVerifySuccess,
  purpose = 'points_redemption' 
}) {
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [loading, setLoading] = useState(false);
  const [resendTimer, setResendTimer] = useState(30);
  const [canResend, setCanResend] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const inputRefs = useRef([]);

  useEffect(() => {
    if (isOpen && mobile) {
      sendOTP();
      // Focus first input
      setTimeout(() => {
        inputRefs.current[0]?.focus();
      }, 100);
    }
  }, [isOpen, mobile]);

  useEffect(() => {
    if (resendTimer > 0 && isOpen) {
      const timer = setTimeout(() => setResendTimer(resendTimer - 1), 1000);
      return () => clearTimeout(timer);
    } else if (resendTimer === 0) {
      setCanResend(true);
    }
  }, [resendTimer, isOpen]);

  // Send OTP
  const sendOTP = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      await axios.post(
        `${API_URL}/otp/send`,
        { 
          mobile,
          purpose,
          points_to_redeem: points 
        },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      toast.success(`OTP sent to ${mobile}`);
      setResendTimer(30);
      setCanResend(false);
    } catch (error) {
      toast.error('Failed to send OTP');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  // Handle OTP input
  const handleOtpChange = (index, value) => {
    if (value.length > 1) {
      // Handle paste
      const otpArray = value.slice(0, 6).split('');
      const newOtp = [...otp];
      otpArray.forEach((digit, i) => {
        if (i < 6) {
          newOtp[i] = digit;
        }
      });
      setOtp(newOtp);
      
      // Focus last filled input or next empty
      const lastFilledIndex = otpArray.length - 1;
      if (lastFilledIndex < 5) {
        inputRefs.current[lastFilledIndex + 1]?.focus();
      }
    } else {
      // Single character input
      const newOtp = [...otp];
      newOtp[index] = value;
      setOtp(newOtp);

      // Auto-focus next input
      if (value && index < 5) {
        inputRefs.current[index + 1]?.focus();
      }
    }
  };

  // Handle backspace
  const handleKeyDown = (index, e) => {
    if (e.key === 'Backspace' && !otp[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  // Verify OTP
  const verifyOTP = async () => {
    const otpString = otp.join('');
    if (otpString.length !== 6) {
      toast.error('Please enter complete OTP');
      return;
    }

    setVerifying(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.post(
        `${API_URL}/otp/verify`,
        {
          mobile,
          otp: otpString,
          purpose
        },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      if (response.data.verified) {
        toast.success('OTP verified successfully');
        onVerifySuccess(otpString);
        handleClose();
      } else {
        toast.error('Invalid OTP');
        // Clear OTP inputs
        setOtp(['', '', '', '', '', '']);
        inputRefs.current[0]?.focus();
      }
    } catch (error) {
      toast.error('OTP verification failed');
      console.error(error);
    } finally {
      setVerifying(false);
    }
  };

  // Handle close
  const handleClose = () => {
    setOtp(['', '', '', '', '', '']);
    setResendTimer(30);
    setCanResend(false);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="modal-overlay">
      <div className="modal-content otp-modal">
        <div className="modal-header">
          <h2>OTP Verification</h2>
          <button className="btn-close" onClick={handleClose}>
            <FiX />
          </button>
        </div>

        <div className="otp-icon">
          <FiShield size={60} />
        </div>

        <div className="otp-info">
          <p className="otp-message">
            Enter the 6-digit OTP sent to
          </p>
          <p className="otp-mobile">
            <FiPhone /> {mobile}
          </p>
          {points > 0 && (
            <p className="otp-points">
              To redeem <strong>{points} points</strong>
            </p>
          )}
        </div>

        <div className="otp-inputs">
          {otp.map((digit, index) => (
            <input
              key={index}
              ref={el => inputRefs.current[index] = el}
              type="text"
              maxLength="1"
              value={digit}
              onChange={(e) => handleOtpChange(index, e.target.value)}
              onKeyDown={(e) => handleKeyDown(index, e)}
              className="otp-input"
              inputMode="numeric"
              pattern="[0-9]*"
            />
          ))}
        </div>

        <div className="otp-timer">
          {!canResend ? (
            <p>Resend OTP in <strong>{resendTimer}s</strong></p>
          ) : (
            <button 
              className="btn-resend"
              onClick={sendOTP}
              disabled={loading}
            >
              {loading ? 'Sending...' : 'Resend OTP'}
            </button>
          )}
        </div>

        <div className="otp-actions">
          <button 
            className="btn-secondary"
            onClick={handleClose}
          >
            Cancel
          </button>
          <button 
            className="btn-primary"
            onClick={verifyOTP}
            disabled={verifying || otp.join('').length !== 6}
          >
            {verifying ? (
              <>Verifying...</>
            ) : (
              <>
                <FiCheck /> Verify OTP
              </>
            )}
          </button>
        </div>

        <div className="otp-help">
          <FiAlertCircle />
          <span>Didn't receive OTP? Check if the mobile number is correct.</span>
        </div>
      </div>
    </div>
  );
}

export default OTPModal;