import React, { useState, useRef } from 'react';
import { 
  FiUpload, FiDownload, FiX, FiCheck, FiAlertCircle,
  FiFileText, FiRefreshCw, FiEye
} from 'react-icons/fi';
import * as XLSX from 'xlsx';
import toast from 'react-hot-toast';
import axios from 'axios';
import './ExcelImporter.css';

const API_URL = 'http://localhost:8000/api/v1';

function ExcelImporter({ 
  isOpen, 
  onClose, 
  importType = 'items', // items, stock, customers
  onImportSuccess,
  templateUrl
}) {
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [preview, setPreview] = useState([]);
  const [errors, setErrors] = useState([]);
  const [summary, setSummary] = useState(null);
  const [step, setStep] = useState(1); // 1: upload, 2: preview, 3: result
  const fileInputRef = useRef(null);

  // Import configurations - FIXED ENDPOINTS
  const importConfigs = {
    items: {
      title: 'Import Items',
      requiredColumns: ['barcode', 'style_code', 'mrp_incl'],
      optionalColumns: ['color', 'size', 'hsn', 'purchase_rate_basic', 'brand', 'gender', 'category', 'sub_category'],
      endpoint: '/items/import/excel',  // FIXED: Added /excel
      templateName: 'items_template.xlsx'
    },
    stock: {
      title: 'Import Stock',
      requiredColumns: ['barcode', 'quantity'],
      optionalColumns: [],
      endpoint: '/stock/import/excel',  // FIXED: Added /excel
      templateName: 'stock_template.xlsx'
    },
    customers: {
      title: 'Import Customers',
      requiredColumns: ['mobile', 'name'],
      optionalColumns: ['email', 'address', 'city', 'kid1_name', 'kid1_dob', 'kid2_name', 'kid2_dob'],
      endpoint: '/customers/import/excel',  // FIXED: Added /excel
      templateName: 'customers_template.xlsx'
    }
  };

  const config = importConfigs[importType];

  // Handle file selection
  const handleFileSelect = (e) => {
    const selectedFile = e.target.files[0];
    if (!selectedFile) return;

    if (!selectedFile.name.match(/\.(xlsx|xls)$/)) {
      toast.error('Please select an Excel file (.xlsx or .xls)');
      return;
    }

    setFile(selectedFile);
    parseFile(selectedFile);
  };

  // Parse Excel file for preview
  const parseFile = (file) => {
    const reader = new FileReader();
    
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target.result);
        const workbook = XLSX.read(data, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet, { raw: false });

        if (jsonData.length === 0) {
          toast.error('Excel file is empty');
          return;
        }

        // Validate columns
        const fileColumns = Object.keys(jsonData[0]).map(col => col.toLowerCase().replace(/\s+/g, '_'));
        const missingColumns = config.requiredColumns.filter(
          col => !fileColumns.includes(col.toLowerCase())
        );

        if (missingColumns.length > 0) {
          toast.error(`Missing required columns: ${missingColumns.join(', ')}`);
          setErrors([`Missing columns: ${missingColumns.join(', ')}`]);
          return;
        }

        // Clean and validate data
        const cleanedData = jsonData.map((row, idx) => {
          const cleanRow = {};
          const rowErrors = [];

          // Process each column
          Object.keys(row).forEach(key => {
            const cleanKey = key.toLowerCase().replace(/\s+/g, '_');
            cleanRow[cleanKey] = row[key]?.toString().trim() || '';
          });

          // Validate required fields
          config.requiredColumns.forEach(col => {
            if (!cleanRow[col] || cleanRow[col] === '') {
              rowErrors.push(`Row ${idx + 2}: Missing ${col}`);
            }
          });

          // Special validations
          if (importType === 'items') {
            if (cleanRow.mrp_incl && isNaN(parseFloat(cleanRow.mrp_incl))) {
              rowErrors.push(`Row ${idx + 2}: Invalid MRP value`);
            }
            if (cleanRow.purchase_rate_basic && isNaN(parseFloat(cleanRow.purchase_rate_basic))) {
              rowErrors.push(`Row ${idx + 2}: Invalid purchase rate`);
            }
          }

          if (importType === 'stock') {
            if (cleanRow.quantity && isNaN(parseInt(cleanRow.quantity))) {
              rowErrors.push(`Row ${idx + 2}: Invalid quantity`);
            }
          }

          if (importType === 'customers') {
            if (cleanRow.mobile && !/^\d{10}$/.test(cleanRow.mobile)) {
              rowErrors.push(`Row ${idx + 2}: Invalid mobile number`);
            }
          }

          return { data: cleanRow, errors: rowErrors };
        });

        // Collect all errors
        const allErrors = cleanedData
          .flatMap(item => item.errors)
          .filter(Boolean);

        if (allErrors.length > 0) {
          setErrors(allErrors.slice(0, 10)); // Show first 10 errors
          toast.error(`Found ${allErrors.length} validation errors`);
        }

        // Set preview data
        setPreview(cleanedData.slice(0, 10).map(item => item.data));
        setStep(2);

      } catch (error) {
        console.error('File parse error:', error);
        toast.error('Failed to parse Excel file');
      }
    };

    reader.readAsArrayBuffer(file);
  };

  // Process import
  const processImport = async () => {
    if (!file || preview.length === 0) {
      toast.error('No data to import');
      return;
    }

    setLoading(true);
    const formData = new FormData();
    formData.append('file', file);

    try {
      const token = localStorage.getItem('token');
      const response = await axios.post(
        `${API_URL}${config.endpoint}`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'multipart/form-data'
          }
        }
      );

      setSummary(response.data);
      setStep(3);
      toast.success('Import completed successfully');
      
      if (onImportSuccess) {
        onImportSuccess(response.data);
      }

    } catch (error) {
      console.error('Import error:', error);
      if (error.response?.status === 404) {
        toast.error('Import endpoint not found. Please check server configuration.');
      } else if (error.response?.data?.errors) {
        setErrors(error.response.data.errors);
        toast.error('Import failed with errors');
      } else if (error.response?.data?.detail) {
        toast.error(error.response.data.detail);
      } else {
        toast.error('Failed to import data');
      }
    } finally {
      setLoading(false);
    }
  };

  // Download template
  const downloadTemplate = () => {
    // Create template workbook
    const wb = XLSX.utils.book_new();
    
    // Create headers
    const headers = [...config.requiredColumns, ...config.optionalColumns];
    const ws_data = [headers];
    
    // Add sample data
    const sampleData = getSampleData(importType);
    ws_data.push(sampleData);
    
    const ws = XLSX.utils.aoa_to_sheet(ws_data);
    
    // Set column widths
    const colWidths = headers.map(() => ({ wch: 15 }));
    ws['!cols'] = colWidths;
    
    // Add to workbook
    XLSX.utils.book_append_sheet(wb, ws, 'Template');
    
    // Download
    XLSX.writeFile(wb, config.templateName);
    toast.success('Template downloaded');
  };

  // Get sample data for template
  const getSampleData = (type) => {
    switch (type) {
      case 'items':
        return ['ABC123', 'SHIRT-001', '1999', 'Blue', 'L', '6109', '800', 'Brand A', 'Male', 'Shirts', 'Formal'];
      case 'stock':
        return ['ABC123', '50'];
      case 'customers':
        return ['9876543210', 'John Doe', 'john@email.com', '123 Street', 'Mumbai', 'Child 1', '2015-01-15', 'Child 2', '2018-05-20'];
      default:
        return [];
    }
  };

  // Reset state
  const handleClose = () => {
    setFile(null);
    setPreview([]);
    setErrors([]);
    setSummary(null);
    setStep(1);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="modal-overlay">
      <div className="modal-content excel-importer-modal">
        <div className="modal-header">
          <h2>{config.title}</h2>
          <button className="btn-close" onClick={handleClose}>
            <FiX />
          </button>
        </div>

        {/* Step Indicator */}
        <div className="steps-indicator">
          <div className={`step ${step >= 1 ? 'active' : ''}`}>
            <span className="step-number">1</span>
            <span className="step-label">Upload</span>
          </div>
          <div className={`step ${step >= 2 ? 'active' : ''}`}>
            <span className="step-number">2</span>
            <span className="step-label">Preview</span>
          </div>
          <div className={`step ${step >= 3 ? 'active' : ''}`}>
            <span className="step-number">3</span>
            <span className="step-label">Result</span>
          </div>
        </div>

        <div className="modal-body">
          {/* Step 1: Upload */}
          {step === 1 && (
            <div className="upload-section">
              <div className="upload-area">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".xlsx,.xls"
                  onChange={handleFileSelect}
                  style={{ display: 'none' }}
                />
                
                {!file ? (
                  <div 
                    className="upload-dropzone"
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <FiUpload size={48} />
                    <h3>Click to upload Excel file</h3>
                    <p>or drag and drop</p>
                    <span className="file-types">XLSX, XLS</span>
                  </div>
                ) : (
                  <div className="file-selected">
                    <FiFileText size={48} />
                    <h3>{file.name}</h3>
                    <p>{(file.size / 1024).toFixed(2)} KB</p>
                    <button 
                      className="btn-secondary"
                      onClick={() => fileInputRef.current?.click()}
                    >
                      Change File
                    </button>
                  </div>
                )}
              </div>

              <div className="template-section">
                <h4>Need a template?</h4>
                <p>Download our Excel template with the correct format</p>
                <button 
                  className="btn-outline"
                  onClick={downloadTemplate}
                >
                  <FiDownload /> Download Template
                </button>
              </div>

              {errors.length > 0 && (
                <div className="errors-list">
                  <h4><FiAlertCircle /> Validation Errors</h4>
                  <ul>
                    {errors.map((error, idx) => (
                      <li key={idx}>{error}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}

          {/* Step 2: Preview */}
          {step === 2 && (
            <div className="preview-section">
              <h3>Preview Data</h3>
              <p>Showing first {preview.length} rows</p>
              
              <div className="preview-table-wrapper">
                <table className="preview-table">
                  <thead>
                    <tr>
                      {Object.keys(preview[0] || {}).map(key => (
                        <th key={key}>{key.replace(/_/g, ' ').toUpperCase()}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {preview.map((row, idx) => (
                      <tr key={idx}>
                        {Object.values(row).map((value, vIdx) => (
                          <td key={vIdx}>{value}</td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {errors.length > 0 && (
                <div className="errors-list">
                  <h4><FiAlertCircle /> Validation Issues</h4>
                  <ul>
                    {errors.slice(0, 5).map((error, idx) => (
                      <li key={idx}>{error}</li>
                    ))}
                  </ul>
                  {errors.length > 5 && (
                    <p>...and {errors.length - 5} more issues</p>
                  )}
                </div>
              )}

              <div className="preview-actions">
                <button 
                  className="btn-secondary"
                  onClick={() => setStep(1)}
                >
                  Back
                </button>
                <button 
                  className="btn-primary"
                  onClick={processImport}
                  disabled={loading || errors.length > 0}
                >
                  {loading ? <FiRefreshCw className="spin" /> : <FiCheck />}
                  {loading ? 'Importing...' : 'Import Data'}
                </button>
              </div>
            </div>
          )}

          {/* Step 3: Result */}
          {step === 3 && (
            <div className="result-section">
              <div className="result-icon success">
                <FiCheck size={48} />
              </div>
              
              <h3>Import Completed Successfully!</h3>
              
              {summary && (
                <div className="summary-stats">
                  <div className="stat-item">
                    <span className="stat-label">Created</span>
                    <span className="stat-value">{summary.created || 0}</span>
                  </div>
                  <div className="stat-item">
                    <span className="stat-label">Updated</span>
                    <span className="stat-value">{summary.updated || 0}</span>
                  </div>
                  <div className="stat-item">
                    <span className="stat-label">Errors</span>
                    <span className="stat-value">{summary.errors?.length || 0}</span>
                  </div>
                </div>
              )}

              {summary?.errors && summary.errors.length > 0 && (
                <div className="errors-list">
                  <h4>Import Errors</h4>
                  <ul>
                    {summary.errors.slice(0, 10).map((error, idx) => (
                      <li key={idx}>
                        Row {error.row}: {error.error}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              <div className="result-actions">
                <button 
                  className="btn-secondary"
                  onClick={() => {
                    setStep(1);
                    setFile(null);
                    setPreview([]);
                    setErrors([]);
                    setSummary(null);
                  }}
                >
                  Import Another File
                </button>
                <button 
                  className="btn-primary"
                  onClick={handleClose}
                >
                  Done
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default ExcelImporter;