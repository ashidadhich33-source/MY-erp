import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { 
  FiShoppingCart, FiPackage, FiUsers, FiTruck,
  FiRotateCcw, FiBarChart2, FiSettings, FiBox,
  FiDollarSign, FiFileText, FiChevronDown, FiChevronRight,
  FiGrid, FiUserPlus, FiAward, FiTag, FiMessageSquare,
  FiHash, FiUserCheck, FiCreditCard, FiTrendingUp,
  FiDatabase, FiSliders, FiShield, FiGift
} from 'react-icons/fi';
import './Sidebar.css';

function Sidebar() {
  const [expandedSections, setExpandedSections] = useState({
    setup: true,
    itemMaster: true,
    inventory: false,
    setupUsers: false,
    setupStaff: false,
    purchases: false,
    sales: false,
    reports: false
  });

  const toggleSection = (section) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  const menuItems = [
    {
      title: 'Setup',
      key: 'setup',
      expandable: true,
      items: [
        {
          title: 'Item Master',
          key: 'itemMaster',
          expandable: true,
          icon: <FiPackage />,
          subItems: [
            { path: '/setup/items', label: 'Create Item Master', icon: <FiGrid /> },
            {
              title: 'Inventory Management',
              key: 'inventory',
              expandable: true,
              icon: <FiBox />,
              subItems: [
                { path: '/setup/opening-stock', label: 'Opening Stock', icon: <FiDatabase /> },
                { path: '/setup/stock-adjustment', label: 'Stock Adjustment', icon: <FiSliders /> }
              ]
            }
          ]
        },
        { path: '/setup/suppliers', label: 'Setup Suppliers', icon: <FiTruck /> },
        {
          title: 'Setup Users',
          key: 'setupUsers',
          expandable: true,
          icon: <FiUsers />,
          subItems: [
            { path: '/setup/create-user', label: 'Create User', icon: <FiUserPlus /> },
            { path: '/setup/user-access', label: 'Assign Access of Menu Bar', icon: <FiShield /> }
          ]
        },
        { path: '/setup/company', label: 'Setup Company', icon: <FiSettings /> },
        { path: '/setup/customers', label: 'Setup Customer', icon: <FiUsers /> },
        { path: '/setup/loyalty-grade', label: 'Setup Loyalty Grade', icon: <FiAward /> },
        { path: '/setup/coupons', label: 'Setup Coupons', icon: <FiTag /> },
        { path: '/setup/whatsapp', label: 'Setup WhatsApp Cloud API', icon: <FiMessageSquare /> },
        { path: '/setup/bill-series', label: 'Setup Bill Series', icon: <FiHash /> },
        {
          title: 'Setup Staff',
          key: 'setupStaff',
          expandable: true,
          icon: <FiUserCheck />,
          subItems: [
            { path: '/setup/staff', label: 'Staff', icon: <FiUserCheck /> },
            { path: '/setup/targets-incentives', label: 'Setup Targets & Incentives', icon: <FiTrendingUp /> }
          ]
        },
        { path: '/setup/expense-head', label: 'Setup Expense Head', icon: <FiFileText /> },
        { path: '/setup/payment-mode', label: 'Setup Payment Mode', icon: <FiCreditCard /> }
      ]
    },
    {
      title: 'Purchases',
      key: 'purchases',
      expandable: true,
      items: [
        { path: '/purchase', label: 'Purchase Bill', icon: <FiDollarSign /> },
        { path: '/purchase-return', label: 'Purchase Return', icon: <FiRotateCcw /> }
      ]
    },
    {
      title: 'Sales',
      key: 'sales',
      expandable: true,
      items: [
        { path: '/pos', label: 'Sale Bill (POS)', icon: <FiShoppingCart /> },
        { path: '/sale-return', label: 'Sale Returns', icon: <FiRotateCcw /> }
      ]
    },
    {
      title: 'Reports',
      key: 'reports',
      expandable: true,
      items: [
        { path: '/reports/sales', label: 'Sale & Sale Return Report', icon: <FiBarChart2 /> },
        { path: '/reports/customer', label: 'Customer Report', icon: <FiUsers /> },
        { path: '/reports/customer-wise-sale', label: 'Customer Wise Sale Report', icon: <FiTrendingUp /> },
        { path: '/reports/inactive-customers', label: 'Inactive Customers', icon: <FiUserCheck /> },
        { path: '/reports/birthday', label: "Kids' Birthday Report", icon: <FiGift /> },
        { path: '/reports/purchase', label: 'Purchase & Return Report', icon: <FiFileText /> },
        { path: '/reports/hsn', label: 'HSN Wise Sale Report', icon: <FiGrid /> },
        { path: '/reports/staff', label: 'Staff Wise Sale Report', icon: <FiUserCheck /> },
        { path: '/reports/bill-wise', label: 'Bill Wise Sale Report', icon: <FiHash /> },
        { path: '/reports/payment-mode', label: 'Payment Mode Report', icon: <FiCreditCard /> },
        { path: '/reports/expenses', label: 'Expenses Report', icon: <FiDollarSign /> },
        { path: '/reports/stock', label: 'Stock Report', icon: <FiBox /> }
      ]
    }
  ];

  const renderMenuItem = (item, level = 0) => {
    const isExpanded = expandedSections[item.key];
    
    if (item.expandable) {
      return (
        <div key={item.key || item.title} className="menu-section">
          <div 
            className={`menu-header level-${level}`}
            onClick={() => toggleSection(item.key)}
          >
            {item.icon && <span className="menu-icon">{item.icon}</span>}
            <span className="menu-title">{item.title}</span>
            <span className="menu-chevron">
              {isExpanded ? <FiChevronDown /> : <FiChevronRight />}
            </span>
          </div>
          {isExpanded && (
            <div className="menu-content">
              {item.items && item.items.map(subItem => renderMenuItem(subItem, level + 1))}
              {item.subItems && item.subItems.map(subItem => renderMenuItem(subItem, level + 1))}
            </div>
          )}
        </div>
      );
    }

    return (
      <NavLink
        key={item.path}
        to={item.path}
        className={({ isActive }) => `menu-item level-${level} ${isActive ? 'active' : ''}`}
      >
        {item.icon && <span className="menu-icon">{item.icon}</span>}
        <span className="menu-label">{item.label}</span>
      </NavLink>
    );
  };

  return (
    <aside className="sidebar">
      <div className="sidebar-header">
        <div className="brand-logo">
          <FiBox className="logo-icon" />
          <span className="brand-name">PINAK</span>
          <span className="brand-tagline">Fashion ERP</span>
        </div>
      </div>
      <nav className="sidebar-nav">
        {menuItems.map(section => renderMenuItem(section))}
      </nav>
      <div className="sidebar-footer">
        <div className="version-info">v1.0.0</div>
      </div>
    </aside>
  );
}

export default Sidebar;