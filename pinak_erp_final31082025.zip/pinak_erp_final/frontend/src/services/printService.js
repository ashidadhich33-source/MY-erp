import { formatCurrency, formatDate } from './api';

class PrintService {
  constructor() {
    this.printerSettings = this.loadPrinterSettings();
    this.templates = this.initializeTemplates();
  }

  // Load saved printer settings
  loadPrinterSettings() {
    const saved = localStorage.getItem('printerSettings');
    return saved ? JSON.parse(saved) : {
      thermal: {
        enabled: true,
        name: '',
        width: 80,
        fontSize: 12,
        margins: { top: 5, right: 5, bottom: 5, left: 5 }
      },
      a4: {
        enabled: true,
        name: '',
        orientation: 'portrait',
        margins: { top: 20, right: 20, bottom: 20, left: 20 }
      },
      barcode: {
        enabled: true,
        name: '',
        labelWidth: 50,
        labelHeight: 25
      }
    };
  }

  // Save printer settings
  savePrinterSettings(settings) {
    this.printerSettings = { ...this.printerSettings, ...settings };
    localStorage.setItem('printerSettings', JSON.stringify(this.printerSettings));
  }

  // Initialize print templates
  initializeTemplates() {
    return {
      invoice: this.getInvoiceTemplate(),
      receipt: this.getReceiptTemplate(),
      report: this.getReportTemplate(),
      barcode: this.getBarcodeTemplate()
    };
  }

  // Get available printers
  async getAvailablePrinters() {
    try {
      if (window.electron) {
        return await window.electron.getPrinters();
      }
      // Fallback for web version
      return [];
    } catch (error) {
      console.error('Error getting printers:', error);
      return [];
    }
  }

  // Print POS receipt (80mm thermal)
  async printReceipt(saleData, options = {}) {
    const {
      copies = 1,
      preview = false,
      silent = true
    } = options;

    const html = this.generateReceiptHTML(saleData);
    
    if (preview) {
      return this.showPrintPreview(html, 'thermal');
    }

    for (let i = 0; i < copies; i++) {
      await this.printHTML(html, {
        printerName: this.printerSettings.thermal.name,
        silent,
        pageSize: { width: 80000, height: 297000 },
        margins: this.printerSettings.thermal.margins
      });
    }

    return { success: true };
  }

  // Generate receipt HTML for thermal printer
  generateReceiptHTML(saleData) {
    const { company, bill, items, customer, payment, totals } = saleData;

    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <style>
          * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
          }
          body {
            font-family: 'Courier New', monospace;
            font-size: ${this.printerSettings.thermal.fontSize}px;
            width: ${this.printerSettings.thermal.width}mm;
            padding: ${this.printerSettings.thermal.margins.top}mm ${this.printerSettings.thermal.margins.right}mm;
          }
          .header {
            text-align: center;
            margin-bottom: 10px;
            border-bottom: 1px dashed #000;
            padding-bottom: 5px;
          }
          .company-name {
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 3px;
          }
          .company-info {
            font-size: 10px;
            line-height: 1.2;
          }
          .bill-info {
            margin: 10px 0;
            font-size: 11px;
          }
          .bill-row {
            display: flex;
            justify-content: space-between;
            margin: 2px 0;
          }
          .items-table {
            width: 100%;
            margin: 10px 0;
            border-top: 1px dashed #000;
            border-bottom: 1px dashed #000;
          }
          .item-header {
            display: flex;
            justify-content: space-between;
            font-weight: bold;
            padding: 5px 0;
            border-bottom: 1px solid #000;
            font-size: 10px;
          }
          .item-row {
            padding: 3px 0;
            font-size: 10px;
            border-bottom: 1px dotted #ccc;
          }
          .item-details {
            display: flex;
            justify-content: space-between;
          }
          .item-name {
            font-size: 11px;
            margin-bottom: 2px;
          }
          .totals-section {
            margin: 10px 0;
            font-size: 11px;
          }
          .total-row {
            display: flex;
            justify-content: space-between;
            padding: 2px 0;
          }
          .total-row.grand-total {
            font-size: 14px;
            font-weight: bold;
            border-top: 1px solid #000;
            padding-top: 5px;
            margin-top: 5px;
          }
          .payment-section {
            margin: 10px 0;
            padding: 5px 0;
            border-top: 1px dashed #000;
            border-bottom: 1px dashed #000;
            font-size: 11px;
          }
          .footer {
            text-align: center;
            margin-top: 15px;
            font-size: 10px;
            line-height: 1.3;
          }
          .barcode {
            text-align: center;
            margin: 10px 0;
          }
          .thank-you {
            font-weight: bold;
            margin-top: 10px;
            font-size: 12px;
          }
        </style>
      </head>
      <body>
        <div class="header">
          <div class="company-name">${company.name}</div>
          <div class="company-info">
            ${company.address}<br>
            Phone: ${company.phone}<br>
            GSTIN: ${company.gstin}
          </div>
        </div>

        <div class="bill-info">
          <div class="bill-row">
            <span>Bill No:</span>
            <span>${bill.billNo}</span>
          </div>
          <div class="bill-row">
            <span>Date:</span>
            <span>${formatDate(bill.date)}</span>
          </div>
          <div class="bill-row">
            <span>Time:</span>
            <span>${new Date(bill.date).toLocaleTimeString()}</span>
          </div>
          ${customer ? `
            <div class="bill-row">
              <span>Customer:</span>
              <span>${customer.name}</span>
            </div>
            <div class="bill-row">
              <span>Mobile:</span>
              <span>${customer.mobile}</span>
            </div>
          ` : ''}
        </div>

        <div class="items-table">
          <div class="item-header">
            <span style="flex: 2">Item</span>
            <span style="flex: 1; text-align: center">Qty</span>
            <span style="flex: 1; text-align: right">Rate</span>
            <span style="flex: 1; text-align: right">Amount</span>
          </div>
          ${items.map(item => `
            <div class="item-row">
              <div class="item-name">${item.styleCode} - ${item.color} - ${item.size}</div>
              <div class="item-details">
                <span style="flex: 2">${item.barcode}</span>
                <span style="flex: 1; text-align: center">${item.qty}</span>
                <span style="flex: 1; text-align: right">${formatCurrency(item.rate)}</span>
                <span style="flex: 1; text-align: right">${formatCurrency(item.amount)}</span>
              </div>
            </div>
          `).join('')}
        </div>

        <div class="totals-section">
          <div class="total-row">
            <span>Subtotal:</span>
            <span>${formatCurrency(totals.subtotal)}</span>
          </div>
          ${totals.discount > 0 ? `
            <div class="total-row">
              <span>Discount:</span>
              <span>-${formatCurrency(totals.discount)}</span>
            </div>
          ` : ''}
          ${totals.cgst > 0 ? `
            <div class="total-row">
              <span>CGST (${totals.cgstRate}%):</span>
              <span>${formatCurrency(totals.cgst)}</span>
            </div>
            <div class="total-row">
              <span>SGST (${totals.sgstRate}%):</span>
              <span>${formatCurrency(totals.sgst)}</span>
            </div>
          ` : ''}
          ${totals.igst > 0 ? `
            <div class="total-row">
              <span>IGST (${totals.igstRate}%):</span>
              <span>${formatCurrency(totals.igst)}</span>
            </div>
          ` : ''}
          <div class="total-row grand-total">
            <span>TOTAL:</span>
            <span>${formatCurrency(totals.grandTotal)}</span>
          </div>
        </div>

        ${payment ? `
          <div class="payment-section">
            ${payment.cash > 0 ? `
              <div class="bill-row">
                <span>Cash:</span>
                <span>${formatCurrency(payment.cash)}</span>
              </div>
            ` : ''}
            ${payment.card > 0 ? `
              <div class="bill-row">
                <span>Card:</span>
                <span>${formatCurrency(payment.card)}</span>
              </div>
            ` : ''}
            ${payment.other > 0 ? `
              <div class="bill-row">
                <span>Other:</span>
                <span>${formatCurrency(payment.other)}</span>
              </div>
            ` : ''}
            ${payment.change > 0 ? `
              <div class="bill-row">
                <span>Change:</span>
                <span>${formatCurrency(payment.change)}</span>
              </div>
            ` : ''}
          </div>
        ` : ''}

        <div class="footer">
          ${customer && customer.pointsEarned > 0 ? `
            <div>Points Earned: ${customer.pointsEarned}</div>
            <div>Total Points: ${customer.totalPoints}</div>
          ` : ''}
          <div class="thank-you">Thank You! Visit Again</div>
          <div>${company.tagline || 'Your Satisfaction is Our Priority'}</div>
        </div>
      </body>
      </html>
    `;
  }

  // Print A4 document (Purchase bills, reports)
  async printA4Document(documentData, options = {}) {
    const {
      type = 'report',
      preview = false,
      silent = false,
      orientation = 'portrait'
    } = options;

    const html = this.generateA4HTML(documentData, type);
    
    if (preview) {
      return this.showPrintPreview(html, 'a4');
    }

    await this.printHTML(html, {
      printerName: this.printerSettings.a4.name,
      silent,
      landscape: orientation === 'landscape',
      margins: this.printerSettings.a4.margins,
      pageSize: 'A4'
    });

    return { success: true };
  }

  // Generate A4 HTML
  generateA4HTML(data, type) {
    switch (type) {
      case 'purchase':
        return this.generatePurchaseBillHTML(data);
      case 'report':
        return this.generateReportHTML(data);
      case 'invoice':
        return this.generateInvoiceHTML(data);
      default:
        return this.generateGenericHTML(data);
    }
  }

  // Generate Purchase Bill HTML
  generatePurchaseBillHTML(purchaseData) {
    const { company, supplier, bill, items, totals } = purchaseData;

    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <style>
          @page {
            size: A4;
            margin: ${this.printerSettings.a4.margins.top}mm ${this.printerSettings.a4.margins.right}mm ${this.printerSettings.a4.margins.bottom}mm ${this.printerSettings.a4.margins.left}mm;
          }
          body {
            font-family: 'Arial', sans-serif;
            font-size: 12px;
            line-height: 1.5;
            color: #333;
          }
          .header {
            display: flex;
            justify-content: space-between;
            align-items: start;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #333;
          }
          .company-section {
            flex: 1;
          }
          .bill-section {
            text-align: right;
          }
          h1 {
            font-size: 24px;
            color: #333;
            margin: 0 0 10px 0;
          }
          h2 {
            font-size: 18px;
            color: #666;
            margin: 20px 0 10px 0;
          }
          .info-row {
            margin: 5px 0;
          }
          .label {
            font-weight: bold;
            display: inline-block;
            width: 100px;
          }
          table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
          }
          th {
            background: #f5f5f5;
            padding: 10px;
            text-align: left;
            border: 1px solid #ddd;
            font-weight: bold;
          }
          td {
            padding: 8px 10px;
            border: 1px solid #ddd;
          }
          .text-right {
            text-align: right;
          }
          .text-center {
            text-align: center;
          }
          .totals {
            margin-top: 30px;
            float: right;
            width: 300px;
          }
          .total-row {
            display: flex;
            justify-content: space-between;
            padding: 5px 0;
            border-bottom: 1px solid #eee;
          }
          .grand-total {
            font-size: 16px;
            font-weight: bold;
            border-top: 2px solid #333;
            border-bottom: none;
            padding-top: 10px;
          }
          .footer {
            margin-top: 50px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            display: flex;
            justify-content: space-between;
          }
          .signature {
            text-align: center;
            margin-top: 50px;
          }
          .signature-line {
            border-top: 1px solid #333;
            width: 200px;
            margin: 0 auto;
            padding-top: 5px;
          }
          @media print {
            .no-print {
              display: none;
            }
          }
        </style>
      </head>
      <body>
        <div class="header">
          <div class="company-section">
            <h1>${company.name}</h1>
            <div class="info-row">${company.address}</div>
            <div class="info-row">Phone: ${company.phone}</div>
            <div class="info-row">GSTIN: ${company.gstin}</div>
            <div class="info-row">Email: ${company.email}</div>
          </div>
          <div class="bill-section">
            <h1>PURCHASE BILL</h1>
            <div class="info-row"><span class="label">Bill No:</span> ${bill.billNo}</div>
            <div class="info-row"><span class="label">Date:</span> ${formatDate(bill.date)}</div>
            <div class="info-row"><span class="label">Ref No:</span> ${bill.refNo || '-'}</div>
          </div>
        </div>

        <div class="supplier-section">
          <h2>Supplier Details</h2>
          <div class="info-row"><span class="label">Name:</span> ${supplier.name}</div>
          <div class="info-row"><span class="label">GSTIN:</span> ${supplier.gstin || '-'}</div>
          <div class="info-row"><span class="label">Phone:</span> ${supplier.phone}</div>
          <div class="info-row"><span class="label">Email:</span> ${supplier.email || '-'}</div>
        </div>

        <table>
          <thead>
            <tr>
              <th width="5%">S.No</th>
              <th width="15%">Barcode</th>
              <th width="25%">Description</th>
              <th width="10%">HSN</th>
              <th width="8%" class="text-center">Qty</th>
              <th width="10%" class="text-right">Rate</th>
              <th width="8%" class="text-right">Disc %</th>
              <th width="9%" class="text-right">Taxable</th>
              <th width="10%" class="text-right">Amount</th>
            </tr>
          </thead>
          <tbody>
            ${items.map((item, index) => `
              <tr>
                <td class="text-center">${index + 1}</td>
                <td>${item.barcode}</td>
                <td>${item.styleCode} - ${item.color} - ${item.size}</td>
                <td>${item.hsn}</td>
                <td class="text-center">${item.qty}</td>
                <td class="text-right">${formatCurrency(item.rate)}</td>
                <td class="text-right">${item.discountPct || 0}%</td>
                <td class="text-right">${formatCurrency(item.taxable)}</td>
                <td class="text-right">${formatCurrency(item.amount)}</td>
              </tr>
            `).join('')}
          </tbody>
          <tfoot>
            <tr>
              <th colspan="4">Total</th>
              <th class="text-center">${totals.totalQty}</th>
              <th colspan="3"></th>
              <th class="text-right">${formatCurrency(totals.totalAmount)}</th>
            </tr>
          </tfoot>
        </table>

        <div class="totals">
          <div class="total-row">
            <span>Subtotal:</span>
            <span>${formatCurrency(totals.subtotal)}</span>
          </div>
          ${totals.discount > 0 ? `
            <div class="total-row">
              <span>Discount:</span>
              <span>${formatCurrency(totals.discount)}</span>
            </div>
          ` : ''}
          <div class="total-row">
            <span>Taxable Amount:</span>
            <span>${formatCurrency(totals.taxable)}</span>
          </div>
          ${totals.cgst > 0 ? `
            <div class="total-row">
              <span>CGST:</span>
              <span>${formatCurrency(totals.cgst)}</span>
            </div>
            <div class="total-row">
              <span>SGST:</span>
              <span>${formatCurrency(totals.sgst)}</span>
            </div>
          ` : ''}
          ${totals.igst > 0 ? `
            <div class="total-row">
              <span>IGST:</span>
              <span>${formatCurrency(totals.igst)}</span>
            </div>
          ` : ''}
          <div class="total-row grand-total">
            <span>Grand Total:</span>
            <span>${formatCurrency(totals.grandTotal)}</span>
          </div>
        </div>

        <div style="clear: both;"></div>

        <div class="footer">
          <div>
            <h3>Terms & Conditions:</h3>
            <ol>
              <li>Goods once sold will not be taken back</li>
              <li>Interest @18% p.a. will be charged on delayed payments</li>
              <li>Subject to local jurisdiction</li>
            </ol>
          </div>
          <div class="signature">
            <div>For ${company.name}</div>
            <div style="height: 60px;"></div>
            <div class="signature-line">Authorized Signature</div>
          </div>
        </div>
      </body>
      </html>
    `;
  }

  // Print HTML content
  async printHTML(html, options = {}) {
    try {
      if (window.electron) {
        // Electron printing
        return await window.electron.print({
          html,
          ...options
        });
      } else {
        // Web printing
        const printWindow = window.open('', '_blank');
        printWindow.document.write(html);
        printWindow.document.close();
        printWindow.print();
        return { success: true };
      }
    } catch (error) {
      console.error('Print error:', error);
      throw error;
    }
  }

  // Show print preview
  showPrintPreview(html, type = 'a4') {
    const previewWindow = window.open('', '_blank');
    const styles = type === 'thermal' ? this.getThermalPreviewStyles() : this.getA4PreviewStyles();
    
    previewWindow.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Print Preview</title>
        <style>${styles}</style>
      </head>
      <body>
        <div class="preview-controls no-print">
          <button onclick="window.print()">Print</button>
          <button onclick="window.close()">Close</button>
        </div>
        <div class="preview-content">
          ${html}
        </div>
      </body>
      </html>
    `);
    previewWindow.document.close();
    return { success: true };
  }

  // Get thermal preview styles
  getThermalPreviewStyles() {
    return `
      body {
        margin: 0;
        padding: 20px;
        background: #f5f5f5;
      }
      .preview-controls {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        background: white;
        padding: 10px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        z-index: 1000;
        text-align: center;
      }
      .preview-controls button {
        margin: 0 5px;
        padding: 8px 20px;
        font-size: 14px;
        cursor: pointer;
      }
      .preview-content {
        margin-top: 60px;
        background: white;
        width: 80mm;
        margin-left: auto;
        margin-right: auto;
        box-shadow: 0 0 10px rgba(0,0,0,0.1);
        padding: 10px;
      }
      @media print {
        .no-print {
          display: none;
        }
        body {
          margin: 0;
          padding: 0;
          background: white;
        }
        .preview-content {
          margin: 0;
          box-shadow: none;
          width: 80mm;
        }
      }
    `;
  }

  // Get A4 preview styles
  getA4PreviewStyles() {
    return `
      body {
        margin: 0;
        padding: 20px;
        background: #f5f5f5;
      }
      .preview-controls {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        background: white;
        padding: 10px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        z-index: 1000;
        text-align: center;
      }
      .preview-controls button {
        margin: 0 5px;
        padding: 8px 20px;
        font-size: 14px;
        cursor: pointer;
      }
      .preview-content {
        margin-top: 60px;
        background: white;
        width: 210mm;
        min-height: 297mm;
        margin-left: auto;
        margin-right: auto;
        box-shadow: 0 0 10px rgba(0,0,0,0.1);
        padding: 20mm;
      }
      @media print {
        @page {
          size: A4;
          margin: 0;
        }
        .no-print {
          display: none;
        }
        body {
          margin: 0;
          padding: 0;
          background: white;
        }
        .preview-content {
          margin: 0;
          box-shadow: none;
          width: 100%;
          min-height: 100%;
        }
      }
    `;
  }

  // Get invoice template
  getInvoiceTemplate() {
    return '';
  }

  // Get receipt template
  getReceiptTemplate() {
    return '';
  }

  // Get report template
  getReportTemplate() {
    return '';
  }

  // Get barcode template
  getBarcodeTemplate() {
    return '';
  }

  // Generate report HTML
  generateReportHTML(data) {
    return '';
  }

  // Generate invoice HTML
  generateInvoiceHTML(data) {
    return '';
  }

  // Generate generic HTML
  generateGenericHTML(data) {
    return '';
  }
}

export default new PrintService();