import * as XLSX from 'xlsx';
import { formatCurrency, formatDate } from './api';

class ExportService {
  constructor() {
    this.defaultExcelStyles = {
      header: {
        font: { bold: true, size: 12 },
        fill: { fgColor: { rgb: "9333EA" } },
        alignment: { horizontal: "center", vertical: "center" }
      },
      subHeader: {
        font: { bold: true, size: 11 },
        fill: { fgColor: { rgb: "F3F4F6" } }
      },
      currency: {
        numFmt: '₹#,##0.00'
      },
      date: {
        numFmt: 'DD-MM-YYYY'
      },
      percentage: {
        numFmt: '0.00%'
      }
    };
  }

  // Export data to Excel
  exportToExcel(data, options = {}) {
    const {
      filename = `export_${new Date().toISOString().split('T')[0]}.xlsx`,
      sheetName = 'Data',
      headers = null,
      autoWidth = true,
      showTotals = false,
      metadata = null
    } = options;

    try {
      const wb = XLSX.utils.book_new();
      
      // Add metadata sheet if provided
      if (metadata) {
        const metaSheet = this.createMetadataSheet(metadata);
        XLSX.utils.book_append_sheet(wb, metaSheet, 'Info');
      }

      // Process main data
      const ws = this.createDataSheet(data, headers, showTotals);
      
      // Set column widths
      if (autoWidth) {
        ws['!cols'] = this.calculateColumnWidths(data, headers);
      }

      // Apply styles (Note: Full styling requires Pro version)
      this.applyBasicStyles(ws);

      XLSX.utils.book_append_sheet(wb, ws, sheetName);
      
      // Write file
      XLSX.writeFile(wb, filename);
      
      return { success: true, filename };
    } catch (error) {
      console.error('Excel export error:', error);
      throw error;
    }
  }

  // Create data sheet
  createDataSheet(data, headers, showTotals) {
    let worksheetData = [];
    
    // Add custom headers if provided
    if (headers) {
      worksheetData.push(headers);
    }
    
    // Add data rows
    if (Array.isArray(data) && data.length > 0) {
      // If headers not provided, use object keys
      if (!headers) {
        worksheetData.push(Object.keys(data[0]));
      }
      
      data.forEach(row => {
        if (headers) {
          // Map data to header order
          const rowData = headers.map(header => {
            const key = this.findKeyByHeader(header, row);
            return this.formatCellValue(row[key]);
          });
          worksheetData.push(rowData);
        } else {
          worksheetData.push(Object.values(row).map(val => this.formatCellValue(val)));
        }
      });
    }
    
    // Add totals row if needed
    if (showTotals && data.length > 0) {
      const totalsRow = this.calculateTotals(data, headers);
      worksheetData.push(totalsRow);
    }
    
    return XLSX.utils.aoa_to_sheet(worksheetData);
  }

  // Create metadata sheet
  createMetadataSheet(metadata) {
    const metaData = [];
    
    metaData.push(['Report Information']);
    metaData.push([]);
    
    Object.entries(metadata).forEach(([key, value]) => {
      metaData.push([this.formatLabel(key), value]);
    });
    
    metaData.push([]);
    metaData.push(['Generated on', new Date().toLocaleString()]);
    
    return XLSX.utils.aoa_to_sheet(metaData);
  }

  // Format cell value
  formatCellValue(value) {
    if (value === null || value === undefined) return '';
    if (value instanceof Date) return formatDate(value);
    if (typeof value === 'boolean') return value ? 'Yes' : 'No';
    if (typeof value === 'number' && !isNaN(value)) return value;
    return String(value);
  }

  // Find key by header label
  findKeyByHeader(header, obj) {
    // Try exact match
    if (obj.hasOwnProperty(header)) return header;
    
    // Try case-insensitive match
    const key = Object.keys(obj).find(k => 
      k.toLowerCase() === header.toLowerCase()
    );
    if (key) return key;
    
    // Try converting header to camelCase
    const camelKey = header.toLowerCase().replace(/\s+(.)/g, (match, chr) => chr.toUpperCase());
    if (obj.hasOwnProperty(camelKey)) return camelKey;
    
    // Try converting header to snake_case
    const snakeKey = header.toLowerCase().replace(/\s+/g, '_');
    if (obj.hasOwnProperty(snakeKey)) return snakeKey;
    
    return header;
  }

  // Format label for display
  formatLabel(key) {
    return key
      .replace(/([A-Z])/g, ' $1')
      .replace(/_/g, ' ')
      .replace(/^./, str => str.toUpperCase())
      .trim();
  }

  // Calculate column widths
  calculateColumnWidths(data, headers) {
    const cols = [];
    const sampleSize = Math.min(10, data.length);
    
    // Determine number of columns
    const numCols = headers ? headers.length : (data[0] ? Object.keys(data[0]).length : 0);
    
    for (let i = 0; i < numCols; i++) {
      let maxWidth = 10; // Minimum width
      
      // Check header width
      if (headers && headers[i]) {
        maxWidth = Math.max(maxWidth, String(headers[i]).length);
      }
      
      // Check data widths
      for (let j = 0; j < sampleSize; j++) {
        if (data[j]) {
          const value = headers 
            ? data[j][this.findKeyByHeader(headers[i], data[j])]
            : Object.values(data[j])[i];
          
          if (value !== null && value !== undefined) {
            const strValue = String(this.formatCellValue(value));
            maxWidth = Math.max(maxWidth, strValue.length);
          }
        }
      }
      
      cols.push({ width: Math.min(maxWidth + 2, 50) }); // Cap at 50
    }
    
    return cols;
  }

  // Apply basic styles to worksheet
  applyBasicStyles(ws) {
    const range = XLSX.utils.decode_range(ws['!ref']);
    
    // Style header row (first row)
    for (let C = range.s.c; C <= range.e.c; ++C) {
      const cellAddress = XLSX.utils.encode_cell({ r: 0, c: C });
      if (ws[cellAddress]) {
        ws[cellAddress].s = {
          font: { bold: true },
          fill: { fgColor: { rgb: "EFEFEF" } }
        };
      }
    }
  }

  // Calculate totals for numeric columns
  calculateTotals(data, headers) {
    const totals = headers ? new Array(headers.length).fill('') : [];
    totals[0] = 'TOTAL';
    
    // Identify numeric columns
    const numericColumns = [];
    const sampleRow = data[0];
    
    if (sampleRow) {
      Object.entries(sampleRow).forEach(([key, value], index) => {
        if (typeof value === 'number' && !isNaN(value)) {
          numericColumns.push({ key, index });
        }
      });
    }
    
    // Calculate sums
    numericColumns.forEach(({ key, index }) => {
      const sum = data.reduce((acc, row) => {
        const value = row[key];
        return acc + (typeof value === 'number' ? value : 0);
      }, 0);
      
      if (headers) {
        const headerIndex = headers.findIndex(h => 
          this.findKeyByHeader(h, sampleRow) === key
        );
        if (headerIndex !== -1) {
          totals[headerIndex] = sum;
        }
      } else {
        totals[index + 1] = sum; // +1 because first column is 'TOTAL'
      }
    });
    
    return totals;
  }

  // Export specific report types
  exportSalesReport(salesData, options = {}) {
    const formattedData = salesData.map(sale => ({
      'Date': formatDate(sale.billDate),
      'Bill No': sale.billNo,
      'Customer': sale.customerName || 'Walk-in',
      'Mobile': sale.customerMobile || '-',
      'Items': sale.totalItems,
      'Subtotal': sale.subtotal,
      'Discount': sale.discount,
      'Tax': sale.tax,
      'Total': sale.grandTotal,
      'Payment': sale.paymentMode,
      'Staff': sale.staffName || '-'
    }));

    return this.exportToExcel(formattedData, {
      filename: `sales_report_${new Date().toISOString().split('T')[0]}.xlsx`,
      sheetName: 'Sales Report',
      showTotals: true,
      metadata: {
        'Report Type': 'Sales Report',
        'Date Range': options.dateRange || 'All',
        'Total Records': salesData.length,
        'Total Sales': formatCurrency(
          salesData.reduce((sum, s) => sum + s.grandTotal, 0)
        )
      }
    });
  }

  exportStockReport(stockData, options = {}) {
    const formattedData = stockData.map(item => ({
      'Barcode': item.barcode,
      'Style Code': item.styleCode,
      'Color': item.color,
      'Size': item.size,
      'Brand': item.brand,
      'Category': item.category,
      'HSN': item.hsn,
      'MRP': item.mrpIncl,
      'Purchase Rate': item.purchaseRate,
      'Stock Qty': item.qtyOnHand,
      'Stock Value': item.qtyOnHand * item.purchaseRate,
      'Status': item.qtyOnHand > 0 ? 'In Stock' : 'Out of Stock'
    }));

    return this.exportToExcel(formattedData, {
      filename: `stock_report_${new Date().toISOString().split('T')[0]}.xlsx`,
      sheetName: 'Stock Report',
      showTotals: true,
      metadata: {
        'Report Type': 'Stock Report',
        'Total Items': stockData.length,
        'In Stock': stockData.filter(i => i.qtyOnHand > 0).length,
        'Out of Stock': stockData.filter(i => i.qtyOnHand === 0).length,
        'Total Stock Value': formatCurrency(
          stockData.reduce((sum, i) => sum + (i.qtyOnHand * i.purchaseRate), 0)
        )
      }
    });
  }

  exportPurchaseReport(purchaseData, options = {}) {
    const formattedData = purchaseData.map(purchase => ({
      'Date': formatDate(purchase.billDate),
      'Bill No': purchase.billNo,
      'Supplier': purchase.supplierName,
      'GSTIN': purchase.supplierGstin || '-',
      'Items': purchase.totalItems,
      'Qty': purchase.totalQty,
      'Basic Amount': purchase.basicAmount,
      'Discount': purchase.discount,
      'Taxable': purchase.taxableAmount,
      'GST': purchase.totalGst,
      'Total': purchase.grandTotal,
      'Payment': purchase.paymentMode
    }));

    return this.exportToExcel(formattedData, {
      filename: `purchase_report_${new Date().toISOString().split('T')[0]}.xlsx`,
      sheetName: 'Purchase Report',
      showTotals: true,
      metadata: {
        'Report Type': 'Purchase Report',
        'Date Range': options.dateRange || 'All',
        'Total Bills': purchaseData.length,
        'Total Purchase': formatCurrency(
          purchaseData.reduce((sum, p) => sum + p.grandTotal, 0)
        )
      }
    });
  }

  exportCustomerReport(customerData, options = {}) {
    const formattedData = customerData.map(customer => ({
      'Mobile': customer.mobile,
      'Name': customer.name,
      'Email': customer.email || '-',
      'City': customer.city || '-',
      'Grade': customer.gradeName || 'Regular',
      'Points': customer.pointsBalance,
      'Lifetime Purchase': customer.lifetimePurchase,
      'Last Visit': customer.lastVisit ? formatDate(customer.lastVisit) : '-',
      'Total Bills': customer.totalBills || 0,
      'Avg Bill Value': customer.avgBillValue || 0
    }));

    return this.exportToExcel(formattedData, {
      filename: `customer_report_${new Date().toISOString().split('T')[0]}.xlsx`,
      sheetName: 'Customer Report',
      metadata: {
        'Report Type': 'Customer Report',
        'Total Customers': customerData.length,
        'Active Customers': customerData.filter(c => c.isActive).length,
        'Total Lifetime Value': formatCurrency(
          customerData.reduce((sum, c) => sum + c.lifetimePurchase, 0)
        )
      }
    });
  }

  // Export to CSV
  exportToCSV(data, filename = 'export.csv') {
    try {
      const ws = XLSX.utils.json_to_sheet(data);
      const csv = XLSX.utils.sheet_to_csv(ws);
      
      // Create blob and download
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      
      link.setAttribute('href', url);
      link.setAttribute('download', filename);
      link.style.visibility = 'hidden';
      
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      return { success: true, filename };
    } catch (error) {
      console.error('CSV export error:', error);
      throw error;
    }
  }

  // Export to PDF (requires jsPDF library)
  exportToPDF(data, options = {}) {
    // Note: This is a placeholder. Actual implementation requires jsPDF
    console.warn('PDF export requires jsPDF library to be installed');
    
    const {
      title = 'Report',
      orientation = 'portrait',
      format = 'a4'
    } = options;

    // Implementation would go here if jsPDF is available
    /*
    import jsPDF from 'jspdf';
    import 'jspdf-autotable';
    
    const doc = new jsPDF(orientation, 'mm', format);
    doc.text(title, 14, 15);
    doc.autoTable({
      head: [Object.keys(data[0])],
      body: data.map(row => Object.values(row)),
      startY: 25
    });
    doc.save(`${title}.pdf`);
    */
    
    return { 
      success: false, 
      message: 'PDF export not available. Please use Excel export instead.' 
    };
  }

  // Generate and download report
  async generateReport(reportType, params = {}) {
    try {
      // This would typically fetch data from API
      const data = await this.fetchReportData(reportType, params);
      
      switch (reportType) {
        case 'sales':
          return this.exportSalesReport(data, params);
        case 'stock':
          return this.exportStockReport(data, params);
        case 'purchase':
          return this.exportPurchaseReport(data, params);
        case 'customer':
          return this.exportCustomerReport(data, params);
        default:
          return this.exportToExcel(data, {
            filename: `${reportType}_report.xlsx`,
            sheetName: reportType.charAt(0).toUpperCase() + reportType.slice(1)
          });
      }
    } catch (error) {
      console.error('Report generation error:', error);
      throw error;
    }
  }

  // Placeholder for fetching report data
  async fetchReportData(reportType, params) {
    // This would be replaced with actual API call
    return [];
  }
}

export default new ExportService();