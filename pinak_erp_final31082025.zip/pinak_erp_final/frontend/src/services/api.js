// frontend/src/services/api.js - COMPLETE FIXED VERSION
import axios from 'axios';
import toast from 'react-hot-toast';

// API base configuration
const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000/api/v1';
export const API_URL = API_BASE_URL; // For backward compatibility

// Create axios instance
const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor - Add auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor - Handle errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    console.error('API Error:', error);
    
    if (error.response) {
      const { status, data } = error.response;
      
      switch (status) {
        case 401:
          localStorage.removeItem('token');
          localStorage.removeItem('user');
          toast.error('Session expired. Please login again.');
          window.location.href = '/login';
          break;
        case 403:
          toast.error('You do not have permission to perform this action');
          break;
        case 404:
          toast.error('Resource not found');
          break;
        case 422:
          // Validation errors
          if (data.detail && Array.isArray(data.detail)) {
            data.detail.forEach(err => {
              toast.error(`${err.loc?.join(' → ') || 'Field'}: ${err.msg}`);
            });
          } else {
            toast.error(data.detail || 'Validation error');
          }
          break;
        case 500:
          toast.error('Server error. Please try again later.');
          break;
        default:
          toast.error(data?.detail || 'Something went wrong');
      }
    } else if (error.request) {
      toast.error('Network error. Please check your connection.');
    }
    return Promise.reject(error);
  }
);

// Utility Functions
export const formatCurrency = (amount) => {
  if (!amount && amount !== 0) return '₹0.00';
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(amount);
};

export const formatDate = (dateString) => {
  if (!dateString) return '';
  const date = new Date(dateString);
  return date.toLocaleDateString('en-IN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  });
};

export const downloadFile = (blob, filename) => {
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  window.URL.revokeObjectURL(url);
};

// Auth APIs
export const authAPI = {
  login: (credentials) => api.post('/auth/login', credentials),
  logout: () => api.post('/auth/logout'),
  changePassword: (data) => api.post('/auth/change-password', data),
  getCurrentUser: () => api.get('/auth/me'),
};

// Setup APIs
export const setupAPI = {
  // Company
  getCompanies: () => api.get('/setup/companies'),
  getCompany: (id) => api.get(`/setup/companies/${id}`),
  createCompany: (data) => api.post('/setup/companies', data),
  updateCompany: (id, data) => api.put(`/setup/companies/${id}`, data),
  
  // Users
  getUsers: (params) => api.get('/setup/users', { params }),
  getUser: (id) => api.get(`/setup/users/${id}`),
  createUser: (data) => api.post('/setup/users', data),
  updateUser: (id, data) => api.put(`/setup/users/${id}`, data),
  updatePermissions: (userId, permissions) => 
    api.put(`/setup/users/${userId}/permissions`, permissions),
  
  // Suppliers
  getSuppliers: (params) => api.get('/setup/suppliers', { params }),
  getSupplier: (id) => api.get(`/setup/suppliers/${id}`),
  createSupplier: (data) => api.post('/setup/suppliers', data),
  updateSupplier: (id, data) => api.put(`/setup/suppliers/${id}`, data),
  deleteSupplier: (id) => api.delete(`/setup/suppliers/${id}`),
  
  // Customers
  getCustomers: (params) => api.get('/setup/customers', { params }),
  searchCustomer: (mobile) => api.get('/setup/customers/search', { params: { mobile } }),
  createCustomer: (data) => api.post('/setup/customers', data),
  updateCustomer: (mobile, data) => api.put(`/setup/customers/${mobile}`, data),
  getCustomerHistory: (mobile) => api.get(`/setup/customers/${mobile}/history`),
  
  // Loyalty Grades
  getLoyaltyGrades: (activeOnly = true) => 
    api.get('/setup/loyalty-grades', { params: { active_only: activeOnly } }),
  createLoyaltyGrade: (data) => api.post('/setup/loyalty-grades', data),
  updateLoyaltyGrade: (id, data) => api.put(`/setup/loyalty-grades/${id}`, data),
  
  // Coupons
  getCoupons: (params) => api.get('/setup/coupons', { params }),
  createCoupon: (data) => api.post('/setup/coupons', data),
  updateCoupon: (id, data) => api.put(`/setup/coupons/${id}`, data),
  validateCoupon: (code, mobile) => 
    api.post('/setup/coupons/validate', { code, customer_mobile: mobile }),
  
  // Bill Series
  getBillSeries: (params) => api.get('/setup/bill-series', { params }),
  createBillSeries: (data) => api.post('/setup/bill-series', data),
  updateBillSeries: (id, data) => api.put(`/setup/bill-series/${id}`, data),
  
  // Staff
  getStaff: (activeOnly = true) => 
    api.get('/setup/staff', { params: { active_only: activeOnly } }),
  createStaff: (data) => api.post('/setup/staff', data),
  updateStaff: (id, data) => api.put(`/setup/staff/${id}`, data),
  
  // Expense Heads
  getExpenseHeads: (activeOnly = true) =>
    api.get('/setup/expense-heads', { params: { active_only: activeOnly } }),
  createExpenseHead: (data) => api.post('/setup/expense-heads', data),
  updateExpenseHead: (id, data) => api.put(`/setup/expense-heads/${id}`, data),
  
  // Payment Modes
  getPaymentModes: (activeOnly = true) => 
    api.get('/setup/payment-modes', { params: { active_only: activeOnly } }),
  createPaymentMode: (data) => api.post('/setup/payment-modes', data),
  updatePaymentMode: (id, data) => api.put(`/setup/payment-modes/${id}`, data),
  
  // WhatsApp Config
  getWhatsAppConfig: () => api.get('/setup/whatsapp-config'),
  createWhatsAppConfig: (data) => api.post('/setup/whatsapp-config', data),
  testWhatsApp: (mobile) => api.post('/setup/whatsapp-config/test', null, { params: { mobile } }),
  
  // User Access & Permissions
  getUserPermissions: (userId) => api.get(`/setup/users/${userId}/permissions`),
  updateUserPermissions: (userId, permissions) => 
    api.put(`/setup/users/${userId}/permissions`, permissions),
};

// Items APIs - FIXED VERSION
export const itemsAPI = {
  getItems: (params) => api.get('/items', { params }),
  getItem: (barcode) => api.get(`/items/barcode/${barcode}`),  // FIXED: Added /barcode/
  createItem: (data) => api.post('/items/', data),
  updateItem: (barcode, data) => api.put(`/items/barcode/${barcode}`, data),  // FIXED: Added /barcode/
  deleteItem: (barcode) => api.delete(`/items/barcode/${barcode}`),  // FIXED: Added /barcode/
  importItems: (file) => {
    const formData = new FormData();
    formData.append('file', file);
    return api.post('/items/import/excel', formData, {  // Already fixed earlier
      headers: { 'Content-Type': 'multipart/form-data' }
    });
  },
  exportItems: (params) => 
    api.get('/items/export/excel', { params, responseType: 'blob' }),  // FIXED: Added /excel
  searchItems: (query) => api.get('/items/search', { params: query }),
  updateStock: (data) => api.post('/items/update-stock', data),
  getStock: (barcode) => api.get(`/items/stock/${barcode}`),
  updateOpeningStock: (stocks) => api.post('/items/opening-stock', { stocks }),
};

// Sales/POS APIs
export const salesAPI = {
  // POS Operations
  searchItemPOS: (barcode) => api.get('/sales/pos/search-item', { params: { barcode } }),
  searchCustomerPOS: (mobile) => api.get('/sales/pos/search-customer', { params: { mobile } }),
  validateCouponPOS: (code, mobile, amount) => 
    api.post('/sales/pos/validate-coupon', { code, customer_mobile: mobile, bill_amount: amount }),
  
  // Sales Bills
  createSale: (data) => api.post('/sales/bills', data),
  getSale: (id) => api.get(`/sales/bills/${id}`),
  getSales: (params) => api.get('/sales/bills', { params }),
  printBill: (id) => api.get(`/sales/bills/${id}/print`, { responseType: 'blob' }),
  sendWhatsApp: (id, mobile) => api.post(`/sales/bills/${id}/whatsapp`, { mobile }),
  modifySale: (id, data) => api.post(`/sales/bills/${id}/modify`, data),
  
  // Sale Returns
  createReturn: (data) => api.post('/sales/returns', data),
  getReturn: (id) => api.get(`/sales/returns/${id}`),
  getReturns: (params) => api.get('/sales/returns', { params }),
  getReturnCredit: (mobile) => api.get('/sales/return-credits', { params: { customer_mobile: mobile } }),
  useReturnCredit: (creditId, amount) => 
    api.post(`/sales/return-credits/${creditId}/use`, { amount }),
};

// Purchase APIs
export const purchaseAPI = {
  // Purchase Bills
  createPurchase: (data) => api.post('/purchases/bills', data),
  getPurchase: (id) => api.get(`/purchases/bills/${id}`),
  getPurchases: (params) => api.get('/purchases/bills', { params }),
  updatePurchase: (id, data) => api.put(`/purchases/bills/${id}`, data),
  deletePurchase: (id) => api.delete(`/purchases/bills/${id}`),
  
  // Purchase Returns
  createPurchaseReturn: (data) => api.post('/purchases/returns', data),
  getPurchaseReturn: (id) => api.get(`/purchases/returns/${id}`),
  getPurchaseReturns: (params) => api.get('/purchases/returns', { params }),
};

// Reports APIs
export const reportsAPI = {
  // Sale Reports
  getSaleReturnReport: (data) => api.post('/reports/sale-return-detailed', data),
  getCustomerReport: (data) => api.post('/reports/customers', data),
  getCustomerWiseSale: (data) => api.post('/reports/customer-wise-sale', data),
  getInactiveCustomers: (data) => api.post('/reports/inactive-customers', data),
  getBirthdayReport: (data) => api.post('/reports/birthday', data),
  getHSNReport: (data) => api.post('/reports/hsn', data),
  getStaffReport: (data) => api.post('/reports/staff', data),
  getBillWiseReport: (data) => api.post('/reports/bill-wise', data),
  getPaymentModeReport: (data) => api.post('/reports/payment-mode', data),
  getExpensesReport: (data) => api.post('/reports/expenses', data),
  getStockReport: (data) => api.post('/reports/stock', data),
  getPurchaseReport: (data) => api.post('/reports/purchase', data),
  
  // Export Reports
  exportReport: (reportType, data) => 
    api.post(`/reports/${reportType}/export`, data, { responseType: 'blob' }),
};

// Default export
export default api;

// Named exports for convenience
export { API_BASE_URL };