// frontend/src/services/validationService.js
// Validation service for form validations

class ValidationService {
  // Generic validations
  required(value, fieldName = 'Field') {
    if (!value || value.toString().trim() === '') {
      return `${fieldName} is required`;
    }
    return null;
  }

  minLength(value, min, fieldName = 'Field') {
    if (value && value.length < min) {
      return `${fieldName} must be at least ${min} characters`;
    }
    return null;
  }

  maxLength(value, max, fieldName = 'Field') {
    if (value && value.length > max) {
      return `${fieldName} must not exceed ${max} characters`;
    }
    return null;
  }

  email(value) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (value && !emailRegex.test(value)) {
      return 'Invalid email address';
    }
    return null;
  }

  mobile(value) {
    const mobileRegex = /^[6-9]\d{9}$/;
    if (value && !mobileRegex.test(value)) {
      return 'Invalid mobile number (10 digits starting with 6-9)';
    }
    return null;
  }

  gstin(value) {
    const gstinRegex = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;
    if (value && !gstinRegex.test(value)) {
      return 'Invalid GSTIN format';
    }
    return null;
  }

  panCard(value) {
    const panRegex = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
    if (value && !panRegex.test(value)) {
      return 'Invalid PAN card format';
    }
    return null;
  }

  aadharCard(value) {
    const aadharRegex = /^\d{12}$/;
    if (value && !aadharRegex.test(value)) {
      return 'Invalid Aadhar card number (12 digits)';
    }
    return null;
  }

  // Numeric validations
  number(value, fieldName = 'Value') {
    if (value && isNaN(value)) {
      return `${fieldName} must be a number`;
    }
    return null;
  }

  positiveNumber(value, fieldName = 'Value') {
    const num = parseFloat(value);
    if (!isNaN(num) && num <= 0) {
      return `${fieldName} must be a positive number`;
    }
    return null;
  }

  amount(value, min = 0, max = null) {
    const num = parseFloat(value);
    if (isNaN(num)) return 'Invalid amount';
    if (num < min) return 'Amount must be at least ' + min;
    if (max !== null && num > max) return 'Amount must not exceed ' + max;
    return null;
  }

  percentage(value) {
    const num = parseFloat(value);
    if (isNaN(num) || num < 0 || num > 100) {
      return 'Percentage must be between 0 and 100';
    }
    return null;
  }

  // Date validations
  date(value) {
    if (value && isNaN(Date.parse(value))) {
      return 'Invalid date';
    }
    return null;
  }

  dateRange(startDate, endDate) {
    if (startDate && endDate) {
      const start = new Date(startDate);
      const end = new Date(endDate);
      if (start > end) {
        return 'Start date must be before end date';
      }
    }
    return null;
  }

  futureDate(value) {
    if (value) {
      const date = new Date(value);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      if (date < today) {
        return 'Date must be in the future';
      }
    }
    return null;
  }

  pastDate(value) {
    if (value) {
      const date = new Date(value);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      if (date > today) {
        return 'Date must be in the past';
      }
    }
    return null;
  }

  // Business specific validations
  barcode(value) {
    if (value && (value.length < 8 || value.length > 13)) {
      return 'Barcode must be between 8 and 13 characters';
    }
    return null;
  }

  hsn(value) {
    const hsnRegex = /^\d{4,8}$/;
    if (value && !hsnRegex.test(value)) {
      return 'HSN code must be 4-8 digits';
    }
    return null;
  }

  pincode(value) {
    const pincodeRegex = /^\d{6}$/;
    if (value && !pincodeRegex.test(value)) {
      return 'Pincode must be 6 digits';
    }
    return null;
  }

  // Form validation helper
  validateForm(formData, rules) {
    const errors = {};
    
    Object.keys(rules).forEach(field => {
      const value = formData[field];
      const fieldRules = rules[field];
      
      for (const rule of fieldRules) {
        const error = rule(value);
        if (error) {
          errors[field] = error;
          break;
        }
      }
    });
    
    return {
      isValid: Object.keys(errors).length === 0,
      errors
    };
  }

  // Validation rules builder
  rules() {
    return {
      required: (fieldName) => (value) => this.required(value, fieldName),
      minLength: (min, fieldName) => (value) => this.minLength(value, min, fieldName),
      maxLength: (max, fieldName) => (value) => this.maxLength(value, max, fieldName),
      email: () => (value) => this.email(value),
      mobile: () => (value) => this.mobile(value),
      gstin: () => (value) => this.gstin(value),
      amount: (min, max) => (value) => this.amount(value, min, max),
      percentage: () => (value) => this.percentage(value),
      barcode: () => (value) => this.barcode(value),
      hsn: () => (value) => this.hsn(value),
    };
  }
}

export default new ValidationService();