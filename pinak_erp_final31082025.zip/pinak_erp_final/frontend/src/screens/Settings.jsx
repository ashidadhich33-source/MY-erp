import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { toast } from 'react-toastify';
import LoadingOverlay from '../components/LoadingOverlay';
import { API_URL } from '../services/api';
import './SetupScreens.css';

const Settings = () => {
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('general');
  const [settings, setSettings] = useState({
    general: {
      appName: 'PIANK ERP',
      currency: 'INR',
      dateFormat: 'DD-MM-YYYY',
      timeFormat: '12h',
      language: 'en',
      timezone: 'Asia/Kolkata',
      fiscalYear: '2024-25'
    },
    pos: {
      defaultBillSeries: '',
      defaultPaymentMode: 'CASH',
      autoSaveHoldBills: true,
      printAfterSale: true,
      soundEnabled: true,
      showLowStockWarning: true,
      lowStockThreshold: 5,
      allowNegativeStock: false,
      requireCustomerMobile: false,
      enableLoyaltyPoints: true,
      enableCoupons: true
    },
    printer: {
      thermalPrinter: '',
      thermalPrinterWidth: 80,
      a4Printer: '',
      barcodePrinter: '',
      autoDetectPrinters: true,
      printCopies: 1,
      printLogo: true,
      printFooter: true,
      footerText: 'Thank you for shopping!'
    },
    backup: {
      autoBackup: true,
      backupFrequency: 'daily',
      backupTime: '23:00',
      backupLocation: './backups',
      keepBackupDays: 30,
      cloudBackup: false,
      cloudProvider: '',
      lastBackup: null
    },
    security: {
      sessionTimeout: 30,
      requirePasswordChange: false,
      passwordChangeDays: 90,
      minPasswordLength: 8,
      requireStrongPassword: true,
      enableTwoFactor: false,
      maxLoginAttempts: 5,
      lockoutDuration: 30,
      auditLog: true,
      ipWhitelist: []
    },
    notifications: {
      emailEnabled: false,
      emailServer: '',
      emailPort: 587,
      emailUsername: '',
      emailPassword: '',
      emailFrom: '',
      smsEnabled: false,
      smsProvider: '',
      smsApiKey: '',
      whatsappEnabled: true,
      whatsappApiUrl: '',
      whatsappApiToken: '',
      lowStockAlert: true,
      birthdayReminder: true,
      dailySalesReport: true
    }
  });

  const [printers, setPrinters] = useState([]);
  const [billSeries, setBillSeries] = useState([]);
  const [paymentModes, setPaymentModes] = useState([]);

  useEffect(() => {
    loadSettings();
    loadOptions();
  }, []);

  const loadSettings = async () => {
    setLoading(true);
    try {
      // Load from localStorage or API
      const savedSettings = localStorage.getItem('appSettings');
      if (savedSettings) {
        setSettings(JSON.parse(savedSettings));
      } else {
        // Load from API
        const token = localStorage.getItem('token');
        const response = await axios.get(`${API_URL}/settings`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        setSettings(response.data);
      }
    } catch (error) {
      console.error('Failed to load settings:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadOptions = async () => {
    try {
      const token = localStorage.getItem('token');
      
      // Load bill series
      const billSeriesResponse = await axios.get(`${API_URL}/setup/bill-series`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setBillSeries(billSeriesResponse.data || []);
      
      // Load payment modes
      const paymentModesResponse = await axios.get(`${API_URL}/setup/payment-modes`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setPaymentModes(paymentModesResponse.data || []);
      
      // Get available printers if in Electron
      if (window.electron) {
        const availablePrinters = await window.electron.getPrinters();
        setPrinters(availablePrinters || []);
      }
    } catch (error) {
      console.error('Failed to load options:', error);
    }
  };

  const handleSettingChange = (category, field, value) => {
    setSettings(prev => ({
      ...prev,
      [category]: {
        ...prev[category],
        [field]: value
      }
    }));
  };

  const handleSaveSettings = async () => {
    setLoading(true);
    try {
      // Save to localStorage
      localStorage.setItem('appSettings', JSON.stringify(settings));
      
      // Save to API
      const token = localStorage.getItem('token');
      await axios.post(
        `${API_URL}/settings`,
        settings,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      toast.success('Settings saved successfully');
    } catch (error) {
      toast.error('Failed to save settings');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleBackupNow = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.post(
        `${API_URL}/backup/create`,
        {},
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      toast.success('Backup created successfully');
      handleSettingChange('backup', 'lastBackup', new Date().toISOString());
    } catch (error) {
      toast.error('Backup failed');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleRestoreBackup = async () => {
    if (!window.confirm('Are you sure? This will replace all current data!')) {
      return;
    }
    
    // File selection and restore logic
    if (window.electron) {
      const file = await window.electron.selectFile();
      if (file) {
        setLoading(true);
        try {
          await window.electron.restoreDatabase(file.path);
          toast.success('Database restored successfully');
          window.location.reload();
        } catch (error) {
          toast.error('Restore failed');
          console.error(error);
        } finally {
          setLoading(false);
        }
      }
    }
  };

  const handleTestConnection = async (type) => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const endpoint = type === 'email' ? 'test-email' : type === 'sms' ? 'test-sms' : 'test-whatsapp';
      
      await axios.post(
        `${API_URL}/settings/${endpoint}`,
        settings.notifications,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      toast.success(`${type} connection test successful`);
    } catch (error) {
      toast.error(`${type} connection test failed`);
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const renderGeneralSettings = () => (
    <div className="settings-section">
      <h3>General Settings</h3>
      
      <div className="form-grid">
        <div className="form-group">
          <label>Application Name</label>
          <input
            type="text"
            value={settings.general.appName}
            onChange={(e) => handleSettingChange('general', 'appName', e.target.value)}
          />
        </div>
        
        <div className="form-group">
          <label>Currency</label>
          <select
            value={settings.general.currency}
            onChange={(e) => handleSettingChange('general', 'currency', e.target.value)}
          >
            <option value="INR">INR (₹)</option>
            <option value="USD">USD ($)</option>
            <option value="EUR">EUR (€)</option>
            <option value="GBP">GBP (£)</option>
          </select>
        </div>
        
        <div className="form-group">
          <label>Date Format</label>
          <select
            value={settings.general.dateFormat}
            onChange={(e) => handleSettingChange('general', 'dateFormat', e.target.value)}
          >
            <option value="DD-MM-YYYY">DD-MM-YYYY</option>
            <option value="MM-DD-YYYY">MM-DD-YYYY</option>
            <option value="YYYY-MM-DD">YYYY-MM-DD</option>
          </select>
        </div>
        
        <div className="form-group">
          <label>Time Format</label>
          <select
            value={settings.general.timeFormat}
            onChange={(e) => handleSettingChange('general', 'timeFormat', e.target.value)}
          >
            <option value="12h">12 Hour</option>
            <option value="24h">24 Hour</option>
          </select>
        </div>
        
        <div className="form-group">
          <label>Language</label>
          <select
            value={settings.general.language}
            onChange={(e) => handleSettingChange('general', 'language', e.target.value)}
          >
            <option value="en">English</option>
            <option value="hi">Hindi</option>
          </select>
        </div>
        
        <div className="form-group">
          <label>Fiscal Year</label>
          <input
            type="text"
            value={settings.general.fiscalYear}
            onChange={(e) => handleSettingChange('general', 'fiscalYear', e.target.value)}
            placeholder="2024-25"
          />
        </div>
      </div>
    </div>
  );

  const renderPOSSettings = () => (
    <div className="settings-section">
      <h3>POS Settings</h3>
      
      <div className="form-grid">
        <div className="form-group">
          <label>Default Bill Series</label>
          <select
            value={settings.pos.defaultBillSeries}
            onChange={(e) => handleSettingChange('pos', 'defaultBillSeries', e.target.value)}
          >
            <option value="">Select Bill Series</option>
            {billSeries.map(series => (
              <option key={series.id} value={series.id}>{series.code}</option>
            ))}
          </select>
        </div>
        
        <div className="form-group">
          <label>Default Payment Mode</label>
          <select
            value={settings.pos.defaultPaymentMode}
            onChange={(e) => handleSettingChange('pos', 'defaultPaymentMode', e.target.value)}
          >
            {paymentModes.map(mode => (
              <option key={mode.id} value={mode.name}>{mode.name}</option>
            ))}
          </select>
        </div>
        
        <div className="form-group">
          <label>Low Stock Threshold</label>
          <input
            type="number"
            value={settings.pos.lowStockThreshold}
            onChange={(e) => handleSettingChange('pos', 'lowStockThreshold', parseInt(e.target.value))}
            min="1"
          />
        </div>
      </div>
      
      <div className="checkbox-group">
        <label>
          <input
            type="checkbox"
            checked={settings.pos.autoSaveHoldBills}
            onChange={(e) => handleSettingChange('pos', 'autoSaveHoldBills', e.target.checked)}
          />
          Auto-save held bills
        </label>
        
        <label>
          <input
            type="checkbox"
            checked={settings.pos.printAfterSale}
            onChange={(e) => handleSettingChange('pos', 'printAfterSale', e.target.checked)}
          />
          Print receipt after sale
        </label>
        
        <label>
          <input
            type="checkbox"
            checked={settings.pos.soundEnabled}
            onChange={(e) => handleSettingChange('pos', 'soundEnabled', e.target.checked)}
          />
          Enable sound alerts
        </label>
        
        <label>
          <input
            type="checkbox"
            checked={settings.pos.showLowStockWarning}
            onChange={(e) => handleSettingChange('pos', 'showLowStockWarning', e.target.checked)}
          />
          Show low stock warnings
        </label>
        
        <label>
          <input
            type="checkbox"
            checked={settings.pos.allowNegativeStock}
            onChange={(e) => handleSettingChange('pos', 'allowNegativeStock', e.target.checked)}
          />
          Allow negative stock
        </label>
        
        <label>
          <input
            type="checkbox"
            checked={settings.pos.requireCustomerMobile}
            onChange={(e) => handleSettingChange('pos', 'requireCustomerMobile', e.target.checked)}
          />
          Require customer mobile
        </label>
        
        <label>
          <input
            type="checkbox"
            checked={settings.pos.enableLoyaltyPoints}
            onChange={(e) => handleSettingChange('pos', 'enableLoyaltyPoints', e.target.checked)}
          />
          Enable loyalty points
        </label>
        
        <label>
          <input
            type="checkbox"
            checked={settings.pos.enableCoupons}
            onChange={(e) => handleSettingChange('pos', 'enableCoupons', e.target.checked)}
          />
          Enable coupons
        </label>
      </div>
    </div>
  );

  const renderPrinterSettings = () => (
    <div className="settings-section">
      <h3>Printer Settings</h3>
      
      <div className="form-grid">
        <div className="form-group">
          <label>Thermal Printer (Receipt)</label>
          <select
            value={settings.printer.thermalPrinter}
            onChange={(e) => handleSettingChange('printer', 'thermalPrinter', e.target.value)}
          >
            <option value="">Select Printer</option>
            {printers.map(printer => (
              <option key={printer.name} value={printer.name}>{printer.name}</option>
            ))}
          </select>
        </div>
        
        <div className="form-group">
          <label>Thermal Printer Width</label>
          <select
            value={settings.printer.thermalPrinterWidth}
            onChange={(e) => handleSettingChange('printer', 'thermalPrinterWidth', parseInt(e.target.value))}
          >
            <option value={58}>58mm</option>
            <option value={80}>80mm</option>
          </select>
        </div>
        
        <div className="form-group">
          <label>A4 Printer (Reports)</label>
          <select
            value={settings.printer.a4Printer}
            onChange={(e) => handleSettingChange('printer', 'a4Printer', e.target.value)}
          >
            <option value="">Select Printer</option>
            {printers.map(printer => (
              <option key={printer.name} value={printer.name}>{printer.name}</option>
            ))}
          </select>
        </div>
        
        <div className="form-group">
          <label>Barcode Label Printer</label>
          <select
            value={settings.printer.barcodePrinter}
            onChange={(e) => handleSettingChange('printer', 'barcodePrinter', e.target.value)}
          >
            <option value="">Select Printer</option>
            {printers.map(printer => (
              <option key={printer.name} value={printer.name}>{printer.name}</option>
            ))}
          </select>
        </div>
        
        <div className="form-group">
          <label>Print Copies</label>
          <input
            type="number"
            value={settings.printer.printCopies}
            onChange={(e) => handleSettingChange('printer', 'printCopies', parseInt(e.target.value))}
            min="1"
            max="5"
          />
        </div>
        
        <div className="form-group">
          <label>Footer Text</label>
          <input
            type="text"
            value={settings.printer.footerText}
            onChange={(e) => handleSettingChange('printer', 'footerText', e.target.value)}
            placeholder="Thank you message"
          />
        </div>
      </div>
      
      <div className="checkbox-group">
        <label>
          <input
            type="checkbox"
            checked={settings.printer.autoDetectPrinters}
            onChange={(e) => handleSettingChange('printer', 'autoDetectPrinters', e.target.checked)}
          />
          Auto-detect printers
        </label>
        
        <label>
          <input
            type="checkbox"
            checked={settings.printer.printLogo}
            onChange={(e) => handleSettingChange('printer', 'printLogo', e.target.checked)}
          />
          Print company logo
        </label>
        
        <label>
          <input
            type="checkbox"
            checked={settings.printer.printFooter}
            onChange={(e) => handleSettingChange('printer', 'printFooter', e.target.checked)}
          />
          Print footer text
        </label>
      </div>
    </div>
  );

  const renderBackupSettings = () => (
    <div className="settings-section">
      <h3>Backup & Recovery</h3>
      
      <div className="form-grid">
        <div className="form-group">
          <label>Backup Frequency</label>
          <select
            value={settings.backup.backupFrequency}
            onChange={(e) => handleSettingChange('backup', 'backupFrequency', e.target.value)}
          >
            <option value="hourly">Hourly</option>
            <option value="daily">Daily</option>
            <option value="weekly">Weekly</option>
            <option value="monthly">Monthly</option>
          </select>
        </div>
        
        <div className="form-group">
          <label>Backup Time</label>
          <input
            type="time"
            value={settings.backup.backupTime}
            onChange={(e) => handleSettingChange('backup', 'backupTime', e.target.value)}
          />
        </div>
        
        <div className="form-group">
          <label>Backup Location</label>
          <input
            type="text"
            value={settings.backup.backupLocation}
            onChange={(e) => handleSettingChange('backup', 'backupLocation', e.target.value)}
            placeholder="./backups"
          />
        </div>
        
        <div className="form-group">
          <label>Keep Backups (Days)</label>
          <input
            type="number"
            value={settings.backup.keepBackupDays}
            onChange={(e) => handleSettingChange('backup', 'keepBackupDays', parseInt(e.target.value))}
            min="1"
            max="365"
          />
        </div>
      </div>
      
      <div className="checkbox-group">
        <label>
          <input
            type="checkbox"
            checked={settings.backup.autoBackup}
            onChange={(e) => handleSettingChange('backup', 'autoBackup', e.target.checked)}
          />
          Enable automatic backup
        </label>
        
        <label>
          <input
            type="checkbox"
            checked={settings.backup.cloudBackup}
            onChange={(e) => handleSettingChange('backup', 'cloudBackup', e.target.checked)}
          />
          Enable cloud backup
        </label>
      </div>
      
      <div className="backup-info">
        {settings.backup.lastBackup && (
          <p>Last backup: {new Date(settings.backup.lastBackup).toLocaleString()}</p>
        )}
      </div>
      
      <div className="backup-actions">
        <button className="btn-action" onClick={handleBackupNow}>
          Backup Now
        </button>
        <button className="btn-warning" onClick={handleRestoreBackup}>
          Restore from Backup
        </button>
      </div>
    </div>
  );

  const renderSecuritySettings = () => (
    <div className="settings-section">
      <h3>Security Settings</h3>
      
      <div className="form-grid">
        <div className="form-group">
          <label>Session Timeout (minutes)</label>
          <input
            type="number"
            value={settings.security.sessionTimeout}
            onChange={(e) => handleSettingChange('security', 'sessionTimeout', parseInt(e.target.value))}
            min="5"
            max="120"
          />
        </div>
        
        <div className="form-group">
          <label>Password Change Days</label>
          <input
            type="number"
            value={settings.security.passwordChangeDays}
            onChange={(e) => handleSettingChange('security', 'passwordChangeDays', parseInt(e.target.value))}
            min="30"
            max="365"
          />
        </div>
        
        <div className="form-group">
          <label>Minimum Password Length</label>
          <input
            type="number"
            value={settings.security.minPasswordLength}
            onChange={(e) => handleSettingChange('security', 'minPasswordLength', parseInt(e.target.value))}
            min="6"
            max="20"
          />
        </div>
        
        <div className="form-group">
          <label>Max Login Attempts</label>
          <input
            type="number"
            value={settings.security.maxLoginAttempts}
            onChange={(e) => handleSettingChange('security', 'maxLoginAttempts', parseInt(e.target.value))}
            min="3"
            max="10"
          />
        </div>
        
        <div className="form-group">
          <label>Lockout Duration (minutes)</label>
          <input
            type="number"
            value={settings.security.lockoutDuration}
            onChange={(e) => handleSettingChange('security', 'lockoutDuration', parseInt(e.target.value))}
            min="5"
            max="60"
          />
        </div>
      </div>
      
      <div className="checkbox-group">
        <label>
          <input
            type="checkbox"
            checked={settings.security.requirePasswordChange}
            onChange={(e) => handleSettingChange('security', 'requirePasswordChange', e.target.checked)}
          />
          Require periodic password change
        </label>
        
        <label>
          <input
            type="checkbox"
            checked={settings.security.requireStrongPassword}
            onChange={(e) => handleSettingChange('security', 'requireStrongPassword', e.target.checked)}
          />
          Require strong passwords
        </label>
        
        <label>
          <input
            type="checkbox"
            checked={settings.security.enableTwoFactor}
            onChange={(e) => handleSettingChange('security', 'enableTwoFactor', e.target.checked)}
          />
          Enable two-factor authentication
        </label>
        
        <label>
          <input
            type="checkbox"
            checked={settings.security.auditLog}
            onChange={(e) => handleSettingChange('security', 'auditLog', e.target.checked)}
          />
          Enable audit logging
        </label>
      </div>
    </div>
  );

  const renderNotificationSettings = () => (
    <div className="settings-section">
      <h3>Notification Settings</h3>
      
      {/* WhatsApp Settings */}
      <div className="notification-group">
        <h4>WhatsApp Settings</h4>
        <div className="form-grid">
          <div className="form-group">
            <label>API URL</label>
            <input
              type="text"
              value={settings.notifications.whatsappApiUrl}
              onChange={(e) => handleSettingChange('notifications', 'whatsappApiUrl', e.target.value)}
              placeholder="https://api.whatsapp.com/..."
            />
          </div>
          
          <div className="form-group">
            <label>API Token</label>
            <input
              type="password"
              value={settings.notifications.whatsappApiToken}
              onChange={(e) => handleSettingChange('notifications', 'whatsappApiToken', e.target.value)}
              placeholder="Your API token"
            />
          </div>
        </div>
        
        <button 
          className="btn-test" 
          onClick={() => handleTestConnection('whatsapp')}
        >
          Test WhatsApp Connection
        </button>
      </div>
      
      <div className="checkbox-group">
        <label>
          <input
            type="checkbox"
            checked={settings.notifications.lowStockAlert}
            onChange={(e) => handleSettingChange('notifications', 'lowStockAlert', e.target.checked)}
          />
          Send low stock alerts
        </label>
        
        <label>
          <input
            type="checkbox"
            checked={settings.notifications.birthdayReminder}
            onChange={(e) => handleSettingChange('notifications', 'birthdayReminder', e.target.checked)}
          />
          Send birthday reminders
        </label>
        
        <label>
          <input
            type="checkbox"
            checked={settings.notifications.dailySalesReport}
            onChange={(e) => handleSettingChange('notifications', 'dailySalesReport', e.target.checked)}
          />
          Send daily sales report
        </label>
      </div>
    </div>
  );

  const tabs = [
    { key: 'general', label: 'General', icon: '⚙️' },
    { key: 'pos', label: 'POS', icon: '🛒' },
    { key: 'printer', label: 'Printers', icon: '🖨️' },
    { key: 'backup', label: 'Backup', icon: '💾' },
    { key: 'security', label: 'Security', icon: '🔐' },
    { key: 'notifications', label: 'Notifications', icon: '🔔' }
  ];

  return (
    <div className="settings-container">
      {loading && <LoadingOverlay show={true} message="Loading settings..." />}
      
      <div className="settings-header">
        <h2>System Settings</h2>
        <button className="btn-primary" onClick={handleSaveSettings}>
          Save Settings
        </button>
      </div>
      
      <div className="settings-tabs">
        {tabs.map(tab => (
          <button
            key={tab.key}
            className={`settings-tab ${activeTab === tab.key ? 'active' : ''}`}
            onClick={() => setActiveTab(tab.key)}
          >
            <span className="tab-icon">{tab.icon}</span>
            <span className="tab-label">{tab.label}</span>
          </button>
        ))}
      </div>
      
      <div className="settings-content">
        {activeTab === 'general' && renderGeneralSettings()}
        {activeTab === 'pos' && renderPOSSettings()}
        {activeTab === 'printer' && renderPrinterSettings()}
        {activeTab === 'backup' && renderBackupSettings()}
        {activeTab === 'security' && renderSecuritySettings()}
        {activeTab === 'notifications' && renderNotificationSettings()}
      </div>
    </div>
  );
};

export default Settings;