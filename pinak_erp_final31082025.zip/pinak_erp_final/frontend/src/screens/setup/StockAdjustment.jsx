import React, { useState, useEffect } from 'react';
import { 
  FiSliders, FiPackage, FiAlertCircle, FiSearch,
  FiRefreshCw, FiTrendingUp, FiTrendingDown, FiDownload, FiX
} from 'react-icons/fi';
import toast from 'react-hot-toast';
import * as XLSX from 'xlsx';
import axios from 'axios';
import './SetupScreens.css';

const API_URL = 'http://localhost:8000/api/v1';

function StockAdjustment() {
  const [stocks, setStocks] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState('all'); // all, low, out, overstocked
  
  // Stats
  const [stats, setStats] = useState({
    totalItems: 0,
    totalStock: 0,
    lowStock: 0,
    outOfStock: 0,
    overstocked: 0,
    totalValue: 0
  });

  // Stock movements history
  const [movements, setMovements] = useState([]);
  const [showMovements, setShowMovements] = useState(false);
  const [selectedBarcode, setSelectedBarcode] = useState(null);

  // Fetch stock data
  const fetchStockData = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      
      if (!token) {
        toast.error('Please login to continue');
        setLoading(false);
        return;
      }

      const response = await axios.get(
        `${API_URL}/setup/stock-adjustment`,
        { 
          headers: { 
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          } 
        }
      );
      
      if (response.data && response.data.stocks) {
        const stockData = response.data.stocks;
        setStocks(stockData);
        
        // Calculate stats
        const calculatedStats = {
          totalItems: stockData.length,
          totalStock: stockData.reduce((sum, item) => sum + (item.qty || 0), 0),
          lowStock: stockData.filter(item => item.qty > 0 && item.qty <= 10).length,
          outOfStock: stockData.filter(item => item.qty === 0).length,
          overstocked: stockData.filter(item => item.qty > 100).length,
          totalValue: stockData.reduce((sum, item) => sum + ((item.qty || 0) * (item.mrp_incl || 0)), 0)
        };
        setStats(calculatedStats);
        
        toast.success('Stock data loaded successfully');
      } else {
        setStocks([]);
        toast.error('No stock data available');
      }
    } catch (error) {
      console.error('Error fetching stock data:', error);
      
      if (error.response) {
        if (error.response.status === 401) {
          toast.error('Session expired. Please login again');
        } else if (error.response.status === 404) {
          toast.error('Stock adjustment endpoint not found. Please contact support');
        } else {
          toast.error(error.response.data?.detail || 'Failed to fetch stock data');
        }
      } else if (error.request) {
        toast.error('Cannot connect to server. Please check if backend is running');
      } else {
        toast.error('Failed to fetch stock data');
      }
      
      setStocks([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStockData();
    // Auto-refresh every 30 seconds
    const interval = setInterval(fetchStockData, 30000);
    return () => clearInterval(interval);
  }, []);

  // View stock movements for a specific item
  const viewMovements = async (barcode) => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(
        `${API_URL}/setup/stock-movements/${barcode}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      if (response.data && response.data.movements) {
        setMovements(response.data.movements);
        setSelectedBarcode(barcode);
        setShowMovements(true);
      } else {
        toast.error('No movements found for this item');
      }
    } catch (error) {
      toast.error('Failed to fetch stock movements');
      console.error(error);
    }
  };

  // Export to Excel
  const handleExport = () => {
    if (stocks.length === 0) {
      toast.error('No data to export');
      return;
    }

    const exportData = stocks.map(item => ({
      Barcode: item.barcode,
      'Style Code': item.style_code,
      Color: item.color || '',
      Size: item.size || '',
      'Current Stock': item.qty || 0,
      MRP: item.mrp_incl || 0,
      'Stock Value': (item.qty || 0) * (item.mrp_incl || 0),
      'Stock Status': getStockStatus(item.qty || 0),
      'Last Updated': item.last_updated ? new Date(item.last_updated).toLocaleString() : 'N/A'
    }));

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Stock Adjustment');
    
    // Add column widths
    ws['!cols'] = [
      { width: 15 }, { width: 15 }, { width: 10 }, { width: 8 },
      { width: 12 }, { width: 10 }, { width: 12 }, { width: 12 }, { width: 20 }
    ];
    
    XLSX.writeFile(wb, `stock_adjustment_${new Date().toISOString().split('T')[0]}.xlsx`);
    toast.success('Stock report exported successfully');
  };

  // Get stock status
  const getStockStatus = (qty) => {
    if (qty === 0) return 'Out of Stock';
    if (qty <= 10) return 'Low Stock';
    if (qty > 100) return 'Overstocked';
    return 'Normal';
  };

  // Get status color
  const getStatusColor = (qty) => {
    if (qty === 0) return 'red';
    if (qty <= 10) return 'orange';
    if (qty > 100) return 'blue';
    return 'green';
  };

  // Filter stocks
  const filteredStocks = stocks.filter(item => {
    const matchesSearch = searchTerm === '' || 
      item.barcode?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.style_code?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.color?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.size?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesFilter = 
      filter === 'all' ||
      (filter === 'low' && item.qty > 0 && item.qty <= 10) ||
      (filter === 'out' && item.qty === 0) ||
      (filter === 'overstocked' && item.qty > 100);
    
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="setup-container">
      {/* Header */}
      <div className="setup-header">
        <div className="header-left">
          <h1 className="page-title">
            <FiSliders className="title-icon" />
            Stock Adjustment
          </h1>
          <p className="page-subtitle">View-only stock monitoring (Auto-updates from transactions)</p>
        </div>
        
        <div className="header-actions">
          <button 
            className="btn btn-secondary" 
            onClick={fetchStockData}
            disabled={loading}
          >
            <FiRefreshCw className={loading ? 'spinning' : ''} />
            Refresh
          </button>
          
          <button className="btn btn-secondary" onClick={handleExport}>
            <FiDownload />
            Export Report
          </button>
        </div>
      </div>

      {/* Info Alert */}
      <div className="alert-info">
        <FiAlertCircle />
        <div>
          <strong>Auto-Updated Stock Levels</strong>
          <p>Stock quantities automatically adjust when Sale, Sale Return, Purchase, or Purchase Return occur. This is a view-only screen for monitoring.</p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon">
            <FiPackage />
          </div>
          <div className="stat-content">
            <p className="stat-label">TOTAL ITEMS</p>
            <p className="stat-value">{stats.totalItems}</p>
          </div>
        </div>
        
        <div className="stat-card">
          <div className="stat-icon green">
            <FiTrendingUp />
          </div>
          <div className="stat-content">
            <p className="stat-label">TOTAL STOCK</p>
            <p className="stat-value">{stats.totalStock}</p>
          </div>
        </div>
        
        <div className="stat-card">
          <div className="stat-icon orange">
            <FiTrendingDown />
          </div>
          <div className="stat-content">
            <p className="stat-label">LOW STOCK</p>
            <p className="stat-value orange">{stats.lowStock}</p>
          </div>
        </div>
        
        <div className="stat-card">
          <div className="stat-icon red">
            <FiAlertCircle />
          </div>
          <div className="stat-content">
            <p className="stat-label">OUT OF STOCK</p>
            <p className="stat-value red">{stats.outOfStock}</p>
          </div>
        </div>
        
        <div className="stat-card">
          <div className="stat-icon blue">
            <FiPackage />
          </div>
          <div className="stat-content">
            <p className="stat-label">OVERSTOCKED</p>
            <p className="stat-value blue">{stats.overstocked}</p>
          </div>
        </div>
        
        <div className="stat-card">
          <div className="stat-icon">
            <span>₹</span>
          </div>
          <div className="stat-content">
            <p className="stat-label">TOTAL VALUE</p>
            <p className="stat-value">₹{stats.totalValue.toFixed(2)}</p>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="data-table-container">
        <div className="table-header">
          <div className="search-box">
            <FiSearch className="search-icon" />
            <input
              type="text"
              placeholder="Search by barcode, style code, color, size..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="search-input"
            />
          </div>
          
          <div className="filter-tabs">
            <button
              className={`filter-tab ${filter === 'all' ? 'active' : ''}`}
              onClick={() => setFilter('all')}
            >
              All Items ({stocks.length})
            </button>
            <button
              className={`filter-tab ${filter === 'low' ? 'active' : ''}`}
              onClick={() => setFilter('low')}
            >
              Low Stock ({stats.lowStock})
            </button>
            <button
              className={`filter-tab ${filter === 'out' ? 'active' : ''}`}
              onClick={() => setFilter('out')}
            >
              Out of Stock ({stats.outOfStock})
            </button>
            <button
              className={`filter-tab ${filter === 'overstocked' ? 'active' : ''}`}
              onClick={() => setFilter('overstocked')}
            >
              Overstocked ({stats.overstocked})
            </button>
          </div>
        </div>

        {/* Table */}
        <div className="table-wrapper">
          {loading ? (
            <div className="no-data">
              <div className="spinner"></div>
              <p>Loading stock data...</p>
            </div>
          ) : filteredStocks.length > 0 ? (
            <table className="data-table">
              <thead>
                <tr>
                  <th>Barcode</th>
                  <th>Style Code</th>
                  <th>Color</th>
                  <th>Size</th>
                  <th className="text-center">Current Stock</th>
                  <th className="text-right">MRP</th>
                  <th className="text-right">Stock Value</th>
                  <th className="text-center">Status</th>
                  <th className="text-center">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredStocks.map((item) => (
                  <tr key={item.barcode} className={item.qty === 0 ? 'out-of-stock' : ''}>
                    <td className="font-medium">{item.barcode}</td>
                    <td>{item.style_code}</td>
                    <td>{item.color || '-'}</td>
                    <td>{item.size || '-'}</td>
                    <td className="text-center">
                      <span className={`stock-badge ${getStatusColor(item.qty)}`}>
                        {item.qty || 0}
                      </span>
                    </td>
                    <td className="text-right">₹{(item.mrp_incl || 0).toFixed(2)}</td>
                    <td className="text-right font-medium">
                      ₹{((item.qty || 0) * (item.mrp_incl || 0)).toFixed(2)}
                    </td>
                    <td className="text-center">
                      <span className={`status-label ${getStatusColor(item.qty)}`}>
                        {getStockStatus(item.qty || 0)}
                      </span>
                    </td>
                    <td className="text-center">
                      <button
                        onClick={() => viewMovements(item.barcode)}
                        className="link-btn"
                      >
                        View History
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <div className="no-data">
              <FiPackage />
              <h3>No items found</h3>
              {searchTerm && (
                <p>Try adjusting your search or filter criteria</p>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Stock Movements Modal */}
      {showMovements && (
        <div className="modal-overlay">
          <div className="modal-content large">
            <div className="modal-header">
              <h3>Stock Movement History - {selectedBarcode}</h3>
              <button
                onClick={() => {
                  setShowMovements(false);
                  setMovements([]);
                  setSelectedBarcode(null);
                }}
                className="close-btn"
              >
                <FiX />
              </button>
            </div>
            
            <div className="movements-list">
              {movements.length > 0 ? (
                <table className="movements-table">
                  <thead>
                    <tr>
                      <th>Date</th>
                      <th>Type</th>
                      <th>Reference</th>
                      <th className="text-center">Qty Change</th>
                      <th>Description</th>
                    </tr>
                  </thead>
                  <tbody>
                    {movements.map((movement, index) => (
                      <tr key={index}>
                        <td>{movement.date ? new Date(movement.date).toLocaleString() : 'N/A'}</td>
                        <td>
                          <span className={`movement-type ${movement.type}`}>
                            {movement.type}
                          </span>
                        </td>
                        <td>{movement.reference}</td>
                        <td className={`text-center ${movement.qty_change > 0 ? 'positive' : 'negative'}`}>
                          {movement.qty_change > 0 ? '+' : ''}{movement.qty_change}
                        </td>
                        <td>{movement.description}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              ) : (
                <div className="no-movements">
                  <p>No movement history available for this item</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Add CSS for spinner animation */}
      <style jsx>{`
        .spinning {
          animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        
        .spinner {
          width: 40px;
          height: 40px;
          border: 4px solid #f3f4f6;
          border-top: 4px solid #9333ea;
          border-radius: 50%;
          animation: spin 1s linear infinite;
          margin: 0 auto 1rem;
        }
        
        .modal-overlay {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0, 0, 0, 0.5);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 1000;
        }
        
        .modal-content.large {
          width: 90%;
          max-width: 1000px;
          max-height: 80vh;
          overflow: hidden;
          background: white;
          border-radius: 8px;
          display: flex;
          flex-direction: column;
        }
        
        .modal-header {
          padding: 1.5rem;
          border-bottom: 1px solid #e5e7eb;
          display: flex;
          justify-content: space-between;
          align-items: center;
        }
        
        .modal-header h3 {
          font-size: 1.25rem;
          font-weight: 600;
          color: #1f2937;
        }
        
        .close-btn {
          background: transparent;
          border: none;
          color: #6b7280;
          cursor: pointer;
          padding: 0.5rem;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: color 0.3s ease;
        }
        
        .close-btn:hover {
          color: #1f2937;
        }
        
        .filter-tabs {
          display: flex;
          gap: 0.5rem;
        }
        
        .filter-tab {
          padding: 0.5rem 1rem;
          border: 1px solid #e5e7eb;
          background: white;
          border-radius: 6px;
          cursor: pointer;
          transition: all 0.3s ease;
          font-size: 0.875rem;
          color: #4b5563;
        }
        
        .filter-tab:hover {
          background: #f3f4f6;
        }
        
        .filter-tab.active {
          background: linear-gradient(135deg, #9333ea 0%, #4f46e5 100%);
          color: white;
          border-color: transparent;
        }
        
        .stock-badge {
          display: inline-block;
          padding: 0.375rem 0.75rem;
          border-radius: 20px;
          font-weight: 700;
          font-size: 0.9rem;
        }
        
        .stock-badge.green {
          background: #d1fae5;
          color: #065f46;
        }
        
        .stock-badge.orange {
          background: #fed7aa;
          color: #92400e;
        }
        
        .stock-badge.red {
          background: #fee2e2;
          color: #991b1b;
        }
        
        .stock-badge.blue {
          background: #dbeafe;
          color: #1e40af;
        }
        
        .status-label {
          padding: 0.375rem 0.75rem;
          border-radius: 6px;
          font-size: 0.8rem;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }
        
        .status-label.green {
          background: #10b981;
          color: white;
        }
        
        .status-label.orange {
          background: #f59e0b;
          color: white;
        }
        
        .status-label.red {
          background: #ef4444;
          color: white;
        }
        
        .status-label.blue {
          background: #3b82f6;
          color: white;
        }
        
        .link-btn {
          background: transparent;
          border: none;
          color: #9333ea;
          text-decoration: underline;
          cursor: pointer;
          font-weight: 600;
          transition: all 0.3s ease;
        }
        
        .link-btn:hover {
          color: #4f46e5;
        }
        
        .movements-list {
          padding: 1.5rem;
          overflow-y: auto;
          max-height: calc(80vh - 100px);
        }
        
        .movements-table {
          width: 100%;
          border-collapse: collapse;
        }
        
        .movements-table th {
          padding: 0.75rem;
          background: #f3f4f6;
          text-align: left;
          font-weight: 600;
          color: #4b5563;
          font-size: 0.875rem;
        }
        
        .movements-table td {
          padding: 0.75rem;
          border-bottom: 1px solid #e5e7eb;
        }
        
        .movement-type {
          padding: 0.25rem 0.5rem;
          border-radius: 4px;
          font-size: 0.75rem;
          font-weight: 600;
        }
        
        .movement-type.sale {
          background: #fee2e2;
          color: #991b1b;
        }
        
        .movement-type.purchase {
          background: #d1fae5;
          color: #065f46;
        }
        
        .movement-type.return {
          background: #fef3c7;
          color: #92400e;
        }
        
        .positive {
          color: #059669;
          font-weight: 600;
        }
        
        .negative {
          color: #dc2626;
          font-weight: 600;
        }
        
        .no-movements {
          text-align: center;
          color: #9ca3af;
          padding: 2rem;
        }
        
        tr.out-of-stock {
          background: #fef2f2;
        }
      `}</style>
    </div>
  );
}

export default StockAdjustment;