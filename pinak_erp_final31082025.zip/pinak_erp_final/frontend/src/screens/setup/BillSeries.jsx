import React, { useState, useEffect } from 'react';
import { 
  FiFileText, FiPlus, FiSave, FiEdit2, FiTrash2,
  FiCalendar, FiHash, FiSettings, FiRefreshCw,
  FiLayers, FiCheckCircle, FiAlertCircle
} from 'react-icons/fi';
import toast from 'react-hot-toast';
import axios from 'axios';
import './SetupScreens.css';

const API_URL = 'http://localhost:8000/api/v1';

function BillSeries() {
  const [billSeries, setBillSeries] = useState([]);
  const [loading, setLoading] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [editingSeries, setEditingSeries] = useState(null);
  
  // Form state
  const [formData, setFormData] = useState({
    type: 'SALE',
    prefix: 'SALE/',
    starting_number: 1,
    width: 6,
    financial_year: '2024-25',
    tax_region: 'LOCAL',
    active: true,
    description: ''
  });

  // Validation errors
  const [errors, setErrors] = useState({});

  // Bill types
  const billTypes = [
    { value: 'SALE', label: 'Sales Invoice', icon: '🛍️' },
    { value: 'PURCHASE', label: 'Purchase Bill', icon: '📦' },
    { value: 'SALE_RETURN', label: 'Sales Return', icon: '↩️' },
    { value: 'PURCHASE_RETURN', label: 'Purchase Return', icon: '↪️' },
    { value: 'EXPENSE', label: 'Expense Voucher', icon: '💰' },
    { value: 'PAYMENT', label: 'Payment Receipt', icon: '💳' },
    { value: 'QUOTATION', label: 'Quotation', icon: '📝' },
    { value: 'DELIVERY', label: 'Delivery Challan', icon: '🚚' }
  ];

  // Tax regions
  const taxRegions = [
    { value: 'LOCAL', label: 'Local (CGST + SGST)' },
    { value: 'INTERSTATE', label: 'Inter-State (IGST)' },
    { value: 'EXPORT', label: 'Export (Zero Rated)' },
    { value: 'SEZ', label: 'SEZ Supply' }
  ];

  // Stats
  const [stats, setStats] = useState({
    totalSeries: 0,
    activeSeries: 0,
    currentNumbers: {},
    lastUpdated: null
  });

  // Fetch bill series
  const fetchBillSeries = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(
        `${API_URL}/setup/bill-series`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      const seriesData = response.data || [];
      setBillSeries(seriesData);
      
      // Calculate stats
      const currentNumbers = {};
      seriesData.forEach(series => {
        currentNumbers[series.type] = series.current_number || series.starting_number;
      });
      
      setStats({
        totalSeries: seriesData.length,
        activeSeries: seriesData.filter(s => s.active).length,
        currentNumbers,
        lastUpdated: new Date().toISOString()
      });
    } catch (error) {
      toast.error('Failed to fetch bill series');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBillSeries();
  }, []);

  // Validate form
  const validateForm = () => {
    const newErrors = {};

    if (!formData.prefix.trim()) {
      newErrors.prefix = 'Prefix is required';
    } else if (formData.prefix.length > 20) {
      newErrors.prefix = 'Prefix too long (max 20 characters)';
    }

    if (formData.starting_number < 1) {
      newErrors.starting_number = 'Starting number must be at least 1';
    }

    if (formData.width < 1 || formData.width > 10) {
      newErrors.width = 'Width must be between 1 and 10';
    }

    if (!formData.financial_year.trim()) {
      newErrors.financial_year = 'Financial year is required';
    }

    // Check for duplicate type if creating new
    if (!editingSeries) {
      const exists = billSeries.some(s => s.type === formData.type);
      if (exists) {
        newErrors.type = 'Series for this document type already exists';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      toast.error('Please fix the errors in the form');
      return;
    }

    const confirmMsg = editingSeries 
      ? 'Update bill series configuration?' 
      : 'Create new bill series?';
      
    if (!window.confirm(confirmMsg)) return;

    try {
      const token = localStorage.getItem('token');
      const endpoint = editingSeries 
        ? `${API_URL}/setup/bill-series/${editingSeries.id}`
        : `${API_URL}/setup/bill-series`;
      
      const method = editingSeries ? 'put' : 'post';
      
      await axios[method](endpoint, formData, {
        headers: { Authorization: `Bearer ${token}` }
      });

      toast.success(`Bill series ${editingSeries ? 'updated' : 'created'} successfully`);
      setShowModal(false);
      resetForm();
      fetchBillSeries();
    } catch (error) {
      if (error.response?.data?.detail) {
        toast.error(error.response.data.detail);
      } else {
        toast.error('Failed to save bill series');
      }
    }
  };

  // Reset form
  const resetForm = () => {
    setFormData({
      type: 'SALE',
      prefix: 'SALE/',
      starting_number: 1,
      width: 6,
      financial_year: '2024-25',
      tax_region: 'LOCAL',
      active: true,
      description: ''
    });
    setEditingSeries(null);
    setErrors({});
  };

  // Edit series
  const handleEdit = (series) => {
    setFormData(series);
    setEditingSeries(series);
    setShowModal(true);
  };

  // Delete series
  const handleDelete = async (series) => {
    if (!window.confirm(`Delete bill series for "${series.type}"? This cannot be undone.`)) {
      return;
    }

    try {
      const token = localStorage.getItem('token');
      await axios.delete(
        `${API_URL}/setup/bill-series/${series.id}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      toast.success('Bill series deleted successfully');
      fetchBillSeries();
    } catch (error) {
      if (error.response?.data?.detail) {
        toast.error(error.response.data.detail);
      } else {
        toast.error('Failed to delete bill series');
      }
    }
  };

  // Reset counter
  const resetCounter = async (series) => {
    if (!window.confirm(`Reset counter for "${series.type}" to starting number ${series.starting_number}?`)) {
      return;
    }

    try {
      const token = localStorage.getItem('token');
      await axios.post(
        `${API_URL}/setup/bill-series/${series.id}/reset-counter`,
        {},
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      toast.success('Counter reset successfully');
      fetchBillSeries();
    } catch (error) {
      toast.error('Failed to reset counter');
    }
  };

  // Generate preview
  const generatePreview = (series) => {
    const paddedNumber = series.current_number.toString().padStart(series.width, '0');
    return `${series.prefix}${paddedNumber}`;
  };

  return (
    <div className="setup-container">
      {/* Header */}
      <div className="setup-header">
        <div className="header-left">
          <h1 className="page-title">
            <FiFileText className="title-icon" />
            Bill Series Configuration
          </h1>
          <p className="page-subtitle">Configure document numbering series and formats</p>
        </div>
        <div className="header-actions">
          <button className="btn-refresh" onClick={fetchBillSeries}>
            <FiRefreshCw /> Refresh
          </button>
          <button className="btn-primary" onClick={() => setShowModal(true)}>
            <FiPlus /> Add Bill Series
          </button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon-wrapper purple">
            <FiLayers />
          </div>
          <div className="stat-content">
            <p className="stat-label">Total Series</p>
            <p className="stat-value">{stats.totalSeries}</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon-wrapper green">
            <FiCheckCircle />
          </div>
          <div className="stat-content">
            <p className="stat-label">Active Series</p>
            <p className="stat-value">{stats.activeSeries}</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon-wrapper blue">
            <FiHash />
          </div>
          <div className="stat-content">
            <p className="stat-label">Sales Counter</p>
            <p className="stat-value">{stats.currentNumbers.SALE || 1}</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon-wrapper orange">
            <FiCalendar />
          </div>
          <div className="stat-content">
            <p className="stat-label">Financial Year</p>
            <p className="stat-value">2024-25</p>
          </div>
        </div>
      </div>

      {/* Bill Series List */}
      <div className="table-container">
        <table className="data-table">
          <thead>
            <tr>
              <th>Document Type</th>
              <th>Prefix</th>
              <th>Current Number</th>
              <th>Sample Format</th>
              <th>Tax Region</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan="7" className="text-center">
                  <div className="loading-spinner">Loading...</div>
                </td>
              </tr>
            ) : billSeries.length === 0 ? (
              <tr>
                <td colSpan="7" className="text-center empty-state">
                  <FiFileText size={48} />
                  <p>No bill series configured</p>
                  <button className="btn-primary btn-sm" onClick={() => setShowModal(true)}>
                    Add First Series
                  </button>
                </td>
              </tr>
            ) : (
              billSeries.map((series) => {
                const billType = billTypes.find(t => t.value === series.type);
                return (
                  <tr key={series.id}>
                    <td>
                      <div className="bill-type-cell">
                        <span className="bill-type-icon">{billType?.icon}</span>
                        <div>
                          <div className="bill-type-name">{billType?.label}</div>
                          <div className="bill-type-code">{series.type}</div>
                        </div>
                      </div>
                    </td>
                    <td className="prefix-cell">{series.prefix}</td>
                    <td className="number-cell">
                      <div className="current-number">
                        {series.current_number || series.starting_number}
                      </div>
                      <div className="number-range">
                        Starting: {series.starting_number}
                      </div>
                    </td>
                    <td className="preview-cell">
                      <code>{generatePreview(series)}</code>
                    </td>
                    <td>
                      <span className={`badge badge-${series.tax_region.toLowerCase()}`}>
                        {taxRegions.find(r => r.value === series.tax_region)?.label}
                      </span>
                    </td>
                    <td>
                      <span className={`status-badge ${series.active ? 'active' : 'inactive'}`}>
                        {series.active ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                    <td>
                      <div className="action-buttons">
                        <button 
                          className="btn-icon"
                          onClick={() => handleEdit(series)}
                          title="Edit"
                        >
                          <FiEdit2 />
                        </button>
                        <button 
                          className="btn-icon"
                          onClick={() => resetCounter(series)}
                          title="Reset Counter"
                        >
                          <FiRefreshCw />
                        </button>
                        <button 
                          className="btn-icon btn-danger"
                          onClick={() => handleDelete(series)}
                          title="Delete"
                        >
                          <FiTrash2 />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Add/Edit Modal */}
      {showModal && (
        <div className="modal-overlay">
          <div className="modal-content">
            <div className="modal-header">
              <h2>{editingSeries ? 'Edit Bill Series' : 'Add Bill Series'}</h2>
              <button className="btn-close" onClick={() => {
                setShowModal(false);
                resetForm();
              }}>×</button>
            </div>

            <form onSubmit={handleSubmit} className="modal-form">
              <div className="form-row">
                <div className="form-group">
                  <label>Document Type *</label>
                  <select
                    value={formData.type}
                    onChange={(e) => setFormData({...formData, type: e.target.value})}
                    disabled={editingSeries}
                    className={errors.type ? 'error' : ''}
                  >
                    {billTypes.map(type => (
                      <option key={type.value} value={type.value}>
                        {type.label}
                      </option>
                    ))}
                  </select>
                  {errors.type && <span className="error-message">{errors.type}</span>}
                </div>

                <div className="form-group">
                  <label>Prefix *</label>
                  <input
                    type="text"
                    value={formData.prefix}
                    onChange={(e) => setFormData({...formData, prefix: e.target.value})}
                    placeholder="e.g., SALE/, INV-"
                    className={errors.prefix ? 'error' : ''}
                  />
                  {errors.prefix && <span className="error-message">{errors.prefix}</span>}
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Starting Number *</label>
                  <input
                    type="number"
                    value={formData.starting_number}
                    onChange={(e) => setFormData({...formData, starting_number: parseInt(e.target.value) || 1})}
                    min="1"
                    className={errors.starting_number ? 'error' : ''}
                  />
                  {errors.starting_number && <span className="error-message">{errors.starting_number}</span>}
                </div>

                <div className="form-group">
                  <label>Number Width *</label>
                  <input
                    type="number"
                    value={formData.width}
                    onChange={(e) => setFormData({...formData, width: parseInt(e.target.value) || 6})}
                    min="1"
                    max="10"
                    className={errors.width ? 'error' : ''}
                  />
                  {errors.width && <span className="error-message">{errors.width}</span>}
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Financial Year *</label>
                  <input
                    type="text"
                    value={formData.financial_year}
                    onChange={(e) => setFormData({...formData, financial_year: e.target.value})}
                    placeholder="2024-25"
                    className={errors.financial_year ? 'error' : ''}
                  />
                  {errors.financial_year && <span className="error-message">{errors.financial_year}</span>}
                </div>

                <div className="form-group">
                  <label>Tax Region *</label>
                  <select
                    value={formData.tax_region}
                    onChange={(e) => setFormData({...formData, tax_region: e.target.value})}
                  >
                    {taxRegions.map(region => (
                      <option key={region.value} value={region.value}>
                        {region.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="form-group">
                <label>Description</label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  rows="3"
                  placeholder="Additional notes about this bill series..."
                />
              </div>

              <div className="form-group">
                <label className="checkbox-label">
                  <input
                    type="checkbox"
                    checked={formData.active}
                    onChange={(e) => setFormData({...formData, active: e.target.checked})}
                  />
                  Active
                </label>
              </div>

              <div className="preview-section">
                <h4>Preview</h4>
                <div className="preview-box">
                  <code>
                    {formData.prefix}
                    {(formData.starting_number || 1).toString().padStart(formData.width || 6, '0')}
                  </code>
                </div>
              </div>

              <div className="modal-footer">
                <button 
                  type="button" 
                  className="btn-secondary"
                  onClick={() => {
                    setShowModal(false);
                    resetForm();
                  }}
                >
                  Cancel
                </button>
                <button type="submit" className="btn-primary">
                  <FiSave /> {editingSeries ? 'Update' : 'Save'} Series
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default BillSeries;