import React, { useState, useEffect, useRef } from 'react';
import { 
  FiPackage, FiPlus, FiEdit2, FiTrash2, FiSearch, 
  FiFilter, FiDownload, FiUpload, FiDollarSign,
  FiTag, FiBox, FiGrid, FiList, FiCheckCircle,
  FiAlertCircle, FiX, FiSave, FiRefreshCw
} from 'react-icons/fi';
import toast from 'react-hot-toast';
import { itemsAPI } from '../../services/api';
import ExcelImporter from '../../components/ExcelImporter';
import './Items.css';

function Items() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [showImportModal, setShowImportModal] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [viewMode, setViewMode] = useState('list'); // Default to list view
  
  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalItems, setTotalItems] = useState(0);
  const itemsPerPage = 20;
  
  // Form state
  const [formData, setFormData] = useState({
    barcode: '',
    style_code: '',
    color: '',
    size: '',
    hsn: '',
    mrp_incl: '',
    purchase_rate_basic: '',
    brand: '',
    gender: '',
    category: '',
    sub_category: '',
    active: true
  });

  // Filters
  const [filters, setFilters] = useState({
    brand: '',
    category: '',
    size: '',
    color: '',
    active_only: false
  });

  // Stats
  const [stats, setStats] = useState({
    total: 0,
    active: 0,
    low_stock: 0,
    total_value: 0
  });

  // Dropdown options
  const [brands, setBrands] = useState([]);
  const [categories, setCategories] = useState([]);
  const [sizes, setSizes] = useState([]);
  const [colors, setColors] = useState([]);

  // Fetch items
  const fetchItems = async (page = 1) => {
    setLoading(true);
    try {
      const response = await itemsAPI.getItems({
        skip: (page - 1) * itemsPerPage,
        limit: itemsPerPage,
        ...filters,
        search: searchTerm || undefined
      });

      // Handle different response formats
      let itemsData = [];
      let total = 0;
      
      if (Array.isArray(response.data)) {
        itemsData = response.data;
        total = itemsData.length;
      } else if (response.data && typeof response.data === 'object') {
        itemsData = response.data.items || response.data.data || [];
        total = response.data.total || response.data.count || itemsData.length;
      }

      setItems(itemsData);
      setTotalItems(total);
      setTotalPages(Math.ceil(total / itemsPerPage));
      setCurrentPage(page);

      // Extract unique values for filter dropdowns
      const uniqueBrands = [...new Set(itemsData.map(item => item.brand).filter(Boolean))];
      const uniqueCategories = [...new Set(itemsData.map(item => item.category).filter(Boolean))];
      const uniqueSizes = [...new Set(itemsData.map(item => item.size).filter(Boolean))];
      const uniqueColors = [...new Set(itemsData.map(item => item.color).filter(Boolean))];
      
      // Set these for dropdown options
      setBrands(uniqueBrands);
      setCategories(uniqueCategories);
      setSizes(uniqueSizes);
      setColors(uniqueColors);

      // Update stats
      const activeCount = itemsData.filter(item => item.status === 'active').length;
      const totalValue = itemsData.reduce((sum, item) => 
        sum + (parseFloat(item.mrp_incl) || 0) * (item.stock?.qty_on_hand || 0), 0
      );
      
      setStats({
        total: total,
        active: activeCount,
        low_stock: itemsData.filter(item => (item.stock?.qty_on_hand || 0) < 10).length,
        total_value: totalValue
      });
    } catch (error) {
      console.error('Error fetching items:', error);
      toast.error('Failed to fetch items');
      setItems([]);
    } finally {
      setLoading(false);
    }
  };

  // Initial load
  useEffect(() => {
    fetchItems(1);
  }, []);

  // Load when filters change
  useEffect(() => {
    fetchItems(1);
  }, [filters]);

  // Search with debounce
  useEffect(() => {
    const timer = setTimeout(() => {
      if (searchTerm !== undefined) {
        fetchItems(1);
      }
    }, 500);
    return () => clearTimeout(timer);
  }, [searchTerm]);

  // Reset form
  const resetForm = () => {
    setFormData({
      barcode: '',
      style_code: '',
      color: '',
      size: '',
      hsn: '',
      mrp_incl: '',
      purchase_rate_basic: '',
      brand: '',
      gender: '',
      category: '',
      sub_category: '',
      active: true
    });
    setEditingItem(null);
  };

  // Handle input change
  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  // Handle form submit
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validation
    if (!formData.barcode || !formData.style_code || !formData.mrp_incl) {
      toast.error('Please fill in all required fields');
      return;
    }

    try {
      // Prepare data for submission - send only changed fields for update
      const submitData = {
        style_code: formData.style_code,
        color: formData.color || '',
        size: formData.size || '',
        hsn: formData.hsn || '',
        mrp_incl: parseFloat(formData.mrp_incl) || 0,
        purchase_rate_basic: parseFloat(formData.purchase_rate_basic) || 0,
        brand: formData.brand || '',
        gender: formData.gender || '',
        category: formData.category || '',
        sub_category: formData.sub_category || '',
        status: formData.active ? 'active' : 'inactive'
      };

      if (editingItem) {
        // For update, don't send barcode as it's in URL
        await itemsAPI.updateItem(editingItem.barcode, submitData);
        toast.success('Item updated successfully');
      } else {
        // For create, include barcode
        submitData.barcode = formData.barcode;
        await itemsAPI.createItem(submitData);
        toast.success('Item created successfully');
      }
      
      setShowModal(false);
      resetForm();
      
      // Force refresh to get updated data from backend
      setTimeout(() => {
        fetchItems(1); // Fetch from first page to ensure we see the updated item
      }, 100);
      
    } catch (error) {
      console.error('Error saving item:', error);
      if (error.response?.data?.detail) {
        toast.error(error.response.data.detail);
      } else {
        toast.error('Failed to save item');
      }
    }
  };

  // Handle edit
  const handleEdit = (item) => {
    setEditingItem(item);
    setFormData({
      barcode: item.barcode || '',
      style_code: item.style_code || '',
      color: item.color || '',
      size: item.size || '',
      hsn: item.hsn || '',
      mrp_incl: item.mrp_incl || '',
      purchase_rate_basic: item.purchase_rate_basic || '',
      brand: item.brand || '',
      gender: item.gender || '',
      category: item.category || '',
      sub_category: item.sub_category || '',
      active: item.status === 'active'  // Check the status field
    });
    setShowModal(true);
  };

  // Handle delete
  const handleDelete = async (item) => {
    if (!window.confirm(`Delete item ${item.style_code}? This action cannot be undone.`)) {
      return;
    }

    try {
      await itemsAPI.deleteItem(item.barcode);
      toast.success('Item deleted successfully');
      fetchItems(currentPage);
    } catch (error) {
      console.error('Error deleting item:', error);
      toast.error('Failed to delete item');
    }
  };

  // Handle import success
  const handleImportSuccess = (result) => {
    setShowImportModal(false);
    // Force refresh with a small delay
    setTimeout(() => {
      fetchItems(1);
      setFilters({
        brand: '',
        category: '',
        size: '',
        color: '',
        active_only: false
      });
      setSearchTerm('');
    }, 500);
    
    const created = result.created || 0;
    const updated = result.updated || 0;
    const total = created + updated;
    
    if (total > 0) {
      toast.success(`Successfully imported ${created} new items${updated > 0 ? ` and updated ${updated} items` : ''}`);
    }
  };

  // Handle Excel export
  const handleExport = async () => {
    try {
      const response = await itemsAPI.exportItems(filters);
      
      // Create download link
      const blob = new Blob([response.data], { 
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' 
      });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `items_export_${new Date().toISOString().split('T')[0]}.xlsx`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      
      toast.success('Items exported successfully');
    } catch (error) {
      console.error('Error exporting items:', error);
      toast.error('Failed to export items');
    }
  };

  // Filter items locally
  const displayItems = items.length > 0 ? items : [];
  
  const filteredItems = displayItems.filter(item => {
    if (!item) return false;
    
    const searchLower = (searchTerm || '').toLowerCase();
    const matchesSearch = !searchTerm || (
      (item.barcode || '').toLowerCase().includes(searchLower) ||
      (item.style_code || '').toLowerCase().includes(searchLower) ||
      (item.brand || '').toLowerCase().includes(searchLower) ||
      (item.color || '').toLowerCase().includes(searchLower) ||
      (item.size || '').toLowerCase().includes(searchLower)
    );

    const matchesFilters = (
      (!filters.brand || item.brand === filters.brand) &&
      (!filters.category || item.category === filters.category) &&
      (!filters.size || item.size === filters.size) &&
      (!filters.color || item.color === filters.color) &&
      (!filters.active_only || item.active !== false)
    );

    return matchesSearch && matchesFilters;
  });

  // Calculate GST rate based on MRP
  const getGSTRate = (mrp) => {
    const price = parseFloat(mrp);
    return price >= 1000 ? 12 : 5;
  };

  return (
    <div className="setup-container">
      {/* Header */}
      <div className="setup-header">
        <div className="header-left">
          <h1 className="page-title">
            <FiPackage className="title-icon" />
            Item Master
          </h1>
          <p className="page-subtitle">Manage your product inventory</p>
        </div>
        
        <div className="header-actions">
          <button 
            className="btn btn-secondary"
            onClick={() => fetchItems(1)}
            title="Refresh"
          >
            <FiRefreshCw />
            Refresh
          </button>
          
          <button 
            className="btn btn-secondary"
            onClick={() => setShowImportModal(true)}
            title="Import from Excel"
          >
            <FiUpload />
            Import Excel
          </button>
          
          <button 
            className="btn btn-secondary"
            onClick={handleExport}
            title="Export to Excel"
          >
            <FiDownload />
            Export
          </button>
          
          <button 
            className="btn btn-primary"
            onClick={() => {
              resetForm();
              setShowModal(true);
            }}
          >
            <FiPlus />
            Add Item
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon blue">
            <FiPackage />
          </div>
          <div className="stat-content">
            <p className="stat-label">Total Items</p>
            <p className="stat-value">{stats.total}</p>
          </div>
        </div>
        
        <div className="stat-card">
          <div className="stat-icon green">
            <FiCheckCircle />
          </div>
          <div className="stat-content">
            <p className="stat-label">Active</p>
            <p className="stat-value">{stats.active}</p>
          </div>
        </div>
        
        <div className="stat-card">
          <div className="stat-icon orange">
            <FiAlertCircle />
          </div>
          <div className="stat-content">
            <p className="stat-label">Low Stock</p>
            <p className="stat-value">{stats.low_stock}</p>
          </div>
        </div>
        
        <div className="stat-card">
          <div className="stat-icon purple">
            <FiDollarSign />
          </div>
          <div className="stat-content">
            <p className="stat-label">Total Value</p>
            <p className="stat-value">₹{stats.total_value.toLocaleString()}</p>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="controls-section">
        <div className="search-bar">
          <FiSearch className="search-icon" />
          <input
            type="text"
            placeholder="Search by barcode, style code, brand, color, or size..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="search-input"
          />
        </div>
        
        <div className="filter-controls" style={{ display: 'flex', gap: '10px', alignItems: 'center', flexWrap: 'wrap' }}>
          <select 
            className="filter-select"
            value={filters.brand}
            onChange={(e) => setFilters({...filters, brand: e.target.value})}
            style={{ minWidth: '150px' }}
          >
            <option value="">All Brands</option>
            {brands.map(brand => (
              <option key={brand} value={brand}>{brand}</option>
            ))}
          </select>
          
          <select 
            className="filter-select"
            value={filters.category}
            onChange={(e) => setFilters({...filters, category: e.target.value})}
            style={{ minWidth: '150px' }}
          >
            <option value="">All Categories</option>
            {categories.map(category => (
              <option key={category} value={category}>{category}</option>
            ))}
          </select>
          
          <select 
            className="filter-select"
            value={filters.size}
            onChange={(e) => setFilters({...filters, size: e.target.value})}
            style={{ minWidth: '150px' }}
          >
            <option value="">All Sizes</option>
            {sizes.map(size => (
              <option key={size} value={size}>{size}</option>
            ))}
          </select>
          
          <select 
            className="filter-select"
            value={filters.color}
            onChange={(e) => setFilters({...filters, color: e.target.value})}
            style={{ minWidth: '150px' }}
          >
            <option value="">All Colors</option>
            {colors.map(color => (
              <option key={color} value={color}>{color}</option>
            ))}
          </select>
          
          <label className="checkbox-label" style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
            <input
              type="checkbox"
              checked={filters.active_only}
              onChange={(e) => setFilters({...filters, active_only: e.target.checked})}
            />
            Active Only
          </label>
          
          <div className="view-toggle" style={{ marginLeft: 'auto' }}>
            <button
              className={`view-btn ${viewMode === 'grid' ? 'active' : ''}`}
              onClick={() => setViewMode('grid')}
              title="Grid View"
            >
              <FiGrid />
            </button>
            <button
              className={`view-btn ${viewMode === 'list' ? 'active' : ''}`}
              onClick={() => setViewMode('list')}
              title="List View"
            >
              <FiList />
            </button>
          </div>
        </div>
      </div>

      {/* Items Display */}
      {loading ? (
        <div className="loading-state">
          <div className="loading-spinner"></div>
          <p>Loading items...</p>
        </div>
      ) : filteredItems.length === 0 ? (
        <div className="empty-state">
          <FiPackage size={48} />
          <h3>No items found</h3>
          <p>Start by adding your first item or adjusting filters</p>
          <button 
            className="btn btn-primary"
            onClick={() => {
              resetForm();
              setShowModal(true);
            }}
          >
            <FiPlus /> Add First Item
          </button>
        </div>
      ) : viewMode === 'grid' ? (
        <div className="items-grid">
          {filteredItems.map((item) => (
            <div key={item.barcode} className="item-card">
              <div className="item-card-header">
                <span className={`item-status ${item.status === 'active' ? 'active' : 'inactive'}`}>
                  {item.status === 'active' ? 'Active' : 'Inactive'}
                </span>
                <div className="item-actions">
                  <button 
                    className="btn-icon"
                    onClick={() => handleEdit(item)}
                    title="Edit"
                  >
                    <FiEdit2 />
                  </button>
                  <button 
                    className="btn-icon delete"
                    onClick={() => handleDelete(item)}
                    title="Delete"
                  >
                    <FiTrash2 />
                  </button>
                </div>
              </div>
              
              <div className="item-card-body">
                <h3 className="item-style">{item.style_code}</h3>
                <p className="item-barcode">
                  <FiTag /> {item.barcode}
                </p>
                
                <div className="item-details">
                  {item.brand && <span className="item-tag">{item.brand}</span>}
                  {item.color && <span className="item-tag">{item.color}</span>}
                  {item.size && <span className="item-tag">{item.size}</span>}
                </div>
                
                <div className="item-pricing">
                  <div className="price-item">
                    <span className="price-label">MRP</span>
                    <span className="price-value">₹{item.mrp_incl}</span>
                  </div>
                  <div className="price-item">
                    <span className="price-label">Cost</span>
                    <span className="price-value">₹{item.purchase_rate_basic || 0}</span>
                  </div>
                </div>
                
                {item.stock && (
                  <div className="item-stock">
                    <span className="stock-label">Stock:</span>
                    <span className={`stock-value ${item.stock.qty_on_hand < 10 ? 'low' : ''}`}>
                      {item.stock.qty_on_hand || 0}
                    </span>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="items-table">
          <table>
            <thead>
              <tr>
                <th style={{width: '50px'}}>S.No</th>
                <th>Barcode</th>
                <th>Style Code</th>
                <th>Brand</th>
                <th>Color</th>
                <th>Size</th>
                <th>Gender</th>
                <th>Category</th>
                <th>Sub Category</th>
                <th>HSN</th>
                <th>MRP</th>
                <th>Cost</th>
                <th>Stock</th>
                <th>Status</th>
                <th style={{width: '100px'}}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredItems.map((item, index) => (
                <tr key={item.barcode} className={index % 2 === 0 ? 'even-row' : 'odd-row'}>
                  <td>{(currentPage - 1) * itemsPerPage + index + 1}</td>
                  <td>{item.barcode}</td>
                  <td>{item.style_code}</td>
                  <td>{item.brand || '-'}</td>
                  <td>{item.color || '-'}</td>
                  <td>{item.size || '-'}</td>
                  <td>{item.gender || '-'}</td>
                  <td>{item.category || '-'}</td>
                  <td>{item.sub_category || '-'}</td>
                  <td>{item.hsn || '-'}</td>
                  <td>₹{item.mrp_incl}</td>
                  <td>₹{item.purchase_rate_basic || 0}</td>
                  <td className={item.stock?.qty_on_hand < 10 ? 'low-stock' : ''}>
                    {item.stock?.qty_on_hand || 0}
                  </td>
                  <td>
                    <span className={`status-badge ${item.status === 'active' ? 'active' : 'inactive'}`}>
                      {item.status === 'active' ? 'ACTIVE' : 'INACTIVE'}
                    </span>
                  </td>
                  <td>
                    <div className="table-actions">
                      <button 
                        className="btn-icon"
                        onClick={() => handleEdit(item)}
                        title="Edit"
                      >
                        <FiEdit2 />
                      </button>
                      <button 
                        className="btn-icon delete"
                        onClick={() => handleDelete(item)}
                        title="Delete"
                      >
                        <FiTrash2 />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="pagination">
          <button 
            className="btn-page"
            onClick={() => fetchItems(currentPage - 1)}
            disabled={currentPage === 1}
          >
            Previous
          </button>
          
          <div className="page-numbers">
            {[...Array(totalPages)].map((_, i) => (
              <button
                key={i}
                className={`btn-page-number ${currentPage === i + 1 ? 'active' : ''}`}
                onClick={() => fetchItems(i + 1)}
              >
                {i + 1}
              </button>
            )).slice(Math.max(0, currentPage - 3), Math.min(totalPages, currentPage + 2))}
          </div>
          
          <button 
            className="btn-page"
            onClick={() => fetchItems(currentPage + 1)}
            disabled={currentPage === totalPages}
          >
            Next
          </button>
        </div>
      )}

      {/* Add/Edit Modal */}
      {showModal && (
        <div className="modal-overlay">
          <div className="modal-content">
            <div className="modal-header">
              <h2>{editingItem ? 'Edit Item' : 'Add New Item'}</h2>
              <button 
                className="modal-close"
                onClick={() => {
                  setShowModal(false);
                  resetForm();
                }}
              >
                <FiX />
              </button>
            </div>
            
            <form onSubmit={handleSubmit} className="item-form">
              <div className="form-grid">
                <div className="form-group">
                  <label>Barcode *</label>
                  <input
                    type="text"
                    name="barcode"
                    value={formData.barcode}
                    onChange={handleInputChange}
                    className="form-input"
                    required
                    disabled={editingItem}
                  />
                </div>
                
                <div className="form-group">
                  <label>Style Code *</label>
                  <input
                    type="text"
                    name="style_code"
                    value={formData.style_code}
                    onChange={handleInputChange}
                    className="form-input"
                    required
                  />
                </div>
                
                <div className="form-group">
                  <label>Brand</label>
                  <input
                    type="text"
                    name="brand"
                    value={formData.brand}
                    onChange={handleInputChange}
                    className="form-input"
                  />
                </div>
                
                <div className="form-group">
                  <label>Color</label>
                  <input
                    type="text"
                    name="color"
                    value={formData.color}
                    onChange={handleInputChange}
                    className="form-input"
                  />
                </div>
                
                <div className="form-group">
                  <label>Size</label>
                  <input
                    type="text"
                    name="size"
                    value={formData.size}
                    onChange={handleInputChange}
                    className="form-input"
                  />
                </div>
                
                <div className="form-group">
                  <label>HSN Code</label>
                  <input
                    type="text"
                    name="hsn"
                    value={formData.hsn}
                    onChange={handleInputChange}
                    className="form-input"
                  />
                </div>
                
                <div className="form-group">
                  <label>MRP (Incl. GST) *</label>
                  <input
                    type="number"
                    name="mrp_incl"
                    value={formData.mrp_incl}
                    onChange={handleInputChange}
                    className="form-input"
                    required
                    min="0"
                    step="0.01"
                  />
                  {formData.mrp_incl && (
                    <span className="gst-info">
                      GST: {getGSTRate(formData.mrp_incl)}%
                    </span>
                  )}
                </div>
                
                <div className="form-group">
                  <label>Purchase Rate (Basic)</label>
                  <input
                    type="number"
                    name="purchase_rate_basic"
                    value={formData.purchase_rate_basic}
                    onChange={handleInputChange}
                    className="form-input"
                    min="0"
                    step="0.01"
                  />
                </div>
                
                <div className="form-group">
                  <label>Gender</label>
                  <select
                    name="gender"
                    value={formData.gender || ''}
                    onChange={handleInputChange}
                    className="form-input"
                  >
                    <option value="">Select Gender</option>
                    <option value="BOYS">BOYS</option>
                    <option value="GIRLS">GIRLS</option>
                    <option value="MEN">MEN</option>
                    <option value="WOMEN">WOMEN</option>
                    <option value="UNISEX">UNISEX</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Kids">Kids</option>
                  </select>
                </div>
                
                <div className="form-group">
                  <label>Category</label>
                  <input
                    type="text"
                    name="category"
                    value={formData.category}
                    onChange={handleInputChange}
                    className="form-input"
                  />
                </div>
                
                <div className="form-group">
                  <label>Sub Category</label>
                  <input
                    type="text"
                    name="sub_category"
                    value={formData.sub_category}
                    onChange={handleInputChange}
                    className="form-input"
                  />
                </div>
                
                <div className="form-group">
                  <label className="checkbox-label">
                    <input
                      type="checkbox"
                      name="active"
                      checked={formData.active}
                      onChange={handleInputChange}
                    />
                    Active
                  </label>
                </div>
              </div>
              
              <div className="form-footer">
                <button 
                  type="button"
                  className="btn btn-secondary"
                  onClick={() => {
                    setShowModal(false);
                    resetForm();
                  }}
                >
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary">
                  <FiSave /> {editingItem ? 'Update' : 'Save'} Item
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Excel Importer Modal */}
      <ExcelImporter
        isOpen={showImportModal}
        onClose={() => setShowImportModal(false)}
        importType="items"
        onImportSuccess={handleImportSuccess}
      />
    </div>
  );
}

export default Items;