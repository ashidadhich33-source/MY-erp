import React, { useState, useEffect } from 'react';
import { 
  FiTruck, FiPlus, FiEdit2, FiTrash2, FiSave,
  FiSearch, FiMapPin, FiPhone, FiMail, FiFileText,
  FiToggleLeft, FiToggleRight, FiX, FiCheckCircle
} from 'react-icons/fi';
import toast from 'react-hot-toast';
import axios from 'axios';
import './SetupScreens.css';

const API_URL = 'http://localhost:8000/api/v1';

function Suppliers() {
  const [suppliers, setSuppliers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState(null);
  
  // Form state
  const [formData, setFormData] = useState({
    name: '',
    gstin: '',
    email: '',
    phone: '',
    location_type: 'local',
    address: '',
    city: '',
    state: '',
    pincode: '',
    contact_person: '',
    active: true
  });

  // Validation errors
  const [errors, setErrors] = useState({});

  // Stats
  const [stats, setStats] = useState({
    total: 0,
    active: 0,
    local: 0,
    interstate: 0
  });

  // Fetch suppliers
  const fetchSuppliers = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(
        `${API_URL}/setup/suppliers`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      const suppliersData = response.data.suppliers || [];
      setSuppliers(suppliersData);
      
      // Calculate stats
      setStats({
        total: suppliersData.length,
        active: suppliersData.filter(s => s.active).length,
        local: suppliersData.filter(s => s.location_type === 'local').length,
        interstate: suppliersData.filter(s => s.location_type === 'inter-state').length
      });
    } catch (error) {
      toast.error('Failed to fetch suppliers');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSuppliers();
  }, []);

  // Validate GSTIN
  const validateGSTIN = (gstin) => {
    const gstRegex = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;
    return gstRegex.test(gstin);
  };

  // Validate email
  const validateEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  // Validate phone
  const validatePhone = (phone) => {
    const phoneRegex = /^[6-9]\d{9}$/;
    return phoneRegex.test(phone);
  };

  // Validate form
  const validateForm = () => {
    const newErrors = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Supplier name is required';
    }

    if (formData.gstin && !validateGSTIN(formData.gstin)) {
      newErrors.gstin = 'Invalid GSTIN format';
    }

    if (formData.email && !validateEmail(formData.email)) {
      newErrors.email = 'Invalid email format';
    }

    if (!formData.phone) {
      newErrors.phone = 'Phone number is required';
    } else if (!validatePhone(formData.phone)) {
      newErrors.phone = 'Invalid phone number';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Handle form submission - UPDATED
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      toast.error('Please fix the errors in the form');
      return;
    }

    const confirmMsg = editingSupplier 
      ? 'Update supplier details?' 
      : 'Do you want to save this supplier?';
      
    if (!window.confirm(confirmMsg)) return;

    try {
      const token = localStorage.getItem('token');
      const endpoint = editingSupplier 
        ? `${API_URL}/setup/suppliers/${editingSupplier.id}`
        : `${API_URL}/setup/suppliers`;
      
      const method = editingSupplier ? 'put' : 'post';
      
      // Explicitly construct the data to send
      const dataToSend = {
        name: formData.name || '',
        gstin: formData.gstin || '',
        email: formData.email || '',
        phone: formData.phone || '',
        location_type: formData.location_type || 'local',
        address: formData.address || '',
        city: formData.city || '',
        state: formData.state || '',
        pincode: formData.pincode || '',
        contact_person: formData.contact_person || '',  // Ensure this is included
        active: formData.active
      };
      
      console.log('Sending data:', dataToSend);  // Debug log
      
      const response = await axios[method](endpoint, dataToSend, {
        headers: { 
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      
      console.log('Response:', response.data);  // Debug log

      toast.success(`Supplier ${editingSupplier ? 'updated' : 'saved'} successfully`);
      setShowModal(false);
      resetForm();
      fetchSuppliers();
    } catch (error) {
      console.error('Error details:', error.response);  // Debug log
      if (error.response?.data?.detail) {
        toast.error(error.response.data.detail);
      } else {
        toast.error('Failed to save supplier');
      }
    }
  };

  // Reset form
  const resetForm = () => {
    setFormData({
      name: '',
      gstin: '',
      email: '',
      phone: '',
      location_type: 'local',
      address: '',
      city: '',
      state: '',
      pincode: '',
      contact_person: '',
      active: true
    });
    setEditingSupplier(null);
    setErrors({});
  };

  // Edit supplier - UPDATED
  const handleEdit = (supplier) => {
    // Explicitly map each field to ensure nothing is undefined
    setFormData({
      name: supplier.name || '',
      gstin: supplier.gstin || '',
      email: supplier.email || '',
      phone: supplier.phone || '',
      location_type: supplier.location_type || 'local',
      address: supplier.address || '',
      city: supplier.city || '',
      state: supplier.state || '',
      pincode: supplier.pincode || '',
      contact_person: supplier.contact_person || '',  // Ensure this field is mapped
      active: supplier.active !== undefined ? supplier.active : true
    });
    setEditingSupplier(supplier);
    setShowModal(true);
    
    // Debug log
    console.log('Editing supplier:', supplier);
    console.log('Form data set to:', {
      ...supplier,
      contact_person: supplier.contact_person || ''
    });
  };

  // Toggle supplier status
  const toggleStatus = async (supplier) => {
    try {
      const token = localStorage.getItem('token');
      await axios.patch(
        `${API_URL}/setup/suppliers/${supplier.id}/toggle-status`,
        {},
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      toast.success(`Supplier ${supplier.active ? 'deactivated' : 'activated'}`);
      fetchSuppliers();
    } catch (error) {
      toast.error('Failed to update supplier status');
    }
  };

  // Delete supplier
  const handleDelete = async (supplier) => {
    if (!window.confirm(`Delete supplier "${supplier.name}"? This action cannot be undone.`)) {
      return;
    }

    try {
      const token = localStorage.getItem('token');
      await axios.delete(
        `${API_URL}/setup/suppliers/${supplier.id}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      toast.success('Supplier deleted successfully');
      fetchSuppliers();
    } catch (error) {
      toast.error('Failed to delete supplier');
    }
  };

  // Filter suppliers
  const filteredSuppliers = suppliers.filter(supplier => {
    const searchLower = searchTerm.toLowerCase();
    return (
      supplier.name?.toLowerCase().includes(searchLower) ||
      supplier.gstin?.toLowerCase().includes(searchLower) ||
      supplier.phone?.includes(searchTerm) ||
      supplier.email?.toLowerCase().includes(searchLower) ||
      supplier.city?.toLowerCase().includes(searchLower)
    );
  });

  return (
    <div className="setup-container">
      {/* Header */}
      <div className="setup-header">
        <div className="header-left">
          <h1 className="page-title">
            <FiTruck className="title-icon" />
            Setup Suppliers
          </h1>
          <p className="page-subtitle">Manage your supplier network</p>
        </div>
        
        <div className="header-actions">
          <button 
            className="btn btn-primary"
            onClick={() => {
              resetForm();
              setShowModal(true);
            }}
          >
            <FiPlus />
            Add Supplier
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon blue">
            <FiTruck />
          </div>
          <div className="stat-content">
            <p className="stat-label">Total Suppliers</p>
            <p className="stat-value">{stats.total}</p>
          </div>
        </div>
        
        <div className="stat-card">
          <div className="stat-icon green">
            <FiCheckCircle />
          </div>
          <div className="stat-content">
            <p className="stat-label">Active</p>
            <p className="stat-value">{stats.active}</p>
          </div>
        </div>
        
        <div className="stat-card">
          <div className="stat-icon purple">
            <FiMapPin />
          </div>
          <div className="stat-content">
            <p className="stat-label">Local</p>
            <p className="stat-value">{stats.local}</p>
          </div>
        </div>
        
        <div className="stat-card">
          <div className="stat-icon orange">
            <FiTruck />
          </div>
          <div className="stat-content">
            <p className="stat-label">Inter-state</p>
            <p className="stat-value">{stats.interstate}</p>
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="search-section">
        <div className="search-box">
          <FiSearch className="search-icon" />
          <input
            type="text"
            placeholder="Search by name, GSTIN, phone, email..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="search-input"
          />
        </div>
      </div>

      {/* Suppliers List */}
      {loading ? (
        <div className="loading-container">
          <div className="loading-spinner"></div>
          <p>Loading suppliers...</p>
        </div>
      ) : filteredSuppliers.length === 0 ? (
        <div className="empty-state">
          <FiTruck className="empty-icon" />
          <h3>No suppliers found</h3>
          <p>Start by adding your first supplier</p>
        </div>
      ) : (
        <div className="cards-grid">
          {filteredSuppliers.map(supplier => (
            <div key={supplier.id} className="supplier-card">
              <div className="card-header">
                <div className="supplier-info">
                  <h3 className="supplier-name">{supplier.name}</h3>
                  {supplier.gstin && (
                    <p className="supplier-gstin">GSTIN: {supplier.gstin}</p>
                  )}
                </div>
                <div className="card-actions">
                  <button
                    className={`status-toggle ${supplier.active ? 'active' : ''}`}
                    onClick={() => toggleStatus(supplier)}
                    title={supplier.active ? 'Active' : 'Inactive'}
                  >
                    {supplier.active ? <FiToggleRight /> : <FiToggleLeft />}
                  </button>
                </div>
              </div>
              
              <div className="card-body">
                <div className="info-row">
                  <FiMapPin className="info-icon" />
                  <span className={`location-badge ${supplier.location_type}`}>
                    {supplier.location_type === 'local' ? 'Local' : 'Inter-state'}
                  </span>
                </div>
                
                {supplier.phone && (
                  <div className="info-row">
                    <FiPhone className="info-icon" />
                    <span>{supplier.phone}</span>
                  </div>
                )}
                
                {supplier.email && (
                  <div className="info-row">
                    <FiMail className="info-icon" />
                    <span>{supplier.email}</span>
                  </div>
                )}
                
                {supplier.city && (
                  <div className="info-row">
                    <FiMapPin className="info-icon" />
                    <span>{supplier.city}{supplier.state ? `, ${supplier.state}` : ''}</span>
                  </div>
                )}
                
                {supplier.contact_person && (
                  <div className="info-row">
                    <FiFileText className="info-icon" />
                    <span>Contact: {supplier.contact_person}</span>
                  </div>
                )}
              </div>
              
              <div className="card-footer">
                <button
                  className="btn-icon"
                  onClick={() => handleEdit(supplier)}
                >
                  <FiEdit2 />
                  Edit
                </button>
                <button
                  className="btn-icon danger"
                  onClick={() => handleDelete(supplier)}
                >
                  <FiTrash2 />
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add/Edit Modal */}
      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal-content modal-large" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h2>{editingSupplier ? 'Edit Supplier' : 'Add New Supplier'}</h2>
              <button className="modal-close" onClick={() => setShowModal(false)}>
                <FiX />
              </button>
            </div>
            
            <form onSubmit={handleSubmit} className="supplier-form">
              <div className="form-grid">
                <div className="form-group">
                  <label>Supplier Name *</label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => {
                      console.log('Name changed:', e.target.value);
                      setFormData({ ...formData, name: e.target.value });
                    }}
                    className={`form-input ${errors.name ? 'error' : ''}`}
                    placeholder="Enter supplier name"
                  />
                  {errors.name && <span className="error-message">{errors.name}</span>}
                </div>
                
                <div className="form-group">
                  <label>GST Number</label>
                  <input
                    type="text"
                    value={formData.gstin}
                    onChange={(e) => setFormData({ ...formData, gstin: e.target.value.toUpperCase() })}
                    className={`form-input ${errors.gstin ? 'error' : ''}`}
                    placeholder="29ABCDE1234F1Z5"
                    maxLength="15"
                  />
                  {errors.gstin && <span className="error-message">{errors.gstin}</span>}
                </div>
                
                <div className="form-group">
                  <label>Email</label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className={`form-input ${errors.email ? 'error' : ''}`}
                    placeholder="supplier@example.com"
                  />
                  {errors.email && <span className="error-message">{errors.email}</span>}
                </div>
                
                <div className="form-group">
                  <label>Phone *</label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className={`form-input ${errors.phone ? 'error' : ''}`}
                    placeholder="9876543210"
                    maxLength="10"
                  />
                  {errors.phone && <span className="error-message">{errors.phone}</span>}
                </div>
                
                <div className="form-group">
                  <label>Location Type *</label>
                  <select
                    value={formData.location_type}
                    onChange={(e) => setFormData({ ...formData, location_type: e.target.value })}
                    className="form-input"
                  >
                    <option value="local">Local</option>
                    <option value="inter-state">Inter-state</option>
                  </select>
                </div>
                
                <div className="form-group">
                  <label>Contact Person</label>
                  <input
                    type="text"
                    value={formData.contact_person}
                    onChange={(e) => {
                      console.log('Contact person changed:', e.target.value);
                      setFormData({ ...formData, contact_person: e.target.value });
                    }}
                    className="form-input"
                    placeholder="Contact person name"
                  />
                </div>
                
                <div className="form-group full-width">
                  <label>Address</label>
                  <input
                    type="text"
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    className="form-input"
                    placeholder="Street address"
                  />
                </div>
                
                <div className="form-group">
                  <label>City</label>
                  <input
                    type="text"
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    className="form-input"
                    placeholder="City"
                  />
                </div>
                
                <div className="form-group">
                  <label>State</label>
                  <input
                    type="text"
                    value={formData.state}
                    onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                    className="form-input"
                    placeholder="State"
                  />
                </div>
                
                <div className="form-group">
                  <label>Pincode</label>
                  <input
                    type="text"
                    value={formData.pincode}
                    onChange={(e) => setFormData({ ...formData, pincode: e.target.value })}
                    className="form-input"
                    placeholder="6-digit pincode"
                    maxLength="6"
                  />
                </div>
                
                <div className="form-group">
                  <label>Status</label>
                  <select
                    value={formData.active}
                    onChange={(e) => setFormData({ ...formData, active: e.target.value === 'true' })}
                    className="form-input"
                  >
                    <option value="true">Active</option>
                    <option value="false">Inactive</option>
                  </select>
                </div>
              </div>
              
              <div className="form-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary">
                  <FiSave />
                  {editingSupplier ? 'Update' : 'Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default Suppliers;