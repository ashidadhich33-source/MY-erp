import React, { useState, useEffect } from 'react';
import { 
  FiTarget, FiPlus, FiSave, FiEdit2, FiTrash2,
  FiTrendingUp, FiDollarSign, FiAward, FiCalendar,
  FiRefreshCw, FiPercent, FiUsers, FiBarChart
} from 'react-icons/fi';
import toast from 'react-hot-toast';
import axios from 'axios';
import './SetupScreens.css';

const API_URL = 'http://localhost:8000/api/v1';

function TargetsIncentives() {
  const [targets, setTargets] = useState([]);
  const [incentives, setIncentives] = useState([]);
  const [loading, setLoading] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [modalType, setModalType] = useState('target'); // 'target' or 'incentive'
  const [editingItem, setEditingItem] = useState(null);
  const [selectedMonth, setSelectedMonth] = useState(new Date().toISOString().slice(0, 7));
  
  // Form state for targets
  const [targetForm, setTargetForm] = useState({
    staff_id: '',
    period_type: 'monthly',
    period_value: '',
    sales_target: '',
    items_target: '',
    category_targets: [],
    active: true
  });

  // Form state for incentives
  const [incentiveForm, setIncentiveForm] = useState({
    name: '',
    type: 'percentage', // percentage, fixed, tiered
    calculation_base: 'sales', // sales, profit, items
    min_achievement: 80,
    slabs: [
      { from: 80, to: 100, value: 2 },
      { from: 100, to: 120, value: 3 },
      { from: 120, to: 999999, value: 5 }
    ],
    applicable_to: 'all', // all, specific_roles, specific_staff
    roles: [],
    staff_ids: [],
    active: true
  });

  // Staff list
  const [staff, setStaff] = useState([]);
  
  // Validation errors
  const [errors, setErrors] = useState({});

  // Stats
  const [stats, setStats] = useState({
    totalTargets: 0,
    activeTargets: 0,
    avgAchievement: 0,
    totalIncentivePaid: 0,
    topPerformer: null
  });

  // Performance data
  const [performance, setPerformance] = useState([]);

  // Fetch all data
  useEffect(() => {
    fetchTargets();
    fetchIncentives();
    fetchStaff();
    fetchPerformance();
  }, [selectedMonth]);

  // Fetch targets
  const fetchTargets = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(
        `${API_URL}/setup/targets?month=${selectedMonth}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      setTargets(response.data || []);
      calculateStats(response.data);
    } catch (error) {
      toast.error('Failed to fetch targets');
    } finally {
      setLoading(false);
    }
  };

  // Fetch incentives
  const fetchIncentives = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(
        `${API_URL}/setup/incentives`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      setIncentives(response.data || []);
    } catch (error) {
      console.error('Failed to fetch incentives');
    }
  };

  // Fetch staff
  const fetchStaff = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(
        `${API_URL}/setup/staff?active=true`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      setStaff(response.data || []);
    } catch (error) {
      console.error('Failed to fetch staff');
    }
  };

  // Fetch performance
  const fetchPerformance = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(
        `${API_URL}/setup/targets/performance?month=${selectedMonth}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      setPerformance(response.data || []);
    } catch (error) {
      console.error('Failed to fetch performance');
    }
  };

  // Calculate stats
  const calculateStats = (targetData) => {
    const activeTargets = targetData.filter(t => t.active);
    const achievements = performance.map(p => p.achievement_percentage || 0);
    const avgAchievement = achievements.length > 0 
      ? achievements.reduce((a, b) => a + b, 0) / achievements.length 
      : 0;
    
    const topPerformer = performance.reduce((top, current) => {
      if (!top || current.achievement_percentage > top.achievement_percentage) {
        return current;
      }
      return top;
    }, null);

    setStats({
      totalTargets: targetData.length,
      activeTargets: activeTargets.length,
      avgAchievement: avgAchievement.toFixed(1),
      totalIncentivePaid: performance.reduce((sum, p) => sum + (p.incentive_earned || 0), 0),
      topPerformer
    });
  };

  // Open modal
  const openModal = (type, item = null) => {
    setModalType(type);
    setEditingItem(item);
    
    if (type === 'target') {
      if (item) {
        setTargetForm(item);
      } else {
        setTargetForm({
          staff_id: '',
          period_type: 'monthly',
          period_value: selectedMonth,
          sales_target: '',
          items_target: '',
          category_targets: [],
          active: true
        });
      }
    } else {
      if (item) {
        setIncentiveForm(item);
      } else {
        setIncentiveForm({
          name: '',
          type: 'percentage',
          calculation_base: 'sales',
          min_achievement: 80,
          slabs: [
            { from: 80, to: 100, value: 2 },
            { from: 100, to: 120, value: 3 },
            { from: 120, to: 999999, value: 5 }
          ],
          applicable_to: 'all',
          roles: [],
          staff_ids: [],
          active: true
        });
      }
    }
    
    setShowModal(true);
    setErrors({});
  };

  // Validate target form
  const validateTargetForm = () => {
    const newErrors = {};

    if (!targetForm.staff_id) {
      newErrors.staff_id = 'Please select a staff member';
    }

    if (!targetForm.period_value) {
      newErrors.period_value = 'Period is required';
    }

    if (!targetForm.sales_target || targetForm.sales_target <= 0) {
      newErrors.sales_target = 'Sales target must be greater than 0';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Validate incentive form
  const validateIncentiveForm = () => {
    const newErrors = {};

    if (!incentiveForm.name.trim()) {
      newErrors.name = 'Incentive name is required';
    }

    if (incentiveForm.slabs.length === 0) {
      newErrors.slabs = 'At least one slab is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Handle target submission
  const handleTargetSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateTargetForm()) {
      toast.error('Please fix the errors');
      return;
    }

    try {
      const token = localStorage.getItem('token');
      const endpoint = editingItem 
        ? `${API_URL}/setup/targets/${editingItem.id}`
        : `${API_URL}/setup/targets`;
      
      const method = editingItem ? 'put' : 'post';
      
      await axios[method](endpoint, targetForm, {
        headers: { Authorization: `Bearer ${token}` }
      });

      toast.success(`Target ${editingItem ? 'updated' : 'created'} successfully`);
      setShowModal(false);
      fetchTargets();
    } catch (error) {
      toast.error('Failed to save target');
    }
  };

  // Handle incentive submission
  const handleIncentiveSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateIncentiveForm()) {
      toast.error('Please fix the errors');
      return;
    }

    try {
      const token = localStorage.getItem('token');
      const endpoint = editingItem 
        ? `${API_URL}/setup/incentives/${editingItem.id}`
        : `${API_URL}/setup/incentives`;
      
      const method = editingItem ? 'put' : 'post';
      
      await axios[method](endpoint, incentiveForm, {
        headers: { Authorization: `Bearer ${token}` }
      });

      toast.success(`Incentive ${editingItem ? 'updated' : 'created'} successfully`);
      setShowModal(false);
      fetchIncentives();
    } catch (error) {
      toast.error('Failed to save incentive');
    }
  };

  // Add incentive slab
  const addSlab = () => {
    const lastSlab = incentiveForm.slabs[incentiveForm.slabs.length - 1];
    const newFrom = lastSlab ? lastSlab.to : 0;
    
    setIncentiveForm({
      ...incentiveForm,
      slabs: [
        ...incentiveForm.slabs,
        { from: newFrom, to: newFrom + 20, value: 0 }
      ]
    });
  };

  // Remove incentive slab
  const removeSlab = (index) => {
    setIncentiveForm({
      ...incentiveForm,
      slabs: incentiveForm.slabs.filter((_, i) => i !== index)
    });
  };

  // Update slab
  const updateSlab = (index, field, value) => {
    const newSlabs = [...incentiveForm.slabs];
    newSlabs[index][field] = parseFloat(value) || 0;
    setIncentiveForm({ ...incentiveForm, slabs: newSlabs });
  };

  // Delete target
  const handleDeleteTarget = async (target) => {
    if (!window.confirm('Delete this target?')) return;

    try {
      const token = localStorage.getItem('token');
      await axios.delete(
        `${API_URL}/setup/targets/${target.id}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      toast.success('Target deleted successfully');
      fetchTargets();
    } catch (error) {
      toast.error('Failed to delete target');
    }
  };

  // Delete incentive
  const handleDeleteIncentive = async (incentive) => {
    if (!window.confirm('Delete this incentive scheme?')) return;

    try {
      const token = localStorage.getItem('token');
      await axios.delete(
        `${API_URL}/setup/incentives/${incentive.id}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      toast.success('Incentive deleted successfully');
      fetchIncentives();
    } catch (error) {
      toast.error('Failed to delete incentive');
    }
  };

  // Calculate achievement color
  const getAchievementColor = (percentage) => {
    if (percentage >= 120) return 'achievement-excellent';
    if (percentage >= 100) return 'achievement-good';
    if (percentage >= 80) return 'achievement-average';
    return 'achievement-poor';
  };

  return (
    <div className="setup-container">
      {/* Header */}
      <div className="setup-header">
        <div className="header-left">
          <h1 className="page-title">
            <FiTarget className="title-icon" />
            Targets & Incentives
          </h1>
          <p className="page-subtitle">Manage sales targets and incentive schemes</p>
        </div>
        <div className="header-actions">
          <input
            type="month"
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(e.target.value)}
            className="month-selector"
          />
          <button className="btn-refresh" onClick={fetchTargets}>
            <FiRefreshCw /> Refresh
          </button>
          <button className="btn-primary" onClick={() => openModal('target')}>
            <FiPlus /> Add Target
          </button>
          <button className="btn-secondary" onClick={() => openModal('incentive')}>
            <FiAward /> Add Incentive
          </button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon-wrapper purple">
            <FiTarget />
          </div>
          <div className="stat-content">
            <p className="stat-label">Active Targets</p>
            <p className="stat-value">{stats.activeTargets}</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon-wrapper green">
            <FiTrendingUp />
          </div>
          <div className="stat-content">
            <p className="stat-label">Avg Achievement</p>
            <p className="stat-value">{stats.avgAchievement}%</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon-wrapper blue">
            <FiDollarSign />
          </div>
          <div className="stat-content">
            <p className="stat-label">Incentives Paid</p>
            <p className="stat-value">₹{stats.totalIncentivePaid.toLocaleString()}</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon-wrapper orange">
            <FiAward />
          </div>
          <div className="stat-content">
            <p className="stat-label">Top Performer</p>
            <p className="stat-value">{stats.topPerformer?.staff_name || '-'}</p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="tabs-container">
        <button className="tab-button active">Performance Dashboard</button>
        <button className="tab-button">Targets</button>
        <button className="tab-button">Incentive Schemes</button>
      </div>

      {/* Performance Table */}
      <div className="table-container">
        <h3 className="section-title">
          <FiBarChart /> Performance Overview - {new Date(selectedMonth).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
        </h3>
        <table className="data-table">
          <thead>
            <tr>
              <th>Staff</th>
              <th>Target</th>
              <th>Achieved</th>
              <th>Achievement %</th>
              <th>Performance</th>
              <th>Incentive Earned</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {performance.length === 0 ? (
              <tr>
                <td colSpan="7" className="text-center empty-state">
                  <FiTarget size={48} />
                  <p>No performance data available</p>
                </td>
              </tr>
            ) : (
              performance.map((perf) => (
                <tr key={perf.id}>
                  <td className="staff-name-cell">{perf.staff_name}</td>
                  <td className="target-cell">₹{perf.target?.toLocaleString()}</td>
                  <td className="achieved-cell">₹{perf.achieved?.toLocaleString()}</td>
                  <td>
                    <span className={`achievement-badge ${getAchievementColor(perf.achievement_percentage)}`}>
                      {perf.achievement_percentage}%
                    </span>
                  </td>
                  <td>
                    <div className="performance-bar">
                      <div 
                        className="performance-fill"
                        style={{ 
                          width: `${Math.min(perf.achievement_percentage, 150)}%`,
                          background: perf.achievement_percentage >= 100 
                            ? 'linear-gradient(90deg, #10b981, #059669)'
                            : 'linear-gradient(90deg, #f59e0b, #d97706)'
                        }}
                      />
                    </div>
                  </td>
                  <td className="incentive-cell">
                    ₹{perf.incentive_earned?.toLocaleString()}
                  </td>
                  <td>
                    <span className={`status-badge ${perf.achievement_percentage >= 100 ? 'achieved' : 'pending'}`}>
                      {perf.achievement_percentage >= 100 ? 'Achieved' : 'In Progress'}
                    </span>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Incentive Schemes */}
      <div className="incentives-section">
        <h3 className="section-title">
          <FiAward /> Active Incentive Schemes
        </h3>
        <div className="incentives-grid">
          {incentives.filter(i => i.active).map((incentive) => (
            <div key={incentive.id} className="incentive-card">
              <div className="incentive-header">
                <h4>{incentive.name}</h4>
                <div className="incentive-actions">
                  <button onClick={() => openModal('incentive', incentive)}>
                    <FiEdit2 />
                  </button>
                  <button onClick={() => handleDeleteIncentive(incentive)}>
                    <FiTrash2 />
                  </button>
                </div>
              </div>
              <div className="incentive-details">
                <p><strong>Type:</strong> {incentive.type}</p>
                <p><strong>Based on:</strong> {incentive.calculation_base}</p>
                <p><strong>Min Achievement:</strong> {incentive.min_achievement}%</p>
              </div>
              <div className="slabs-display">
                <h5>Slabs:</h5>
                {incentive.slabs?.map((slab, index) => (
                  <div key={index} className="slab-item">
                    {slab.from}% - {slab.to === 999999 ? '∞' : `${slab.to}%`}: 
                    <strong> {slab.value}{incentive.type === 'percentage' ? '%' : ` ₹`}</strong>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Modal */}
      {showModal && (
        <div className="modal-overlay">
          <div className="modal-content modal-lg">
            <div className="modal-header">
              <h2>
                {modalType === 'target' 
                  ? (editingItem ? 'Edit Target' : 'Add Target')
                  : (editingItem ? 'Edit Incentive' : 'Add Incentive')}
              </h2>
              <button className="btn-close" onClick={() => setShowModal(false)}>×</button>
            </div>

            {modalType === 'target' ? (
              <form onSubmit={handleTargetSubmit} className="modal-form">
                <div className="form-row">
                  <div className="form-group">
                    <label>Staff Member *</label>
                    <select
                      value={targetForm.staff_id}
                      onChange={(e) => setTargetForm({...targetForm, staff_id: e.target.value})}
                      className={errors.staff_id ? 'error' : ''}
                    >
                      <option value="">Select Staff</option>
                      {staff.map(s => (
                        <option key={s.id} value={s.id}>{s.name}</option>
                      ))}
                    </select>
                    {errors.staff_id && <span className="error-message">{errors.staff_id}</span>}
                  </div>

                  <div className="form-group">
                    <label>Period *</label>
                    <input
                      type="month"
                      value={targetForm.period_value}
                      onChange={(e) => setTargetForm({...targetForm, period_value: e.target.value})}
                      className={errors.period_value ? 'error' : ''}
                    />
                    {errors.period_value && <span className="error-message">{errors.period_value}</span>}
                  </div>
                </div>

                <div className="form-row">
                  <div className="form-group">
                    <label>Sales Target (₹) *</label>
                    <input
                      type="number"
                      value={targetForm.sales_target}
                      onChange={(e) => setTargetForm({...targetForm, sales_target: e.target.value})}
                      className={errors.sales_target ? 'error' : ''}
                      placeholder="Monthly sales target"
                    />
                    {errors.sales_target && <span className="error-message">{errors.sales_target}</span>}
                  </div>

                  <div className="form-group">
                    <label>Items Target</label>
                    <input
                      type="number"
                      value={targetForm.items_target}
                      onChange={(e) => setTargetForm({...targetForm, items_target: e.target.value})}
                      placeholder="Number of items to sell"
                    />
                  </div>
                </div>

                <div className="form-group">
                  <label className="checkbox-label">
                    <input
                      type="checkbox"
                      checked={targetForm.active}
                      onChange={(e) => setTargetForm({...targetForm, active: e.target.checked})}
                    />
                    Active
                  </label>
                </div>

                <div className="modal-footer">
                  <button type="button" className="btn-secondary" onClick={() => setShowModal(false)}>
                    Cancel
                  </button>
                  <button type="submit" className="btn-primary">
                    <FiSave /> {editingItem ? 'Update' : 'Save'} Target
                  </button>
                </div>
              </form>
            ) : (
              <form onSubmit={handleIncentiveSubmit} className="modal-form">
                <div className="form-group">
                  <label>Incentive Name *</label>
                  <input
                    type="text"
                    value={incentiveForm.name}
                    onChange={(e) => setIncentiveForm({...incentiveForm, name: e.target.value})}
                    className={errors.name ? 'error' : ''}
                    placeholder="e.g., Monthly Sales Incentive"
                  />
                  {errors.name && <span className="error-message">{errors.name}</span>}
                </div>

                <div className="form-row">
                  <div className="form-group">
                    <label>Type</label>
                    <select
                      value={incentiveForm.type}
                      onChange={(e) => setIncentiveForm({...incentiveForm, type: e.target.value})}
                    >
                      <option value="percentage">Percentage</option>
                      <option value="fixed">Fixed Amount</option>
                      <option value="tiered">Tiered</option>
                    </select>
                  </div>

                  <div className="form-group">
                    <label>Based On</label>
                    <select
                      value={incentiveForm.calculation_base}
                      onChange={(e) => setIncentiveForm({...incentiveForm, calculation_base: e.target.value})}
                    >
                      <option value="sales">Sales Amount</option>
                      <option value="profit">Profit</option>
                      <option value="items">Items Sold</option>
                    </select>
                  </div>

                  <div className="form-group">
                    <label>Min Achievement (%)</label>
                    <input
                      type="number"
                      value={incentiveForm.min_achievement}
                      onChange={(e) => setIncentiveForm({...incentiveForm, min_achievement: e.target.value})}
                      min="0"
                      max="100"
                    />
                  </div>
                </div>

                <div className="slabs-section">
                  <div className="slabs-header">
                    <h4>Incentive Slabs</h4>
                    <button type="button" className="btn-add-slab" onClick={addSlab}>
                      <FiPlus /> Add Slab
                    </button>
                  </div>
                  {incentiveForm.slabs.map((slab, index) => (
                    <div key={index} className="slab-row">
                      <input
                        type="number"
                        value={slab.from}
                        onChange={(e) => updateSlab(index, 'from', e.target.value)}
                        placeholder="From %"
                      />
                      <span>to</span>
                      <input
                        type="number"
                        value={slab.to === 999999 ? '' : slab.to}
                        onChange={(e) => updateSlab(index, 'to', e.target.value || 999999)}
                        placeholder="To %"
                      />
                      <span>=</span>
                      <input
                        type="number"
                        value={slab.value}
                        onChange={(e) => updateSlab(index, 'value', e.target.value)}
                        placeholder="Value"
                        step="0.1"
                      />
                      <span>{incentiveForm.type === 'percentage' ? '%' : '₹'}</span>
                      {incentiveForm.slabs.length > 1 && (
                        <button 
                          type="button" 
                          className="btn-remove-slab"
                          onClick={() => removeSlab(index)}
                        >
                          <FiTrash2 />
                        </button>
                      )}
                    </div>
                  ))}
                </div>

                <div className="form-group">
                  <label className="checkbox-label">
                    <input
                      type="checkbox"
                      checked={incentiveForm.active}
                      onChange={(e) => setIncentiveForm({...incentiveForm, active: e.target.checked})}
                    />
                    Active
                  </label>
                </div>

                <div className="modal-footer">
                  <button type="button" className="btn-secondary" onClick={() => setShowModal(false)}>
                    Cancel
                  </button>
                  <button type="submit" className="btn-primary">
                    <FiSave /> {editingItem ? 'Update' : 'Save'} Incentive
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default TargetsIncentives;