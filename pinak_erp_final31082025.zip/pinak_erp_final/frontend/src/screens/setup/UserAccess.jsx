import React, { useState, useEffect } from 'react';
import { 
  FiShield, FiUser, FiCheck, FiX, FiSave,
  FiEye, FiEdit, FiUpload, FiDownload, FiPrinter,
  FiClock, FiUserCheck, FiChevronDown, FiChevronRight, FiSettings, FiPlus
} from 'react-icons/fi';
import toast from 'react-hot-toast';
import axios from 'axios';
import './SetupScreens.css';

const API_URL = 'http://localhost:8000/api/v1';

function UserAccess() {
  const [users, setUsers] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [permissions, setPermissions] = useState({});
  const [expandedMenus, setExpandedMenus] = useState({});
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  // Menu structure matching sidebar
  const menuStructure = [
    {
      key: 'setup',
      title: 'Setup',
      icon: <FiSettings />,
      children: [
        {
          key: 'item_master',
          title: 'Item Master',
          children: [
            { key: 'create_item_master', title: 'Create Item Master' },
            { key: 'opening_stock', title: 'Opening Stock' },
            { key: 'stock_adjustment', title: 'Stock Adjustment' }
          ]
        },
        { key: 'suppliers', title: 'Setup Suppliers' },
        {
          key: 'users',
          title: 'Setup Users',
          children: [
            { key: 'create_user', title: 'Create User' },
            { key: 'user_access', title: 'Assign Access of Menu Bar' }
          ]
        },
        { key: 'company', title: 'Setup Company' },
        { key: 'customers', title: 'Setup Customer' },
        { key: 'loyalty_grade', title: 'Setup Loyalty Grade' },
        { key: 'coupons', title: 'Setup Coupons' },
        { key: 'whatsapp', title: 'Setup WhatsApp Cloud API' },
        { key: 'bill_series', title: 'Setup Bill Series' },
        {
          key: 'staff',
          title: 'Setup Staff',
          children: [
            { key: 'staff_management', title: 'Staff' },
            { key: 'targets_incentives', title: 'Setup Targets & Incentives' }
          ]
        },
        { key: 'expense_head', title: 'Setup Expense Head' },
        { key: 'payment_mode', title: 'Setup Payment Mode' }
      ]
    },
    {
      key: 'purchases',
      title: 'Purchases',
      children: [
        { key: 'purchase_bill', title: 'Purchase Bill' },
        { key: 'purchase_return', title: 'Purchase Return' }
      ]
    },
    {
      key: 'sales',
      title: 'Sales',
      children: [
        { key: 'pos', title: 'Sale Bill (POS)' },
        { key: 'sale_return', title: 'Sale Returns' }
      ]
    },
    {
      key: 'reports',
      title: 'Reports',
      children: [
        { key: 'sale_report', title: 'Sale & Sale Return Report' },
        { key: 'customer_report', title: 'Customer Report' },
        { key: 'purchase_report', title: 'Purchase & Return Report' },
        { key: 'hsn_report', title: 'HSN Wise Sale Report' },
        { key: 'staff_report', title: 'Staff Wise Sale Report' },
        { key: 'stock_report', title: 'Stock Report' }
      ]
    }
  ];

  // Permission types
  const permissionTypes = [
    { key: 'view', label: 'View', icon: <FiEye />, color: 'blue' },
    { key: 'create', label: 'Create', icon: <FiPlus />, color: 'green' },
    { key: 'edit', label: 'Edit', icon: <FiEdit />, color: 'orange' },
    { key: 'import', label: 'Import', icon: <FiUpload />, color: 'purple' },
    { key: 'export', label: 'Export', icon: <FiDownload />, color: 'cyan' },
    { key: 'print', label: 'Print', icon: <FiPrinter />, color: 'pink' },
    { key: 'modify_past', label: 'Modify Past', icon: <FiClock />, color: 'red' },
    { key: 'admin', label: 'Admin', icon: <FiUserCheck />, color: 'indigo' }
  ];

  // Fetch users
  const fetchUsers = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(
        `${API_URL}/setup/users`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setUsers(response.data.users || []);
    } catch (error) {
      toast.error('Failed to fetch users');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  // Fetch user permissions
  const fetchUserPermissions = async (userId) => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(
        `${API_URL}/setup/users/${userId}/permissions`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setPermissions(response.data.permissions || {});
    } catch (error) {
      toast.error('Failed to fetch user permissions');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  // Handle user selection
  const handleUserSelect = (user) => {
    setSelectedUser(user);
    fetchUserPermissions(user.id);
  };

  // Toggle menu expansion
  const toggleMenu = (menuKey) => {
    setExpandedMenus(prev => ({
      ...prev,
      [menuKey]: !prev[menuKey]
    }));
  };

  // Toggle permission
  const togglePermission = (menuKey, permissionType) => {
    setPermissions(prev => ({
      ...prev,
      [menuKey]: {
        ...prev[menuKey],
        [permissionType]: !prev[menuKey]?.[permissionType]
      }
    }));
  };

  // Toggle all permissions for a menu
  const toggleAllPermissions = (menuKey, enable) => {
    const newPermissions = {};
    permissionTypes.forEach(type => {
      newPermissions[type.key] = enable;
    });
    
    setPermissions(prev => ({
      ...prev,
      [menuKey]: newPermissions
    }));
  };

  // Apply template
  const applyTemplate = (template) => {
    const templates = {
      admin: {
        // Admin gets all permissions
        pattern: () => {
          const allPermissions = {};
          const addPermissions = (menu, parentKey = '') => {
            const key = parentKey ? `${parentKey}.${menu.key}` : menu.key;
            allPermissions[key] = {};
            permissionTypes.forEach(type => {
              allPermissions[key][type.key] = true;
            });
            if (menu.children) {
              menu.children.forEach(child => addPermissions(child, key));
            }
          };
          menuStructure.forEach(menu => addPermissions(menu));
          return allPermissions;
        }
      },
      manager: {
        // Manager gets most permissions except admin
        pattern: () => {
          const allPermissions = {};
          const addPermissions = (menu, parentKey = '') => {
            const key = parentKey ? `${parentKey}.${menu.key}` : menu.key;
            allPermissions[key] = {};
            permissionTypes.forEach(type => {
              allPermissions[key][type.key] = type.key !== 'admin';
            });
            if (menu.children) {
              menu.children.forEach(child => addPermissions(child, key));
            }
          };
          menuStructure.forEach(menu => addPermissions(menu));
          return allPermissions;
        }
      },
      staff: {
        // Staff gets basic permissions
        pattern: () => {
          const allPermissions = {};
          const basicMenus = ['sales', 'sales.pos', 'sales.sale_return', 'reports'];
          basicMenus.forEach(key => {
            allPermissions[key] = {
              view: true,
              create: true,
              print: true
            };
          });
          return allPermissions;
        }
      }
    };

    if (templates[template]) {
      setPermissions(templates[template].pattern());
      toast.success(`Applied ${template} template`);
    }
  };

  // Save permissions
  const savePermissions = async () => {
    if (!selectedUser) {
      toast.error('Please select a user first');
      return;
    }

    if (!window.confirm(`Save access permissions for ${selectedUser.display_name}?`)) {
      return;
    }

    setSaving(true);
    try {
      const token = localStorage.getItem('token');
      await axios.post(
        `${API_URL}/setup/users/${selectedUser.id}/permissions`,
        { permissions },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      toast.success('Permissions saved successfully');
    } catch (error) {
      toast.error('Failed to save permissions');
      console.error(error);
    } finally {
      setSaving(false);
    }
  };

  // Render menu item
  const renderMenuItem = (menu, parentKey = '', level = 0) => {
    const menuKey = parentKey ? `${parentKey}.${menu.key}` : menu.key;
    const hasChildren = menu.children && menu.children.length > 0;
    const isExpanded = expandedMenus[menuKey];
    const menuPermissions = permissions[menuKey] || {};

    return (
      <div key={menuKey} className="permission-item" style={{ marginLeft: level * 20 }}>
        <div className="permission-row">
          <div className="menu-name">
            {hasChildren && (
              <button
                className="expand-btn"
                onClick={() => toggleMenu(menuKey)}
              >
                {isExpanded ? <FiChevronDown /> : <FiChevronRight />}
              </button>
            )}
            <span className={`menu-label level-${level}`}>
              {menu.title}
            </span>
          </div>
          
          <div className="permission-toggles">
            {permissionTypes.map(type => (
              <button
                key={type.key}
                className={`permission-btn ${menuPermissions[type.key] ? 'active' : ''} ${type.color}`}
                onClick={() => togglePermission(menuKey, type.key)}
                title={type.label}
              >
                {type.icon}
              </button>
            ))}
            
            <div className="bulk-actions">
              <button
                className="bulk-btn enable"
                onClick={() => toggleAllPermissions(menuKey, true)}
                title="Enable all"
              >
                <FiCheck />
              </button>
              <button
                className="bulk-btn disable"
                onClick={() => toggleAllPermissions(menuKey, false)}
                title="Disable all"
              >
                <FiX />
              </button>
            </div>
          </div>
        </div>
        
        {hasChildren && isExpanded && (
          <div className="menu-children">
            {menu.children.map(child => 
              renderMenuItem(child, menuKey, level + 1)
            )}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="setup-container">
      {/* Header */}
      <div className="setup-header">
        <div className="header-left">
          <h1 className="page-title">
            <FiShield className="title-icon" />
            Assign Access of Menu Bar
          </h1>
          <p className="page-subtitle">Configure user permissions and access control</p>
        </div>
        
        <div className="header-actions">
          {selectedUser && (
            <button 
              className="btn btn-primary"
              onClick={savePermissions}
              disabled={saving}
            >
              <FiSave />
              {saving ? 'Saving...' : 'Save ACL'}
            </button>
          )}
        </div>
      </div>

      <div className="access-container">
        {/* User Selection */}
        <div className="user-selection">
          <h3 className="section-title">Select User</h3>
          <div className="users-list">
            {loading ? (
              <div className="loading-message">Loading users...</div>
            ) : users.length === 0 ? (
              <div className="empty-message">No users found</div>
            ) : (
              users.map(user => (
                <div
                  key={user.id}
                  className={`user-item ${selectedUser?.id === user.id ? 'selected' : ''}`}
                  onClick={() => handleUserSelect(user)}
                >
                  <div className="user-avatar">
                    {user.display_name.charAt(0).toUpperCase()}
                  </div>
                  <div className="user-details">
                    <p className="user-name">{user.display_name}</p>
                    <p className="user-role">@{user.username} • {user.role}</p>
                  </div>
                  <FiChevronRight className="select-icon" />
                </div>
              ))
            )}
          </div>
        </div>

        {/* Permissions Configuration */}
        <div className="permissions-config">
          {!selectedUser ? (
            <div className="empty-state">
              <FiUser className="empty-icon" />
              <h3>Select a user</h3>
              <p>Choose a user from the list to configure their access permissions</p>
            </div>
          ) : (
            <>
              <div className="config-header">
                <h3 className="section-title">
                  Permissions for {selectedUser.display_name}
                </h3>
                
                <div className="template-buttons">
                  <button
                    className="template-btn"
                    onClick={() => applyTemplate('admin')}
                  >
                    Apply Admin Template
                  </button>
                  <button
                    className="template-btn"
                    onClick={() => applyTemplate('manager')}
                  >
                    Apply Manager Template
                  </button>
                  <button
                    className="template-btn"
                    onClick={() => applyTemplate('staff')}
                  >
                    Apply Staff Template
                  </button>
                </div>
              </div>

              <div className="permission-legend">
                {permissionTypes.map(type => (
                  <div key={type.key} className="legend-item">
                    <span className={`legend-icon ${type.color}`}>
                      {type.icon}
                    </span>
                    <span className="legend-label">{type.label}</span>
                  </div>
                ))}
              </div>

              <div className="permissions-tree">
                {menuStructure.map(menu => renderMenuItem(menu))}
              </div>
            </>
          )}
        </div>
      </div>

      {/* Additional Styles */}
      <style jsx>{`
        .access-container {
          display: grid;
          grid-template-columns: 350px 1fr;
          gap: 2rem;
          margin-top: 2rem;
        }
        
        .user-selection {
          background: white;
          border-radius: 16px;
          padding: 1.5rem;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.06);
          max-height: calc(100vh - 250px);
          overflow-y: auto;
        }
        
        .section-title {
          font-size: 1.125rem;
          font-weight: 700;
          color: #1f2937;
          margin: 0 0 1.5rem 0;
        }
        
        .users-list {
          display: flex;
          flex-direction: column;
          gap: 0.75rem;
        }
        
        .user-item {
          display: flex;
          align-items: center;
          gap: 1rem;
          padding: 1rem;
          background: #f9fafb;
          border-radius: 12px;
          cursor: pointer;
          transition: all 0.3s ease;
          border: 2px solid transparent;
        }
        
        .user-item:hover {
          background: linear-gradient(135deg, rgba(147, 51, 234, 0.05) 0%, rgba(79, 70, 229, 0.05) 100%);
          border-color: rgba(147, 51, 234, 0.2);
        }
        
        .user-item.selected {
          background: linear-gradient(135deg, rgba(147, 51, 234, 0.1) 0%, rgba(79, 70, 229, 0.1) 100%);
          border-color: #9333ea;
        }
        
        .user-avatar {
          width: 40px;
          height: 40px;
          border-radius: 50%;
          background: linear-gradient(135deg, #9333ea 0%, #4f46e5 100%);
          color: white;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: 700;
          flex-shrink: 0;
        }
        
        .user-details {
          flex: 1;
        }
        
        .user-name {
          font-weight: 600;
          color: #1f2937;
          margin: 0 0 0.25rem 0;
        }
        
        .user-role {
          font-size: 0.875rem;
          color: #6b7280;
          margin: 0;
        }
        
        .select-icon {
          color: #9ca3af;
          transition: all 0.3s ease;
        }
        
        .user-item.selected .select-icon {
          color: #9333ea;
          transform: translateX(4px);
        }
        
        .permissions-config {
          background: white;
          border-radius: 16px;
          padding: 1.5rem;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.06);
          max-height: calc(100vh - 250px);
          overflow-y: auto;
        }
        
        .config-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 1.5rem;
        }
        
        .template-buttons {
          display: flex;
          gap: 0.75rem;
        }
        
        .template-btn {
          padding: 0.5rem 1rem;
          background: linear-gradient(135deg, #f3f4f6 0%, #e5e7eb 100%);
          border: none;
          border-radius: 8px;
          color: #4b5563;
          font-weight: 600;
          font-size: 0.875rem;
          cursor: pointer;
          transition: all 0.3s ease;
        }
        
        .template-btn:hover {
          background: linear-gradient(135deg, #9333ea 0%, #4f46e5 100%);
          color: white;
        }
        
        .permission-legend {
          display: flex;
          gap: 1.5rem;
          padding: 1rem;
          background: #f9fafb;
          border-radius: 12px;
          margin-bottom: 1.5rem;
        }
        
        .legend-item {
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }
        
        .legend-icon {
          width: 28px;
          height: 28px;
          border-radius: 6px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 0.875rem;
          color: white;
        }
        
        .legend-icon.blue { background: #3b82f6; }
        .legend-icon.green { background: #10b981; }
        .legend-icon.orange { background: #f59e0b; }
        .legend-icon.purple { background: #9333ea; }
        .legend-icon.cyan { background: #06b6d4; }
        .legend-icon.pink { background: #ec4899; }
        .legend-icon.red { background: #ef4444; }
        .legend-icon.indigo { background: #6366f1; }
        
        .legend-label {
          font-size: 0.875rem;
          color: #4b5563;
          font-weight: 500;
        }
        
        .permissions-tree {
          border: 2px solid #e5e7eb;
          border-radius: 12px;
          overflow: hidden;
        }
        
        .permission-item {
          border-bottom: 1px solid #f3f4f6;
        }
        
        .permission-item:last-child {
          border-bottom: none;
        }
        
        .permission-row {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 0.75rem 1rem;
          background: white;
          transition: background 0.3s ease;
        }
        
        .permission-row:hover {
          background: #f9fafb;
        }
        
        .menu-name {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          flex: 1;
        }
        
        .expand-btn {
          background: transparent;
          border: none;
          color: #6b7280;
          cursor: pointer;
          padding: 0.25rem;
          font-size: 1rem;
          transition: all 0.3s ease;
        }
        
        .expand-btn:hover {
          color: #9333ea;
        }
        
        .menu-label {
          font-weight: 600;
          color: #1f2937;
        }
        
        .menu-label.level-0 {
          font-size: 1rem;
        }
        
        .menu-label.level-1 {
          font-size: 0.925rem;
          font-weight: 500;
        }
        
        .menu-label.level-2 {
          font-size: 0.875rem;
          font-weight: 400;
          color: #4b5563;
        }
        
        .permission-toggles {
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }
        
        .permission-btn {
          width: 32px;
          height: 32px;
          border-radius: 6px;
          border: 2px solid #e5e7eb;
          background: white;
          color: #9ca3af;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          transition: all 0.3s ease;
          font-size: 0.875rem;
        }
        
        .permission-btn:hover {
          transform: scale(1.1);
        }
        
        .permission-btn.active {
          color: white;
          border-color: transparent;
        }
        
        .permission-btn.active.blue { background: #3b82f6; }
        .permission-btn.active.green { background: #10b981; }
        .permission-btn.active.orange { background: #f59e0b; }
        .permission-btn.active.purple { background: #9333ea; }
        .permission-btn.active.cyan { background: #06b6d4; }
        .permission-btn.active.pink { background: #ec4899; }
        .permission-btn.active.red { background: #ef4444; }
        .permission-btn.active.indigo { background: #6366f1; }
        
        .bulk-actions {
          display: flex;
          gap: 0.25rem;
          margin-left: 1rem;
          padding-left: 1rem;
          border-left: 2px solid #e5e7eb;
        }
        
        .bulk-btn {
          width: 28px;
          height: 28px;
          border-radius: 6px;
          border: none;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          transition: all 0.3s ease;
          font-size: 0.875rem;
        }
        
        .bulk-btn.enable {
          background: #d1fae5;
          color: #065f46;
        }
        
        .bulk-btn.enable:hover {
          background: #10b981;
          color: white;
        }
        
        .bulk-btn.disable {
          background: #fee2e2;
          color: #991b1b;
        }
        
        .bulk-btn.disable:hover {
          background: #ef4444;
          color: white;
        }
        
        .menu-children {
          background: #fafafa;
        }
        
        .loading-message,
        .empty-message {
          text-align: center;
          color: #9ca3af;
          padding: 2rem;
        }
        
        @media (max-width: 1024px) {
          .access-container {
            grid-template-columns: 1fr;
          }
          
          .user-selection {
            max-height: 300px;
          }
        }
        
        @media (max-width: 768px) {
          .permission-toggles {
            flex-wrap: wrap;
          }
          
          .template-buttons {
            flex-direction: column;
          }
          
          .permission-legend {
            flex-wrap: wrap;
          }
        }
      `}</style>
    </div>
  );
}

export default UserAccess;