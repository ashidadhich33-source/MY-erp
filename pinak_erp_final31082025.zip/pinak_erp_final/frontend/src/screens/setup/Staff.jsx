import React, { useState, useEffect } from 'react';
import { 
  FiUsers, FiPlus, FiSave, FiEdit2, FiTrash2,
  FiPhone, FiMail, FiMapPin, FiClock, FiDollarSign,
  FiAward, FiCalendar, FiRefreshCw, FiUserCheck, FiSearch
} from 'react-icons/fi';
import toast from 'react-hot-toast';
import axios from 'axios';
import './SetupScreens.css';

const API_URL = 'http://localhost:8000/api/v1';

function Staff() {
  const [staff, setStaff] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editingStaff, setEditingStaff] = useState(null);
  const [filterRole, setFilterRole] = useState('all');
  
  // Form state
  const [formData, setFormData] = useState({
    code: '',
    name: '',
    mobile: '',
    email: '',
    role: 'sales',
    department: 'sales',
    join_date: '',
    birth_date: '',
    address: '',
    city: '',
    pincode: '',
    salary: '',
    commission_rate: 0,
    target: 0,
    emergency_contact: '',
    emergency_name: '',
    active: true
  });

  // Validation errors
  const [errors, setErrors] = useState({});

  // Stats
  const [stats, setStats] = useState({
    total: 0,
    active: 0,
    salesStaff: 0,
    managers: 0,
    totalSalary: 0,
    avgCommission: 0
  });

  // Roles and departments
  const roles = [
    { value: 'sales', label: 'Sales Executive' },
    { value: 'cashier', label: 'Cashier' },
    { value: 'manager', label: 'Store Manager' },
    { value: 'supervisor', label: 'Supervisor' },
    { value: 'helper', label: 'Helper' },
    { value: 'security', label: 'Security' }
  ];

  const departments = [
    { value: 'sales', label: 'Sales' },
    { value: 'accounts', label: 'Accounts' },
    { value: 'warehouse', label: 'Warehouse' },
    { value: 'admin', label: 'Administration' },
    { value: 'support', label: 'Support' }
  ];

  // Fetch staff
  const fetchStaff = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(
        `${API_URL}/setup/staff`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      const staffData = response.data || [];
      setStaff(staffData);
      
      // Calculate stats
      const activeStaff = staffData.filter(s => s.active);
      const totalSalary = staffData.reduce((sum, s) => sum + (s.salary || 0), 0);
      const avgCommission = staffData.reduce((sum, s) => sum + s.commission_rate, 0) / (staffData.length || 1);
      
      setStats({
        total: staffData.length,
        active: activeStaff.length,
        salesStaff: staffData.filter(s => s.role === 'sales').length,
        managers: staffData.filter(s => s.role === 'manager').length,
        totalSalary,
        avgCommission: avgCommission.toFixed(2)
      });
    } catch (error) {
      toast.error('Failed to fetch staff');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStaff();
    generateStaffCode();
  }, []);

  // Generate unique staff code
  const generateStaffCode = () => {
    const code = `STF${Date.now().toString().slice(-6)}`;
    setFormData(prev => ({ ...prev, code }));
  };

  // Filter staff
  const filteredStaff = staff.filter(member => {
    const matchesSearch = member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         member.mobile.includes(searchTerm) ||
                         member.code.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = filterRole === 'all' || member.role === filterRole;
    return matchesSearch && matchesRole;
  });

  // Validate form
  const validateForm = () => {
    const newErrors = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Name is required';
    }

    if (!formData.mobile.trim()) {
      newErrors.mobile = 'Mobile is required';
    } else if (!/^[6-9]\d{9}$/.test(formData.mobile)) {
      newErrors.mobile = 'Invalid mobile number';
    }

    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Invalid email format';
    }

    if (!formData.join_date) {
      newErrors.join_date = 'Join date is required';
    }

    if (formData.commission_rate < 0 || formData.commission_rate > 100) {
      newErrors.commission_rate = 'Commission rate must be between 0 and 100';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      toast.error('Please fix the errors in the form');
      return;
    }

    const confirmMsg = editingStaff 
      ? 'Update staff details?' 
      : 'Add new staff member?';
      
    if (!window.confirm(confirmMsg)) return;

    try {
      const token = localStorage.getItem('token');
      const endpoint = editingStaff 
        ? `${API_URL}/setup/staff/${editingStaff.id}`
        : `${API_URL}/setup/staff`;
      
      const method = editingStaff ? 'put' : 'post';
      
      await axios[method](endpoint, formData, {
        headers: { Authorization: `Bearer ${token}` }
      });

      toast.success(`Staff ${editingStaff ? 'updated' : 'added'} successfully`);
      setShowModal(false);
      resetForm();
      fetchStaff();
    } catch (error) {
      if (error.response?.data?.detail) {
        toast.error(error.response.data.detail);
      } else {
        toast.error('Failed to save staff');
      }
    }
  };

  // Reset form
  const resetForm = () => {
    setFormData({
      code: '',
      name: '',
      mobile: '',
      email: '',
      role: 'sales',
      department: 'sales',
      join_date: '',
      birth_date: '',
      address: '',
      city: '',
      pincode: '',
      salary: '',
      commission_rate: 0,
      target: 0,
      emergency_contact: '',
      emergency_name: '',
      active: true
    });
    setEditingStaff(null);
    setErrors({});
    generateStaffCode();
  };

  // Edit staff
  const handleEdit = (staffMember) => {
    setFormData({
      ...staffMember,
      join_date: staffMember.join_date.split('T')[0],
      birth_date: staffMember.birth_date ? staffMember.birth_date.split('T')[0] : ''
    });
    setEditingStaff(staffMember);
    setShowModal(true);
  };

  // Toggle status
  const toggleStatus = async (staffMember) => {
    try {
      const token = localStorage.getItem('token');
      await axios.patch(
        `${API_URL}/setup/staff/${staffMember.id}/toggle-status`,
        {},
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      toast.success(`Staff ${staffMember.active ? 'deactivated' : 'activated'}`);
      fetchStaff();
    } catch (error) {
      toast.error('Failed to update staff status');
    }
  };

  // Delete staff
  const handleDelete = async (staffMember) => {
    if (!window.confirm(`Delete staff member "${staffMember.name}"?`)) {
      return;
    }

    try {
      const token = localStorage.getItem('token');
      await axios.delete(
        `${API_URL}/setup/staff/${staffMember.id}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      toast.success('Staff deleted successfully');
      fetchStaff();
    } catch (error) {
      toast.error('Failed to delete staff');
    }
  };

  // Calculate attendance (mock)
  const getAttendancePercentage = (staffMember) => {
    // Mock calculation - in real app, this would come from attendance data
    return Math.floor(Math.random() * (100 - 75) + 75);
  };

  return (
    <div className="setup-container">
      {/* Header */}
      <div className="setup-header">
        <div className="header-left">
          <h1 className="page-title">
            <FiUsers className="title-icon" />
            Staff Management
          </h1>
          <p className="page-subtitle">Manage staff profiles, roles and commissions</p>
        </div>
        <div className="header-actions">
          <button className="btn-refresh" onClick={fetchStaff}>
            <FiRefreshCw /> Refresh
          </button>
          <button className="btn-primary" onClick={() => setShowModal(true)}>
            <FiPlus /> Add Staff
          </button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon-wrapper purple">
            <FiUsers />
          </div>
          <div className="stat-content">
            <p className="stat-label">Total Staff</p>
            <p className="stat-value">{stats.total}</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon-wrapper green">
            <FiUserCheck />
          </div>
          <div className="stat-content">
            <p className="stat-label">Active Staff</p>
            <p className="stat-value">{stats.active}</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon-wrapper blue">
            <FiDollarSign />
          </div>
          <div className="stat-content">
            <p className="stat-label">Total Salary</p>
            <p className="stat-value">₹{stats.totalSalary.toLocaleString()}</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon-wrapper orange">
            <FiAward />
          </div>
          <div className="stat-content">
            <p className="stat-label">Avg Commission</p>
            <p className="stat-value">{stats.avgCommission}%</p>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="filters-bar">
        <div className="search-box">
          <FiSearch className="search-icon" />
          <input
            type="text"
            placeholder="Search by name, mobile or code..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="search-input"
          />
        </div>
        
        <select 
          value={filterRole}
          onChange={(e) => setFilterRole(e.target.value)}
          className="filter-select"
        >
          <option value="all">All Roles</option>
          {roles.map(role => (
            <option key={role.value} value={role.value}>{role.label}</option>
          ))}
        </select>
      </div>

      {/* Staff Table */}
      <div className="table-container">
        <table className="data-table">
          <thead>
            <tr>
              <th>Code</th>
              <th>Name</th>
              <th>Contact</th>
              <th>Role</th>
              <th>Department</th>
              <th>Join Date</th>
              <th>Commission</th>
              <th>Attendance</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan="10" className="text-center">
                  <div className="loading-spinner">Loading...</div>
                </td>
              </tr>
            ) : filteredStaff.length === 0 ? (
              <tr>
                <td colSpan="10" className="text-center empty-state">
                  <FiUsers size={48} />
                  <p>No staff members found</p>
                </td>
              </tr>
            ) : (
              filteredStaff.map((member) => (
                <tr key={member.id}>
                  <td className="code-cell">{member.code}</td>
                  <td>
                    <div className="name-cell">
                      <div className="name-primary">{member.name}</div>
                      {member.birth_date && (
                        <div className="name-secondary">
                          <FiCalendar size={12} /> {new Date(member.birth_date).toLocaleDateString()}
                        </div>
                      )}
                    </div>
                  </td>
                  <td>
                    <div className="contact-cell">
                      <div><FiPhone size={12} /> {member.mobile}</div>
                      {member.email && (
                        <div><FiMail size={12} /> {member.email}</div>
                      )}
                    </div>
                  </td>
                  <td>
                    <span className="role-badge">
                      {roles.find(r => r.value === member.role)?.label}
                    </span>
                  </td>
                  <td>{departments.find(d => d.value === member.department)?.label}</td>
                  <td>{new Date(member.join_date).toLocaleDateString()}</td>
                  <td className="commission-cell">
                    {member.commission_rate}%
                  </td>
                  <td>
                    <div className="attendance-cell">
                      <div className="attendance-bar">
                        <div 
                          className="attendance-fill"
                          style={{ width: `${getAttendancePercentage(member)}%` }}
                        />
                      </div>
                      <span className="attendance-text">
                        {getAttendancePercentage(member)}%
                      </span>
                    </div>
                  </td>
                  <td>
                    <span className={`status-badge ${member.active ? 'active' : 'inactive'}`}>
                      {member.active ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td>
                    <div className="action-buttons">
                      <button 
                        className="btn-icon"
                        onClick={() => handleEdit(member)}
                        title="Edit"
                      >
                        <FiEdit2 />
                      </button>
                      <button 
                        className="btn-icon"
                        onClick={() => toggleStatus(member)}
                        title={member.active ? 'Deactivate' : 'Activate'}
                      >
                        <FiUserCheck />
                      </button>
                      <button 
                        className="btn-icon btn-danger"
                        onClick={() => handleDelete(member)}
                        title="Delete"
                      >
                        <FiTrash2 />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Add/Edit Modal */}
      {showModal && (
        <div className="modal-overlay">
          <div className="modal-content modal-lg">
            <div className="modal-header">
              <h2>{editingStaff ? 'Edit Staff' : 'Add Staff Member'}</h2>
              <button className="btn-close" onClick={() => {
                setShowModal(false);
                resetForm();
              }}>×</button>
            </div>

            <form onSubmit={handleSubmit} className="modal-form">
              <div className="form-section">
                <h3>Basic Information</h3>
                <div className="form-row">
                  <div className="form-group">
                    <label>Staff Code</label>
                    <input
                      type="text"
                      value={formData.code}
                      readOnly
                      className="readonly"
                    />
                  </div>

                  <div className="form-group">
                    <label>Name *</label>
                    <input
                      type="text"
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                      className={errors.name ? 'error' : ''}
                    />
                    {errors.name && <span className="error-message">{errors.name}</span>}
                  </div>
                </div>

                <div className="form-row">
                  <div className="form-group">
                    <label>Mobile *</label>
                    <input
                      type="text"
                      value={formData.mobile}
                      onChange={(e) => setFormData({...formData, mobile: e.target.value})}
                      maxLength="10"
                      className={errors.mobile ? 'error' : ''}
                    />
                    {errors.mobile && <span className="error-message">{errors.mobile}</span>}
                  </div>

                  <div className="form-group">
                    <label>Email</label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                      className={errors.email ? 'error' : ''}
                    />
                    {errors.email && <span className="error-message">{errors.email}</span>}
                  </div>
                </div>

                <div className="form-row">
                  <div className="form-group">
                    <label>Role *</label>
                    <select
                      value={formData.role}
                      onChange={(e) => setFormData({...formData, role: e.target.value})}
                    >
                      {roles.map(role => (
                        <option key={role.value} value={role.value}>
                          {role.label}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="form-group">
                    <label>Department *</label>
                    <select
                      value={formData.department}
                      onChange={(e) => setFormData({...formData, department: e.target.value})}
                    >
                      {departments.map(dept => (
                        <option key={dept.value} value={dept.value}>
                          {dept.label}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              <div className="form-section">
                <h3>Employment Details</h3>
                <div className="form-row">
                  <div className="form-group">
                    <label>Join Date *</label>
                    <input
                      type="date"
                      value={formData.join_date}
                      onChange={(e) => setFormData({...formData, join_date: e.target.value})}
                      className={errors.join_date ? 'error' : ''}
                    />
                    {errors.join_date && <span className="error-message">{errors.join_date}</span>}
                  </div>

                  <div className="form-group">
                    <label>Birth Date</label>
                    <input
                      type="date"
                      value={formData.birth_date}
                      onChange={(e) => setFormData({...formData, birth_date: e.target.value})}
                    />
                  </div>
                </div>

                <div className="form-row">
                  <div className="form-group">
                    <label>Monthly Salary</label>
                    <input
                      type="number"
                      value={formData.salary}
                      onChange={(e) => setFormData({...formData, salary: e.target.value})}
                      placeholder="₹"
                    />
                  </div>

                  <div className="form-group">
                    <label>Commission Rate (%)</label>
                    <input
                      type="number"
                      value={formData.commission_rate}
                      onChange={(e) => setFormData({...formData, commission_rate: e.target.value})}
                      min="0"
                      max="100"
                      step="0.1"
                      className={errors.commission_rate ? 'error' : ''}
                    />
                    {errors.commission_rate && <span className="error-message">{errors.commission_rate}</span>}
                  </div>

                  <div className="form-group">
                    <label>Monthly Target</label>
                    <input
                      type="number"
                      value={formData.target}
                      onChange={(e) => setFormData({...formData, target: e.target.value})}
                      placeholder="₹"
                    />
                  </div>
                </div>
              </div>

              <div className="form-section">
                <h3>Address & Emergency Contact</h3>
                <div className="form-group">
                  <label>Address</label>
                  <textarea
                    value={formData.address}
                    onChange={(e) => setFormData({...formData, address: e.target.value})}
                    rows="2"
                  />
                </div>

                <div className="form-row">
                  <div className="form-group">
                    <label>City</label>
                    <input
                      type="text"
                      value={formData.city}
                      onChange={(e) => setFormData({...formData, city: e.target.value})}
                    />
                  </div>

                  <div className="form-group">
                    <label>Pincode</label>
                    <input
                      type="text"
                      value={formData.pincode}
                      onChange={(e) => setFormData({...formData, pincode: e.target.value})}
                      maxLength="6"
                    />
                  </div>
                </div>

                <div className="form-row">
                  <div className="form-group">
                    <label>Emergency Contact Name</label>
                    <input
                      type="text"
                      value={formData.emergency_name}
                      onChange={(e) => setFormData({...formData, emergency_name: e.target.value})}
                    />
                  </div>

                  <div className="form-group">
                    <label>Emergency Contact Number</label>
                    <input
                      type="text"
                      value={formData.emergency_contact}
                      onChange={(e) => setFormData({...formData, emergency_contact: e.target.value})}
                      maxLength="10"
                    />
                  </div>
                </div>
              </div>

              <div className="form-group">
                <label className="checkbox-label">
                  <input
                    type="checkbox"
                    checked={formData.active}
                    onChange={(e) => setFormData({...formData, active: e.target.checked})}
                  />
                  Active
                </label>
              </div>

              <div className="modal-footer">
                <button 
                  type="button" 
                  className="btn-secondary"
                  onClick={() => {
                    setShowModal(false);
                    resetForm();
                  }}
                >
                  Cancel
                </button>
                <button type="submit" className="btn-primary">
                  <FiSave /> {editingStaff ? 'Update' : 'Save'} Staff
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default Staff;