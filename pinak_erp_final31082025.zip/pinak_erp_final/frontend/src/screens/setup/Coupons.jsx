import React, { useState, useEffect } from 'react';
import { 
  FiTag, FiPlus, FiEdit2, FiTrash2, FiSave,
  FiPercent, FiDollarSign, FiCalendar, FiUser,
  FiToggleLeft, FiToggleRight, FiX, FiCopy,
  FiSend, FiCheckCircle, FiAlertCircle, FiSearch
} from 'react-icons/fi';
import toast from 'react-hot-toast';
import axios from 'axios';
import './SetupScreens.css';

const API_URL = 'http://localhost:8000/api/v1';

function Coupons() {
  const [coupons, setCoupons] = useState([]);
  const [loading, setLoading] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [editingCoupon, setEditingCoupon] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState('all'); // all, active, expired, used
  
  // Form state
  const [formData, setFormData] = useState({
    code: '',
    type: 'percent', // percent or flat
    value: '',
    max_cap: '',
    valid_from: '',
    valid_to: '',
    min_bill: '',
    bound_mobile: '',
    active: true,
    description: ''
  });

  // Validation errors
  const [errors, setErrors] = useState({});

  // Stats
  const [stats, setStats] = useState({
    total: 0,
    active: 0,
    expired: 0,
    used: 0
  });

  // Fetch coupons
  const fetchCoupons = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(
        `${API_URL}/setup/coupons`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      const couponsData = response.data.coupons || [];
      setCoupons(couponsData);
      
      // Calculate stats
      const now = new Date();
      setStats({
        total: couponsData.length,
        active: couponsData.filter(c => c.active && new Date(c.valid_to) >= now).length,
        expired: couponsData.filter(c => new Date(c.valid_to) < now).length,
        used: couponsData.filter(c => c.used_count > 0).length
      });
    } catch (error) {
      toast.error('Failed to fetch coupons');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCoupons();
  }, []);

  // Generate random coupon code
  const generateCode = () => {
    const prefix = 'PINAK';
    const random = Math.random().toString(36).substring(2, 8).toUpperCase();
    setFormData({ ...formData, code: `${prefix}${random}` });
  };

  // Validate form
  const validateForm = () => {
    const newErrors = {};

    if (!formData.code.trim()) {
      newErrors.code = 'Coupon code is required';
    } else if (formData.code.length < 4) {
      newErrors.code = 'Code must be at least 4 characters';
    }

    if (!formData.value) {
      newErrors.value = 'Value is required';
    } else if (formData.type === 'percent' && (formData.value <= 0 || formData.value > 100)) {
      newErrors.value = 'Percentage must be between 1 and 100';
    } else if (formData.type === 'flat' && formData.value <= 0) {
      newErrors.value = 'Amount must be positive';
    }

    if (formData.type === 'percent' && formData.max_cap && formData.max_cap < 0) {
      newErrors.max_cap = 'Max cap must be positive';
    }

    if (!formData.valid_from) {
      newErrors.valid_from = 'Valid from date is required';
    }

    if (!formData.valid_to) {
      newErrors.valid_to = 'Valid to date is required';
    } else if (new Date(formData.valid_to) < new Date(formData.valid_from)) {
      newErrors.valid_to = 'Valid to must be after valid from';
    }

    if (formData.min_bill && formData.min_bill < 0) {
      newErrors.min_bill = 'Minimum bill must be positive';
    }

    if (formData.bound_mobile && !/^[6-9]\d{9}$/.test(formData.bound_mobile)) {
      newErrors.bound_mobile = 'Invalid mobile number';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      toast.error('Please fix the errors in the form');
      return;
    }

    try {
      const token = localStorage.getItem('token');
      const endpoint = editingCoupon 
        ? `${API_URL}/setup/coupons/${editingCoupon.id}`
        : `${API_URL}/setup/coupons`;
      
      const method = editingCoupon ? 'put' : 'post';
      
      await axios[method](endpoint, formData, {
        headers: { Authorization: `Bearer ${token}` } }
      );

      toast.success(`Coupon ${editingCoupon ? 'updated' : 'created'} successfully`);
      setShowModal(false);
      resetForm();
      fetchCoupons();
    } catch (error) {
      if (error.response?.data?.detail) {
        toast.error(error.response.data.detail);
      } else {
        toast.error('Failed to save coupon');
      }
    }
  };

  // Reset form
  const resetForm = () => {
    setFormData({
      code: '',
      type: 'percent',
      value: '',
      max_cap: '',
      valid_from: '',
      valid_to: '',
      min_bill: '',
      bound_mobile: '',
      active: true,
      description: ''
    });
    setEditingCoupon(null);
    setErrors({});
  };

  // Edit coupon
  const handleEdit = (coupon) => {
    setFormData({
      ...coupon,
      valid_from: coupon.valid_from.split('T')[0],
      valid_to: coupon.valid_to.split('T')[0]
    });
    setEditingCoupon(coupon);
    setShowModal(true);
  };

  // Toggle coupon status
  const toggleStatus = async (coupon) => {
    try {
      const token = localStorage.getItem('token');
      await axios.patch(
        `${API_URL}/setup/coupons/${coupon.id}/toggle-status`,
        {},
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      toast.success(`Coupon ${coupon.active ? 'deactivated' : 'activated'}`);
      fetchCoupons();
    } catch (error) {
      toast.error('Failed to update coupon status');
    }
  };

  // Delete coupon
  const handleDelete = async (coupon) => {
    if (!window.confirm(`Delete coupon "${coupon.code}"? This action cannot be undone.`)) {
      return;
    }

    try {
      const token = localStorage.getItem('token');
      await axios.delete(
        `${API_URL}/setup/coupons/${coupon.id}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      toast.success('Coupon deleted successfully');
      fetchCoupons();
    } catch (error) {
      toast.error('Failed to delete coupon');
    }
  };

  // Copy coupon code
  const copyCode = (code) => {
    navigator.clipboard.writeText(code);
    toast.success(`Copied: ${code}`);
  };

  // Send coupon via WhatsApp
  const sendWhatsApp = async (coupon) => {
    if (!coupon.bound_mobile) {
      toast.error('This coupon is not bound to a mobile number');
      return;
    }

    try {
      const token = localStorage.getItem('token');
      await axios.post(
        `${API_URL}/setup/coupons/${coupon.id}/send-whatsapp`,
        {},
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      toast.success('Coupon sent via WhatsApp');
    } catch (error) {
      toast.error('Failed to send coupon');
    }
  };

  // Check if coupon is expired
  const isExpired = (coupon) => {
    return new Date(coupon.valid_to) < new Date();
  };

  // Filter coupons
  const filteredCoupons = coupons.filter(coupon => {
    const matchesSearch = searchTerm === '' || 
      coupon.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      coupon.description?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesFilter = 
      filter === 'all' ||
      (filter === 'active' && coupon.active && !isExpired(coupon)) ||
      (filter === 'expired' && isExpired(coupon)) ||
      (filter === 'used' && coupon.used_count > 0);
    
    return matchesSearch && matchesFilter;
  });

  // Format date for display
  const formatDate = (date) => {
    return new Date(date).toLocaleDateString('en-IN');
  };

  // Calculate discount display
  const getDiscountDisplay = (coupon) => {
    if (coupon.type === 'percent') {
      return `${coupon.value}% OFF${coupon.max_cap ? ` (Max ₹${coupon.max_cap})` : ''}`;
    }
    return `₹${coupon.value} OFF`;
  };

  return (
    <div className="setup-container">
      {/* Header */}
      <div className="setup-header">
        <div className="header-left">
          <h1 className="page-title">
            <FiTag className="title-icon" />
            Setup Coupons
          </h1>
          <p className="page-subtitle">Create and manage discount coupons</p>
        </div>
        
        <div className="header-actions">
          <button 
            className="btn btn-primary"
            onClick={() => {
              resetForm();
              setShowModal(true);
            }}
          >
            <FiPlus />
            New Coupon
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon blue">
            <FiTag />
          </div>
          <div className="stat-content">
            <p className="stat-label">Total Coupons</p>
            <p className="stat-value">{stats.total}</p>
          </div>
        </div>
        
        <div className="stat-card">
          <div className="stat-icon green">
            <FiCheckCircle />
          </div>
          <div className="stat-content">
            <p className="stat-label">Active</p>
            <p className="stat-value">{stats.active}</p>
          </div>
        </div>
        
        <div className="stat-card">
          <div className="stat-icon red">
            <FiAlertCircle />
          </div>
          <div className="stat-content">
            <p className="stat-label">Expired</p>
            <p className="stat-value">{stats.expired}</p>
          </div>
        </div>
        
        <div className="stat-card">
          <div className="stat-icon purple">
            <FiUser />
          </div>
          <div className="stat-content">
            <p className="stat-label">Used</p>
            <p className="stat-value">{stats.used}</p>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="search-section">
        <div className="search-box">
          <FiSearch className="search-icon" />
          <input
            type="text"
            placeholder="Search by code or description..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="search-input"
          />
        </div>
        
        <div className="filter-tabs">
          <button
            className={`filter-tab ${filter === 'all' ? 'active' : ''}`}
            onClick={() => setFilter('all')}
          >
            All
          </button>
          <button
            className={`filter-tab ${filter === 'active' ? 'active' : ''}`}
            onClick={() => setFilter('active')}
          >
            Active
          </button>
          <button
            className={`filter-tab ${filter === 'expired' ? 'active' : ''}`}
            onClick={() => setFilter('expired')}
          >
            Expired
          </button>
          <button
            className={`filter-tab ${filter === 'used' ? 'active' : ''}`}
            onClick={() => setFilter('used')}
          >
            Used
          </button>
        </div>
      </div>

      {/* Coupons Grid */}
      {loading ? (
        <div className="loading-container">
          <div className="loading-spinner"></div>
          <p>Loading coupons...</p>
        </div>
      ) : filteredCoupons.length === 0 ? (
        <div className="empty-state">
          <FiTag className="empty-icon" />
          <h3>No coupons found</h3>
          <p>Start by creating your first discount coupon</p>
        </div>
      ) : (
        <div className="coupons-grid">
          {filteredCoupons.map(coupon => (
            <div key={coupon.id} className={`coupon-card ${isExpired(coupon) ? 'expired' : ''}`}>
              <div className="coupon-header">
                <div className="coupon-code-section">
                  <h3 className="coupon-code">{coupon.code}</h3>
                  <button
                    className="copy-btn"
                    onClick={() => copyCode(coupon.code)}
                    title="Copy code"
                  >
                    <FiCopy />
                  </button>
                </div>
                <button
                  className={`status-toggle ${coupon.active ? 'active' : ''}`}
                  onClick={() => toggleStatus(coupon)}
                  disabled={isExpired(coupon)}
                >
                  {coupon.active ? <FiToggleRight /> : <FiToggleLeft />}
                </button>
              </div>
              
              <div className="coupon-body">
                <div className="discount-display">
                  {coupon.type === 'percent' ? <FiPercent /> : <FiDollarSign />}
                  <span className="discount-text">{getDiscountDisplay(coupon)}</span>
                </div>
                
                {coupon.description && (
                  <p className="coupon-description">{coupon.description}</p>
                )}
                
                <div className="coupon-details">
                  {coupon.min_bill > 0 && (
                    <div className="detail-item">
                      <span className="detail-label">Min Bill:</span>
                      <span className="detail-value">₹{coupon.min_bill}</span>
                    </div>
                  )}
                  
                  <div className="detail-item">
                    <span className="detail-label">Valid:</span>
                    <span className="detail-value">
                      {formatDate(coupon.valid_from)} - {formatDate(coupon.valid_to)}
                    </span>
                  </div>
                  
                  {coupon.bound_mobile && (
                    <div className="detail-item">
                      <span className="detail-label">Bound to:</span>
                      <span className="detail-value">{coupon.bound_mobile}</span>
                    </div>
                  )}
                  
                  <div className="detail-item">
                    <span className="detail-label">Used:</span>
                    <span className="detail-value">{coupon.used_count || 0} times</span>
                  </div>
                </div>
                
                {isExpired(coupon) && (
                  <div className="expired-badge">
                    <FiAlertCircle />
                    Expired
                  </div>
                )}
              </div>
              
              <div className="coupon-footer">
                <button
                  className="btn-icon"
                  onClick={() => handleEdit(coupon)}
                >
                  <FiEdit2 />
                </button>
                {coupon.bound_mobile && (
                  <button
                    className="btn-icon"
                    onClick={() => sendWhatsApp(coupon)}
                    title="Send via WhatsApp"
                  >
                    <FiSend />
                  </button>
                )}
                <button
                  className="btn-icon danger"
                  onClick={() => handleDelete(coupon)}
                >
                  <FiTrash2 />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add/Edit Modal */}
      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal-content modal-large" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h2>{editingCoupon ? 'Edit Coupon' : 'Create New Coupon'}</h2>
              <button className="modal-close" onClick={() => setShowModal(false)}>
                <FiX />
              </button>
            </div>
            
            <form onSubmit={handleSubmit} className="coupon-form">
              <div className="form-grid">
                <div className="form-group">
                  <label>Coupon Code *</label>
                  <div className="code-input-group">
                    <input
                      type="text"
                      value={formData.code}
                      onChange={(e) => setFormData({ ...formData, code: e.target.value.toUpperCase() })}
                      className={`form-input ${errors.code ? 'error' : ''}`}
                      placeholder="Enter code"
                    />
                    <button
                      type="button"
                      className="btn btn-secondary"
                      onClick={generateCode}
                    >
                      Generate
                    </button>
                  </div>
                  {errors.code && <span className="error-message">{errors.code}</span>}
                </div>
                
                <div className="form-group">
                  <label>Type *</label>
                  <select
                    value={formData.type}
                    onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                    className="form-input"
                  >
                    <option value="percent">Percentage Discount</option>
                    <option value="flat">Flat Amount Discount</option>
                  </select>
                </div>
                
                <div className="form-group">
                  <label>
                    {formData.type === 'percent' ? 'Percentage (%)' : 'Amount (₹)'} *
                  </label>
                  <input
                    type="number"
                    value={formData.value}
                    onChange={(e) => setFormData({ ...formData, value: e.target.value })}
                    className={`form-input ${errors.value ? 'error' : ''}`}
                    placeholder={formData.type === 'percent' ? '10' : '100'}
                    min="0"
                    max={formData.type === 'percent' ? '100' : undefined}
                    step="0.01"
                  />
                  {errors.value && <span className="error-message">{errors.value}</span>}
                </div>
                
                {formData.type === 'percent' && (
                  <div className="form-group">
                    <label>Max Discount Cap (₹)</label>
                    <input
                      type="number"
                      value={formData.max_cap}
                      onChange={(e) => setFormData({ ...formData, max_cap: e.target.value })}
                      className={`form-input ${errors.max_cap ? 'error' : ''}`}
                      placeholder="Optional maximum discount"
                      min="0"
                      step="1"
                    />
                    {errors.max_cap && <span className="error-message">{errors.max_cap}</span>}
                  </div>
                )}
                
                <div className="form-group">
                  <label>Valid From *</label>
                  <input
                    type="date"
                    value={formData.valid_from}
                    onChange={(e) => setFormData({ ...formData, valid_from: e.target.value })}
                    className={`form-input ${errors.valid_from ? 'error' : ''}`}
                  />
                  {errors.valid_from && <span className="error-message">{errors.valid_from}</span>}
                </div>
                
                <div className="form-group">
                  <label>Valid To *</label>
                  <input
                    type="date"
                    value={formData.valid_to}
                    onChange={(e) => setFormData({ ...formData, valid_to: e.target.value })}
                    className={`form-input ${errors.valid_to ? 'error' : ''}`}
                  />
                  {errors.valid_to && <span className="error-message">{errors.valid_to}</span>}
                </div>
                
                <div className="form-group">
                  <label>Minimum Bill Amount (₹)</label>
                  <input
                    type="number"
                    value={formData.min_bill}
                    onChange={(e) => setFormData({ ...formData, min_bill: e.target.value })}
                    className={`form-input ${errors.min_bill ? 'error' : ''}`}
                    placeholder="0"
                    min="0"
                    step="1"
                  />
                  {errors.min_bill && <span className="error-message">{errors.min_bill}</span>}
                </div>
                
                <div className="form-group">
                  <label>Bound to Mobile</label>
                  <input
                    type="tel"
                    value={formData.bound_mobile}
                    onChange={(e) => setFormData({ ...formData, bound_mobile: e.target.value })}
                    className={`form-input ${errors.bound_mobile ? 'error' : ''}`}
                    placeholder="10-digit mobile (optional)"
                    maxLength="10"
                  />
                  {errors.bound_mobile && <span className="error-message">{errors.bound_mobile}</span>}
                  <p className="field-hint">
                    If specified, only this customer can use the coupon
                  </p>
                </div>
                
                <div className="form-group full-width">
                  <label>Description</label>
                  <textarea
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    className="form-input"
                    placeholder="Optional description for internal reference"
                    rows="2"
                  />
                </div>
              </div>
              
              <div className="form-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary">
                  <FiSave />
                  {editingCoupon ? 'Update' : 'Create'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Additional Styles */}
      <style jsx>{`
        .filter-tabs {
          display: flex;
          gap: 0.5rem;
          background: white;
          padding: 0.375rem;
          border-radius: 12px;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }
        
        .filter-tab {
          padding: 0.75rem 1.5rem;
          background: transparent;
          border: none;
          border-radius: 8px;
          font-weight: 600;
          color: #6b7280;
          cursor: pointer;
          transition: all 0.3s ease;
        }
        
        .filter-tab:hover {
          background: #f3f4f6;
        }
        
        .filter-tab.active {
          background: linear-gradient(135deg, #9333ea 0%, #4f46e5 100%);
          color: white;
        }
        
        .coupons-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(380px, 1fr));
          gap: 1.5rem;
        }
        
        .coupon-card {
          background: white;
          border-radius: 16px;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.06);
          overflow: hidden;
          transition: all 0.3s ease;
          border: 2px solid transparent;
        }
        
        .coupon-card:hover {
          transform: translateY(-4px);
          box-shadow: 0 12px 30px rgba(0, 0, 0, 0.12);
          border-color: #9333ea;
        }
        
        .coupon-card.expired {
          opacity: 0.7;
          background: #f9fafb;
        }
        
        .coupon-header {
          padding: 1.25rem 1.25rem 0;
          display: flex;
          justify-content: space-between;
          align-items: center;
        }
        
        .coupon-code-section {
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }
        
        .coupon-code {
          font-size: 1.25rem;
          font-weight: 700;
          color: #9333ea;
          margin: 0;
          font-family: 'Monaco', 'Courier New', monospace;
        }
        
        .copy-btn {
          padding: 0.25rem;
          background: transparent;
          border: none;
          color: #6b7280;
          cursor: pointer;
          font-size: 1rem;
          transition: all 0.3s ease;
        }
        
        .copy-btn:hover {
          color: #9333ea;
        }
        
        .status-toggle {
          background: transparent;
          border: none;
          font-size: 2rem;
          cursor: pointer;
          transition: all 0.3s ease;
          color: #d1d5db;
        }
        
        .status-toggle.active {
          color: #10b981;
        }
        
        .status-toggle:disabled {
          cursor: not-allowed;
          opacity: 0.5;
        }
        
        .coupon-body {
          padding: 1.25rem;
        }
        
        .discount-display {
          display: flex;
          align-items: center;
          gap: 0.75rem;
          padding: 0.75rem;
          background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
          border-radius: 10px;
          margin-bottom: 1rem;
        }
        
        .discount-display svg {
          font-size: 1.5rem;
          color: #d97706;
        }
        
        .discount-text {
          font-size: 1.25rem;
          font-weight: 700;
          color: #92400e;
        }
        
        .coupon-description {
          color: #6b7280;
          font-size: 0.875rem;
          margin: 0 0 1rem 0;
          line-height: 1.5;
        }
        
        .coupon-details {
          display: flex;
          flex-direction: column;
          gap: 0.5rem;
        }
        
        .detail-item {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 0.5rem 0;
          border-bottom: 1px solid #f3f4f6;
        }
        
        .detail-item:last-child {
          border-bottom: none;
        }
        
        .detail-label {
          font-size: 0.875rem;
          color: #9ca3af;
          font-weight: 500;
        }
        
        .detail-value {
          font-size: 0.875rem;
          color: #4b5563;
          font-weight: 600;
        }
        
        .expired-badge {
          display: inline-flex;
          align-items: center;
          gap: 0.375rem;
          padding: 0.5rem 0.75rem;
          background: #fee2e2;
          color: #991b1b;
          border-radius: 8px;
          font-size: 0.875rem;
          font-weight: 600;
          margin-top: 1rem;
        }
        
        .coupon-footer {
          padding: 1rem 1.25rem;
          background: #f9fafb;
          border-top: 1px solid #e5e7eb;
          display: flex;
          gap: 0.5rem;
        }
        
        .btn-icon {
          padding: 0.5rem;
          background: white;
          border: 2px solid #e5e7eb;
          border-radius: 8px;
          color: #6b7280;
          cursor: pointer;
          transition: all 0.3s ease;
        }
        
        .btn-icon:hover {
          border-color: #9333ea;
          color: #9333ea;
        }
        
        .btn-icon.danger:hover {
          border-color: #ef4444;
          color: #ef4444;
        }
        
        .code-input-group {
          display: flex;
          gap: 0.75rem;
        }
        
        .code-input-group .form-input {
          flex: 1;
        }
        
        .field-hint {
          margin-top: 0.5rem;
          font-size: 0.75rem;
          color: #6b7280;
        }
        
        @media (max-width: 768px) {
          .coupons-grid {
            grid-template-columns: 1fr;
          }
        }
      `}</style>
    </div>
  );
}

export default Coupons;