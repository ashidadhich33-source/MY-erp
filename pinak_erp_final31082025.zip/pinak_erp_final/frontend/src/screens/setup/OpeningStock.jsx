import React, { useState, useEffect, useRef } from 'react';
import { 
  FiDatabase, FiUpload, FiDownload, FiSave, 
  FiSearch, FiRefreshCw, FiAlertCircle, FiCheckCircle,
  FiPackage, FiEdit3, FiX, FiDollarSign
} from 'react-icons/fi';
import toast from 'react-hot-toast';
import * as XLSX from 'xlsx';
import axios from 'axios';
import './OpeningStock.css';

const API_URL = 'http://localhost:8000/api/v1';

function OpeningStock() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [editMode, setEditMode] = useState({});
  const [modifiedItems, setModifiedItems] = useState({});
  const fileInputRef = useRef(null);
  
  // Stats
  const [stats, setStats] = useState({
    totalItems: 0,
    totalQty: 0,
    totalValue: 0,
    totalCostValue: 0,
    modifiedCount: 0
  });

  // Fetch all items with stock
  const fetchItems = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(
        `${API_URL}/setup/opening-stock`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      const itemsData = response.data.items || [];
      setItems(itemsData);
      
      // Calculate stats
      calculateStats(itemsData);
    } catch (error) {
      toast.error('Failed to fetch items');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  // Calculate statistics
  const calculateStats = (itemsList) => {
    const totalQty = itemsList.reduce((sum, item) => sum + (item.qty || 0), 0);
    const totalValue = itemsList.reduce((sum, item) => 
      sum + ((item.qty || 0) * (item.mrp_incl || 0)), 0
    );
    const totalCostValue = itemsList.reduce((sum, item) => 
      sum + ((item.qty || 0) * (item.purchase_rate_basic || 0)), 0
    );
    
    setStats({
      totalItems: itemsList.length,
      totalQty,
      totalValue,
      totalCostValue,
      modifiedCount: Object.keys(modifiedItems).length
    });
  };

  useEffect(() => {
    fetchItems();
  }, []);

  // Handle quantity change
  const handleQtyChange = (barcode, value) => {
    const qty = parseInt(value) || 0;
    
    // Update modified items
    setModifiedItems(prev => ({
      ...prev,
      [barcode]: qty
    }));
    
    // Update local state
    const updatedItems = items.map(item => 
      item.barcode === barcode ? { ...item, qty } : item
    );
    setItems(updatedItems);
    
    // Recalculate stats
    calculateStats(updatedItems);
  };

  // Toggle edit mode for a specific item
  const toggleEditMode = (barcode) => {
    setEditMode(prev => ({
      ...prev,
      [barcode]: !prev[barcode]
    }));
  };

  // Save all modified items
  const handleSaveAll = async () => {
    if (Object.keys(modifiedItems).length === 0) {
      toast.error('No changes to save');
      return;
    }

    const confirmMsg = `Save stock quantities for ${Object.keys(modifiedItems).length} items?`;
    if (!window.confirm(confirmMsg)) return;

    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const updates = Object.entries(modifiedItems).map(([barcode, qty]) => ({
        barcode,
        qty
      }));

      const response = await axios.post(
        `${API_URL}/setup/opening-stock/bulk-update`,
        { updates },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      if (response.data.success) {
        toast.success(response.data.message || `Updated stock for ${updates.length} items`);
        setModifiedItems({});
        setEditMode({});
        fetchItems();
      } else {
        toast.error(response.data.message || 'Failed to save stock quantities');
      }
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to save stock quantities');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  // Export template
  const handleExportTemplate = () => {
    try {
      const templateData = items.map(item => ({
        BARCODE: item.barcode,
        STYLE_CODE: item.style_code,
        BRAND: item.brand || '',
        COLOR: item.color || '',
        SIZE: item.size || '',
        HSN: item.hsn || '',
        MRP: item.mrp_incl || 0,
        COST: item.purchase_rate_basic || 0,
        QTY: item.qty || 0
      }));

      const ws = XLSX.utils.json_to_sheet(templateData);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Opening Stock');
      
      // Add instructions sheet
      const instructions = [
        ['Instructions'],
        [''],
        ['1. Only BARCODE and QTY columns will be imported'],
        ['2. Other columns are for reference only'],
        ['3. Do not change BARCODE values'],
        ['4. Update only the QTY column with your stock quantities'],
        ['5. Save the file as .xlsx or .xls format'],
        ['6. Import the file back using IMPORT EXCEL button']
      ];
      const ws2 = XLSX.utils.aoa_to_sheet(instructions);
      XLSX.utils.book_append_sheet(wb, ws2, 'Instructions');
      
      // Set column widths
      ws['!cols'] = [
        { width: 20 }, // BARCODE
        { width: 15 }, // STYLE_CODE
        { width: 15 }, // BRAND
        { width: 10 }, // COLOR
        { width: 10 }, // SIZE
        { width: 10 }, // HSN
        { width: 10 }, // MRP
        { width: 10 }, // COST
        { width: 10 }  // QTY
      ];
      
      XLSX.writeFile(wb, `opening_stock_template_${new Date().toISOString().split('T')[0]}.xlsx`);
      toast.success('Template exported successfully');
    } catch (error) {
      toast.error('Failed to export template');
      console.error(error);
    }
  };

  // Import from Excel
  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    // Validate file type
    if (!file.name.endsWith('.xlsx') && !file.name.endsWith('.xls')) {
      toast.error('Please upload an Excel file (.xlsx or .xls)');
      e.target.value = '';
      return;
    }

    setLoading(true);
    
    try {
      const token = localStorage.getItem('token');
      const formData = new FormData();
      formData.append('file', file);

      const response = await axios.post(
        `${API_URL}/setup/opening-stock/import`,
        formData,
        {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'multipart/form-data'
          }
        }
      );

      if (response.data.success) {
        toast.success(response.data.message || 'Stock data imported successfully');
        
        // Show errors if any
        if (response.data.data?.errors?.length > 0) {
          console.log('Import errors:', response.data.data.errors);
          response.data.data.errors.slice(0, 3).forEach(error => {
            toast.error(error, { duration: 5000 });
          });
        }
        
        // Refresh the items list
        fetchItems();
      } else {
        toast.error(response.data.message || 'Failed to import stock data');
      }
    } catch (error) {
      console.error('Import error:', error);
      toast.error('Failed to import. Check console for details.');
    } finally {
      e.target.value = '';
      setLoading(false);
    }
  };

  // Filter items based on search
  const filteredItems = items.filter(item => {
    const searchLower = searchTerm.toLowerCase();
    return (
      item.barcode?.toLowerCase().includes(searchLower) ||
      item.style_code?.toLowerCase().includes(searchLower) ||
      item.brand?.toLowerCase().includes(searchLower) ||
      item.color?.toLowerCase().includes(searchLower) ||
      item.size?.toLowerCase().includes(searchLower)
    );
  });

  return (
    <div className="opening-stock-container">
      <div className="page-header">
        <div className="page-title-section">
          <h2 className="page-title">
            <FiDatabase /> Opening Stock
          </h2>
          <p className="page-subtitle">Manage initial stock quantities</p>
        </div>
        <div className="page-actions">
          <button 
            onClick={fetchItems} 
            className="btn btn-outline"
            disabled={loading}
            title="Refresh data"
          >
            <FiRefreshCw className={loading ? 'spin' : ''} /> REFRESH
          </button>
          
          <button 
            onClick={handleExportTemplate}
            className="btn btn-outline"
            disabled={items.length === 0}
            title="Export current items to Excel template"
          >
            <FiDownload /> EXPORT TEMPLATE
          </button>
          
          <button 
            onClick={() => fileInputRef.current?.click()}
            className="btn btn-outline"
            disabled={loading}
            title="Import stock quantities from Excel"
          >
            <FiUpload /> IMPORT EXCEL
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept=".xlsx,.xls"
            style={{ display: 'none' }}
            onChange={handleFileUpload}
          />
          
          <button 
            onClick={handleSaveAll}
            className="btn btn-primary"
            disabled={Object.keys(modifiedItems).length === 0 || loading}
            title="Save all modified quantities"
          >
            <FiSave /> SAVE ALL ({Object.keys(modifiedItems).length})
          </button>
        </div>
      </div>

      {/* Stats Cards - Improved Layout */}
      <div className="stats-container">
        <div className="stat-card">
          <div className="stat-header">
            <span className="stat-label">TOTAL ITEMS</span>
            <FiPackage className="stat-icon" />
          </div>
          <div className="stat-value">{stats.totalItems}</div>
        </div>
        
        <div className="stat-card">
          <div className="stat-header">
            <span className="stat-label">TOTAL QUANTITY</span>
            <FiDatabase className="stat-icon" />
          </div>
          <div className="stat-value">{stats.totalQty.toLocaleString()}</div>
        </div>
        
        <div className="stat-card">
          <div className="stat-header">
            <span className="stat-label">TOTAL VALUE</span>
            <FiDollarSign className="stat-icon" />
          </div>
          <div className="stat-value">₹{stats.totalValue.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
          <div className="stat-subtitle">At MRP</div>
        </div>

        <div className="stat-card">
          <div className="stat-header">
            <span className="stat-label">TOTAL COST VALUE</span>
            <FiDollarSign className="stat-icon" />
          </div>
          <div className="stat-value">₹{stats.totalCostValue.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
          <div className="stat-subtitle">At Cost</div>
        </div>
        
        <div className="stat-card modified">
          <div className="stat-header">
            <span className="stat-label">MODIFIED ITEMS</span>
            <FiEdit3 className="stat-icon" />
          </div>
          <div className="stat-value">{stats.modifiedCount}</div>
        </div>
      </div>

      {/* Search and Info Section */}
      <div className="controls-section">
        <div className="search-container">
          <FiSearch className="search-icon" />
          <input
            type="text"
            className="search-input"
            placeholder="Search by barcode, style code, brand, color, size..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="info-message">
          <FiAlertCircle />
          <span>Import Excel with two columns only: BARCODE, QTY</span>
        </div>
      </div>

      {/* Data Table */}
      <div className="table-wrapper">
        <table className="stock-table">
          <thead>
            <tr>
              <th>BARCODE</th>
              <th>STYLE CODE</th>
              <th>COLOR</th>
              <th>SIZE</th>
              <th>HSN</th>
              <th>MRP</th>
              <th>COST</th>
              <th className="qty-column">QTY</th>
              <th>TOTAL VALUE</th>
              <th>COST VALUE</th>
              <th>ACTIONS</th>
            </tr>
          </thead>
          <tbody>
            {filteredItems.length === 0 ? (
              <tr>
                <td colSpan="11" className="empty-row">
                  {searchTerm ? 'No items found matching your search' : 'No items found. Import items from Item Master first.'}
                </td>
              </tr>
            ) : (
              filteredItems.map((item) => {
                const currentQty = modifiedItems[item.barcode] !== undefined ? modifiedItems[item.barcode] : item.qty;
                const totalValue = currentQty * (item.mrp_incl || 0);
                const costValue = currentQty * (item.purchase_rate_basic || 0);
                const isModified = modifiedItems[item.barcode] !== undefined;
                
                return (
                  <tr key={item.barcode} className={isModified ? 'modified-row' : ''}>
                    <td className="barcode-cell">{item.barcode}</td>
                    <td>{item.style_code}</td>
                    <td>{item.color}</td>
                    <td>{item.size}</td>
                    <td>{item.hsn || '6111'}</td>
                    <td className="currency-cell">₹{item.mrp_incl || 0}</td>
                    <td className="currency-cell">₹{item.purchase_rate_basic || 0}</td>
                    <td className="qty-cell">
                      <input
                        type="number"
                        value={currentQty}
                        onChange={(e) => handleQtyChange(item.barcode, e.target.value)}
                        min="0"
                        className={`qty-input ${isModified ? 'modified' : ''}`}
                      />
                    </td>
                    <td className="currency-cell value-cell">
                      ₹{totalValue.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </td>
                    <td className="currency-cell cost-cell">
                      ₹{costValue.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </td>
                    <td className="action-cell">
                      {isModified && (
                        <button 
                          onClick={() => {
                            const updatedModified = {...modifiedItems};
                            delete updatedModified[item.barcode];
                            setModifiedItems(updatedModified);
                            
                            // Reset to original value
                            const updatedItems = items.map(i => 
                              i.barcode === item.barcode ? { ...i, qty: i.qty || 0 } : i
                            );
                            setItems(updatedItems);
                            calculateStats(updatedItems);
                          }}
                          className="btn-icon"
                          title="Reset changes"
                        >
                          <FiX />
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
          {filteredItems.length > 0 && (
            <tfoot>
              <tr className="footer-row">
                <td colSpan="7" className="footer-label">TOTALS:</td>
                <td className="footer-value">{stats.totalQty}</td>
                <td className="footer-value">
                  ₹{stats.totalValue.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </td>
                <td className="footer-value">
                  ₹{stats.totalCostValue.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </td>
                <td></td>
              </tr>
            </tfoot>
          )}
        </table>
      </div>
    </div>
  );
}

export default OpeningStock;