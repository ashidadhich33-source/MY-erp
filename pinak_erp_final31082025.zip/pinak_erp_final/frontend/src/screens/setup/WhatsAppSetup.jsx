import React, { useState, useEffect } from 'react';
import { 
  FiMessageSquare, FiSave, FiCheckCircle, FiAlertCircle,
  FiKey, FiPhone, FiGlobe, FiSend, FiRefreshCw,
  FiInfo, FiX
} from 'react-icons/fi';
import toast from 'react-hot-toast';
import axios from 'axios';
import './SetupScreens.css';

const API_URL = 'http://localhost:8000/api/v1';

function WhatsAppSetup() {
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState('disconnected');
  
  // Form state
  const [formData, setFormData] = useState({
    phone_number_id: '',
    access_token: '',
    verify_token: '',
    webhook_url: '',
    business_account_id: '',
    app_id: '',
    app_secret: '',
    default_country_code: '91',
    enabled: false,
    // Message templates
    otp_template: 'Your OTP is: {{otp}}. Valid for 5 minutes.',
    invoice_template: 'Thank you for shopping! Your invoice {{invoice_no}} of ₹{{amount}} is ready.',
    coupon_template: 'Special offer! Use code {{code}} to get {{discount}} off. Valid till {{expiry}}.',
    birthday_template: 'Happy Birthday {{name}}! Enjoy {{discount}} off on your special day.'
  });

  // Validation errors
  const [errors, setErrors] = useState({});

  // Test message
  const [testNumber, setTestNumber] = useState('');
  const [showTestModal, setShowTestModal] = useState(false);

  // Fetch WhatsApp configuration
  const fetchConfig = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(
        `${API_URL}/setup/whatsapp`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      if (response.data) {
        setFormData(response.data);
        setConnectionStatus(response.data.enabled ? 'connected' : 'disconnected');
      }
    } catch (error) {
      if (error.response?.status !== 404) {
        toast.error('Failed to fetch WhatsApp configuration');
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchConfig();
  }, []);

  // Validate form
  const validateForm = () => {
    const newErrors = {};

    if (!formData.phone_number_id.trim()) {
      newErrors.phone_number_id = 'Phone Number ID is required';
    }

    if (!formData.access_token.trim()) {
      newErrors.access_token = 'Access Token is required';
    }

    if (!formData.business_account_id.trim()) {
      newErrors.business_account_id = 'Business Account ID is required';
    }

    if (!formData.app_id.trim()) {
      newErrors.app_id = 'App ID is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      toast.error('Please fix the errors in the form');
      return;
    }

    const confirmMsg = 'Save WhatsApp Cloud API configuration?';
    if (!window.confirm(confirmMsg)) return;

    setSaving(true);
    try {
      const token = localStorage.getItem('token');
      await axios.post(
        `${API_URL}/setup/whatsapp`,
        formData,
        { headers: { Authorization: `Bearer ${token}` } }
      );

      toast.success('WhatsApp configuration saved successfully');
      setConnectionStatus(formData.enabled ? 'connected' : 'disconnected');
    } catch (error) {
      if (error.response?.data?.detail) {
        toast.error(error.response.data.detail);
      } else {
        toast.error('Failed to save WhatsApp configuration');
      }
    } finally {
      setSaving(false);
    }
  };

  // Test connection
  const testConnection = async () => {
    if (!formData.phone_number_id || !formData.access_token) {
      toast.error('Please enter Phone Number ID and Access Token first');
      return;
    }

    setTesting(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.post(
        `${API_URL}/setup/whatsapp/test`,
        {
          phone_number_id: formData.phone_number_id,
          access_token: formData.access_token
        },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      if (response.data.success) {
        toast.success('WhatsApp connection successful!');
        setConnectionStatus('connected');
      } else {
        toast.error('Connection failed. Please check your credentials.');
        setConnectionStatus('error');
      }
    } catch (error) {
      toast.error('Failed to test connection');
      setConnectionStatus('error');
    } finally {
      setTesting(false);
    }
  };

  // Send test message
  const sendTestMessage = async () => {
    if (!testNumber || testNumber.length !== 10) {
      toast.error('Please enter a valid 10-digit mobile number');
      return;
    }

    try {
      const token = localStorage.getItem('token');
      await axios.post(
        `${API_URL}/setup/whatsapp/send-test`,
        {
          mobile: testNumber,
          message: 'This is a test message from Pinak ERP WhatsApp integration.'
        },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      toast.success('Test message sent successfully!');
      setShowTestModal(false);
      setTestNumber('');
    } catch (error) {
      toast.error('Failed to send test message');
    }
  };

  return (
    <div className="setup-container">
      {/* Header */}
      <div className="setup-header">
        <div className="header-left">
          <h1 className="page-title">
            <FiMessageSquare className="title-icon" />
            Setup WhatsApp Cloud API
          </h1>
          <p className="page-subtitle">Configure WhatsApp Business API for OTP and notifications</p>
        </div>
        
        <div className="header-actions">
          <div className={`connection-status ${connectionStatus}`}>
            {connectionStatus === 'connected' ? <FiCheckCircle /> : <FiAlertCircle />}
            <span>{connectionStatus === 'connected' ? 'Connected' : 'Not Connected'}</span>
          </div>
          
          <button 
            className="btn btn-primary"
            onClick={handleSubmit}
            disabled={saving}
          >
            <FiSave />
            {saving ? 'Saving...' : 'Save Configuration'}
          </button>
        </div>
      </div>

      {/* Setup Instructions */}
      <div className="instructions-card">
        <FiInfo className="info-icon" />
        <div className="instructions-content">
          <h3>Setup Instructions</h3>
          <ol>
            <li>Create a WhatsApp Business Account at <a href="https://business.facebook.com" target="_blank" rel="noopener noreferrer">business.facebook.com</a></li>
            <li>Set up a WhatsApp Business API app in Meta for Developers</li>
            <li>Get your Phone Number ID from the WhatsApp Business API dashboard</li>
            <li>Generate a permanent Access Token for your app</li>
            <li>Configure the webhook URL to receive messages (optional)</li>
          </ol>
        </div>
      </div>

      {loading ? (
        <div className="loading-container">
          <div className="loading-spinner"></div>
          <p>Loading WhatsApp configuration...</p>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="whatsapp-form">
          {/* API Configuration */}
          <div className="form-section">
            <h3 className="section-title">
              <FiKey />
              API Configuration
            </h3>
            
            <div className="form-grid">
              <div className="form-group">
                <label>Phone Number ID *</label>
                <input
                  type="text"
                  value={formData.phone_number_id}
                  onChange={(e) => setFormData({ ...formData, phone_number_id: e.target.value })}
                  className={`form-input ${errors.phone_number_id ? 'error' : ''}`}
                  placeholder="Enter Phone Number ID from WhatsApp Business"
                />
                {errors.phone_number_id && <span className="error-message">{errors.phone_number_id}</span>}
              </div>
              
              <div className="form-group">
                <label>Access Token *</label>
                <input
                  type="password"
                  value={formData.access_token}
                  onChange={(e) => setFormData({ ...formData, access_token: e.target.value })}
                  className={`form-input ${errors.access_token ? 'error' : ''}`}
                  placeholder="Enter permanent access token"
                />
                {errors.access_token && <span className="error-message">{errors.access_token}</span>}
              </div>
              
              <div className="form-group">
                <label>Business Account ID *</label>
                <input
                  type="text"
                  value={formData.business_account_id}
                  onChange={(e) => setFormData({ ...formData, business_account_id: e.target.value })}
                  className={`form-input ${errors.business_account_id ? 'error' : ''}`}
                  placeholder="Enter Business Account ID"
                />
                {errors.business_account_id && <span className="error-message">{errors.business_account_id}</span>}
              </div>
              
              <div className="form-group">
                <label>App ID *</label>
                <input
                  type="text"
                  value={formData.app_id}
                  onChange={(e) => setFormData({ ...formData, app_id: e.target.value })}
                  className={`form-input ${errors.app_id ? 'error' : ''}`}
                  placeholder="Enter App ID"
                />
                {errors.app_id && <span className="error-message">{errors.app_id}</span>}
              </div>
              
              <div className="form-group">
                <label>App Secret</label>
                <input
                  type="password"
                  value={formData.app_secret}
                  onChange={(e) => setFormData({ ...formData, app_secret: e.target.value })}
                  className="form-input"
                  placeholder="Enter App Secret (optional)"
                />
              </div>
              
              <div className="form-group">
                <label>Verify Token</label>
                <input
                  type="text"
                  value={formData.verify_token}
                  onChange={(e) => setFormData({ ...formData, verify_token: e.target.value })}
                  className="form-input"
                  placeholder="Token for webhook verification"
                />
              </div>
              
              <div className="form-group">
                <label>Webhook URL</label>
                <input
                  type="url"
                  value={formData.webhook_url}
                  onChange={(e) => setFormData({ ...formData, webhook_url: e.target.value })}
                  className="form-input"
                  placeholder="https://yourdomain.com/webhook"
                />
              </div>
              
              <div className="form-group">
                <label>Default Country Code</label>
                <input
                  type="text"
                  value={formData.default_country_code}
                  onChange={(e) => setFormData({ ...formData, default_country_code: e.target.value })}
                  className="form-input"
                  placeholder="91"
                />
              </div>
              
              <div className="form-group">
                <label>Status</label>
                <select
                  value={formData.enabled}
                  onChange={(e) => setFormData({ ...formData, enabled: e.target.value === 'true' })}
                  className="form-input"
                >
                  <option value="true">Enabled</option>
                  <option value="false">Disabled</option>
                </select>
              </div>
            </div>
            
            <div className="test-connection">
              <button
                type="button"
                className="btn btn-secondary"
                onClick={testConnection}
                disabled={testing}
              >
                <FiRefreshCw className={testing ? 'spinning' : ''} />
                {testing ? 'Testing...' : 'Test Connection'}
              </button>
              
              <button
                type="button"
                className="btn btn-secondary"
                onClick={() => setShowTestModal(true)}
                disabled={connectionStatus !== 'connected'}
              >
                <FiSend />
                Send Test Message
              </button>
            </div>
          </div>

          {/* Message Templates */}
          <div className="form-section">
            <h3 className="section-title">
              <FiMessageSquare />
              Message Templates
            </h3>
            
            <div className="form-grid">
              <div className="form-group full-width">
                <label>OTP Template</label>
                <textarea
                  value={formData.otp_template}
                  onChange={(e) => setFormData({ ...formData, otp_template: e.target.value })}
                  className="form-input"
                  placeholder="Your OTP is: {{otp}}. Valid for 5 minutes."
                  rows="2"
                />
                <p className="field-hint">Available variables: {'{{otp}}'}</p>
              </div>
              
              <div className="form-group full-width">
                <label>Invoice Template</label>
                <textarea
                  value={formData.invoice_template}
                  onChange={(e) => setFormData({ ...formData, invoice_template: e.target.value })}
                  className="form-input"
                  placeholder="Thank you for shopping! Your invoice {{invoice_no}} of ₹{{amount}} is ready."
                  rows="2"
                />
                <p className="field-hint">Available variables: {'{{invoice_no}}, {{amount}}, {{customer_name}}'}</p>
              </div>
              
              <div className="form-group full-width">
                <label>Coupon Template</label>
                <textarea
                  value={formData.coupon_template}
                  onChange={(e) => setFormData({ ...formData, coupon_template: e.target.value })}
                  className="form-input"
                  placeholder="Special offer! Use code {{code}} to get {{discount}} off."
                  rows="2"
                />
                <p className="field-hint">Available variables: {'{{code}}, {{discount}}, {{expiry}}'}</p>
              </div>
              
              <div className="form-group full-width">
                <label>Birthday Template</label>
                <textarea
                  value={formData.birthday_template}
                  onChange={(e) => setFormData({ ...formData, birthday_template: e.target.value })}
                  className="form-input"
                  placeholder="Happy Birthday {{name}}! Enjoy special discount on your day."
                  rows="2"
                />
                <p className="field-hint">Available variables: {'{{name}}, {{discount}}'}</p>
              </div>
            </div>
          </div>
        </form>
      )}

      {/* Test Message Modal */}
      {showTestModal && (
        <div className="modal-overlay" onClick={() => setShowTestModal(false)}>
          <div className="modal-content modal-small" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h2>Send Test Message</h2>
              <button className="modal-close" onClick={() => setShowTestModal(false)}>
                <FiX />
              </button>
            </div>
            
            <div className="test-modal-body">
              <div className="form-group">
                <label>Mobile Number</label>
                <input
                  type="tel"
                  value={testNumber}
                  onChange={(e) => setTestNumber(e.target.value)}
                  className="form-input"
                  placeholder="10-digit mobile number"
                  maxLength="10"
                />
              </div>
              
              <div className="test-info">
                <FiInfo />
                <p>A test message will be sent to verify the WhatsApp integration is working correctly.</p>
              </div>
              
              <div className="form-footer">
                <button 
                  className="btn btn-secondary" 
                  onClick={() => setShowTestModal(false)}
                >
                  Cancel
                </button>
                <button 
                  className="btn btn-primary" 
                  onClick={sendTestMessage}
                >
                  <FiSend />
                  Send Test
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Additional Styles */}
      <style jsx>{`
        .connection-status {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          padding: 0.5rem 1rem;
          border-radius: 20px;
          font-size: 0.875rem;
          font-weight: 600;
        }
        
        .connection-status.connected {
          background: linear-gradient(135deg, #d1fae5 0%, #a7f3d0 100%);
          color: #065f46;
        }
        
        .connection-status.disconnected,
        .connection-status.error {
          background: linear-gradient(135deg, #fee2e2 0%, #fecaca 100%);
          color: #991b1b;
        }
        
        .instructions-card {
          display: flex;
          gap: 1.25rem;
          padding: 1.5rem;
          background: linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%);
          border-radius: 16px;
          margin-bottom: 2rem;
        }
        
        .instructions-card .info-icon {
          font-size: 1.75rem;
          color: #3b82f6;
          flex-shrink: 0;
        }
        
        .instructions-content h3 {
          margin: 0 0 1rem 0;
          color: #1e40af;
        }
        
        .instructions-content ol {
          margin: 0;
          padding-left: 1.25rem;
          color: #1e3a8a;
          line-height: 1.8;
        }
        
        .instructions-content a {
          color: #2563eb;
          text-decoration: underline;
        }
        
        .whatsapp-form {
          display: flex;
          flex-direction: column;
          gap: 2rem;
        }
        
        .test-connection {
          display: flex;
          gap: 1rem;
          margin-top: 1.5rem;
          padding-top: 1.5rem;
          border-top: 2px solid #e5e7eb;
        }
        
        .spinning {
          animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
        
        .modal-small {
          max-width: 500px;
        }
        
        .test-modal-body {
          padding: 1.5rem;
        }
        
        .test-info {
          display: flex;
          gap: 0.75rem;
          padding: 1rem;
          background: #f0f9ff;
          border-radius: 8px;
          margin: 1rem 0;
        }
        
        .test-info svg {
          color: #0284c7;
          flex-shrink: 0;
        }
        
        .test-info p {
          margin: 0;
          color: #0c4a6e;
          font-size: 0.875rem;
        }
        
        .field-hint {
          margin-top: 0.5rem;
          font-size: 0.75rem;
          color: #6b7280;
          font-family: 'Monaco', 'Courier New', monospace;
        }
      `}</style>
    </div>
  );
}

export default WhatsAppSetup;