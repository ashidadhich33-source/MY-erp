import React, { useState, useEffect } from 'react';
import { 
  FiAward, FiPlus, FiEdit2, FiTrash2, FiSave,
  FiTrendingUp, FiPercent, FiDollarSign, FiX,
  FiChevronUp, FiInfo
} from 'react-icons/fi';
import toast from 'react-hot-toast';
import axios from 'axios';
import './SetupScreens.css';

const API_URL = 'http://localhost:8000/api/v1';

function LoyaltyGrade() {
  const [grades, setGrades] = useState([]);
  const [loading, setLoading] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [editingGrade, setEditingGrade] = useState(null);
  
  // Form state
  const [formData, setFormData] = useState({
    name: '',
    amount_from: '',
    amount_to: '',
    points_percent: '',
    benefits: '',
    color: '#9333ea'
  });

  // Validation errors
  const [errors, setErrors] = useState({});

  // Predefined colors for grades
  const gradeColors = [
    { name: 'Silver', color: '#9ca3af' },
    { name: 'Gold', color: '#f59e0b' },
    { name: 'Platinum', color: '#8b5cf6' },
    { name: 'Diamond', color: '#3b82f6' },
    { name: 'Titanium', color: '#1f2937' }
  ];

  // Fetch loyalty grades
  const fetchGrades = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(
        `${API_URL}/setup/loyalty-grades`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setGrades(response.data.grades || []);
    } catch (error) {
      toast.error('Failed to fetch loyalty grades');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchGrades();
  }, []);

  // Validate form
  const validateForm = () => {
    const newErrors = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Grade name is required';
    }

    if (!formData.amount_from && formData.amount_from !== 0) {
      newErrors.amount_from = 'Amount from is required';
    } else if (formData.amount_from < 0) {
      newErrors.amount_from = 'Amount must be positive';
    }

    if (!formData.amount_to) {
      newErrors.amount_to = 'Amount to is required';
    } else if (parseFloat(formData.amount_to) <= parseFloat(formData.amount_from)) {
      newErrors.amount_to = 'Amount to must be greater than amount from';
    }

    if (!formData.points_percent) {
      newErrors.points_percent = 'Points percentage is required';
    } else if (formData.points_percent <= 0 || formData.points_percent > 100) {
      newErrors.points_percent = 'Points must be between 0 and 100';
    }

    // Check for overlapping ranges
    const fromAmount = parseFloat(formData.amount_from);
    const toAmount = parseFloat(formData.amount_to);
    
    grades.forEach(grade => {
      if (editingGrade?.id !== grade.id) {
        if ((fromAmount >= grade.amount_from && fromAmount <= grade.amount_to) ||
            (toAmount >= grade.amount_from && toAmount <= grade.amount_to) ||
            (fromAmount <= grade.amount_from && toAmount >= grade.amount_to)) {
          newErrors.amount_from = 'Range overlaps with existing grade';
        }
      }
    });

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      toast.error('Please fix the errors in the form');
      return;
    }

    try {
      const token = localStorage.getItem('token');
      const endpoint = editingGrade 
        ? `${API_URL}/setup/loyalty-grades/${editingGrade.id}`
        : `${API_URL}/setup/loyalty-grades`;
      
      const method = editingGrade ? 'put' : 'post';
      
      await axios[method](endpoint, formData, {
        headers: { Authorization: `Bearer ${token}` } }
      );

      toast.success(`Loyalty grade ${editingGrade ? 'updated' : 'created'} successfully`);
      setShowModal(false);
      resetForm();
      fetchGrades();
    } catch (error) {
      if (error.response?.data?.detail) {
        toast.error(error.response.data.detail);
      } else {
        toast.error('Failed to save loyalty grade');
      }
    }
  };

  // Reset form
  const resetForm = () => {
    setFormData({
      name: '',
      amount_from: '',
      amount_to: '',
      points_percent: '',
      benefits: '',
      color: '#9333ea'
    });
    setEditingGrade(null);
    setErrors({});
  };

  // Edit grade
  const handleEdit = (grade) => {
    setFormData(grade);
    setEditingGrade(grade);
    setShowModal(true);
  };

  // Delete grade
  const handleDelete = async (grade) => {
    if (!window.confirm(`Delete grade "${grade.name}"? This action cannot be undone.`)) {
      return;
    }

    try {
      const token = localStorage.getItem('token');
      await axios.delete(
        `${API_URL}/setup/loyalty-grades/${grade.id}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      toast.success('Loyalty grade deleted successfully');
      fetchGrades();
    } catch (error) {
      toast.error('Failed to delete loyalty grade');
    }
  };

  // Calculate example points
  const calculateExamplePoints = (amount, percent) => {
    return Math.floor(amount * (percent / 100));
  };

  return (
    <div className="setup-container">
      {/* Header */}
      <div className="setup-header">
        <div className="header-left">
          <h1 className="page-title">
            <FiAward className="title-icon" />
            Setup Loyalty Grade
          </h1>
          <p className="page-subtitle">Configure customer loyalty tiers and rewards</p>
        </div>
        
        <div className="header-actions">
          <button 
            className="btn btn-primary"
            onClick={() => {
              resetForm();
              setShowModal(true);
            }}
          >
            <FiPlus />
            Add Grade
          </button>
        </div>
      </div>

      {/* Info Alert */}
      <div className="info-alert">
        <FiInfo />
        <div>
          <strong>Auto-Upgrade Feature</strong>
          <p>When a customer's lifetime purchases cross a threshold, their grade automatically upgrades to the next level.</p>
        </div>
      </div>

      {/* Grades List */}
      {loading ? (
        <div className="loading-container">
          <div className="loading-spinner"></div>
          <p>Loading loyalty grades...</p>
        </div>
      ) : grades.length === 0 ? (
        <div className="empty-state">
          <FiAward className="empty-icon" />
          <h3>No loyalty grades configured</h3>
          <p>Start by creating your first loyalty grade</p>
        </div>
      ) : (
        <div className="grades-container">
          {grades.sort((a, b) => a.amount_from - b.amount_from).map((grade, index) => (
            <div key={grade.id} className="grade-card">
              <div className="grade-header" style={{ background: `linear-gradient(135deg, ${grade.color}22 0%, ${grade.color}44 100%)` }}>
                <div className="grade-icon" style={{ background: grade.color }}>
                  <FiAward />
                </div>
                <div className="grade-title">
                  <h3>{grade.name}</h3>
                  <span className="grade-level">Level {index + 1}</span>
                </div>
                <div className="grade-actions">
                  <button className="action-btn" onClick={() => handleEdit(grade)}>
                    <FiEdit2 />
                  </button>
                  <button className="action-btn danger" onClick={() => handleDelete(grade)}>
                    <FiTrash2 />
                  </button>
                </div>
              </div>
              
              <div className="grade-body">
                <div className="grade-range">
                  <div className="range-item">
                    <span className="range-label">From</span>
                    <span className="range-value">₹{grade.amount_from.toLocaleString()}</span>
                  </div>
                  <FiChevronUp className="range-arrow" />
                  <div className="range-item">
                    <span className="range-label">To</span>
                    <span className="range-value">₹{grade.amount_to.toLocaleString()}</span>
                  </div>
                </div>
                
                <div className="points-info">
                  <div className="points-rate">
                    <FiPercent className="points-icon" />
                    <span className="points-text">{grade.points_percent}% points on purchases</span>
                  </div>
                  
                  <div className="points-example">
                    <span className="example-label">Example:</span>
                    <span className="example-text">
                      ₹10,000 purchase = {calculateExamplePoints(10000, grade.points_percent)} points
                    </span>
                  </div>
                </div>
                
                {grade.benefits && (
                  <div className="grade-benefits">
                    <span className="benefits-label">Benefits:</span>
                    <p className="benefits-text">{grade.benefits}</p>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add/Edit Modal */}
      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h2>{editingGrade ? 'Edit Loyalty Grade' : 'Add New Loyalty Grade'}</h2>
              <button className="modal-close" onClick={() => setShowModal(false)}>
                <FiX />
              </button>
            </div>
            
            <form onSubmit={handleSubmit} className="grade-form">
              <div className="form-grid">
                <div className="form-group">
                  <label>Grade Name *</label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className={`form-input ${errors.name ? 'error' : ''}`}
                    placeholder="e.g., Silver, Gold, Platinum"
                  />
                  {errors.name && <span className="error-message">{errors.name}</span>}
                </div>
                
                <div className="form-group">
                  <label>Color Theme</label>
                  <div className="color-selector">
                    <input
                      type="color"
                      value={formData.color}
                      onChange={(e) => setFormData({ ...formData, color: e.target.value })}
                      className="color-input"
                    />
                    <div className="color-presets">
                      {gradeColors.map(preset => (
                        <button
                          key={preset.name}
                          type="button"
                          className="color-preset"
                          style={{ background: preset.color }}
                          onClick={() => setFormData({ ...formData, color: preset.color })}
                          title={preset.name}
                        />
                      ))}
                    </div>
                  </div>
                </div>
                
                <div className="form-group">
                  <label>Amount From (₹) *</label>
                  <input
                    type="number"
                    value={formData.amount_from}
                    onChange={(e) => setFormData({ ...formData, amount_from: e.target.value })}
                    className={`form-input ${errors.amount_from ? 'error' : ''}`}
                    placeholder="0"
                    min="0"
                    step="1"
                  />
                  {errors.amount_from && <span className="error-message">{errors.amount_from}</span>}
                </div>
                
                <div className="form-group">
                  <label>Amount To (₹) *</label>
                  <input
                    type="number"
                    value={formData.amount_to}
                    onChange={(e) => setFormData({ ...formData, amount_to: e.target.value })}
                    className={`form-input ${errors.amount_to ? 'error' : ''}`}
                    placeholder="10000"
                    min="1"
                    step="1"
                  />
                  {errors.amount_to && <span className="error-message">{errors.amount_to}</span>}
                </div>
                
                <div className="form-group">
                  <label>Points Percentage (%) *</label>
                  <input
                    type="number"
                    value={formData.points_percent}
                    onChange={(e) => setFormData({ ...formData, points_percent: e.target.value })}
                    className={`form-input ${errors.points_percent ? 'error' : ''}`}
                    placeholder="1.5"
                    min="0.1"
                    max="100"
                    step="0.1"
                  />
                  {errors.points_percent && <span className="error-message">{errors.points_percent}</span>}
                  <p className="field-hint">
                    Percentage of purchase amount given as loyalty points
                  </p>
                </div>
                
                <div className="form-group">
                  <label>Additional Benefits</label>
                  <textarea
                    value={formData.benefits}
                    onChange={(e) => setFormData({ ...formData, benefits: e.target.value })}
                    className="form-input"
                    placeholder="e.g., Free shipping, Birthday bonus, Priority support"
                    rows="3"
                  />
                </div>
              </div>
              
              {/* Live Preview */}
              {formData.name && formData.points_percent && (
                <div className="preview-section">
                  <h4>Preview</h4>
                  <div className="preview-card" style={{ borderColor: formData.color }}>
                    <div className="preview-header" style={{ background: `${formData.color}15` }}>
                      <FiAward style={{ color: formData.color }} />
                      <span>{formData.name} Member</span>
                    </div>
                    <div className="preview-content">
                      <p>Earn {formData.points_percent}% points on every purchase</p>
                      <p className="preview-example">
                        Example: Spend ₹5,000 → Get {calculateExamplePoints(5000, formData.points_percent)} points
                      </p>
                    </div>
                  </div>
                </div>
              )}
              
              <div className="form-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary">
                  <FiSave />
                  {editingGrade ? 'Update' : 'Create'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Additional Styles */}
      <style jsx>{`
        .info-alert {
          display: flex;
          gap: 1rem;
          padding: 1.25rem;
          background: linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%);
          border-left: 4px solid #3b82f6;
          border-radius: 12px;
          margin-bottom: 2rem;
          align-items: flex-start;
        }
        
        .info-alert svg {
          font-size: 1.5rem;
          color: #3b82f6;
          flex-shrink: 0;
          margin-top: 0.25rem;
        }
        
        .info-alert strong {
          display: block;
          color: #1e40af;
          margin-bottom: 0.25rem;
        }
        
        .info-alert p {
          margin: 0;
          color: #1e3a8a;
          font-size: 0.9rem;
        }
        
        .grades-container {
          display: grid;
          gap: 1.5rem;
        }
        
        .grade-card {
          background: white;
          border-radius: 16px;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.06);
          overflow: hidden;
          transition: all 0.3s ease;
        }
        
        .grade-card:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 30px rgba(0, 0, 0, 0.1);
        }
        
        .grade-header {
          padding: 1.5rem;
          display: flex;
          align-items: center;
          gap: 1rem;
        }
        
        .grade-icon {
          width: 50px;
          height: 50px;
          border-radius: 12px;
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
          font-size: 1.5rem;
        }
        
        .grade-title {
          flex: 1;
        }
        
        .grade-title h3 {
          margin: 0;
          font-size: 1.25rem;
          font-weight: 700;
          color: #1f2937;
        }
        
        .grade-level {
          font-size: 0.875rem;
          color: #6b7280;
          font-weight: 500;
        }
        
        .grade-actions {
          display: flex;
          gap: 0.5rem;
        }
        
        .action-btn {
          padding: 0.5rem;
          background: white;
          border: 2px solid #e5e7eb;
          border-radius: 8px;
          color: #6b7280;
          cursor: pointer;
          transition: all 0.3s ease;
        }
        
        .action-btn:hover {
          border-color: #9333ea;
          color: #9333ea;
        }
        
        .action-btn.danger:hover {
          border-color: #ef4444;
          color: #ef4444;
        }
        
        .grade-body {
          padding: 1.5rem;
        }
        
        .grade-range {
          display: flex;
          align-items: center;
          gap: 1rem;
          padding: 1rem;
          background: #f9fafb;
          border-radius: 12px;
          margin-bottom: 1rem;
        }
        
        .range-item {
          flex: 1;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 0.25rem;
        }
        
        .range-label {
          font-size: 0.75rem;
          color: #9ca3af;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }
        
        .range-value {
          font-size: 1.25rem;
          font-weight: 700;
          color: #1f2937;
        }
        
        .range-arrow {
          color: #9ca3af;
          font-size: 1.25rem;
        }
        
        .points-info {
          display: flex;
          flex-direction: column;
          gap: 0.75rem;
          margin-bottom: 1rem;
        }
        
        .points-rate {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          font-weight: 600;
          color: #059669;
        }
        
        .points-icon {
          font-size: 1.125rem;
        }
        
        .points-example {
          padding: 0.75rem;
          background: linear-gradient(135deg, #d1fae5 0%, #a7f3d0 100%);
          border-radius: 8px;
          font-size: 0.875rem;
        }
        
        .example-label {
          color: #065f46;
          font-weight: 600;
          margin-right: 0.5rem;
        }
        
        .example-text {
          color: #047857;
        }
        
        .grade-benefits {
          padding-top: 1rem;
          border-top: 1px solid #e5e7eb;
        }
        
        .benefits-label {
          display: block;
          font-size: 0.875rem;
          font-weight: 600;
          color: #6b7280;
          margin-bottom: 0.5rem;
        }
        
        .benefits-text {
          margin: 0;
          color: #4b5563;
          font-size: 0.875rem;
          line-height: 1.5;
        }
        
        .color-selector {
          display: flex;
          gap: 1rem;
          align-items: center;
        }
        
        .color-input {
          width: 60px;
          height: 40px;
          border: 2px solid #e5e7eb;
          border-radius: 8px;
          cursor: pointer;
        }
        
        .color-presets {
          display: flex;
          gap: 0.5rem;
        }
        
        .color-preset {
          width: 32px;
          height: 32px;
          border-radius: 6px;
          border: 2px solid #e5e7eb;
          cursor: pointer;
          transition: all 0.3s ease;
        }
        
        .color-preset:hover {
          transform: scale(1.1);
          border-color: #9333ea;
        }
        
        .field-hint {
          margin-top: 0.5rem;
          font-size: 0.75rem;
          color: #6b7280;
        }
        
        .preview-section {
          margin-top: 1.5rem;
          padding: 1rem;
          background: #f9fafb;
          border-radius: 12px;
        }
        
        .preview-section h4 {
          margin: 0 0 1rem 0;
          font-size: 0.875rem;
          font-weight: 600;
          color: #6b7280;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }
        
        .preview-card {
          background: white;
          border: 2px solid;
          border-radius: 10px;
          overflow: hidden;
        }
        
        .preview-header {
          padding: 1rem;
          display: flex;
          align-items: center;
          gap: 0.5rem;
          font-weight: 600;
        }
        
        .preview-content {
          padding: 1rem;
        }
        
        .preview-content p {
          margin: 0 0 0.5rem 0;
          font-size: 0.875rem;
          color: #4b5563;
        }
        
        .preview-example {
          color: #059669;
          font-weight: 600;
        }
        
        @media (max-width: 768px) {
          .grade-range {
            flex-direction: column;
          }
          
          .range-arrow {
            transform: rotate(90deg);
          }
        }
      `}</style>
    </div>
  );
}

export default LoyaltyGrade;