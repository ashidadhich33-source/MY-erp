import React, { useState, useEffect } from 'react';
import { 
  FiDollarSign, FiPlus, FiSave, FiEdit2, FiTrash2,
  FiTrendingDown, FiCalendar, FiRefreshCw, FiPieChart,
  FiAlertCircle, FiCheckCircle
} from 'react-icons/fi';
import toast from 'react-hot-toast';
import axios from 'axios';
import './SetupScreens.css';

const API_URL = 'http://localhost:8000/api/v1';

function ExpenseHead() {
  const [expenseHeads, setExpenseHeads] = useState([]);
  const [loading, setLoading] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [editingHead, setEditingHead] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  
  // Form state
  const [formData, setFormData] = useState({
    name: '',
    code: '',
    category: 'operational',
    type: 'fixed',
    budget_monthly: '',
    budget_yearly: '',
    is_recurring: false,
    recurring_day: 1,
    description: '',
    active: true
  });

  // Validation errors
  const [errors, setErrors] = useState({});

  // Stats
  const [stats, setStats] = useState({
    totalHeads: 0,
    activeHeads: 0,
    totalMonthlyBudget: 0,
    totalYearlyBudget: 0,
    recurringExpenses: 0,
    highestBudget: null
  });

  // Categories
  const categories = [
    { value: 'operational', label: 'Operational', icon: '⚙️' },
    { value: 'administrative', label: 'Administrative', icon: '📋' },
    { value: 'marketing', label: 'Marketing', icon: '📣' },
    { value: 'utilities', label: 'Utilities', icon: '💡' },
    { value: 'maintenance', label: 'Maintenance', icon: '🔧' },
    { value: 'salary', label: 'Salary & Wages', icon: '💰' },
    { value: 'rent', label: 'Rent & Lease', icon: '🏢' },
    { value: 'miscellaneous', label: 'Miscellaneous', icon: '📦' }
  ];

  // Expense types
  const expenseTypes = [
    { value: 'fixed', label: 'Fixed' },
    { value: 'variable', label: 'Variable' },
    { value: 'semi-variable', label: 'Semi-Variable' }
  ];

  // Fetch expense heads
  const fetchExpenseHeads = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(
        `${API_URL}/setup/expense-heads`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      const headsData = response.data || [];
      setExpenseHeads(headsData);
      calculateStats(headsData);
    } catch (error) {
      toast.error('Failed to fetch expense heads');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchExpenseHeads();
    generateExpenseCode();
  }, []);

  // Generate unique expense code
  const generateExpenseCode = () => {
    const code = `EXP${Date.now().toString().slice(-6)}`;
    setFormData(prev => ({ ...prev, code }));
  };

  // Calculate stats
  const calculateStats = (heads) => {
    const activeHeads = heads.filter(h => h.active);
    const totalMonthly = heads.reduce((sum, h) => sum + (h.budget_monthly || 0), 0);
    const totalYearly = heads.reduce((sum, h) => sum + (h.budget_yearly || 0), 0);
    const recurring = heads.filter(h => h.is_recurring).length;
    const highest = heads.reduce((max, h) => {
      if (!max || h.budget_yearly > max.budget_yearly) return h;
      return max;
    }, null);

    setStats({
      totalHeads: heads.length,
      activeHeads: activeHeads.length,
      totalMonthlyBudget: totalMonthly,
      totalYearlyBudget: totalYearly,
      recurringExpenses: recurring,
      highestBudget: highest
    });
  };

  // Filter expense heads
  const filteredHeads = expenseHeads.filter(head =>
    head.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    head.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
    head.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Validate form
  const validateForm = () => {
    const newErrors = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Expense head name is required';
    }

    if (!formData.code.trim()) {
      newErrors.code = 'Code is required';
    }

    if (formData.budget_monthly && formData.budget_monthly < 0) {
      newErrors.budget_monthly = 'Budget cannot be negative';
    }

    if (formData.budget_yearly && formData.budget_yearly < 0) {
      newErrors.budget_yearly = 'Budget cannot be negative';
    }

    if (formData.is_recurring && (formData.recurring_day < 1 || formData.recurring_day > 31)) {
      newErrors.recurring_day = 'Day must be between 1 and 31';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      toast.error('Please fix the errors in the form');
      return;
    }

    const confirmMsg = editingHead 
      ? 'Update expense head?' 
      : 'Create new expense head?';
      
    if (!window.confirm(confirmMsg)) return;

    try {
      const token = localStorage.getItem('token');
      const endpoint = editingHead 
        ? `${API_URL}/setup/expense-heads/${editingHead.id}`
        : `${API_URL}/setup/expense-heads`;
      
      const method = editingHead ? 'put' : 'post';
      
      await axios[method](endpoint, formData, {
        headers: { Authorization: `Bearer ${token}` }
      });

      toast.success(`Expense head ${editingHead ? 'updated' : 'created'} successfully`);
      setShowModal(false);
      resetForm();
      fetchExpenseHeads();
    } catch (error) {
      if (error.response?.data?.detail) {
        toast.error(error.response.data.detail);
      } else {
        toast.error('Failed to save expense head');
      }
    }
  };

  // Reset form
  const resetForm = () => {
    setFormData({
      name: '',
      code: '',
      category: 'operational',
      type: 'fixed',
      budget_monthly: '',
      budget_yearly: '',
      is_recurring: false,
      recurring_day: 1,
      description: '',
      active: true
    });
    setEditingHead(null);
    setErrors({});
    generateExpenseCode();
  };

  // Edit expense head
  const handleEdit = (head) => {
    setFormData(head);
    setEditingHead(head);
    setShowModal(true);
  };

  // Toggle status
  const toggleStatus = async (head) => {
    try {
      const token = localStorage.getItem('token');
      await axios.patch(
        `${API_URL}/setup/expense-heads/${head.id}/toggle-status`,
        {},
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      toast.success(`Expense head ${head.active ? 'deactivated' : 'activated'}`);
      fetchExpenseHeads();
    } catch (error) {
      toast.error('Failed to update status');
    }
  };

  // Delete expense head
  const handleDelete = async (head) => {
    if (!window.confirm(`Delete expense head "${head.name}"?`)) {
      return;
    }

    try {
      const token = localStorage.getItem('token');
      await axios.delete(
        `${API_URL}/setup/expense-heads/${head.id}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      toast.success('Expense head deleted successfully');
      fetchExpenseHeads();
    } catch (error) {
      toast.error('Failed to delete expense head');
    }
  };

  // Calculate budget utilization
  const getBudgetUtilization = (head) => {
    // Mock calculation - in real app, this would come from actual expense data
    const utilization = Math.random() * 100;
    return {
      percentage: utilization.toFixed(1),
      color: utilization > 90 ? 'red' : utilization > 70 ? 'orange' : 'green'
    };
  };

  return (
    <div className="setup-container">
      {/* Header */}
      <div className="setup-header">
        <div className="header-left">
          <h1 className="page-title">
            <FiDollarSign className="title-icon" />
            Expense Heads
          </h1>
          <p className="page-subtitle">Configure expense categories and budgets</p>
        </div>
        <div className="header-actions">
          <button className="btn-refresh" onClick={fetchExpenseHeads}>
            <FiRefreshCw /> Refresh
          </button>
          <button className="btn-primary" onClick={() => setShowModal(true)}>
            <FiPlus /> Add Expense Head
          </button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon-wrapper purple">
            <FiPieChart />
          </div>
          <div className="stat-content">
            <p className="stat-label">Total Heads</p>
            <p className="stat-value">{stats.totalHeads}</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon-wrapper green">
            <FiCheckCircle />
          </div>
          <div className="stat-content">
            <p className="stat-label">Active Heads</p>
            <p className="stat-value">{stats.activeHeads}</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon-wrapper blue">
            <FiTrendingDown />
          </div>
          <div className="stat-content">
            <p className="stat-label">Monthly Budget</p>
            <p className="stat-value">₹{stats.totalMonthlyBudget.toLocaleString()}</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon-wrapper orange">
            <FiCalendar />
          </div>
          <div className="stat-content">
            <p className="stat-label">Recurring</p>
            <p className="stat-value">{stats.recurringExpenses}</p>
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="filters-bar">
        <div className="search-box">
          <input
            type="text"
            placeholder="Search expense heads..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="search-input"
          />
        </div>
      </div>

      {/* Expense Heads Table */}
      <div className="table-container">
        <table className="data-table">
          <thead>
            <tr>
              <th>Code</th>
              <th>Name</th>
              <th>Category</th>
              <th>Type</th>
              <th>Monthly Budget</th>
              <th>Yearly Budget</th>
              <th>Utilization</th>
              <th>Recurring</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan="10" className="text-center">
                  <div className="loading-spinner">Loading...</div>
                </td>
              </tr>
            ) : filteredHeads.length === 0 ? (
              <tr>
                <td colSpan="10" className="text-center empty-state">
                  <FiDollarSign size={48} />
                  <p>No expense heads found</p>
                  <button className="btn-primary btn-sm" onClick={() => setShowModal(true)}>
                    Add First Expense Head
                  </button>
                </td>
              </tr>
            ) : (
              filteredHeads.map((head) => {
                const utilization = getBudgetUtilization(head);
                const category = categories.find(c => c.value === head.category);
                
                return (
                  <tr key={head.id}>
                    <td className="code-cell">{head.code}</td>
                    <td>
                      <div className="name-with-icon">
                        <span className="category-icon">{category?.icon}</span>
                        {head.name}
                      </div>
                    </td>
                    <td>
                      <span className="category-badge">
                        {category?.label}
                      </span>
                    </td>
                    <td>
                      <span className={`type-badge type-${head.type}`}>
                        {expenseTypes.find(t => t.value === head.type)?.label}
                      </span>
                    </td>
                    <td className="budget-cell">
                      ₹{head.budget_monthly?.toLocaleString() || '-'}
                    </td>
                    <td className="budget-cell">
                      ₹{head.budget_yearly?.toLocaleString() || '-'}
                    </td>
                    <td>
                      <div className="utilization-cell">
                        <div className="utilization-bar">
                          <div 
                            className={`utilization-fill utilization-${utilization.color}`}
                            style={{ width: `${utilization.percentage}%` }}
                          />
                        </div>
                        <span className="utilization-text">
                          {utilization.percentage}%
                        </span>
                      </div>
                    </td>
                    <td>
                      {head.is_recurring ? (
                        <span className="recurring-badge">
                          Day {head.recurring_day}
                        </span>
                      ) : (
                        <span className="non-recurring">-</span>
                      )}
                    </td>
                    <td>
                      <span className={`status-badge ${head.active ? 'active' : 'inactive'}`}>
                        {head.active ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                    <td>
                      <div className="action-buttons">
                        <button 
                          className="btn-icon"
                          onClick={() => handleEdit(head)}
                          title="Edit"
                        >
                          <FiEdit2 />
                        </button>
                        <button 
                          className="btn-icon"
                          onClick={() => toggleStatus(head)}
                          title={head.active ? 'Deactivate' : 'Activate'}
                        >
                          {head.active ? <FiAlertCircle /> : <FiCheckCircle />}
                        </button>
                        <button 
                          className="btn-icon btn-danger"
                          onClick={() => handleDelete(head)}
                          title="Delete"
                        >
                          <FiTrash2 />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Add/Edit Modal */}
      {showModal && (
        <div className="modal-overlay">
          <div className="modal-content">
            <div className="modal-header">
              <h2>{editingHead ? 'Edit Expense Head' : 'Add Expense Head'}</h2>
              <button className="btn-close" onClick={() => {
                setShowModal(false);
                resetForm();
              }}>×</button>
            </div>

            <form onSubmit={handleSubmit} className="modal-form">
              <div className="form-row">
                <div className="form-group">
                  <label>Code</label>
                  <input
                    type="text"
                    value={formData.code}
                    readOnly
                    className="readonly"
                  />
                </div>

                <div className="form-group">
                  <label>Name *</label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    className={errors.name ? 'error' : ''}
                    placeholder="e.g., Office Rent"
                  />
                  {errors.name && <span className="error-message">{errors.name}</span>}
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Category *</label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({...formData, category: e.target.value})}
                  >
                    {categories.map(cat => (
                      <option key={cat.value} value={cat.value}>
                        {cat.icon} {cat.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="form-group">
                  <label>Type *</label>
                  <select
                    value={formData.type}
                    onChange={(e) => setFormData({...formData, type: e.target.value})}
                  >
                    {expenseTypes.map(type => (
                      <option key={type.value} value={type.value}>
                        {type.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Monthly Budget</label>
                  <input
                    type="number"
                    value={formData.budget_monthly}
                    onChange={(e) => setFormData({...formData, budget_monthly: e.target.value})}
                    className={errors.budget_monthly ? 'error' : ''}
                    placeholder="₹"
                    min="0"
                  />
                  {errors.budget_monthly && <span className="error-message">{errors.budget_monthly}</span>}
                </div>

                <div className="form-group">
                  <label>Yearly Budget</label>
                  <input
                    type="number"
                    value={formData.budget_yearly}
                    onChange={(e) => setFormData({...formData, budget_yearly: e.target.value})}
                    className={errors.budget_yearly ? 'error' : ''}
                    placeholder="₹"
                    min="0"
                  />
                  {errors.budget_yearly && <span className="error-message">{errors.budget_yearly}</span>}
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label className="checkbox-label">
                    <input
                      type="checkbox"
                      checked={formData.is_recurring}
                      onChange={(e) => setFormData({...formData, is_recurring: e.target.checked})}
                    />
                    Is Recurring Expense
                  </label>
                </div>

                {formData.is_recurring && (
                  <div className="form-group">
                    <label>Recurring Day *</label>
                    <input
                      type="number"
                      value={formData.recurring_day}
                      onChange={(e) => setFormData({...formData, recurring_day: e.target.value})}
                      className={errors.recurring_day ? 'error' : ''}
                      min="1"
                      max="31"
                    />
                    {errors.recurring_day && <span className="error-message">{errors.recurring_day}</span>}
                  </div>
                )}
              </div>

              <div className="form-group">
                <label>Description</label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  rows="3"
                  placeholder="Additional notes..."
                />
              </div>

              <div className="form-group">
                <label className="checkbox-label">
                  <input
                    type="checkbox"
                    checked={formData.active}
                    onChange={(e) => setFormData({...formData, active: e.target.checked})}
                  />
                  Active
                </label>
              </div>

              <div className="modal-footer">
                <button 
                  type="button" 
                  className="btn-secondary"
                  onClick={() => {
                    setShowModal(false);
                    resetForm();
                  }}
                >
                  Cancel
                </button>
                <button type="submit" className="btn-primary">
                  <FiSave /> {editingHead ? 'Update' : 'Save'} Expense Head
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default ExpenseHead;