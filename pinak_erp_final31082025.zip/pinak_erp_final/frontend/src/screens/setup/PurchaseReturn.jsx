import React, { useState, useEffect } from 'react';
import { 
  FiRotateCcw, FiSearch, FiPlus, FiTrash2,
  FiSave, FiPackage, FiAlertCircle, FiCheckCircle,
  FiFileText, FiCalendar, FiDollarSign
} from 'react-icons/fi';
import toast from 'react-hot-toast';
import axios from 'axios';
import './SetupScreens.css';

const API_URL = 'http://localhost:8000/api/v1';

function PurchaseReturn() {
  const [loading, setLoading] = useState(false);
  const [searching, setSearching] = useState(false);
  const [billSearch, setBillSearch] = useState('');
  const [selectedBill, setSelectedBill] = useState(null);
  const [returnItems, setReturnItems] = useState([]);
  const [returnReason, setReturnReason] = useState('');
  const [debitNoteNo, setDebitNoteNo] = useState('');
  
  // Stats
  const [stats, setStats] = useState({
    todayReturns: 0,
    monthReturns: 0,
    totalValue: 0,
    pendingApprovals: 0
  });

  // Return reasons
  const returnReasons = [
    'Damaged Goods',
    'Wrong Items',
    'Quality Issues',
    'Expired Products',
    'Excess Quantity',
    'Price Dispute',
    'Other'
  ];

  // Generate debit note number
  useEffect(() => {
    generateDebitNoteNumber();
    fetchStats();
  }, []);

  const generateDebitNoteNumber = () => {
    const prefix = 'DN/';
    const timestamp = Date.now().toString().slice(-6);
    setDebitNoteNo(`${prefix}${timestamp}`);
  };

  const fetchStats = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(
        `${API_URL}/purchase-returns/stats`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setStats(response.data);
    } catch (error) {
      console.error('Failed to fetch stats');
    }
  };

  // Search purchase bill
  const searchBill = async () => {
    if (!billSearch.trim()) {
      toast.error('Please enter a bill number');
      return;
    }

    setSearching(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(
        `${API_URL}/purchases/bill/${billSearch}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );

      if (response.data) {
        setSelectedBill(response.data);
        setReturnItems(
          response.data.items.map(item => ({
            ...item,
            return_qty: 0,
            selected: false,
            max_returnable: item.quantity - (item.returned_qty || 0)
          }))
        );
        toast.success('Purchase bill loaded');
      } else {
        toast.error('Bill not found');
      }
    } catch (error) {
      toast.error('Failed to fetch bill details');
    } finally {
      setSearching(false);
    }
  };

  // Handle item selection
  const handleItemSelect = (index, selected) => {
    const updatedItems = [...returnItems];
    updatedItems[index].selected = selected;
    if (!selected) {
      updatedItems[index].return_qty = 0;
    }
    setReturnItems(updatedItems);
  };

  // Handle quantity change
  const handleQtyChange = (index, qty) => {
    const updatedItems = [...returnItems];
    const maxQty = updatedItems[index].max_returnable;
    
    if (qty > maxQty) {
      toast.error(`Maximum returnable quantity is ${maxQty}`);
      return;
    }
    
    updatedItems[index].return_qty = qty;
    updatedItems[index].selected = qty > 0;
    setReturnItems(updatedItems);
  };

  // Calculate totals
  const calculateTotals = () => {
    let totalItems = 0;
    let totalAmount = 0;
    let totalGST = 0;

    returnItems.forEach(item => {
      if (item.selected && item.return_qty > 0) {
        totalItems += item.return_qty;
        const itemAmount = item.return_qty * item.purchase_rate;
        const gstAmount = itemAmount * (item.gst_rate / 100);
        totalAmount += itemAmount;
        totalGST += gstAmount;
      }
    });

    return {
      totalItems,
      totalAmount,
      totalGST,
      grandTotal: totalAmount + totalGST
    };
  };

  // Process return
  const processReturn = async () => {
    const selectedItems = returnItems.filter(item => item.selected && item.return_qty > 0);
    
    if (selectedItems.length === 0) {
      toast.error('Please select items to return');
      return;
    }

    if (!returnReason) {
      toast.error('Please select a return reason');
      return;
    }

    const confirmMsg = `Process return for ${selectedItems.length} items?`;
    if (!window.confirm(confirmMsg)) return;

    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const returnData = {
        purchase_bill_id: selectedBill.id,
        debit_note_no: debitNoteNo,
        return_date: new Date().toISOString(),
        reason: returnReason,
        items: selectedItems.map(item => ({
          item_id: item.id,
          barcode: item.barcode,
          return_qty: item.return_qty,
          purchase_rate: item.purchase_rate,
          gst_rate: item.gst_rate
        })),
        ...calculateTotals()
      };

      const response = await axios.post(
        `${API_URL}/purchase-returns`,
        returnData,
        { headers: { Authorization: `Bearer ${token}` } }
      );

      toast.success('Purchase return processed successfully');
      
      // Reset form
      setSelectedBill(null);
      setReturnItems([]);
      setBillSearch('');
      setReturnReason('');
      generateDebitNoteNumber();
      fetchStats();
      
      // Print debit note if needed
      if (window.confirm('Print debit note?')) {
        printDebitNote(response.data);
      }
    } catch (error) {
      toast.error('Failed to process return');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  // Print debit note
  const printDebitNote = (returnData) => {
    // Implementation for printing debit note
    window.print();
  };

  const totals = calculateTotals();

  return (
    <div className="setup-container">
      {/* Header */}
      <div className="setup-header">
        <div className="header-left">
          <h1 className="page-title">
            <FiRotateCcw className="title-icon" />
            Purchase Return
          </h1>
          <p className="page-subtitle">Process purchase returns and generate debit notes</p>
        </div>
        <div className="header-actions">
          <div className="debit-note-display">
            <FiFileText />
            Debit Note: <strong>{debitNoteNo}</strong>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon-wrapper purple">
            <FiRotateCcw />
          </div>
          <div className="stat-content">
            <p className="stat-label">Today's Returns</p>
            <p className="stat-value">{stats.todayReturns}</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon-wrapper blue">
            <FiCalendar />
          </div>
          <div className="stat-content">
            <p className="stat-label">Month Returns</p>
            <p className="stat-value">{stats.monthReturns}</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon-wrapper green">
            <FiDollarSign />
          </div>
          <div className="stat-content">
            <p className="stat-label">Total Value</p>
            <p className="stat-value">₹{stats.totalValue.toLocaleString()}</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon-wrapper orange">
            <FiAlertCircle />
          </div>
          <div className="stat-content">
            <p className="stat-label">Pending Approvals</p>
            <p className="stat-value">{stats.pendingApprovals}</p>
          </div>
        </div>
      </div>

      {/* Bill Search Section */}
      <div className="search-section">
        <div className="search-card">
          <h3><FiSearch /> Search Purchase Bill</h3>
          <div className="search-row">
            <input
              type="text"
              placeholder="Enter purchase bill number..."
              value={billSearch}
              onChange={(e) => setBillSearch(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && searchBill()}
              className="search-input-large"
            />
            <button 
              className="btn-primary"
              onClick={searchBill}
              disabled={searching}
            >
              {searching ? 'Searching...' : 'Search Bill'}
            </button>
          </div>
        </div>
      </div>

      {/* Selected Bill Details */}
      {selectedBill && (
        <div className="bill-details-card">
          <div className="bill-header">
            <div className="bill-info">
              <h3>Bill No: {selectedBill.bill_no}</h3>
              <p>Date: {new Date(selectedBill.bill_date).toLocaleDateString()}</p>
            </div>
            <div className="supplier-info">
              <p><strong>Supplier:</strong> {selectedBill.supplier_name}</p>
              <p><strong>Total Amount:</strong> ₹{selectedBill.grand_total.toLocaleString()}</p>
            </div>
          </div>

          {/* Return Reason */}
          <div className="return-reason-section">
            <label>Return Reason *</label>
            <select 
              value={returnReason}
              onChange={(e) => setReturnReason(e.target.value)}
              className="reason-select"
            >
              <option value="">Select reason</option>
              {returnReasons.map(reason => (
                <option key={reason} value={reason}>{reason}</option>
              ))}
            </select>
          </div>

          {/* Items Table */}
          <div className="table-container">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Select</th>
                  <th>Barcode</th>
                  <th>Item</th>
                  <th>Purchase Rate</th>
                  <th>GST %</th>
                  <th>Purchased Qty</th>
                  <th>Already Returned</th>
                  <th>Return Qty</th>
                  <th>Amount</th>
                </tr>
              </thead>
              <tbody>
                {returnItems.map((item, index) => {
                  const returnAmount = item.return_qty * item.purchase_rate;
                  const gstAmount = returnAmount * (item.gst_rate / 100);
                  
                  return (
                    <tr key={index} className={item.selected ? 'selected-row' : ''}>
                      <td>
                        <input
                          type="checkbox"
                          checked={item.selected}
                          onChange={(e) => handleItemSelect(index, e.target.checked)}
                          disabled={item.max_returnable === 0}
                        />
                      </td>
                      <td className="barcode-cell">{item.barcode}</td>
                      <td>
                        <div className="item-name">{item.style_code}</div>
                        <div className="item-details">
                          {item.color} | {item.size} | {item.brand}
                        </div>
                      </td>
                      <td className="price-cell">₹{item.purchase_rate}</td>
                      <td>{item.gst_rate}%</td>
                      <td className="qty-cell">{item.quantity}</td>
                      <td className="returned-qty">
                        {item.returned_qty || 0}
                      </td>
                      <td>
                        <input
                          type="number"
                          value={item.return_qty}
                          onChange={(e) => handleQtyChange(index, parseInt(e.target.value) || 0)}
                          min="0"
                          max={item.max_returnable}
                          className="qty-input"
                          disabled={item.max_returnable === 0}
                        />
                      </td>
                      <td className="amount-cell">
                        {item.return_qty > 0 && (
                          <>
                            ₹{returnAmount.toFixed(2)}
                            <div className="gst-text">
                              +GST ₹{gstAmount.toFixed(2)}
                            </div>
                          </>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Return Summary */}
          <div className="return-summary">
            <div className="summary-left">
              <div className="info-message">
                <FiAlertCircle />
                Selected {returnItems.filter(i => i.selected).length} items for return
              </div>
            </div>
            <div className="summary-right">
              <div className="summary-row">
                <span>Total Items:</span>
                <strong>{totals.totalItems}</strong>
              </div>
              <div className="summary-row">
                <span>Total Amount:</span>
                <strong>₹{totals.totalAmount.toFixed(2)}</strong>
              </div>
              <div className="summary-row">
                <span>Total GST:</span>
                <strong>₹{totals.totalGST.toFixed(2)}</strong>
              </div>
              <div className="summary-row grand-total">
                <span>Grand Total:</span>
                <strong>₹{totals.grandTotal.toFixed(2)}</strong>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="action-footer">
            <button 
              className="btn-secondary"
              onClick={() => {
                setSelectedBill(null);
                setReturnItems([]);
                setBillSearch('');
              }}
            >
              Cancel
            </button>
            <button 
              className="btn-primary"
              onClick={processReturn}
              disabled={loading || totals.totalItems === 0}
            >
              <FiSave />
              {loading ? 'Processing...' : 'Process Return'}
            </button>
          </div>
        </div>
      )}

      {/* Recent Returns */}
      <div className="recent-section">
        <h3>Recent Returns</h3>
        <div className="recent-returns-grid">
          {/* This would display recent return transactions */}
          <div className="return-card">
            <div className="return-header">
              <span className="return-no">DN/123456</span>
              <span className="return-date">Today, 2:30 PM</span>
            </div>
            <div className="return-details">
              <p>Supplier: Fashion Hub</p>
              <p>Items: 5 | Amount: ₹12,500</p>
              <p>Reason: Damaged Goods</p>
            </div>
            <div className="return-status">
              <span className="status-badge approved">Approved</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default PurchaseReturn;