import React, { useState, useEffect, useRef } from 'react';
import { 
  FiUsers, FiPlus, FiEdit2, FiSearch, FiPhone, FiMail,
  FiMapPin, FiCalendar, FiGift, FiSave, FiX, FiCheckCircle,
  FiClock, FiUser, FiAward, FiUpload, FiDownload, FiFileText,
  FiTrash2, FiAlertCircle
} from 'react-icons/fi';
import toast from 'react-hot-toast';
import { setupAPI } from '../../services/api';
import axios from 'axios';
import * as XLSX from 'xlsx';
import './SetupScreens.css';

const API_URL = 'http://localhost:8000/api/v1';

function Customers() {
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [showImportModal, setShowImportModal] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState(null);
  const fileInputRef = useRef(null);
  
  // Import state
  const [importFile, setImportFile] = useState(null);
  const [importData, setImportData] = useState([]);
  const [importErrors, setImportErrors] = useState([]);
  const [importing, setImporting] = useState(false);
  
  // Form state - Added kids fields
  const [formData, setFormData] = useState({
    name: '',
    mobile: '',
    email: '',
    address: '',
    city: '',
    pincode: '',
    birthday: '',
    anniversary: '',
    kid1_name: '',
    kid1_dob: '',
    kid2_name: '',
    kid2_dob: '',
    kid3_name: '',
    kid3_dob: '',
    loyalty_points: 0,
    current_grade: 'Regular',
    active: true
  });

  // Validation errors - Store as strings, not objects
  const [errors, setErrors] = useState({});

  // Stats
  const [stats, setStats] = useState({
    total: 0,
    active: 0,
    regular: 0,
    silver: 0,
    gold: 0,
    platinum: 0
  });

  // Fetch customers
  const fetchCustomers = async () => {
    setLoading(true);
    try {
      const response = await setupAPI.getCustomers({
        skip: 0,
        limit: 100, // Changed from 1000 to 100 - backend limit
        search: searchTerm || undefined
      });
      
      const customersData = Array.isArray(response.data) ? response.data : [];
      setCustomers(customersData);
      
      // Calculate stats
      const total = customersData.length;
      const active = customersData.filter(c => c.active !== false).length;
      const regular = customersData.filter(c => !c.loyalty_grade_id || c.current_grade === 'Regular').length;
      const silver = customersData.filter(c => c.loyalty_grade?.name === 'Silver' || c.current_grade === 'Silver').length;
      const gold = customersData.filter(c => c.loyalty_grade?.name === 'Gold' || c.current_grade === 'Gold').length;
      const platinum = customersData.filter(c => c.loyalty_grade?.name === 'Platinum' || c.current_grade === 'Platinum').length;
      
      setStats({ total, active, regular, silver, gold, platinum });
    } catch (error) {
      console.error('Error fetching customers:', error);
      
      // More detailed error handling
      if (error.response?.data?.detail) {
        const detail = error.response.data.detail;
        if (Array.isArray(detail)) {
          // Handle validation errors
          detail.forEach(err => {
            console.error('Validation error:', err);
          });
          toast.error('Failed to fetch customers: Invalid request parameters');
        } else if (typeof detail === 'string') {
          toast.error(`Failed to fetch customers: ${detail}`);
        } else {
          toast.error('Failed to fetch customers');
        }
      } else {
        toast.error('Failed to fetch customers. Please check your connection.');
      }
      
      setCustomers([]);
      setStats({
        total: 0,
        active: 0,
        regular: 0,
        silver: 0,
        gold: 0,
        platinum: 0
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCustomers();
  }, [searchTerm]);

  // Validate mobile number
  const validateMobile = (mobile) => {
    const mobileRegex = /^[6-9]\d{9}$/;
    return mobileRegex.test(mobile);
  };

  // Validate email
  const validateEmail = (email) => {
    if (!email) return true;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  // Validate form
  const validateForm = () => {
    const newErrors = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Name is required';
    }

    if (!formData.mobile.trim()) {
      newErrors.mobile = 'Mobile number is required';
    } else if (!validateMobile(formData.mobile)) {
      newErrors.mobile = 'Invalid mobile number format';
    }

    if (formData.email && !validateEmail(formData.email)) {
      newErrors.email = 'Invalid email format';
    }

    if (formData.pincode && !/^\d{6}$/.test(formData.pincode)) {
      newErrors.pincode = 'Pincode must be 6 digits';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Reset form - Updated with kids fields
  const resetForm = () => {
    setFormData({
      name: '',
      mobile: '',
      email: '',
      address: '',
      city: '',
      pincode: '',
      birthday: '',
      anniversary: '',
      kid1_name: '',
      kid1_dob: '',
      kid2_name: '',
      kid2_dob: '',
      kid3_name: '',
      kid3_dob: '',
      loyalty_points: 0,
      current_grade: 'Regular',
      active: true
    });
    setErrors({});
    setEditingCustomer(null);
  };

  // Handle input change
  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    
    let finalValue = value;
    
    if (type === 'checkbox') {
      finalValue = checked;
    } else if (type === 'date') {
      // HTML5 date input already provides YYYY-MM-DD format
      finalValue = value;
    } else if (name.includes('dob') || name === 'birthday' || name === 'anniversary') {
      // For text inputs that should contain dates
      // Allow the user to type, we'll convert on submit
      finalValue = value;
    } else {
      finalValue = value;
    }
    
    setFormData(prev => ({
      ...prev,
      [name]: finalValue
    }));
    
    // Clear error for this field when user starts typing
    if (errors[name]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };

  // Helper function to convert date from DD/MM/YYYY to YYYY-MM-DD
  const convertDateToISO = (dateStr) => {
    if (!dateStr || dateStr === '') return null;
    
    // If already in YYYY-MM-DD format, return as is
    if (dateStr.match(/^\d{4}-\d{2}-\d{2}$/)) {
      return dateStr;
    }
    
    // Convert from DD/MM/YYYY to YYYY-MM-DD
    if (dateStr.match(/^\d{1,2}\/\d{1,2}\/\d{4}$/)) {
      const parts = dateStr.split('/');
      const day = parts[0].padStart(2, '0');
      const month = parts[1].padStart(2, '0');
      const year = parts[2];
      return `${year}-${month}-${day}`;
    }
    
    // Try to parse other formats
    try {
      const date = new Date(dateStr);
      if (!isNaN(date.getTime())) {
        return date.toISOString().split('T')[0];
      }
    } catch (e) {
      console.error('Invalid date format:', dateStr);
    }
    
    return null;
  };

  // Handle submit
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      toast.error('Please fix validation errors');
      return;
    }

    // Prepare data with properly formatted dates
    const submitData = {
      ...formData,
      birthday: convertDateToISO(formData.birthday),
      anniversary: convertDateToISO(formData.anniversary),
      kid1_dob: convertDateToISO(formData.kid1_dob),
      kid2_dob: convertDateToISO(formData.kid2_dob),
      kid3_dob: convertDateToISO(formData.kid3_dob)
    };

    // Remove null date values to avoid backend validation errors
    Object.keys(submitData).forEach(key => {
      if (key.includes('dob') || key === 'birthday' || key === 'anniversary') {
        if (submitData[key] === null || submitData[key] === '') {
          delete submitData[key];
        }
      }
    });

    try {
      if (editingCustomer) {
        await setupAPI.updateCustomer(editingCustomer.mobile, submitData);
        toast.success('Customer updated successfully');
      } else {
        await setupAPI.createCustomer(submitData);
        toast.success('Customer created successfully');
      }
      
      setShowModal(false);
      resetForm();
      fetchCustomers();
    } catch (error) {
      console.error('Error saving customer:', error);
      
      // Handle validation errors from backend
      if (error.response?.data?.detail) {
        const detail = error.response.data.detail;
        
        // Check if detail is an array of validation errors
        if (Array.isArray(detail)) {
          const newErrors = {};
          detail.forEach(err => {
            // Extract field name from loc array
            const fieldName = err.loc?.[err.loc.length - 1] || 'unknown';
            // Store only the message string, not the entire error object
            newErrors[fieldName] = err.msg || 'Validation error';
            
            // Also show as toast
            toast.error(`${fieldName}: ${err.msg}`);
          });
          setErrors(newErrors);
        } else if (typeof detail === 'string') {
          // If detail is a string, show it as toast
          toast.error(detail);
        } else if (typeof detail === 'object' && detail.msg) {
          // If detail is an object with msg property
          toast.error(detail.msg);
        } else {
          toast.error('Failed to save customer');
        }
      } else {
        toast.error(`Failed to ${editingCustomer ? 'update' : 'create'} customer`);
      }
    }
  };

  // Handle edit
  const handleEdit = (customer) => {
    setFormData({
      name: customer.name || '',
      mobile: customer.mobile || '',
      email: customer.email || '',
      address: customer.address || '',
      city: customer.city || '',
      pincode: customer.pincode || '',
      birthday: customer.birthday || '',
      anniversary: customer.anniversary || '',
      kid1_name: customer.kid1_name || '',
      kid1_dob: customer.kid1_dob || '',
      kid2_name: customer.kid2_name || '',
      kid2_dob: customer.kid2_dob || '',
      kid3_name: customer.kid3_name || '',
      kid3_dob: customer.kid3_dob || '',
      loyalty_points: customer.loyalty_points || 0,
      current_grade: customer.current_grade || 'Regular',
      active: customer.active !== undefined ? customer.active : true
    });
    setEditingCustomer(customer);
    setShowModal(true);
    setErrors({});
  };

  // Handle delete - Using direct axios call
  const handleDelete = async (mobile) => {
    if (!window.confirm('Are you sure you want to delete this customer?')) {
      return;
    }

    try {
      const token = localStorage.getItem('token');
      // Using DELETE method with mobile as path parameter
      await axios.delete(
        `${API_URL}/setup/customers/${mobile}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      toast.success('Customer deleted successfully');
      fetchCustomers();
    } catch (error) {
      console.error('Error deleting customer:', error);
      if (error.response?.data?.detail) {
        toast.error(error.response.data.detail);
      } else {
        toast.error('Failed to delete customer. This customer may have transaction history.');
      }
    }
  };

  // Download sample Excel template
  const downloadSampleExcel = () => {
    const sampleData = [
      {
        name: 'John Doe',
        mobile: '9876543210',
        email: 'john@example.com',
        address: '123 Main Street',
        city: 'Mumbai',
        pincode: '400001',
        birthday: '1990-05-15',
        anniversary: '2015-10-20',
        kid1_name: 'Alice',
        kid1_dob: '2018-03-10',
        kid2_name: 'Bob',
        kid2_dob: '2020-07-25',
        kid3_name: '',
        kid3_dob: ''
      },
      {
        name: 'Jane Smith',
        mobile: '9876543211',
        email: 'jane@example.com',
        address: '456 Park Avenue',
        city: 'Delhi',
        pincode: '110001',
        birthday: '1985-08-22',
        anniversary: '',
        kid1_name: '',
        kid1_dob: '',
        kid2_name: '',
        kid2_dob: '',
        kid3_name: '',
        kid3_dob: ''
      }
    ];

    const ws = XLSX.utils.json_to_sheet(sampleData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Customers');

    // Set column widths
    const colWidths = [
      { wch: 20 }, // name
      { wch: 12 }, // mobile
      { wch: 25 }, // email
      { wch: 30 }, // address
      { wch: 15 }, // city
      { wch: 8 },  // pincode
      { wch: 12 }, // birthday
      { wch: 12 }, // anniversary
      { wch: 15 }, // kid1_name
      { wch: 12 }, // kid1_dob
      { wch: 15 }, // kid2_name
      { wch: 12 }, // kid2_dob
      { wch: 15 }, // kid3_name
      { wch: 12 }  // kid3_dob
    ];
    ws['!cols'] = colWidths;

    XLSX.writeFile(wb, 'customer_import_template.xlsx');
    toast.success('Sample template downloaded');
  };

  // Handle file selection for import
  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    if (!file.name.match(/\.(xlsx|xls)$/)) {
      toast.error('Please select an Excel file');
      return;
    }

    setImportFile(file);
    parseExcelFile(file);
  };

  // Parse Excel file
  const parseExcelFile = (file) => {
    const reader = new FileReader();
    
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target.result);
        const workbook = XLSX.read(data, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet);

        // Validate and format data
        const validatedData = [];
        const errors = [];

        jsonData.forEach((row, index) => {
          const rowErrors = [];
          
          // Validate required fields
          if (!row.name) rowErrors.push('Name is required');
          if (!row.mobile) rowErrors.push('Mobile is required');
          else if (!validateMobile(row.mobile.toString())) rowErrors.push('Invalid mobile number');
          
          if (row.email && !validateEmail(row.email)) rowErrors.push('Invalid email');
          if (row.pincode && !/^\d{6}$/.test(row.pincode.toString())) rowErrors.push('Invalid pincode');

          if (rowErrors.length > 0) {
            errors.push({ row: index + 2, errors: rowErrors });
          } else {
            // Format dates if present
            const formattedRow = {
              ...row,
              mobile: row.mobile.toString(),
              pincode: row.pincode ? row.pincode.toString() : '',
              birthday: convertDateToISO(row.birthday),
              anniversary: convertDateToISO(row.anniversary),
              kid1_dob: convertDateToISO(row.kid1_dob),
              kid2_dob: convertDateToISO(row.kid2_dob),
              kid3_dob: convertDateToISO(row.kid3_dob)
            };
            validatedData.push(formattedRow);
          }
        });

        setImportData(validatedData);
        setImportErrors(errors);
        
        if (errors.length > 0) {
          toast.error(`Found ${errors.length} rows with errors`);
        } else {
          toast.success(`${validatedData.length} customers ready to import`);
        }
      } catch (error) {
        console.error('Error parsing file:', error);
        toast.error('Failed to parse Excel file');
      }
    };

    reader.readAsArrayBuffer(file);
  };

  // Handle bulk import
  const handleBulkImport = async () => {
    if (importData.length === 0) {
      toast.error('No valid data to import');
      return;
    }

    setImporting(true);
    let successCount = 0;
    let failCount = 0;

    for (const customer of importData) {
      try {
        // Remove empty date fields
        const cleanedData = { ...customer };
        Object.keys(cleanedData).forEach(key => {
          if ((key.includes('dob') || key === 'birthday' || key === 'anniversary') && 
              (!cleanedData[key] || cleanedData[key] === '')) {
            delete cleanedData[key];
          }
        });

        await setupAPI.createCustomer(cleanedData);
        successCount++;
      } catch (error) {
        console.error(`Failed to import customer ${customer.mobile}:`, error);
        failCount++;
      }
    }

    setImporting(false);
    setShowImportModal(false);
    setImportFile(null);
    setImportData([]);
    setImportErrors([]);
    
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }

    toast.success(`Import completed: ${successCount} succeeded, ${failCount} failed`);
    fetchCustomers();
  };

  return (
    <div className="setup-container">
      {/* Header */}
      <div className="setup-header">
        <div className="header-left">
          <h1 className="page-title">
            <FiUsers className="title-icon" />
            Customer Management
          </h1>
          <p className="page-subtitle">Manage your customer database and loyalty programs</p>
        </div>
        <div className="header-actions">
          <button 
            className="btn btn-secondary"
            onClick={downloadSampleExcel}
            title="Download sample Excel template"
          >
            <FiDownload /> Sample Excel
          </button>
          <button 
            className="btn btn-secondary"
            onClick={() => setShowImportModal(true)}
          >
            <FiUpload /> Import Excel
          </button>
          <button 
            className="btn btn-primary"
            onClick={() => {
              resetForm();
              setShowModal(true);
            }}
          >
            <FiPlus /> Add Customer
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon">
            <FiUsers />
          </div>
          <div className="stat-content">
            <span className="stat-label">Total Customers</span>
            <span className="stat-value">{stats.total}</span>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon green">
            <FiCheckCircle />
          </div>
          <div className="stat-content">
            <span className="stat-label">Active</span>
            <span className="stat-value">{stats.active}</span>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon blue">
            <FiUser />
          </div>
          <div className="stat-content">
            <span className="stat-label">Regular</span>
            <span className="stat-value">{stats.regular}</span>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon purple">
            <FiAward />
          </div>
          <div className="stat-content">
            <span className="stat-label">Premium</span>
            <span className="stat-value">{stats.silver + stats.gold + stats.platinum}</span>
          </div>
        </div>
      </div>

      {/* Search Bar */}
      <div className="search-container">
        <FiSearch className="search-icon" />
        <input
          type="text"
          placeholder="Search customers by name, mobile, or email..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="search-input"
        />
      </div>

      {/* Customers Table */}
      <div className="table-container">
        <table className="data-table" style={{ width: '100%' }}>
          <thead>
            <tr>
              <th style={{ textAlign: 'left' }}>Name</th>
              <th style={{ textAlign: 'left' }}>Mobile</th>
              <th style={{ textAlign: 'left' }}>Email</th>
              <th style={{ textAlign: 'left' }}>City</th>
              <th style={{ textAlign: 'center' }}>Loyalty Points</th>
              <th style={{ textAlign: 'center' }}>Grade</th>
              <th style={{ textAlign: 'center' }}>Status</th>
              <th style={{ textAlign: 'center', width: '120px' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan="8" className="text-center">Loading...</td>
              </tr>
            ) : customers.length === 0 ? (
              <tr>
                <td colSpan="8" className="text-center">No customers found</td>
              </tr>
            ) : (
              customers.map((customer) => (
                <tr key={customer.mobile}>
                  <td>{customer.name}</td>
                  <td>{customer.mobile}</td>
                  <td>{customer.email || '-'}</td>
                  <td>{customer.city || '-'}</td>
                  <td>{customer.loyalty_points || 0}</td>
                  <td>
                    <span className={`badge badge-${(customer.current_grade || 'regular').toLowerCase()}`}>
                      {customer.current_grade || 'Regular'}
                    </span>
                  </td>
                  <td>
                    <span className={`badge ${customer.active !== false ? 'badge-success' : 'badge-danger'}`}>
                      {customer.active !== false ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td>
                    <div className="action-buttons" style={{ display: 'flex', gap: '8px', justifyContent: 'center' }}>
                      <button
                        className="btn-action-edit"
                        onClick={() => handleEdit(customer)}
                        title="Edit Customer"
                        style={{
                          padding: '8px',
                          borderRadius: '6px',
                          border: '1px solid #3b82f6',
                          background: '#eff6ff',
                          color: '#3b82f6',
                          cursor: 'pointer',
                          display: 'inline-flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          transition: 'all 0.2s',
                          minWidth: '32px',
                          minHeight: '32px'
                        }}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.background = '#3b82f6';
                          e.currentTarget.style.color = '#fff';
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.background = '#eff6ff';
                          e.currentTarget.style.color = '#3b82f6';
                        }}
                      >
                        <FiEdit2 size={16} />
                      </button>
                      <button
                        className="btn-action-delete"
                        onClick={() => handleDelete(customer.mobile)}
                        title="Delete Customer"
                        style={{
                          padding: '8px',
                          borderRadius: '6px',
                          border: '1px solid #ef4444',
                          background: '#fef2f2',
                          color: '#ef4444',
                          cursor: 'pointer',
                          display: 'inline-flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          transition: 'all 0.2s',
                          minWidth: '32px',
                          minHeight: '32px'
                        }}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.background = '#ef4444';
                          e.currentTarget.style.color = '#fff';
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.background = '#fef2f2';
                          e.currentTarget.style.color = '#ef4444';
                        }}
                      >
                        <FiTrash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Add/Edit Modal */}
      {showModal && (
        <div className="modal-overlay">
          <div className="modal-content large">
            <div className="modal-header">
              <h2>{editingCustomer ? 'Edit Customer' : 'Add New Customer'}</h2>
              <button 
                className="btn btn-icon"
                onClick={() => {
                  setShowModal(false);
                  resetForm();
                }}
              >
                <FiX />
              </button>
            </div>

            <form onSubmit={handleSubmit}>
              <div className="modal-body">
                {/* Basic Information */}
                <div className="form-section">
                  <h4>Basic Information</h4>
                  <div className="form-grid">
                    <div className="form-group">
                      <label className="required">Name</label>
                      <input
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                        className={errors.name ? 'error' : ''}
                        placeholder="Enter customer name"
                      />
                      {errors.name && <span className="error-text">{errors.name}</span>}
                    </div>
                    
                    <div className="form-group">
                      <label className="required">Mobile Number</label>
                      <input
                        type="tel"
                        name="mobile"
                        value={formData.mobile}
                        onChange={handleInputChange}
                        className={errors.mobile ? 'error' : ''}
                        placeholder="10-digit mobile number"
                        maxLength="10"
                        disabled={editingCustomer}
                      />
                      {errors.mobile && <span className="error-text">{errors.mobile}</span>}
                    </div>
                    
                    <div className="form-group">
                      <label>Email Address</label>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        className={errors.email ? 'error' : ''}
                        placeholder="customer@example.com"
                      />
                      {errors.email && <span className="error-text">{errors.email}</span>}
                    </div>
                    
                    <div className="form-group">
                      <label>City</label>
                      <input
                        type="text"
                        name="city"
                        value={formData.city}
                        onChange={handleInputChange}
                        placeholder="Enter city"
                      />
                    </div>
                  </div>
                </div>

                {/* Address Information */}
                <div className="form-section">
                  <h4>Address Information</h4>
                  <div className="form-grid">
                    <div className="form-group col-span-2">
                      <label>Address</label>
                      <input
                        type="text"
                        name="address"
                        value={formData.address}
                        onChange={handleInputChange}
                        placeholder="Enter full address"
                      />
                    </div>
                    
                    <div className="form-group">
                      <label>Pincode</label>
                      <input
                        type="text"
                        name="pincode"
                        value={formData.pincode}
                        onChange={handleInputChange}
                        className={errors.pincode ? 'error' : ''}
                        placeholder="6-digit pincode"
                        maxLength="6"
                      />
                      {errors.pincode && <span className="error-text">{errors.pincode}</span>}
                    </div>
                  </div>
                </div>

                {/* Special Dates */}
                <div className="form-section">
                  <h4>Special Dates</h4>
                  <div className="form-grid">
                    <div className="form-group">
                      <label>Birthday</label>
                      <input
                        type="date"
                        name="birthday"
                        value={formData.birthday}
                        onChange={handleInputChange}
                      />
                    </div>
                    
                    <div className="form-group">
                      <label>Anniversary</label>
                      <input
                        type="date"
                        name="anniversary"
                        value={formData.anniversary}
                        onChange={handleInputChange}
                      />
                    </div>
                  </div>
                </div>

                {/* Children Information */}
                <div className="form-section">
                  <h4>Children Information</h4>
                  <div className="form-grid">
                    <div className="form-group">
                      <label>Child 1 Name</label>
                      <input
                        type="text"
                        name="kid1_name"
                        value={formData.kid1_name}
                        onChange={handleInputChange}
                        placeholder="Enter child 1 name"
                      />
                    </div>
                    
                    <div className="form-group">
                      <label>Child 1 Date of Birth</label>
                      <input
                        type="date"
                        name="kid1_dob"
                        value={formData.kid1_dob}
                        onChange={handleInputChange}
                      />
                    </div>
                    
                    <div className="form-group">
                      <label>Child 2 Name</label>
                      <input
                        type="text"
                        name="kid2_name"
                        value={formData.kid2_name}
                        onChange={handleInputChange}
                        placeholder="Enter child 2 name"
                      />
                    </div>
                    
                    <div className="form-group">
                      <label>Child 2 Date of Birth</label>
                      <input
                        type="date"
                        name="kid2_dob"
                        value={formData.kid2_dob}
                        onChange={handleInputChange}
                      />
                    </div>
                    
                    <div className="form-group">
                      <label>Child 3 Name</label>
                      <input
                        type="text"
                        name="kid3_name"
                        value={formData.kid3_name}
                        onChange={handleInputChange}
                        placeholder="Enter child 3 name"
                      />
                    </div>
                    
                    <div className="form-group">
                      <label>Child 3 Date of Birth</label>
                      <input
                        type="date"
                        name="kid3_dob"
                        value={formData.kid3_dob}
                        onChange={handleInputChange}
                      />
                    </div>
                  </div>
                </div>

                {/* Loyalty Information (only show for editing) */}
                {editingCustomer && (
                  <div className="form-section">
                    <h4>Loyalty Information</h4>
                    <div className="form-grid">
                      <div className="form-group">
                        <label>Loyalty Points</label>
                        <input
                          type="number"
                          name="loyalty_points"
                          value={formData.loyalty_points}
                          onChange={handleInputChange}
                          min="0"
                          disabled
                        />
                      </div>
                      
                      <div className="form-group">
                        <label>Current Grade</label>
                        <input
                          type="text"
                          name="current_grade"
                          value={formData.current_grade}
                          disabled
                        />
                      </div>
                      
                      <div className="form-group">
                        <label>
                          <input
                            type="checkbox"
                            name="active"
                            checked={formData.active}
                            onChange={handleInputChange}
                          />
                          Active Customer
                        </label>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div className="modal-footer">
                <button 
                  type="button" 
                  className="btn btn-secondary"
                  onClick={() => {
                    setShowModal(false);
                    resetForm();
                  }}
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="btn btn-primary"
                >
                  <FiSave /> {editingCustomer ? 'Update' : 'Save'} Customer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Import Modal */}
      {showImportModal && (
        <div className="modal-overlay">
          <div className="modal-content">
            <div className="modal-header">
              <h2>Import Customers from Excel</h2>
              <button 
                className="btn btn-icon"
                onClick={() => {
                  setShowImportModal(false);
                  setImportFile(null);
                  setImportData([]);
                  setImportErrors([]);
                  if (fileInputRef.current) {
                    fileInputRef.current.value = '';
                  }
                }}
              >
                <FiX />
              </button>
            </div>

            <div className="modal-body">
              <div className="import-section">
                <div className="import-instructions">
                  <h4>Instructions:</h4>
                  <ol>
                    <li>Download the sample Excel template</li>
                    <li>Fill in customer details in the template</li>
                    <li>Required fields: Name and Mobile</li>
                    <li>Date format: YYYY-MM-DD or DD/MM/YYYY</li>
                    <li>Upload the filled Excel file</li>
                  </ol>
                </div>

                <div className="file-upload-area">
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".xlsx,.xls"
                    onChange={handleFileSelect}
                    style={{ display: 'none' }}
                  />
                  
                  {!importFile ? (
                    <div 
                      className="upload-placeholder"
                      onClick={() => fileInputRef.current?.click()}
                    >
                      <FiUpload size={48} />
                      <p>Click to select Excel file</p>
                      <span>or drag and drop</span>
                    </div>
                  ) : (
                    <div className="file-selected">
                      <FiFileText size={32} />
                      <p>{importFile.name}</p>
                      <button 
                        className="btn btn-sm btn-secondary"
                        onClick={() => fileInputRef.current?.click()}
                      >
                        Change File
                      </button>
                    </div>
                  )}
                </div>

                {/* Import Summary */}
                {importData.length > 0 && (
                  <div className="import-summary">
                    <h4>Import Summary:</h4>
                    <p className="text-success">
                      <FiCheckCircle /> {importData.length} valid customers ready to import
                    </p>
                  </div>
                )}

                {/* Import Errors */}
                {importErrors.length > 0 && (
                  <div className="import-errors">
                    <h4 className="text-danger">
                      <FiAlertCircle /> Errors Found:
                    </h4>
                    <div className="error-list">
                      {importErrors.slice(0, 5).map((error, index) => (
                        <div key={index} className="error-item">
                          <strong>Row {error.row}:</strong> {error.errors.join(', ')}
                        </div>
                      ))}
                      {importErrors.length > 5 && (
                        <p className="text-muted">...and {importErrors.length - 5} more errors</p>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="modal-footer">
              <button 
                className="btn btn-secondary"
                onClick={downloadSampleExcel}
              >
                <FiDownload /> Download Template
              </button>
              <button 
                className="btn btn-primary"
                onClick={handleBulkImport}
                disabled={importData.length === 0 || importing}
              >
                {importing ? (
                  <>Importing...</>
                ) : (
                  <>
                    <FiUpload /> Import {importData.length} Customers
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Customers;