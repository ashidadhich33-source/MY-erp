import React, { useState, useEffect, useRef } from 'react';
import { 
  FiBriefcase, FiSave, FiEdit2, FiMapPin, FiPhone, 
  FiMail, FiFileText, FiUser, FiCreditCard, FiGlobe,
  FiCheckCircle, FiAlertCircle, FiInfo, FiUpload, FiX, FiImage
} from 'react-icons/fi';
import toast from 'react-hot-toast';
import { setupAPI } from '../../services/api';
import './SetupScreens.css';

function Company() {
  const [companies, setCompanies] = useState([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editingCompany, setEditingCompany] = useState(null);
  const fileInputRef = useRef(null);
  
  // Form state with logo_base64 instead of logo_path
  const [formData, setFormData] = useState({
    name: '',
    display_name: '',
    gstin: '',
    pan: '',
    address: '',
    city: '',
    state: '',
    pincode: '',
    phone: '',
    email: '',
    website: '',
    bank_name: '',
    bank_account: '',
    bank_ifsc: '',
    logo_base64: null,  // Changed from logo_path to logo_base64
    active: true
  });

  // Logo preview state
  const [logoPreview, setLogoPreview] = useState(null);

  // Validation errors
  const [errors, setErrors] = useState({});

  // Indian States
  const indianStates = [
    'ANDAMAN AND NICOBAR ISLANDS',
    'ANDHRA PRADESH',
    'ARUNACHAL PRADESH',
    'ASSAM',
    'BIHAR',
    'CHANDIGARH',
    'CHHATTISGARH',
    'DADRA AND NAGAR HAVELI',
    'DAMAN AND DIU',
    'DELHI',
    'GOA',
    'GUJARAT',
    'HARYANA',
    'HIMACHAL PRADESH',
    'JAMMU AND KASHMIR',
    'JHARKHAND',
    'KARNATAKA',
    'KERALA',
    'LADAKH',
    'LAKSHADWEEP',
    'MADHYA PRADESH',
    'MAHARASHTRA',
    'MANIPUR',
    'MEGHALAYA',
    'MIZORAM',
    'NAGALAND',
    'ODISHA',
    'PUDUCHERRY',
    'PUNJAB',
    'RAJASTHAN',
    'SIKKIM',
    'TAMIL NADU',
    'TELANGANA',
    'TRIPURA',
    'UTTAR PRADESH',
    'UTTARAKHAND',
    'WEST BENGAL'
  ];

  // Fetch companies
  const fetchCompanies = async () => {
    setLoading(true);
    try {
      const response = await setupAPI.getCompanies();
      const companiesData = Array.isArray(response.data) ? response.data : [];
      setCompanies(companiesData);
      
      // If companies exist, load the first one for editing
      if (companiesData.length > 0 && !editingCompany) {
        const company = companiesData[0];
        setEditingCompany(company);
        setFormData({
          name: company.name || '',
          display_name: company.display_name || '',
          gstin: company.gstin || '',
          pan: company.pan || '',
          address: company.address || '',
          city: company.city || '',
          state: company.state || '',
          pincode: company.pincode || '',
          phone: company.phone || '',
          email: company.email || '',
          website: company.website || '',
          bank_name: company.bank_name || '',
          bank_account: company.bank_account || '',
          bank_ifsc: company.bank_ifsc || '',
          logo_base64: company.logo_base64 || null,  // Changed from logo_path
          active: company.active !== false
        });
        // Set logo preview if exists
        if (company.logo_base64) {
          setLogoPreview(company.logo_base64);
        }
      }
    } catch (error) {
      console.error('Error fetching companies:', error);
      toast.error('Failed to fetch company details');
      setCompanies([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCompanies();
  }, []);

  // Handle logo file selection
  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    // Validate file type
    const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
    if (!validTypes.includes(file.type)) {
      toast.error('Please select a valid image file (JPEG, PNG, GIF, WebP)');
      return;
    }

    // Validate file size (max 2MB)
    if (file.size > 2 * 1024 * 1024) {
      toast.error('Image size must be less than 2MB');
      return;
    }

    // Convert to base64
    const reader = new FileReader();
    reader.onload = (e) => {
      const base64String = e.target.result;
      setLogoPreview(base64String);
      setFormData(prev => ({ ...prev, logo_base64: base64String }));
      toast.success('Logo uploaded successfully');
    };
    reader.onerror = () => {
      toast.error('Failed to read image file');
    };
    reader.readAsDataURL(file);
  };

  // Remove logo
  const removeLogo = () => {
    setLogoPreview(null);
    setFormData(prev => ({ ...prev, logo_base64: null }));
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
    toast.info('Logo removed');
  };

  // Validate GSTIN
  const validateGSTIN = (gstin) => {
    if (!gstin) return true; // Optional
    const gstRegex = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;
    return gstRegex.test(gstin);
  };

  // Validate PAN
  const validatePAN = (pan) => {
    if (!pan) return true; // Optional
    const panRegex = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
    return panRegex.test(pan);
  };

  // Validate email
  const validateEmail = (email) => {
    if (!email) return true; // Optional
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  // Validate pincode
  const validatePincode = (pincode) => {
    if (!pincode) return true; // Optional
    const pincodeRegex = /^\d{6}$/;
    return pincodeRegex.test(pincode);
  };

  // Validate phone
  const validatePhone = (phone) => {
    if (!phone) return true; // Optional
    const phoneRegex = /^\d{10}$/;
    return phoneRegex.test(phone);
  };

  // Validate form
  const validateForm = () => {
    const newErrors = {};

    if (!formData.name) {
      newErrors.name = 'Company name is required';
    }

    if (formData.gstin && !validateGSTIN(formData.gstin)) {
      newErrors.gstin = 'Invalid GSTIN format';
    }

    if (formData.pan && !validatePAN(formData.pan)) {
      newErrors.pan = 'Invalid PAN format';
    }

    if (formData.email && !validateEmail(formData.email)) {
      newErrors.email = 'Invalid email format';
    }

    if (formData.pincode && !validatePincode(formData.pincode)) {
      newErrors.pincode = 'Pincode must be 6 digits';
    }

    if (formData.phone && !validatePhone(formData.phone)) {
      newErrors.phone = 'Phone must be 10 digits';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Handle input change
  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    let finalValue = value;

    // Format specific fields
    if (name === 'gstin' || name === 'pan' || name === 'bank_ifsc') {
      finalValue = value.toUpperCase();
    }

    if (name === 'pincode' || name === 'phone') {
      finalValue = value.replace(/\D/g, '');
      if (name === 'pincode') {
        finalValue = finalValue.slice(0, 6);
      } else if (name === 'phone') {
        finalValue = finalValue.slice(0, 10);
      }
    }

    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : finalValue
    }));
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  // Handle submit
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      toast.error('Please fix validation errors');
      return;
    }

    setSaving(true);
    try {
      // Prepare data - ensure all fields are sent including logo_base64
      const dataToSend = {
        name: formData.name,
        display_name: formData.display_name || formData.name,
        gstin: formData.gstin || null,
        pan: formData.pan || null,
        address: formData.address || null,
        city: formData.city || null,
        state: formData.state || null,
        pincode: formData.pincode || null,
        phone: formData.phone || null,
        email: formData.email || null,
        website: formData.website || null,
        bank_name: formData.bank_name || null,
        bank_account: formData.bank_account || null,
        bank_ifsc: formData.bank_ifsc || null,
        logo_base64: formData.logo_base64 || null,  // Changed from logo_path
        active: formData.active
      };

      console.log('Sending company data:', dataToSend);

      let response;
      if (editingCompany && editingCompany.id) {
        response = await setupAPI.updateCompany(editingCompany.id, dataToSend);
        toast.success('Company details updated successfully');
      } else {
        response = await setupAPI.createCompany(dataToSend);
        setEditingCompany(response.data);
        toast.success('Company created successfully');
      }
      
      fetchCompanies();
    } catch (error) {
      console.error('Error saving company:', error);
      if (error.response?.data?.detail) {
        if (Array.isArray(error.response.data.detail)) {
          error.response.data.detail.forEach(err => {
            toast.error(`${err.loc?.join(' → ') || 'Field'}: ${err.msg}`);
          });
        } else {
          toast.error(error.response.data.detail);
        }
      } else {
        toast.error('Failed to save company details');
      }
    } finally {
      setSaving(false);
    }
  };

  // Reset form
  const resetForm = () => {
    setFormData({
      name: '',
      display_name: '',
      gstin: '',
      pan: '',
      address: '',
      city: '',
      state: '',
      pincode: '',
      phone: '',
      email: '',
      website: '',
      bank_name: '',
      bank_account: '',
      bank_ifsc: '',
      logo_base64: null,  // Changed from logo_path
      active: true
    });
    setErrors({});
    setEditingCompany(null);
    setLogoPreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="setup-container">
      {/* Header */}
      <div className="setup-header">
        <div className="header-left">
          <h1 className="page-title">
            <FiBriefcase className="title-icon" />
            Setup Company
          </h1>
          <p className="page-subtitle">Configure your business information</p>
        </div>
        
        <div className="header-actions">
          {editingCompany && (
            <button 
              className="btn btn-secondary"
              onClick={resetForm}
            >
              <FiEdit2 />
              Add New Company
            </button>
          )}
        </div>
      </div>

      {/* Info Card */}
      <div className="info-card">
        <FiInfo className="info-icon" />
        <div className="info-content">
          <h4>Company Setup Guidelines</h4>
          <ul>
            <li>Company name is required for all business operations</li>
            <li>GSTIN format: 22AAAAA0000A1Z5 (15 characters)</li>
            <li>PAN format: AAAAA0000A (10 characters)</li>
            <li>Banking details are used for payment processing</li>
            <li>All tax-related fields should be accurate for compliance</li>
            <li>Logo should be less than 2MB (JPEG, PNG, GIF, or WebP)</li>
          </ul>
        </div>
      </div>

      {loading ? (
        <div className="loading-state">
          <div className="spinner"></div>
          <p>Loading company details...</p>
        </div>
      ) : (
        <div className="company-form-container">
          <div className="company-form">
            <form onSubmit={handleSubmit}>
              {/* Logo Upload Section - NEW */}
              <div className="form-section">
                <h3 className="section-title">
                  <FiImage className="section-icon" />
                  Company Logo
                </h3>
                
                <div className="logo-upload-section">
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleFileSelect}
                    style={{ display: 'none' }}
                  />
                  
                  {logoPreview ? (
                    <div className="logo-preview-container">
                      <div className="logo-preview">
                        <img src={logoPreview} alt="Company Logo" />
                        <button
                          type="button"
                          className="remove-logo-btn"
                          onClick={removeLogo}
                          title="Remove logo"
                        >
                          <FiX />
                        </button>
                      </div>
                      <button
                        type="button"
                        className="btn btn-secondary"
                        onClick={() => fileInputRef.current?.click()}
                      >
                        <FiUpload /> Change Logo
                      </button>
                    </div>
                  ) : (
                    <div 
                      className="logo-placeholder"
                      onClick={() => fileInputRef.current?.click()}
                    >
                      <FiImage size={40} />
                      <p>Click to upload logo</p>
                      <span className="file-hint">Max 2MB (JPEG, PNG, GIF, WebP)</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Basic Information Section */}
              <div className="form-section">
                <h3 className="section-title">
                  <FiBriefcase className="section-icon" />
                  Basic Information
                </h3>
                
                <div className="form-grid">
                  <div className="form-group">
                    <label className="required">Company Name</label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      className={errors.name ? 'error' : ''}
                      placeholder="Legal name as per registration documents"
                    />
                    {errors.name && <span className="error-message">{errors.name}</span>}
                  </div>

                  <div className="form-group">
                    <label>Display Name</label>
                    <input
                      type="text"
                      name="display_name"
                      value={formData.display_name}
                      onChange={handleInputChange}
                      placeholder="Name for receipts/invoices"
                    />
                    <span className="field-hint">Short name for bills and receipts</span>
                  </div>
                </div>
              </div>

              {/* Tax Information Section */}
              <div className="form-section">
                <h3 className="section-title">
                  <FiFileText className="section-icon" />
                  Tax Information
                </h3>
                
                <div className="form-grid">
                  <div className="form-group">
                    <label>GSTIN</label>
                    <input
                      type="text"
                      name="gstin"
                      value={formData.gstin}
                      onChange={handleInputChange}
                      className={errors.gstin ? 'error' : ''}
                      placeholder="22AAAAA0000A1Z5"
                      maxLength="15"
                    />
                    {errors.gstin && <span className="error-message">{errors.gstin}</span>}
                  </div>

                  <div className="form-group">
                    <label>PAN</label>
                    <input
                      type="text"
                      name="pan"
                      value={formData.pan}
                      onChange={handleInputChange}
                      className={errors.pan ? 'error' : ''}
                      placeholder="AAAAA0000A"
                      maxLength="10"
                    />
                    {errors.pan && <span className="error-message">{errors.pan}</span>}
                  </div>
                </div>
              </div>

              {/* Address Information Section */}
              <div className="form-section">
                <h3 className="section-title">
                  <FiMapPin className="section-icon" />
                  Address Information
                </h3>
                
                <div className="form-grid">
                  <div className="form-group full-width">
                    <label>Complete Address</label>
                    <textarea
                      name="address"
                      value={formData.address}
                      onChange={handleInputChange}
                      rows="3"
                      placeholder="Street address, landmark, area details"
                    />
                  </div>

                  <div className="form-group">
                    <label>City</label>
                    <input
                      type="text"
                      name="city"
                      value={formData.city}
                      onChange={handleInputChange}
                      placeholder="Enter city name"
                    />
                  </div>

                  <div className="form-group">
                    <label>State</label>
                    <select
                      name="state"
                      value={formData.state}
                      onChange={handleInputChange}
                    >
                      <option value="">Select State</option>
                      {indianStates.map(state => (
                        <option key={state} value={state}>{state}</option>
                      ))}
                    </select>
                  </div>

                  <div className="form-group">
                    <label>Pin Code</label>
                    <input
                      type="text"
                      name="pincode"
                      value={formData.pincode}
                      onChange={handleInputChange}
                      className={errors.pincode ? 'error' : ''}
                      placeholder="000000"
                      maxLength="6"
                    />
                    {errors.pincode && <span className="error-message">{errors.pincode}</span>}
                    <span className="field-hint">6-digit postal code</span>
                  </div>
                </div>
              </div>

              {/* Contact Information Section */}
              <div className="form-section">
                <h3 className="section-title">
                  <FiPhone className="section-icon" />
                  Contact Information
                </h3>
                
                <div className="form-grid">
                  <div className="form-group">
                    <label>Phone Number</label>
                    <input
                      type="text"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      className={errors.phone ? 'error' : ''}
                      placeholder="9876543210"
                      maxLength="10"
                    />
                    {errors.phone && <span className="error-message">{errors.phone}</span>}
                    <span className="field-hint">10-digit mobile number</span>
                  </div>

                  <div className="form-group">
                    <label>Email Address</label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      className={errors.email ? 'error' : ''}
                      placeholder="company@example.com"
                    />
                    {errors.email && <span className="error-message">{errors.email}</span>}
                    <span className="field-hint">Business email for official communication</span>
                  </div>

                  <div className="form-group">
                    <label>Website</label>
                    <input
                      type="text"
                      name="website"
                      value={formData.website}
                      onChange={handleInputChange}
                      placeholder="https://www.company.com"
                    />
                    <span className="field-hint">Company website URL</span>
                  </div>
                </div>
              </div>

              {/* Banking Information Section */}
              <div className="form-section">
                <h3 className="section-title">
                  <FiCreditCard className="section-icon" />
                  Banking Information
                </h3>
                
                <div className="form-grid">
                  <div className="form-group">
                    <label>Bank Name</label>
                    <input
                      type="text"
                      name="bank_name"
                      value={formData.bank_name}
                      onChange={handleInputChange}
                      placeholder="Enter bank name"
                    />
                    <span className="field-hint">Name of your primary business bank</span>
                  </div>

                  <div className="form-group">
                    <label>Account Number</label>
                    <input
                      type="text"
                      name="bank_account"
                      value={formData.bank_account}
                      onChange={handleInputChange}
                      placeholder="Enter account number"
                    />
                    <span className="field-hint">Current/savings account number</span>
                  </div>

                  <div className="form-group">
                    <label>IFSC Code</label>
                    <input
                      type="text"
                      name="bank_ifsc"
                      value={formData.bank_ifsc}
                      onChange={handleInputChange}
                      placeholder="ABCD0123456"
                      maxLength="11"
                    />
                    <span className="field-hint">11-character bank IFSC code</span>
                  </div>
                </div>
              </div>

              {/* Active Status */}
              <div className="form-section">
                <div className="form-group checkbox-group">
                  <label className="checkbox-label">
                    <input
                      type="checkbox"
                      name="active"
                      checked={formData.active}
                      onChange={handleInputChange}
                    />
                    <span>Active Company</span>
                  </label>
                  <span className="field-hint">Enable this company for business operations</span>
                </div>
              </div>

              {/* Form Actions */}
              <div className="form-actions">
                <button 
                  type="button" 
                  className="btn btn-secondary"
                  onClick={resetForm}
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="btn btn-primary"
                  disabled={saving}
                >
                  {saving ? (
                    <>
                      <div className="spinner small"></div>
                      Saving...
                    </>
                  ) : (
                    <>
                      <FiSave />
                      {editingCompany && editingCompany.id ? 'Update Company' : 'Create Company'}
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>

          {/* Company Preview */}
          {formData.name && (
            <div className="company-preview">
              <h3>Live Preview</h3>
              <div className="preview-card">
                {/* Logo in preview */}
                {logoPreview && (
                  <div className="preview-logo">
                    <img src={logoPreview} alt="Company Logo" />
                  </div>
                )}
                
                <div className="company-header">
                  <h4>{formData.display_name || formData.name}</h4>
                  {formData.gstin && (
                    <div className="gstin">GSTIN: {formData.gstin}</div>
                  )}
                </div>
                
                {formData.address && (
                  <div className="address-block">
                    <FiMapPin className="icon" />
                    <div>
                      {formData.address}
                      {(formData.city || formData.state || formData.pincode) && (
                        <div>
                          {[formData.city, formData.state, formData.pincode].filter(Boolean).join(', ')}
                        </div>
                      )}
                    </div>
                  </div>
                )}
                
                <div className="contact-block">
                  {formData.phone && (
                    <div className="contact-item">
                      <FiPhone className="icon" />
                      {formData.phone}
                    </div>
                  )}
                  {formData.email && (
                    <div className="contact-item">
                      <FiMail className="icon" />
                      {formData.email}
                    </div>
                  )}
                  {formData.website && (
                    <div className="contact-item">
                      <FiGlobe className="icon" />
                      {formData.website}
                    </div>
                  )}
                </div>

                {(formData.bank_name || formData.bank_account) && (
                  <div className="bank-block">
                    <FiCreditCard className="icon" />
                    <div>
                      {formData.bank_name && <div>{formData.bank_name}</div>}
                      {formData.bank_account && <div>A/C: {formData.bank_account}</div>}
                      {formData.bank_ifsc && <div>IFSC: {formData.bank_ifsc}</div>}
                    </div>
                  </div>
                )}

                <div className="status-badge">
                  {formData.active ? (
                    <span className="badge badge-success">
                      <FiCheckCircle /> Active
                    </span>
                  ) : (
                    <span className="badge badge-warning">
                      <FiAlertCircle /> Inactive
                    </span>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Additional CSS for logo upload - Add this to your SetupScreens.css */}
      <style jsx>{`
        .logo-upload-section {
          display: flex;
          align-items: center;
          gap: 1.5rem;
          padding: 1rem 0;
        }

        .logo-preview-container {
          display: flex;
          align-items: center;
          gap: 1rem;
        }

        .logo-preview {
          position: relative;
          width: 120px;
          height: 120px;
          border-radius: 12px;
          overflow: hidden;
          border: 2px solid #e5e7eb;
          background: #f9fafb;
        }

        .logo-preview img {
          width: 100%;
          height: 100%;
          object-fit: contain;
        }

        .remove-logo-btn {
          position: absolute;
          top: 0.5rem;
          right: 0.5rem;
          width: 28px;
          height: 28px;
          border-radius: 50%;
          background: rgba(239, 68, 68, 0.9);
          color: white;
          border: none;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          transition: all 0.2s;
        }

        .remove-logo-btn:hover {
          background: #dc2626;
          transform: scale(1.1);
        }

        .logo-placeholder {
          width: 200px;
          height: 120px;
          border: 2px dashed #d1d5db;
          border-radius: 12px;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          background: #f9fafb;
          color: #9ca3af;
          cursor: pointer;
          transition: all 0.2s;
        }

        .logo-placeholder:hover {
          border-color: #9333ea;
          color: #9333ea;
          background: #faf5ff;
        }

        .logo-placeholder p {
          margin: 0.5rem 0 0;
          font-size: 0.875rem;
          font-weight: 500;
        }

        .file-hint {
          font-size: 0.75rem;
          color: #9ca3af;
          margin-top: 0.25rem;
        }

        .preview-logo {
          width: 80px;
          height: 80px;
          margin: 0 auto 1rem;
          border-radius: 8px;
          overflow: hidden;
          border: 1px solid #e5e7eb;
        }

        .preview-logo img {
          width: 100%;
          height: 100%;
          object-fit: contain;
        }
      `}</style>
    </div>
  );
}

export default Company;