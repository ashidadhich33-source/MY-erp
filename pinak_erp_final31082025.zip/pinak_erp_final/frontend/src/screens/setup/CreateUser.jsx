import React, { useState, useEffect } from 'react';
import { 
  FiUserPlus, FiSave, FiSearch, FiEdit2, FiTrash2,
  FiUser, FiMail, FiPhone, FiLock, FiShield,
  FiToggleLeft, FiToggleRight, FiX, FiEye, FiEyeOff
} from 'react-icons/fi';
import toast from 'react-hot-toast';
import axios from 'axios';
import './SetupScreens.css';

const API_URL = 'http://localhost:8000/api/v1';

function CreateUser() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [showPassword, setShowPassword] = useState(false);
  
  // Form state
  const [formData, setFormData] = useState({
    username: '',
    display_name: '',
    mobile: '',
    email: '',
    password: '',
    confirm_password: '',
    role: 'staff',
    active: true
  });

  // Validation errors
  const [errors, setErrors] = useState({});

  // Available roles
  const roles = [
    { value: 'admin', label: 'Admin', color: 'purple', description: 'Full system access' },
    { value: 'manager', label: 'Manager', color: 'blue', description: 'Management functions' },
    { value: 'staff', label: 'Staff', color: 'green', description: 'Sales and basic operations' },
    { value: 'accountant', label: 'Accountant', color: 'orange', description: 'Financial reports access' }
  ];

  // Fetch users
  const fetchUsers = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(
        `${API_URL}/setup/users`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setUsers(response.data.users || []);
    } catch (error) {
      toast.error('Failed to fetch users');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  // Validate form
  const validateForm = () => {
    const newErrors = {};

    if (!formData.username.trim()) {
      newErrors.username = 'Username is required';
    } else if (formData.username.length < 3) {
      newErrors.username = 'Username must be at least 3 characters';
    }

    if (!formData.display_name.trim()) {
      newErrors.display_name = 'Display name is required';
    }

    if (!formData.mobile) {
      newErrors.mobile = 'Mobile number is required';
    } else if (!/^[6-9]\d{9}$/.test(formData.mobile)) {
      newErrors.mobile = 'Invalid mobile number';
    }

    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Invalid email format';
    }

    if (!editingUser) {
      if (!formData.password) {
        newErrors.password = 'Password is required';
      } else if (formData.password.length < 6) {
        newErrors.password = 'Password must be at least 6 characters';
      }

      if (formData.password !== formData.confirm_password) {
        newErrors.confirm_password = 'Passwords do not match';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      toast.error('Please fix the errors in the form');
      return;
    }

    const confirmMsg = editingUser 
      ? 'Update user details?' 
      : 'Create new user account?';
      
    if (!window.confirm(confirmMsg)) return;

    try {
      const token = localStorage.getItem('token');
      const endpoint = editingUser 
        ? `${API_URL}/setup/users/${editingUser.id}`
        : `${API_URL}/setup/users`;
      
      const method = editingUser ? 'put' : 'post';
      
      const payload = { ...formData };
      delete payload.confirm_password;
      if (editingUser && !payload.password) {
        delete payload.password;
      }
      
      await axios[method](endpoint, payload, {
        headers: { Authorization: `Bearer ${token}` }
      });

      toast.success(`User ${editingUser ? 'updated' : 'created'} successfully`);
      setShowModal(false);
      resetForm();
      fetchUsers();
    } catch (error) {
      if (error.response?.data?.detail) {
        toast.error(error.response.data.detail);
      } else {
        toast.error('Failed to save user');
      }
    }
  };

  // Reset form
  const resetForm = () => {
    setFormData({
      username: '',
      display_name: '',
      mobile: '',
      email: '',
      password: '',
      confirm_password: '',
      role: 'staff',
      active: true
    });
    setEditingUser(null);
    setErrors({});
    setShowPassword(false);
  };

  // Edit user
  const handleEdit = (user) => {
    setFormData({
      ...user,
      password: '',
      confirm_password: ''
    });
    setEditingUser(user);
    setShowModal(true);
  };

  // Toggle user status
  const toggleStatus = async (user) => {
    try {
      const token = localStorage.getItem('token');
      await axios.patch(
        `${API_URL}/setup/users/${user.id}/toggle-status`,
        {},
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      toast.success(`User ${user.active ? 'deactivated' : 'activated'}`);
      fetchUsers();
    } catch (error) {
      toast.error('Failed to update user status');
    }
  };

  // Delete user
  const handleDelete = async (user) => {
    if (!window.confirm(`Delete user "${user.display_name}"? This action cannot be undone.`)) {
      return;
    }

    try {
      const token = localStorage.getItem('token');
      await axios.delete(
        `${API_URL}/setup/users/${user.id}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      toast.success('User deleted successfully');
      fetchUsers();
    } catch (error) {
      toast.error('Failed to delete user');
    }
  };

  // Filter users
  const filteredUsers = users.filter(user => {
    const searchLower = searchTerm.toLowerCase();
    return (
      user.username?.toLowerCase().includes(searchLower) ||
      user.display_name?.toLowerCase().includes(searchLower) ||
      user.mobile?.includes(searchTerm) ||
      user.email?.toLowerCase().includes(searchLower) ||
      user.role?.toLowerCase().includes(searchLower)
    );
  });

  // Get role info
  const getRoleInfo = (roleValue) => {
    return roles.find(r => r.value === roleValue) || roles[2];
  };

  return (
    <div className="setup-container">
      {/* Header */}
      <div className="setup-header">
        <div className="header-left">
          <h1 className="page-title">
            <FiUserPlus className="title-icon" />
            Create User
          </h1>
          <p className="page-subtitle">Manage system users and their access</p>
        </div>
        
        <div className="header-actions">
          <button 
            className="btn btn-primary"
            onClick={() => {
              resetForm();
              setShowModal(true);
            }}
          >
            <FiUserPlus />
            New User
          </button>
        </div>
      </div>

      {/* Search */}
      <div className="search-section">
        <div className="search-box">
          <FiSearch className="search-icon" />
          <input
            type="text"
            placeholder="Search by username, name, mobile, email..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="search-input"
          />
        </div>
      </div>

      {/* Users Grid */}
      {loading ? (
        <div className="loading-container">
          <div className="loading-spinner"></div>
          <p>Loading users...</p>
        </div>
      ) : filteredUsers.length === 0 ? (
        <div className="empty-state">
          <FiUser className="empty-icon" />
          <h3>No users found</h3>
          <p>Start by creating your first user account</p>
        </div>
      ) : (
        <div className="users-grid">
          {filteredUsers.map(user => {
            const roleInfo = getRoleInfo(user.role);
            return (
              <div key={user.id} className="user-card">
                <div className="user-card-header">
                  <div className="user-avatar">
                    {user.display_name.charAt(0).toUpperCase()}
                  </div>
                  <button
                    className={`status-toggle ${user.active ? 'active' : ''}`}
                    onClick={() => toggleStatus(user)}
                    title={user.active ? 'Active' : 'Inactive'}
                  >
                    {user.active ? <FiToggleRight /> : <FiToggleLeft />}
                  </button>
                </div>
                
                <div className="user-card-body">
                  <h3 className="user-name">{user.display_name}</h3>
                  <p className="user-username">@{user.username}</p>
                  
                  <div className={`role-badge ${roleInfo.color}`}>
                    <FiShield />
                    {roleInfo.label}
                  </div>
                  
                  <div className="user-info">
                    <div className="info-item">
                      <FiPhone className="info-icon" />
                      <span>{user.mobile}</span>
                    </div>
                    {user.email && (
                      <div className="info-item">
                        <FiMail className="info-icon" />
                        <span>{user.email}</span>
                      </div>
                    )}
                  </div>
                </div>
                
                <div className="user-card-footer">
                  <button
                    className="btn-icon"
                    onClick={() => handleEdit(user)}
                  >
                    <FiEdit2 />
                  </button>
                  <button
                    className="btn-icon danger"
                    onClick={() => handleDelete(user)}
                  >
                    <FiTrash2 />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add/Edit Modal */}
      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h2>{editingUser ? 'Edit User' : 'Create New User'}</h2>
              <button className="modal-close" onClick={() => setShowModal(false)}>
                <FiX />
              </button>
            </div>
            
            <form onSubmit={handleSubmit} className="user-form">
              <div className="form-grid">
                <div className="form-group">
                  <label>Username *</label>
                  <input
                    type="text"
                    value={formData.username}
                    onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                    className={`form-input ${errors.username ? 'error' : ''}`}
                    placeholder="Enter username"
                    disabled={editingUser}
                  />
                  {errors.username && <span className="error-message">{errors.username}</span>}
                </div>
                
                <div className="form-group">
                  <label>Display Name *</label>
                  <input
                    type="text"
                    value={formData.display_name}
                    onChange={(e) => setFormData({ ...formData, display_name: e.target.value })}
                    className={`form-input ${errors.display_name ? 'error' : ''}`}
                    placeholder="Full name"
                  />
                  {errors.display_name && <span className="error-message">{errors.display_name}</span>}
                </div>
                
                <div className="form-group">
                  <label>Mobile *</label>
                  <input
                    type="tel"
                    value={formData.mobile}
                    onChange={(e) => setFormData({ ...formData, mobile: e.target.value })}
                    className={`form-input ${errors.mobile ? 'error' : ''}`}
                    placeholder="10-digit mobile"
                    maxLength="10"
                  />
                  {errors.mobile && <span className="error-message">{errors.mobile}</span>}
                </div>
                
                <div className="form-group">
                  <label>Email</label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className={`form-input ${errors.email ? 'error' : ''}`}
                    placeholder="user@example.com"
                  />
                  {errors.email && <span className="error-message">{errors.email}</span>}
                </div>
                
                <div className="form-group">
                  <label>Password {!editingUser && '*'}</label>
                  <div className="password-input-wrapper">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={formData.password}
                      onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                      className={`form-input ${errors.password ? 'error' : ''}`}
                      placeholder={editingUser ? 'Leave blank to keep current' : 'Min 6 characters'}
                    />
                    <button
                      type="button"
                      className="password-toggle"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? <FiEyeOff /> : <FiEye />}
                    </button>
                  </div>
                  {errors.password && <span className="error-message">{errors.password}</span>}
                </div>
                
                <div className="form-group">
                  <label>Confirm Password {!editingUser && '*'}</label>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={formData.confirm_password}
                    onChange={(e) => setFormData({ ...formData, confirm_password: e.target.value })}
                    className={`form-input ${errors.confirm_password ? 'error' : ''}`}
                    placeholder="Re-enter password"
                  />
                  {errors.confirm_password && <span className="error-message">{errors.confirm_password}</span>}
                </div>
                
                <div className="form-group">
                  <label>Role *</label>
                  <select
                    value={formData.role}
                    onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                    className="form-input"
                  >
                    {roles.map(role => (
                      <option key={role.value} value={role.value}>
                        {role.label} - {role.description}
                      </option>
                    ))}
                  </select>
                </div>
                
                <div className="form-group">
                  <label>Status</label>
                  <select
                    value={formData.active}
                    onChange={(e) => setFormData({ ...formData, active: e.target.value === 'true' })}
                    className="form-input"
                  >
                    <option value="true">Active</option>
                    <option value="false">Inactive</option>
                  </select>
                </div>
              </div>
              
              <div className="form-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary">
                  <FiSave />
                  {editingUser ? 'Update' : 'Create'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Additional Styles */}
      <style jsx>{`
        .users-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
          gap: 1.5rem;
          margin-bottom: 2rem;
        }
        
        .user-card {
          background: white;
          border-radius: 16px;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.06);
          overflow: hidden;
          transition: all 0.3s ease;
        }
        
        .user-card:hover {
          transform: translateY(-4px);
          box-shadow: 0 12px 30px rgba(0, 0, 0, 0.12);
        }
        
        .user-card-header {
          padding: 1.5rem;
          background: linear-gradient(135deg, #9333ea 0%, #4f46e5 100%);
          display: flex;
          justify-content: space-between;
          align-items: center;
        }
        
        .user-avatar {
          width: 60px;
          height: 60px;
          border-radius: 50%;
          background: white;
          color: #9333ea;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 1.75rem;
          font-weight: 700;
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        
        .status-toggle {
          background: transparent;
          border: none;
          font-size: 2rem;
          cursor: pointer;
          transition: all 0.3s ease;
          color: rgba(255, 255, 255, 0.5);
        }
        
        .status-toggle.active {
          color: white;
        }
        
        .user-card-body {
          padding: 1.5rem;
        }
        
        .user-name {
          font-size: 1.25rem;
          font-weight: 700;
          color: #1f2937;
          margin: 0 0 0.25rem 0;
        }
        
        .user-username {
          font-size: 0.875rem;
          color: #6b7280;
          margin: 0 0 1rem 0;
        }
        
        .role-badge {
          display: inline-flex;
          align-items: center;
          gap: 0.375rem;
          padding: 0.5rem 1rem;
          border-radius: 20px;
          font-size: 0.875rem;
          font-weight: 600;
          margin-bottom: 1rem;
        }
        
        .role-badge.purple {
          background: linear-gradient(135deg, #e9d5ff 0%, #d8b4fe 100%);
          color: #6b21a8;
        }
        
        .role-badge.blue {
          background: linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%);
          color: #1e40af;
        }
        
        .role-badge.green {
          background: linear-gradient(135deg, #d1fae5 0%, #a7f3d0 100%);
          color: #065f46;
        }
        
        .role-badge.orange {
          background: linear-gradient(135deg, #fed7aa 0%, #fbbf24 100%);
          color: #92400e;
        }
        
        .user-info {
          display: flex;
          flex-direction: column;
          gap: 0.5rem;
        }
        
        .info-item {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          color: #6b7280;
          font-size: 0.875rem;
        }
        
        .info-icon {
          color: #9ca3af;
          font-size: 1rem;
        }
        
        .user-card-footer {
          padding: 1rem 1.5rem;
          background: #f9fafb;
          border-top: 1px solid #e5e7eb;
          display: flex;
          gap: 0.75rem;
        }
        
        .btn-icon {
          padding: 0.5rem;
          background: white;
          border: 2px solid #e5e7eb;
          border-radius: 8px;
          color: #6b7280;
          cursor: pointer;
          transition: all 0.3s ease;
          font-size: 1.125rem;
        }
        
        .btn-icon:hover {
          border-color: #9333ea;
          color: #9333ea;
          background: rgba(147, 51, 234, 0.05);
        }
        
        .btn-icon.danger:hover {
          border-color: #ef4444;
          color: #ef4444;
          background: rgba(239, 68, 68, 0.05);
        }
        
        .password-input-wrapper {
          position: relative;
        }
        
        .password-toggle {
          position: absolute;
          right: 1rem;
          top: 50%;
          transform: translateY(-50%);
          background: transparent;
          border: none;
          color: #6b7280;
          cursor: pointer;
          padding: 0.25rem;
          font-size: 1.25rem;
        }
        
        .password-toggle:hover {
          color: #9333ea;
        }
        
        .form-input.error {
          border-color: #ef4444;
        }
        
        .error-message {
          display: block;
          color: #ef4444;
          font-size: 0.75rem;
          margin-top: 0.25rem;
        }
        
        @media (max-width: 768px) {
          .users-grid {
            grid-template-columns: 1fr;
          }
        }
      `}</style>
    </div>
  );
}

export default CreateUser;