import React, { useState, useEffect } from 'react';
import { 
  FiCreditCard, FiPlus, FiSave, FiEdit2, FiTrash2,
  FiSmartphone, FiDollarSign, FiRefreshCw, FiPercent,
  FiCheckCircle, FiAlertCircle, FiTrendingUp
} from 'react-icons/fi';
import toast from 'react-hot-toast';
import axios from 'axios';
import './SetupScreens.css';

const API_URL = 'http://localhost:8000/api/v1';

function PaymentMode() {
  const [paymentModes, setPaymentModes] = useState([]);
  const [loading, setLoading] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [editingMode, setEditingMode] = useState(null);
  
  // Form state
  const [formData, setFormData] = useState({
    name: '',
    code: '',
    type: 'cash',
    charges_type: 'none',
    charges_value: 0,
    bank_account: '',
    settlement_days: 0,
    requires_reference: false,
    min_amount: 0,
    max_amount: 999999,
    active: true,
    description: ''
  });

  // Validation errors
  const [errors, setErrors] = useState({});

  // Stats
  const [stats, setStats] = useState({
    totalModes: 0,
    activeModes: 0,
    digitalModes: 0,
    totalCharges: 0,
    mostUsed: null
  });

  // Payment types
  const paymentTypes = [
    { value: 'cash', label: 'Cash', icon: '💵' },
    { value: 'card', label: 'Credit/Debit Card', icon: '💳' },
    { value: 'upi', label: 'UPI', icon: '📱' },
    { value: 'bank_transfer', label: 'Bank Transfer', icon: '🏦' },
    { value: 'wallet', label: 'Digital Wallet', icon: '👛' },
    { value: 'emi', label: 'EMI', icon: '📊' },
    { value: 'credit', label: 'Store Credit', icon: '🎯' },
    { value: 'cheque', label: 'Cheque', icon: '📝' }
  ];

  // Charge types
  const chargeTypes = [
    { value: 'none', label: 'No Charges' },
    { value: 'percentage', label: 'Percentage (%)' },
    { value: 'fixed', label: 'Fixed Amount (₹)' }
  ];

  // Fetch payment modes
  const fetchPaymentModes = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(
        `${API_URL}/setup/payment-modes`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      const modesData = response.data || [];
      setPaymentModes(modesData);
      calculateStats(modesData);
    } catch (error) {
      toast.error('Failed to fetch payment modes');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPaymentModes();
    generateModeCode();
  }, []);

  // Generate unique mode code
  const generateModeCode = () => {
    const code = `PAY${Date.now().toString().slice(-6)}`;
    setFormData(prev => ({ ...prev, code }));
  };

  // Calculate stats
  const calculateStats = (modes) => {
    const activeModes = modes.filter(m => m.active);
    const digitalModes = modes.filter(m => 
      ['card', 'upi', 'wallet', 'bank_transfer'].includes(m.type)
    );
    const totalCharges = modes.reduce((sum, m) => {
      if (m.charges_type === 'percentage') return sum + m.charges_value;
      return sum;
    }, 0);

    setStats({
      totalModes: modes.length,
      activeModes: activeModes.length,
      digitalModes: digitalModes.length,
      totalCharges: totalCharges.toFixed(2),
      mostUsed: modes[0] // Mock - in real app, this would come from transaction data
    });
  };

  // Validate form
  const validateForm = () => {
    const newErrors = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Payment mode name is required';
    }

    if (!formData.code.trim()) {
      newErrors.code = 'Code is required';
    }

    if (formData.charges_value < 0) {
      newErrors.charges_value = 'Charges cannot be negative';
    }

    if (formData.charges_type === 'percentage' && formData.charges_value > 100) {
      newErrors.charges_value = 'Percentage cannot exceed 100%';
    }

    if (formData.settlement_days < 0) {
      newErrors.settlement_days = 'Settlement days cannot be negative';
    }

    if (formData.min_amount < 0) {
      newErrors.min_amount = 'Minimum amount cannot be negative';
    }

    if (formData.max_amount <= formData.min_amount) {
      newErrors.max_amount = 'Maximum amount must be greater than minimum amount';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      toast.error('Please fix the errors in the form');
      return;
    }

    const confirmMsg = editingMode 
      ? 'Update payment mode?' 
      : 'Add new payment mode?';
      
    if (!window.confirm(confirmMsg)) return;

    try {
      const token = localStorage.getItem('token');
      const endpoint = editingMode 
        ? `${API_URL}/setup/payment-modes/${editingMode.id}`
        : `${API_URL}/setup/payment-modes`;
      
      const method = editingMode ? 'put' : 'post';
      
      await axios[method](endpoint, formData, {
        headers: { Authorization: `Bearer ${token}` }
      });

      toast.success(`Payment mode ${editingMode ? 'updated' : 'added'} successfully`);
      setShowModal(false);
      resetForm();
      fetchPaymentModes();
    } catch (error) {
      if (error.response?.data?.detail) {
        toast.error(error.response.data.detail);
      } else {
        toast.error('Failed to save payment mode');
      }
    }
  };

  // Reset form
  const resetForm = () => {
    setFormData({
      name: '',
      code: '',
      type: 'cash',
      charges_type: 'none',
      charges_value: 0,
      bank_account: '',
      settlement_days: 0,
      requires_reference: false,
      min_amount: 0,
      max_amount: 999999,
      active: true,
      description: ''
    });
    setEditingMode(null);
    setErrors({});
    generateModeCode();
  };

  // Edit mode
  const handleEdit = (mode) => {
    setFormData(mode);
    setEditingMode(mode);
    setShowModal(true);
  };

  // Toggle status
  const toggleStatus = async (mode) => {
    try {
      const token = localStorage.getItem('token');
      await axios.patch(
        `${API_URL}/setup/payment-modes/${mode.id}/toggle-status`,
        {},
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      toast.success(`Payment mode ${mode.active ? 'deactivated' : 'activated'}`);
      fetchPaymentModes();
    } catch (error) {
      toast.error('Failed to update status');
    }
  };

  // Delete mode
  const handleDelete = async (mode) => {
    if (!window.confirm(`Delete payment mode "${mode.name}"?`)) {
      return;
    }

    try {
      const token = localStorage.getItem('token');
      await axios.delete(
        `${API_URL}/setup/payment-modes/${mode.id}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      toast.success('Payment mode deleted successfully');
      fetchPaymentModes();
    } catch (error) {
      toast.error('Failed to delete payment mode');
    }
  };

  // Calculate effective charges
  const calculateCharges = (mode, amount = 1000) => {
    if (mode.charges_type === 'none') return 0;
    if (mode.charges_type === 'percentage') return (amount * mode.charges_value / 100);
    return mode.charges_value;
  };

  return (
    <div className="setup-container">
      {/* Header */}
      <div className="setup-header">
        <div className="header-left">
          <h1 className="page-title">
            <FiCreditCard className="title-icon" />
            Payment Modes
          </h1>
          <p className="page-subtitle">Configure payment methods and transaction charges</p>
        </div>
        <div className="header-actions">
          <button className="btn-refresh" onClick={fetchPaymentModes}>
            <FiRefreshCw /> Refresh
          </button>
          <button className="btn-primary" onClick={() => setShowModal(true)}>
            <FiPlus /> Add Payment Mode
          </button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon-wrapper purple">
            <FiCreditCard />
          </div>
          <div className="stat-content">
            <p className="stat-label">Total Modes</p>
            <p className="stat-value">{stats.totalModes}</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon-wrapper green">
            <FiCheckCircle />
          </div>
          <div className="stat-content">
            <p className="stat-label">Active Modes</p>
            <p className="stat-value">{stats.activeModes}</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon-wrapper blue">
            <FiSmartphone />
          </div>
          <div className="stat-content">
            <p className="stat-label">Digital Modes</p>
            <p className="stat-value">{stats.digitalModes}</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon-wrapper orange">
            <FiPercent />
          </div>
          <div className="stat-content">
            <p className="stat-label">Avg Charges</p>
            <p className="stat-value">{stats.totalCharges}%</p>
          </div>
        </div>
      </div>

      {/* Payment Modes Grid */}
      <div className="payment-modes-grid">
        {loading ? (
          <div className="loading-spinner">Loading...</div>
        ) : paymentModes.length === 0 ? (
          <div className="empty-state">
            <FiCreditCard size={48} />
            <p>No payment modes configured</p>
            <button className="btn-primary btn-sm" onClick={() => setShowModal(true)}>
              Add First Payment Mode
            </button>
          </div>
        ) : (
          paymentModes.map((mode) => {
            const paymentType = paymentTypes.find(t => t.value === mode.type);
            const charges = calculateCharges(mode);
            
            return (
              <div key={mode.id} className={`payment-mode-card ${!mode.active ? 'inactive' : ''}`}>
                <div className="mode-header">
                  <div className="mode-icon">{paymentType?.icon}</div>
                  <div className="mode-info">
                    <h4>{mode.name}</h4>
                    <span className="mode-code">{mode.code}</span>
                  </div>
                  <div className="mode-actions">
                    <button onClick={() => handleEdit(mode)} title="Edit">
                      <FiEdit2 />
                    </button>
                    <button onClick={() => toggleStatus(mode)} title={mode.active ? 'Deactivate' : 'Activate'}>
                      {mode.active ? <FiAlertCircle /> : <FiCheckCircle />}
                    </button>
                    <button onClick={() => handleDelete(mode)} title="Delete" className="btn-danger">
                      <FiTrash2 />
                    </button>
                  </div>
                </div>
                
                <div className="mode-details">
                  <div className="detail-row">
                    <span className="detail-label">Type:</span>
                    <span className="detail-value">{paymentType?.label}</span>
                  </div>
                  
                  {mode.charges_type !== 'none' && (
                    <div className="detail-row">
                      <span className="detail-label">Charges:</span>
                      <span className="detail-value charge-value">
                        {mode.charges_type === 'percentage' 
                          ? `${mode.charges_value}%`
                          : `₹${mode.charges_value}`}
                      </span>
                    </div>
                  )}
                  
                  {mode.settlement_days > 0 && (
                    <div className="detail-row">
                      <span className="detail-label">Settlement:</span>
                      <span className="detail-value">{mode.settlement_days} days</span>
                    </div>
                  )}
                  
                  {mode.requires_reference && (
                    <div className="detail-row">
                      <span className="detail-label">Reference:</span>
                      <span className="detail-value">Required</span>
                    </div>
                  )}
                  
                  <div className="detail-row">
                    <span className="detail-label">Limits:</span>
                    <span className="detail-value">
                      ₹{mode.min_amount.toLocaleString()} - ₹{mode.max_amount.toLocaleString()}
                    </span>
                  </div>
                  
                  {mode.bank_account && (
                    <div className="detail-row">
                      <span className="detail-label">Account:</span>
                      <span className="detail-value">{mode.bank_account}</span>
                    </div>
                  )}
                </div>
                
                <div className="mode-status">
                  <span className={`status-badge ${mode.active ? 'active' : 'inactive'}`}>
                    {mode.active ? 'Active' : 'Inactive'}
                  </span>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Add/Edit Modal */}
      {showModal && (
        <div className="modal-overlay">
          <div className="modal-content">
            <div className="modal-header">
              <h2>{editingMode ? 'Edit Payment Mode' : 'Add Payment Mode'}</h2>
              <button className="btn-close" onClick={() => {
                setShowModal(false);
                resetForm();
              }}>×</button>
            </div>

            <form onSubmit={handleSubmit} className="modal-form">
              <div className="form-row">
                <div className="form-group">
                  <label>Code</label>
                  <input
                    type="text"
                    value={formData.code}
                    readOnly
                    className="readonly"
                  />
                </div>

                <div className="form-group">
                  <label>Name *</label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    className={errors.name ? 'error' : ''}
                    placeholder="e.g., Cash Payment"
                  />
                  {errors.name && <span className="error-message">{errors.name}</span>}
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Type *</label>
                  <select
                    value={formData.type}
                    onChange={(e) => setFormData({...formData, type: e.target.value})}
                  >
                    {paymentTypes.map(type => (
                      <option key={type.value} value={type.value}>
                        {type.icon} {type.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="form-group">
                  <label>Bank Account</label>
                  <input
                    type="text"
                    value={formData.bank_account}
                    onChange={(e) => setFormData({...formData, bank_account: e.target.value})}
                    placeholder="Account number or name"
                  />
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Charge Type</label>
                  <select
                    value={formData.charges_type}
                    onChange={(e) => setFormData({...formData, charges_type: e.target.value})}
                  >
                    {chargeTypes.map(type => (
                      <option key={type.value} value={type.value}>
                        {type.label}
                      </option>
                    ))}
                  </select>
                </div>

                {formData.charges_type !== 'none' && (
                  <div className="form-group">
                    <label>
                      Charge Value {formData.charges_type === 'percentage' ? '(%)' : '(₹)'}
                    </label>
                    <input
                      type="number"
                      value={formData.charges_value}
                      onChange={(e) => setFormData({...formData, charges_value: parseFloat(e.target.value) || 0})}
                      className={errors.charges_value ? 'error' : ''}
                      min="0"
                      max={formData.charges_type === 'percentage' ? "100" : undefined}
                      step="0.01"
                    />
                    {errors.charges_value && <span className="error-message">{errors.charges_value}</span>}
                  </div>
                )}

                <div className="form-group">
                  <label>Settlement Days</label>
                  <input
                    type="number"
                    value={formData.settlement_days}
                    onChange={(e) => setFormData({...formData, settlement_days: parseInt(e.target.value) || 0})}
                    className={errors.settlement_days ? 'error' : ''}
                    min="0"
                  />
                  {errors.settlement_days && <span className="error-message">{errors.settlement_days}</span>}
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Minimum Amount</label>
                  <input
                    type="number"
                    value={formData.min_amount}
                    onChange={(e) => setFormData({...formData, min_amount: parseFloat(e.target.value) || 0})}
                    className={errors.min_amount ? 'error' : ''}
                    min="0"
                  />
                  {errors.min_amount && <span className="error-message">{errors.min_amount}</span>}
                </div>

                <div className="form-group">
                  <label>Maximum Amount</label>
                  <input
                    type="number"
                    value={formData.max_amount}
                    onChange={(e) => setFormData({...formData, max_amount: parseFloat(e.target.value) || 999999})}
                    className={errors.max_amount ? 'error' : ''}
                    min="0"
                  />
                  {errors.max_amount && <span className="error-message">{errors.max_amount}</span>}
                </div>
              </div>

              <div className="form-group">
                <label>Description</label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  rows="3"
                  placeholder="Additional notes..."
                />
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label className="checkbox-label">
                    <input
                      type="checkbox"
                      checked={formData.requires_reference}
                      onChange={(e) => setFormData({...formData, requires_reference: e.target.checked})}
                    />
                    Requires Reference Number
                  </label>
                </div>

                <div className="form-group">
                  <label className="checkbox-label">
                    <input
                      type="checkbox"
                      checked={formData.active}
                      onChange={(e) => setFormData({...formData, active: e.target.checked})}
                    />
                    Active
                  </label>
                </div>
              </div>

              {formData.charges_type !== 'none' && (
                <div className="charge-preview">
                  <h4>Charge Preview</h4>
                  <p>On a transaction of ₹1,000:</p>
                  <p className="charge-amount">
                    Transaction Charge: ₹{calculateCharges(formData, 1000).toFixed(2)}
                  </p>
                </div>
              )}

              <div className="modal-footer">
                <button 
                  type="button" 
                  className="btn-secondary"
                  onClick={() => {
                    setShowModal(false);
                    resetForm();
                  }}
                >
                  Cancel
                </button>
                <button type="submit" className="btn-primary">
                  <FiSave /> {editingMode ? 'Update' : 'Save'} Payment Mode
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default PaymentMode;
