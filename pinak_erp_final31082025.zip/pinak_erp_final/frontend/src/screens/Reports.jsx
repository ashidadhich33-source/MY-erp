import React, { useState, useEffect } from 'react';
import { Routes, Route, NavLink, useNavigate } from 'react-router-dom';
import { 
  FiBarChart2, FiTrendingUp, FiUsers, FiPackage, 
  FiDollarSign, FiFileText, FiCalendar, FiDownload,
  FiFilter, FiPrinter, FiRefreshCw, FiPieChart,
  FiActivity, FiAward, FiShoppingBag, FiTruck
} from 'react-icons/fi';
import toast from 'react-hot-toast';
import { reportsAPI, formatCurrency, formatDate, downloadFile } from '../services/api';
import './Reports.css';

// Import sub-components
import SalesReport from './reports/SalesReport';
import StockReport from './reports/StockReport';
import CustomerReport from './reports/CustomerReport';
import PurchaseReport from './reports/PurchaseReport';
import StaffReport from './reports/StaffReport';
import HSNReport from './reports/HSNReport';

// Dashboard Component
function ReportsDashboard() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [dashboardData, setDashboardData] = useState({
    sales_summary: {
      today: 0,
      week: 0,
      month: 0,
      year: 0
    },
    purchase_summary: {
      today: 0,
      week: 0,
      month: 0,
      year: 0
    },
    stock_summary: {
      total_items: 0,
      total_value: 0,
      low_stock: 0,
      out_of_stock: 0
    },
    customer_summary: {
      total: 0,
      new_this_month: 0,
      active: 0,
      loyalty_members: 0
    },
    top_products: [],
    top_customers: []
  });

  useEffect(() => {
    fetchDashboard();
  }, []);

  const fetchDashboard = async () => {
    setLoading(true);
    try {
      const response = await reportsAPI.getDashboard('month');
      setDashboardData(response.data);
    } catch (error) {
      console.error('Error fetching dashboard:', error);
      toast.error('Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  };

  const reportCards = [
    {
      title: 'Sales Report',
      description: 'Detailed sales analysis with returns',
      icon: <FiTrendingUp />,
      color: 'green',
      path: '/reports/sales',
      stats: dashboardData.sales_summary?.month || 0
    },
    {
      title: 'Stock Report',
      description: 'Inventory levels and movement',
      icon: <FiPackage />,
      color: 'blue',
      path: '/reports/stock',
      stats: dashboardData.stock_summary?.total_items || 0
    },
    {
      title: 'Customer Report',
      description: 'Customer analytics and loyalty',
      icon: <FiUsers />,
      color: 'purple',
      path: '/reports/customers',
      stats: dashboardData.customer_summary?.total || 0
    },
    {
      title: 'Purchase Report',
      description: 'Purchase bills and returns',
      icon: <FiTruck />,
      color: 'orange',
      path: '/reports/purchases',
      stats: dashboardData.purchase_summary?.month || 0
    },
    {
      title: 'Staff Report',
      description: 'Staff performance and targets',
      icon: <FiAward />,
      color: 'pink',
      path: '/reports/staff',
      stats: 'View'
    },
    {
      title: 'HSN Report',
      description: 'HSN-wise tax summary',
      icon: <FiFileText />,
      color: 'indigo',
      path: '/reports/hsn',
      stats: 'GST'
    }
  ];

  return (
    <div className="reports-dashboard">
      {/* Quick Stats */}
      <div className="quick-stats">
        <div className="stat-card">
          <div className="stat-header">
            <FiDollarSign />
            <span>Today's Sales</span>
          </div>
          <div className="stat-value">
            {formatCurrency(dashboardData.sales_summary?.today || 0)}
          </div>
          <div className="stat-change positive">
            +12% from yesterday
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-header">
            <FiShoppingBag />
            <span>Monthly Sales</span>
          </div>
          <div className="stat-value">
            {formatCurrency(dashboardData.sales_summary?.month || 0)}
          </div>
          <div className="stat-change positive">
            +8% from last month
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-header">
            <FiUsers />
            <span>Active Customers</span>
          </div>
          <div className="stat-value">
            {dashboardData.customer_summary?.active || 0}
          </div>
          <div className="stat-change">
            {dashboardData.customer_summary?.new_this_month || 0} new this month
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-header">
            <FiPackage />
            <span>Low Stock Items</span>
          </div>
          <div className="stat-value warning">
            {dashboardData.stock_summary?.low_stock || 0}
          </div>
          <div className="stat-change negative">
            {dashboardData.stock_summary?.out_of_stock || 0} out of stock
          </div>
        </div>
      </div>

      {/* Report Cards Grid */}
      <div className="report-cards">
        {reportCards.map((report, index) => (
          <div
            key={index}
            className={`report-card ${report.color}`}
            onClick={() => navigate(report.path)}
          >
            <div className="report-icon">{report.icon}</div>
            <div className="report-content">
              <h3>{report.title}</h3>
              <p>{report.description}</p>
              <div className="report-stat">
                {typeof report.stats === 'number' 
                  ? formatCurrency(report.stats)
                  : report.stats}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Top Products & Customers */}
      <div className="dashboard-tables">
        <div className="dashboard-section">
          <h2>Top Products This Month</h2>
          {dashboardData.top_products?.length > 0 ? (
            <table className="simple-table">
              <thead>
                <tr>
                  <th>Rank</th>
                  <th>Style Code</th>
                  <th>Brand</th>
                  <th>Qty Sold</th>
                  <th>Revenue</th>
                </tr>
              </thead>
              <tbody>
                {dashboardData.top_products.slice(0, 5).map((product, index) => (
                  <tr key={index}>
                    <td className="rank">#{index + 1}</td>
                    <td>{product.style_code}</td>
                    <td>{product.brand || '-'}</td>
                    <td>{product.qty_sold}</td>
                    <td className="amount">{formatCurrency(product.revenue)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <p className="no-data">No sales data available</p>
          )}
        </div>

        <div className="dashboard-section">
          <h2>Top Customers This Month</h2>
          {dashboardData.top_customers?.length > 0 ? (
            <table className="simple-table">
              <thead>
                <tr>
                  <th>Rank</th>
                  <th>Name</th>
                  <th>Mobile</th>
                  <th>Purchases</th>
                  <th>Amount</th>
                </tr>
              </thead>
              <tbody>
                {dashboardData.top_customers.slice(0, 5).map((customer, index) => (
                  <tr key={index}>
                    <td className="rank">#{index + 1}</td>
                    <td>{customer.name}</td>
                    <td>{customer.mobile}</td>
                    <td>{customer.purchase_count}</td>
                    <td className="amount">{formatCurrency(customer.total_amount)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <p className="no-data">No customer data available</p>
          )}
        </div>
      </div>
    </div>
  );
}

// Main Reports Component
function Reports() {
  const [activeReport, setActiveReport] = useState('dashboard');

  const reportLinks = [
    { path: '/reports', label: 'Dashboard', icon: <FiPieChart /> },
    { path: '/reports/sales', label: 'Sales', icon: <FiTrendingUp /> },
    { path: '/reports/stock', label: 'Stock', icon: <FiPackage /> },
    { path: '/reports/customers', label: 'Customers', icon: <FiUsers /> },
    { path: '/reports/purchases', label: 'Purchases', icon: <FiTruck /> },
    { path: '/reports/staff', label: 'Staff', icon: <FiAward /> },
    { path: '/reports/hsn', label: 'HSN/GST', icon: <FiFileText /> }
  ];

  return (
    <div className="reports-container">
      {/* Header */}
      <div className="page-header">
        <div className="page-title">
          <FiBarChart2 className="page-icon" />
          <h1>Reports & Analytics</h1>
        </div>
        <div className="page-actions">
          <button onClick={() => window.location.reload()} className="btn btn-secondary">
            <FiRefreshCw /> Refresh
          </button>
        </div>
      </div>

      {/* Report Navigation */}
      <div className="report-nav">
        {reportLinks.map((link) => (
          <NavLink
            key={link.path}
            to={link.path}
            end={link.path === '/reports'}
            className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}
          >
            {link.icon}
            <span>{link.label}</span>
          </NavLink>
        ))}
      </div>

      {/* Report Content */}
      <div className="report-content">
        <Routes>
          <Route index element={<ReportsDashboard />} />
          <Route path="sales" element={<SalesReport />} />
          <Route path="stock" element={<StockReport />} />
          <Route path="customers" element={<CustomerReport />} />
          <Route path="purchases" element={<PurchaseReport />} />
          <Route path="staff" element={<StaffReport />} />
          <Route path="hsn" element={<HSNReport />} />
        </Routes>
      </div>
    </div>
  );
}

export default Reports;