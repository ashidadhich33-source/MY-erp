import React, { useState, useEffect, useRef } from 'react';
import { 
  FiTruck, FiPlus, FiX, FiSearch, FiSave, FiPrinter,
  FiCalendar, FiFileText, FiDollarSign, FiPackage,
  FiAlertCircle, FiEdit2, FiTrash2, FiCheck, FiRefreshCw
} from 'react-icons/fi';
import toast from 'react-hot-toast';
import { purchaseAPI, setupAPI, itemsAPI, formatCurrency, formatDate } from '../services/api';
import './Purchase.css';
import { FiTrendingUp } from 'react-icons/fi';

function Purchase() {
  const [loading, setLoading] = useState(false);
  const [suppliers, setSuppliers] = useState([]);
  const [billSeries, setBillSeries] = useState([]);
  const [selectedSupplier, setSelectedSupplier] = useState(null);
  const [selectedSeries, setSelectedSeries] = useState(null);
  const [purchaseItems, setPurchaseItems] = useState([]);
  const [recentPurchases, setRecentPurchases] = useState([]);
  const [showItemModal, setShowItemModal] = useState(false);
  const [editingIndex, setEditingIndex] = useState(null);
  const barcodeInputRef = useRef(null);
  const [searchBarcode, setSearchBarcode] = useState('');
  
  // Bill Details
  const [billDetails, setBillDetails] = useState({
    pb_date: new Date().toISOString().split('T')[0],
    payment_mode: 'cash',
    supplier_bill_no: '',
    supplier_bill_date: new Date().toISOString().split('T')[0],
    reverse_charge: false
  });

  // Item Form
  const [itemForm, setItemForm] = useState({
    barcode: '',
    style_code: '',
    item_name: '',
    size: '',
    color: '',
    hsn: '',
    qty: 1,
    basic_rate: 0,
    disc_pct: 0,
    disc_amount: 0,
    gst_rate: 5,
    cgst_rate: 2.5,
    sgst_rate: 2.5,
    igst_rate: 0
  });

  // Stats
  const [stats, setStats] = useState({
    todayBills: 0,
    todayAmount: 0,
    pendingPayments: 0,
    monthlyPurchases: 0
  });

  useEffect(() => {
    fetchInitialData();
    fetchRecentPurchases();
    fetchStats();
  }, []);

  const fetchInitialData = async () => {
    try {
      // Fetch suppliers
      const suppliersResponse = await setupAPI.getSuppliers({ active_only: true });
      setSuppliers(suppliersResponse.data.items || []);

      // Fetch bill series
      const seriesResponse = await setupAPI.getBillSeries({ type: 'PB' });
      const series = seriesResponse.data || [];
      setBillSeries(series);
      if (series.length > 0) {
        setSelectedSeries(series[0]);
      }
    } catch (error) {
      console.error('Error fetching initial data:', error);
      toast.error('Failed to load initial data');
    }
  };

  const fetchRecentPurchases = async () => {
    try {
      const response = await purchaseAPI.getPurchases({ 
        page_size: 5,
        sort_by: 'pb_date',
        sort_order: 'desc'
      });
      setRecentPurchases(response.data.items || []);
    } catch (error) {
      console.error('Error fetching recent purchases:', error);
    }
  };

  const fetchStats = async () => {
    try {
      const today = new Date().toISOString().split('T')[0];
      const response = await purchaseAPI.getPurchases({ 
        from_date: today,
        to_date: today 
      });
      
      const todayData = response.data.items || [];
      setStats({
        todayBills: todayData.length,
        todayAmount: todayData.reduce((sum, p) => sum + parseFloat(p.grand_total || 0), 0),
        pendingPayments: 0, // Would come from API
        monthlyPurchases: 0  // Would come from API
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  // Search item by barcode
  const searchItem = async (barcode) => {
    if (!barcode) return;

    try {
      const response = await itemsAPI.searchItems({ barcode });
      
      if (response.data && response.data.items && response.data.items.length > 0) {
        const item = response.data.items[0];
        
        // Set item details
        setItemForm({
          ...itemForm,
          barcode: item.barcode,
          style_code: item.style_code,
          item_name: `${item.style_code} ${item.color || ''} ${item.size || ''}`.trim(),
          size: item.size || '',
          color: item.color || '',
          hsn: item.hsn || '',
          basic_rate: item.purchase_rate_basic || 0,
          qty: 1,
          disc_pct: 0,
          disc_amount: 0
        });
        
        // Update GST based on supplier location
        updateGSTRates();
        
        toast.success('Item found');
      } else {
        toast.error('Item not found');
      }
    } catch (error) {
      toast.error('Failed to search item');
    }
  };

  // Update GST rates based on supplier location
  const updateGSTRates = () => {
    if (!selectedSupplier) return;
    
    const isInterState = selectedSupplier.location_type === 'inter';
    const gstRate = parseFloat(itemForm.gst_rate) || 5;
    
    if (isInterState) {
      setItemForm(prev => ({
        ...prev,
        cgst_rate: 0,
        sgst_rate: 0,
        igst_rate: gstRate
      }));
    } else {
      setItemForm(prev => ({
        ...prev,
        cgst_rate: gstRate / 2,
        sgst_rate: gstRate / 2,
        igst_rate: 0
      }));
    }
  };

  // Calculate item totals
  const calculateItemTotals = () => {
    const qty = parseFloat(itemForm.qty) || 0;
    const rate = parseFloat(itemForm.basic_rate) || 0;
    const discPct = parseFloat(itemForm.disc_pct) || 0;
    
    const basicAmount = qty * rate;
    const discAmount = (basicAmount * discPct) / 100;
    const taxableAmount = basicAmount - discAmount;
    
    const cgstAmount = (taxableAmount * itemForm.cgst_rate) / 100;
    const sgstAmount = (taxableAmount * itemForm.sgst_rate) / 100;
    const igstAmount = (taxableAmount * itemForm.igst_rate) / 100;
    
    const totalAmount = taxableAmount + cgstAmount + sgstAmount + igstAmount;
    
    return {
      basicAmount,
      discAmount,
      taxableAmount,
      cgstAmount,
      sgstAmount,
      igstAmount,
      totalAmount
    };
  };

  // Add item to purchase
  const addItem = () => {
    if (!itemForm.barcode) {
      toast.error('Please select an item');
      return;
    }
    
    if (!itemForm.qty || itemForm.qty <= 0) {
      toast.error('Invalid quantity');
      return;
    }
    
    if (!itemForm.basic_rate || itemForm.basic_rate <= 0) {
      toast.error('Invalid rate');
      return;
    }
    
    const totals = calculateItemTotals();
    
    const newItem = {
      ...itemForm,
      ...totals
    };
    
    if (editingIndex !== null) {
      const updatedItems = [...purchaseItems];
      updatedItems[editingIndex] = newItem;
      setPurchaseItems(updatedItems);
      setEditingIndex(null);
      toast.success('Item updated');
    } else {
      setPurchaseItems([...purchaseItems, newItem]);
      toast.success('Item added');
    }
    
    // Reset form
    resetItemForm();
    setShowItemModal(false);
    
    // Focus barcode input
    if (barcodeInputRef.current) {
      barcodeInputRef.current.focus();
    }
  };

  // Edit item
  const editItem = (index) => {
    const item = purchaseItems[index];
    setItemForm(item);
    setEditingIndex(index);
    setShowItemModal(true);
  };

  // Remove item
  const removeItem = (index) => {
    if (window.confirm('Remove this item?')) {
      const updatedItems = purchaseItems.filter((_, i) => i !== index);
      setPurchaseItems(updatedItems);
      toast.success('Item removed');
    }
  };

  // Reset item form
  const resetItemForm = () => {
    setItemForm({
      barcode: '',
      style_code: '',
      item_name: '',
      size: '',
      color: '',
      hsn: '',
      qty: 1,
      basic_rate: 0,
      disc_pct: 0,
      disc_amount: 0,
      gst_rate: 5,
      cgst_rate: 2.5,
      sgst_rate: 2.5,
      igst_rate: 0
    });
    setEditingIndex(null);
  };

  // Calculate bill totals
  const calculateBillTotals = () => {
    const totals = purchaseItems.reduce((acc, item) => {
      acc.totalQty += parseFloat(item.qty) || 0;
      acc.totalBasic += item.basicAmount || 0;
      acc.totalDiscount += item.discAmount || 0;
      acc.totalTaxable += item.taxableAmount || 0;
      acc.totalCGST += item.cgstAmount || 0;
      acc.totalSGST += item.sgstAmount || 0;
      acc.totalIGST += item.igstAmount || 0;
      acc.grandTotal += item.totalAmount || 0;
      return acc;
    }, {
      totalQty: 0,
      totalBasic: 0,
      totalDiscount: 0,
      totalTaxable: 0,
      totalCGST: 0,
      totalSGST: 0,
      totalIGST: 0,
      grandTotal: 0
    });
    
    return totals;
  };

  // Save purchase bill
  const savePurchase = async () => {
    if (!selectedSupplier) {
      toast.error('Please select a supplier');
      return;
    }
    
    if (!selectedSeries) {
      toast.error('Please select a bill series');
      return;
    }
    
    if (purchaseItems.length === 0) {
      toast.error('Please add items');
      return;
    }
    
    const totals = calculateBillTotals();
    
    const purchaseData = {
      pb_series_id: selectedSeries.id,
      pb_date: billDetails.pb_date,
      payment_mode: billDetails.payment_mode,
      supplier_id: selectedSupplier.id,
      supplier_bill_no: billDetails.supplier_bill_no,
      supplier_bill_date: billDetails.supplier_bill_date,
      reverse_charge: billDetails.reverse_charge,
      items: purchaseItems.map(item => ({
        barcode: item.barcode,
        style_code: item.style_code,
        color: item.color,
        size: item.size,
        hsn: item.hsn,
        qty: item.qty,
        basic_rate: item.basic_rate,
        disc_pct: item.disc_pct,
        disc_amount: item.discAmount,
        cgst_rate: item.cgst_rate,
        sgst_rate: item.sgst_rate,
        igst_rate: item.igst_rate,
        cgst_amount: item.cgstAmount,
        sgst_amount: item.sgstAmount,
        igst_amount: item.igstAmount,
        line_taxable: item.taxableAmount,
        line_total: item.totalAmount
      }))
    };
    
    setLoading(true);
    try {
      const response = await purchaseAPI.createPurchase(purchaseData);
      toast.success(`Purchase bill created: ${response.data.pb_no}`);
      
      // Reset form
      resetForm();
      
      // Refresh data
      fetchRecentPurchases();
      fetchStats();
      
      // Option to print
      if (window.confirm('Print purchase bill?')) {
        handlePrintBill(response.data);
      }
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to save purchase');
      console.error('Error saving purchase:', error);
    } finally {
      setLoading(false);
    }
  };

  // Reset entire form
  const resetForm = () => {
    setSelectedSupplier(null);
    setPurchaseItems([]);
    setBillDetails({
      pb_date: new Date().toISOString().split('T')[0],
      payment_mode: 'cash',
      supplier_bill_no: '',
      supplier_bill_date: new Date().toISOString().split('T')[0],
      reverse_charge: false
    });
    resetItemForm();
  };

  // Print bill
  const handlePrintBill = (billData) => {
    console.log('Printing bill:', billData);
    toast.success('Sending to printer...');
  };

  const totals = calculateBillTotals();

  return (
    <div className="purchase-container">
      {/* Header */}
      <div className="page-header">
        <div className="page-title">
          <FiTruck className="page-icon" />
          <h1>Purchase Bill</h1>
        </div>
        <div className="page-actions">
          <button onClick={resetForm} className="btn btn-secondary">
            <FiRefreshCw /> New Bill
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="stats-cards">
        <div className="stat-card">
          <div className="stat-icon blue">
            <FiFileText />
          </div>
          <div className="stat-content">
            <h3>Today's Bills</h3>
            <p>{stats.todayBills}</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon green">
            <FiDollarSign />
          </div>
          <div className="stat-content">
            <h3>Today's Purchase</h3>
            <p>{formatCurrency(stats.todayAmount)}</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon orange">
            <FiCalendar />
          </div>
          <div className="stat-content">
            <h3>Pending Payments</h3>
            <p>{formatCurrency(stats.pendingPayments)}</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon purple">
            <FiTrendingUp />
          </div>
          <div className="stat-content">
            <h3>Monthly Total</h3>
            <p>{formatCurrency(stats.monthlyPurchases)}</p>
          </div>
        </div>
      </div>

      {/* Purchase Form */}
      <div className="purchase-form">
        {/* Bill Details */}
        <div className="form-section card">
          <h2>Bill Details</h2>
          <div className="form-row">
            <div className="form-group">
              <label>Supplier *</label>
              <select
                value={selectedSupplier?.id || ''}
                onChange={(e) => {
                  const supplier = suppliers.find(s => s.id === parseInt(e.target.value));
                  setSelectedSupplier(supplier);
                  updateGSTRates();
                }}
                required
              >
                <option value="">Select Supplier</option>
                {suppliers.map(supplier => (
                  <option key={supplier.id} value={supplier.id}>
                    {supplier.name} ({supplier.location_type})
                  </option>
                ))}
              </select>
              {selectedSupplier && (
                <small className="supplier-info">
                  {selectedSupplier.location_type === 'inter' ? 'Inter-State (IGST)' : 'Local (CGST + SGST)'}
                </small>
              )}
            </div>
            <div className="form-group">
              <label>Bill Series *</label>
              <select
                value={selectedSeries?.id || ''}
                onChange={(e) => {
                  const series = billSeries.find(s => s.id === parseInt(e.target.value));
                  setSelectedSeries(series);
                }}
                required
              >
                {billSeries.map(series => (
                  <option key={series.id} value={series.id}>
                    {series.prefix} - {series.description}
                  </option>
                ))}
              </select>
            </div>
            <div className="form-group">
              <label>Bill Date *</label>
              <input
                type="date"
                value={billDetails.pb_date}
                onChange={(e) => setBillDetails({...billDetails, pb_date: e.target.value})}
                required
              />
            </div>
            <div className="form-group">
              <label>Payment Mode</label>
              <select
                value={billDetails.payment_mode}
                onChange={(e) => setBillDetails({...billDetails, payment_mode: e.target.value})}
              >
                <option value="cash">Cash</option>
                <option value="credit">Credit</option>
              </select>
            </div>
          </div>
          
          <div className="form-row">
            <div className="form-group">
              <label>Supplier Bill No</label>
              <input
                type="text"
                value={billDetails.supplier_bill_no}
                onChange={(e) => setBillDetails({...billDetails, supplier_bill_no: e.target.value})}
                placeholder="Supplier's invoice number"
              />
            </div>
            <div className="form-group">
              <label>Supplier Bill Date</label>
              <input
                type="date"
                value={billDetails.supplier_bill_date}
                onChange={(e) => setBillDetails({...billDetails, supplier_bill_date: e.target.value})}
              />
            </div>
            <div className="form-group checkbox-group">
              <label>
                <input
                  type="checkbox"
                  checked={billDetails.reverse_charge}
                  onChange={(e) => setBillDetails({...billDetails, reverse_charge: e.target.checked})}
                />
                Reverse Charge
              </label>
            </div>
          </div>
        </div>

        {/* Add Items Section */}
        <div className="form-section card">
          <div className="section-header">
            <h2>Items</h2>
            <button 
              onClick={() => {resetItemForm(); setShowItemModal(true);}} 
              className="btn btn-primary"
              disabled={!selectedSupplier}
            >
              <FiPlus /> Add Item
            </button>
          </div>
          
          {/* Quick Barcode Search */}
          <div className="barcode-search">
            <FiSearch />
            <input
              ref={barcodeInputRef}
              type="text"
              placeholder="Scan or enter barcode..."
              value={searchBarcode}
              onChange={(e) => setSearchBarcode(e.target.value)}
              onKeyPress={(e) => {
                if (e.key === 'Enter' && e.target.value) {
                  searchItem(e.target.value);
                  setSearchBarcode('');
                  setShowItemModal(true);
                }
              }}
              disabled={!selectedSupplier}
            />
          </div>

          {/* Items Table */}
          {purchaseItems.length > 0 ? (
            <div className="items-table-container">
              <table className="items-table">
                <thead>
                  <tr>
                    <th>S.No</th>
                    <th>Barcode</th>
                    <th>Style Code</th>
                    <th>Item</th>
                    <th>HSN</th>
                    <th>Qty</th>
                    <th>Rate</th>
                    <th>Disc %</th>
                    <th>Taxable</th>
                    <th>CGST</th>
                    <th>SGST</th>
                    <th>IGST</th>
                    <th>Total</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {purchaseItems.map((item, index) => (
                    <tr key={index}>
                      <td>{index + 1}</td>
                      <td className="barcode">{item.barcode}</td>
                      <td>{item.style_code}</td>
                      <td>{item.item_name}</td>
                      <td>{item.hsn || '-'}</td>
                      <td>{item.qty}</td>
                      <td>{formatCurrency(item.basic_rate)}</td>
                      <td>{item.disc_pct}%</td>
                      <td>{formatCurrency(item.taxableAmount)}</td>
                      <td>{item.cgst_rate > 0 ? formatCurrency(item.cgstAmount) : '-'}</td>
                      <td>{item.sgst_rate > 0 ? formatCurrency(item.sgstAmount) : '-'}</td>
                      <td>{item.igst_rate > 0 ? formatCurrency(item.igstAmount) : '-'}</td>
                      <td className="amount">{formatCurrency(item.totalAmount)}</td>
                      <td className="actions">
                        <button onClick={() => editItem(index)} className="btn-icon">
                          <FiEdit2 />
                        </button>
                        <button onClick={() => removeItem(index)} className="btn-icon delete">
                          <FiTrash2 />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr className="total-row">
                    <td colSpan="5">Total</td>
                    <td>{totals.totalQty}</td>
                    <td colSpan="2"></td>
                    <td>{formatCurrency(totals.totalTaxable)}</td>
                    <td>{totals.totalCGST > 0 ? formatCurrency(totals.totalCGST) : '-'}</td>
                    <td>{totals.totalSGST > 0 ? formatCurrency(totals.totalSGST) : '-'}</td>
                    <td>{totals.totalIGST > 0 ? formatCurrency(totals.totalIGST) : '-'}</td>
                    <td className="grand-total">{formatCurrency(totals.grandTotal)}</td>
                    <td></td>
                  </tr>
                </tfoot>
              </table>
            </div>
          ) : (
            <div className="empty-items">
              <FiPackage size={48} />
              <p>No items added. Click "Add Item" or scan barcode to start.</p>
            </div>
          )}
        </div>

        {/* Bill Summary */}
        {purchaseItems.length > 0 && (
          <div className="bill-summary card">
            <h2>Bill Summary</h2>
            <div className="summary-grid">
              <div className="summary-item">
                <label>Total Items:</label>
                <span>{purchaseItems.length}</span>
              </div>
              <div className="summary-item">
                <label>Total Quantity:</label>
                <span>{totals.totalQty}</span>
              </div>
              <div className="summary-item">
                <label>Total Basic:</label>
                <span>{formatCurrency(totals.totalBasic)}</span>
              </div>
              <div className="summary-item">
                <label>Total Discount:</label>
                <span className="discount">{formatCurrency(totals.totalDiscount)}</span>
              </div>
              <div className="summary-item">
                <label>Total Taxable:</label>
                <span>{formatCurrency(totals.totalTaxable)}</span>
              </div>
              <div className="summary-item">
                <label>Total GST:</label>
                <span>{formatCurrency(totals.totalCGST + totals.totalSGST + totals.totalIGST)}</span>
              </div>
              <div className="summary-item highlight">
                <label>Grand Total:</label>
                <span className="grand-total">{formatCurrency(totals.grandTotal)}</span>
              </div>
            </div>
            
            <div className="bill-actions">
              <button 
                onClick={savePurchase} 
                className="btn btn-primary btn-large"
                disabled={loading || purchaseItems.length === 0}
              >
                {loading ? 'Saving...' : 'Save Purchase Bill'}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Recent Purchases */}
      {recentPurchases.length > 0 && (
        <div className="recent-purchases card">
          <h2>Recent Purchases</h2>
          <table className="purchases-table">
            <thead>
              <tr>
                <th>Bill No</th>
                <th>Date</th>
                <th>Supplier</th>
                <th>Items</th>
                <th>Amount</th>
                <th>Payment</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {recentPurchases.map((purchase) => (
                <tr key={purchase.id}>
                  <td className="bill-no">{purchase.pb_no}</td>
                  <td>{formatDate(purchase.pb_date)}</td>
                  <td>{purchase.supplier_name}</td>
                  <td>{purchase.item_count || 0}</td>
                  <td className="amount">{formatCurrency(purchase.grand_total)}</td>
                  <td>
                    <span className={`payment-mode ${purchase.payment_mode}`}>
                      {purchase.payment_mode}
                    </span>
                  </td>
                  <td>
                    <button 
                      onClick={() => handlePrintBill(purchase)}
                      className="btn-icon"
                      title="Print"
                    >
                      <FiPrinter />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Item Modal */}
      {showItemModal && (
        <div className="modal-overlay" onClick={() => setShowItemModal(false)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h2>{editingIndex !== null ? 'Edit Item' : 'Add Item'}</h2>
              <button onClick={() => setShowItemModal(false)} className="btn-close">
                <FiX />
              </button>
            </div>
            <div className="item-form">
              <div className="form-row">
                <div className="form-group">
                  <label>Barcode</label>
                  <div className="input-group">
                    <input
                      type="text"
                      value={itemForm.barcode}
                      onChange={(e) => setItemForm({...itemForm, barcode: e.target.value})}
                      placeholder="Scan or enter barcode"
                    />
                    <button 
                      onClick={() => searchItem(itemForm.barcode)}
                      className="btn btn-secondary"
                    >
                      <FiSearch />
                    </button>
                  </div>
                </div>
                <div className="form-group">
                  <label>Style Code</label>
                  <input
                    type="text"
                    value={itemForm.style_code}
                    onChange={(e) => setItemForm({...itemForm, style_code: e.target.value})}
                    placeholder="Style code"
                  />
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Item Name</label>
                  <input
                    type="text"
                    value={itemForm.item_name}
                    onChange={(e) => setItemForm({...itemForm, item_name: e.target.value})}
                    placeholder="Item description"
                  />
                </div>
                <div className="form-group">
                  <label>HSN Code</label>
                  <input
                    type="text"
                    value={itemForm.hsn}
                    onChange={(e) => setItemForm({...itemForm, hsn: e.target.value})}
                    placeholder="HSN"
                  />
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Quantity *</label>
                  <input
                    type="number"
                    min="1"
                    value={itemForm.qty}
                    onChange={(e) => setItemForm({...itemForm, qty: e.target.value})}
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Basic Rate (Excl. GST) *</label>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={itemForm.basic_rate}
                    onChange={(e) => setItemForm({...itemForm, basic_rate: e.target.value})}
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Discount %</label>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    step="0.01"
                    value={itemForm.disc_pct}
                    onChange={(e) => setItemForm({...itemForm, disc_pct: e.target.value})}
                  />
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>GST Rate %</label>
                  <select
                    value={itemForm.gst_rate}
                    onChange={(e) => {
                      const rate = parseFloat(e.target.value);
                      setItemForm({...itemForm, gst_rate: rate});
                      updateGSTRates();
                    }}
                  >
                    <option value="0">0%</option>
                    <option value="5">5%</option>
                    <option value="12">12%</option>
                    <option value="18">18%</option>
                    <option value="28">28%</option>
                  </select>
                </div>
                <div className="form-group">
                  <label>Color</label>
                  <input
                    type="text"
                    value={itemForm.color}
                    onChange={(e) => setItemForm({...itemForm, color: e.target.value})}
                  />
                </div>
                <div className="form-group">
                  <label>Size</label>
                  <input
                    type="text"
                    value={itemForm.size}
                    onChange={(e) => setItemForm({...itemForm, size: e.target.value})}
                  />
                </div>
              </div>

              {/* Item Calculation Preview */}
              <div className="item-calculation">
                <h4>Calculation</h4>
                <div className="calc-row">
                  <span>Basic Amount:</span>
                  <span>{formatCurrency(calculateItemTotals().basicAmount)}</span>
                </div>
                <div className="calc-row">
                  <span>Discount:</span>
                  <span className="discount">-{formatCurrency(calculateItemTotals().discAmount)}</span>
                </div>
                <div className="calc-row">
                  <span>Taxable:</span>
                  <span>{formatCurrency(calculateItemTotals().taxableAmount)}</span>
                </div>
                {itemForm.cgst_rate > 0 && (
                  <div className="calc-row">
                    <span>CGST ({itemForm.cgst_rate}%):</span>
                    <span>{formatCurrency(calculateItemTotals().cgstAmount)}</span>
                  </div>
                )}
                {itemForm.sgst_rate > 0 && (
                  <div className="calc-row">
                    <span>SGST ({itemForm.sgst_rate}%):</span>
                    <span>{formatCurrency(calculateItemTotals().sgstAmount)}</span>
                  </div>
                )}
                {itemForm.igst_rate > 0 && (
                  <div className="calc-row">
                    <span>IGST ({itemForm.igst_rate}%):</span>
                    <span>{formatCurrency(calculateItemTotals().igstAmount)}</span>
                  </div>
                )}
                <div className="calc-row total">
                  <span>Total:</span>
                  <span>{formatCurrency(calculateItemTotals().totalAmount)}</span>
                </div>
              </div>

              <div className="modal-footer">
                <button onClick={() => setShowItemModal(false)} className="btn btn-secondary">
                  Cancel
                </button>
                <button onClick={addItem} className="btn btn-primary">
                  {editingIndex !== null ? 'Update Item' : 'Add Item'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Purchase;