import React, { useState, useEffect, useRef } from 'react';
import { 
  FiRotateCcw, FiSearch, FiX, FiCheck, FiAlertCircle,
  FiShoppingBag, FiPackage, FiDollarSign, FiUser,
  FiCalendar, FiPrinter, FiCreditCard, FiMinusCircle,
  FiFileText, FiTrendingDown
} from 'react-icons/fi';
import toast from 'react-hot-toast';
import { salesAPI, setupAPI, formatCurrency, formatDate } from '../services/api';
import './SaleReturn.css';

function SaleReturn() {
  const [loading, setLoading] = useState(false);
  const [searchBillNo, setSearchBillNo] = useState('');
  const [originalSale, setOriginalSale] = useState(null);
  const [returnItems, setReturnItems] = useState([]);
  const [returnReason, setReturnReason] = useState('');
  const [customer, setCustomer] = useState(null);
  const [returnCredit, setReturnCredit] = useState(null);
  const [existingReturns, setExistingReturns] = useState([]);
  const [showHistoryModal, setShowHistoryModal] = useState(false);
  const [recentReturns, setRecentReturns] = useState([]);
  const [billSeries, setBillSeries] = useState([]);
  const [selectedSeries, setSelectedSeries] = useState(null);
  const barcodeInputRef = useRef(null);

  // Stats
  const [stats, setStats] = useState({
    todayReturns: 0,
    todayAmount: 0,
    pendingCredits: 0,
    monthlyReturns: 0
  });

  // Fetch initial data
  useEffect(() => {
    fetchBillSeries();
    fetchRecentReturns();
    fetchStats();
  }, []);

  // Fetch bill series
  const fetchBillSeries = async () => {
    try {
      const response = await setupAPI.getBillSeries({ type: 'SR' });
      const series = response.data || [];
      setBillSeries(series);
      if (series.length > 0) {
        setSelectedSeries(series[0]);
      }
    } catch (error) {
      console.error('Error fetching bill series:', error);
    }
  };

  // Fetch recent returns
  const fetchRecentReturns = async () => {
    try {
      const today = new Date();
      const params = {
        from_date: new Date(today.setDate(today.getDate() - 7)).toISOString().split('T')[0],
        page_size: 10
      };
      const response = await salesAPI.getReturns(params);
      setRecentReturns(response.data.items || []);
    } catch (error) {
      console.error('Error fetching recent returns:', error);
    }
  };

  // Fetch stats
  const fetchStats = async () => {
    try {
      // This would be a custom endpoint - using mock data for now
      const today = new Date().toISOString().split('T')[0];
      const response = await salesAPI.getReturns({ 
        from_date: today,
        to_date: today 
      });
      
      const todayData = response.data.items || [];
      setStats({
        todayReturns: todayData.length,
        todayAmount: todayData.reduce((sum, r) => sum + parseFloat(r.total_incl || 0), 0),
        pendingCredits: 0, // Would come from API
        monthlyReturns: 0  // Would come from API
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  // Search original sale by bill number
  const searchSale = async () => {
    if (!searchBillNo.trim()) {
      toast.error('Please enter a bill number');
      return;
    }

    setLoading(true);
    try {
      // Search for the sale by bill number
      const response = await salesAPI.getSales({ bill_no: searchBillNo });
      
      if (!response.data.items || response.data.items.length === 0) {
        toast.error('Bill not found');
        setOriginalSale(null);
        setReturnItems([]);
        setCustomer(null);
        return;
      }

      const sale = response.data.items[0];
      setOriginalSale(sale);

      // Initialize return items from sale items
      const itemsForReturn = sale.items.map(item => ({
        ...item,
        available_qty: item.qty - (item.returned_qty || 0),
        return_qty: 0,
        selected: false,
        return_amount: 0
      }));
      setReturnItems(itemsForReturn);

      // Fetch customer details if mobile exists
      if (sale.customer_mobile) {
        try {
          const customerResponse = await setupAPI.searchCustomer(sale.customer_mobile);
          setCustomer(customerResponse.data);
          
          // Check for existing return credits
          const creditResponse = await salesAPI.getReturnCredit(sale.customer_mobile);
          setReturnCredit(creditResponse.data);
        } catch (error) {
          console.error('Error fetching customer:', error);
        }
      }

      // Check for existing returns for this sale
      const returnsResponse = await salesAPI.getReturns({ 
        original_sale_id: sale.id 
      });
      setExistingReturns(returnsResponse.data.items || []);

      toast.success('Sale found. Select items to return.');
    } catch (error) {
      toast.error('Failed to search sale');
      console.error('Error searching sale:', error);
    } finally {
      setLoading(false);
    }
  };

  // Handle barcode scan for quick search
  const handleBarcodeSearch = async (barcode) => {
    if (!originalSale) {
      toast.error('Please search for a bill first');
      return;
    }

    const item = returnItems.find(i => i.barcode === barcode);
    if (!item) {
      toast.error('Item not found in this bill');
      return;
    }

    if (item.available_qty <= 0) {
      toast.error('This item has already been fully returned');
      return;
    }

    // Toggle selection and add 1 to return quantity
    handleItemSelection(returnItems.indexOf(item), true, 1);
    toast.success(`Added ${item.style_code} to return`);
  };

  // Handle item selection for return
  const handleItemSelection = (index, selected, returnQty = null) => {
    const updatedItems = [...returnItems];
    const item = updatedItems[index];
    
    item.selected = selected;
    
    if (selected) {
      // Set return quantity
      const qty = returnQty !== null ? returnQty : Math.min(1, item.available_qty);
      item.return_qty = Math.min(qty, item.available_qty);
      
      // Calculate return amount (considering original discount)
      const discountAmount = (item.mrp_incl * item.disc_pct) / 100;
      const priceAfterDiscount = item.mrp_incl - discountAmount;
      item.return_amount = priceAfterDiscount * item.return_qty;
    } else {
      item.return_qty = 0;
      item.return_amount = 0;
    }
    
    setReturnItems(updatedItems);
  };

  // Update return quantity
  const updateReturnQty = (index, qty) => {
    const updatedItems = [...returnItems];
    const item = updatedItems[index];
    
    const returnQty = Math.min(Math.max(0, parseInt(qty) || 0), item.available_qty);
    item.return_qty = returnQty;
    
    if (returnQty > 0) {
      item.selected = true;
      const discountAmount = (item.mrp_incl * item.disc_pct) / 100;
      const priceAfterDiscount = item.mrp_incl - discountAmount;
      item.return_amount = priceAfterDiscount * returnQty;
    } else {
      item.selected = false;
      item.return_amount = 0;
    }
    
    setReturnItems(updatedItems);
  };

  // Calculate totals
  const calculateTotals = () => {
    const selectedItems = returnItems.filter(item => item.selected && item.return_qty > 0);
    const totalItems = selectedItems.reduce((sum, item) => sum + item.return_qty, 0);
    const totalAmount = selectedItems.reduce((sum, item) => sum + item.return_amount, 0);
    
    return { 
      totalItems, 
      totalAmount,
      itemCount: selectedItems.length 
    };
  };

  // Process return
  const processReturn = async () => {
    const selectedItems = returnItems.filter(item => item.selected && item.return_qty > 0);
    
    if (selectedItems.length === 0) {
      toast.error('Please select items to return');
      return;
    }

    if (!returnReason.trim()) {
      toast.error('Please provide a reason for return');
      return;
    }

    if (!selectedSeries) {
      toast.error('Please select a return series');
      return;
    }

    const totals = calculateTotals();
    
    if (!window.confirm(`Process return for ${totals.totalItems} item(s) worth ${formatCurrency(totals.totalAmount)}?`)) {
      return;
    }

    setLoading(true);
    try {
      const returnData = {
        sr_series_id: selectedSeries.id,
        original_sale_id: originalSale.id,
        customer_mobile: originalSale.customer_mobile,
        tax_region: originalSale.tax_region,
        reason: returnReason,
        items: selectedItems.map(item => ({
          sale_id: originalSale.id,
          sale_item_id: item.id,
          barcode: item.barcode,
          style_code: item.style_code,
          color: item.color,
          size: item.size,
          hsn: item.hsn,
          gst_rate: (item.cgst_rate + item.sgst_rate + item.igst_rate),
          unit_mrp_incl: item.mrp_incl,
          disc_pct_at_sale: item.disc_pct,
          return_qty: item.return_qty
        }))
      };

      const response = await salesAPI.createReturn(returnData);
      
      toast.success(`Return processed successfully. Return No: ${response.data.sr_no}`);
      
      // Show return credit details
      if (response.data.return_credit) {
        toast.success(`Return Credit: ${response.data.return_credit.rc_no} - Amount: ${formatCurrency(response.data.return_credit.rc_amount_incl)}`, {
          duration: 5000
        });
      }

      // Reset form
      resetForm();
      
      // Refresh stats and recent returns
      fetchRecentReturns();
      fetchStats();
      
      // Option to print return receipt
      if (window.confirm('Print return receipt?')) {
        // Implement print functionality
        handlePrintReturn(response.data);
      }
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to process return');
      console.error('Error processing return:', error);
    } finally {
      setLoading(false);
    }
  };

  // Reset form
  const resetForm = () => {
    setSearchBillNo('');
    setOriginalSale(null);
    setReturnItems([]);
    setReturnReason('');
    setCustomer(null);
    setReturnCredit(null);
    setExistingReturns([]);
  };

  // Print return receipt
  const handlePrintReturn = (returnData) => {
    // This would integrate with the printing service
    console.log('Printing return:', returnData);
    toast.success('Sending to printer...');
  };

  const totals = calculateTotals();

  return (
    <div className="sale-return-container">
      {/* Header */}
      <div className="page-header">
        <div className="page-title">
          <FiRotateCcw className="page-icon" />
          <h1>Sale Return / Exchange</h1>
        </div>
        <div className="page-actions">
          <button onClick={() => setShowHistoryModal(true)} className="btn btn-secondary">
            <FiFileText /> Return History
          </button>
          <button onClick={resetForm} className="btn btn-secondary">
            <FiX /> Clear
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="stats-cards">
        <div className="stat-card">
          <div className="stat-icon red">
            <FiTrendingDown />
          </div>
          <div className="stat-content">
            <h3>Today's Returns</h3>
            <p>{stats.todayReturns}</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon orange">
            <FiDollarSign />
          </div>
          <div className="stat-content">
            <h3>Return Value Today</h3>
            <p>{formatCurrency(stats.todayAmount)}</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon purple">
            <FiCreditCard />
          </div>
          <div className="stat-content">
            <h3>Pending Credits</h3>
            <p>{formatCurrency(stats.pendingCredits)}</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon blue">
            <FiPackage />
          </div>
          <div className="stat-content">
            <h3>Monthly Returns</h3>
            <p>{stats.monthlyReturns}</p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="return-content">
        {/* Search Section */}
        <div className="search-section card">
          <h2>Search Original Sale</h2>
          <div className="search-controls">
            <div className="search-input-group">
              <FiSearch />
              <input
                type="text"
                placeholder="Enter Bill Number (e.g., INV000001)"
                value={searchBillNo}
                onChange={(e) => setSearchBillNo(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && searchSale()}
              />
              <button onClick={searchSale} className="btn btn-primary" disabled={loading}>
                {loading ? 'Searching...' : 'Search'}
              </button>
            </div>
            {billSeries.length > 0 && (
              <div className="series-selector">
                <label>Return Series:</label>
                <select
                  value={selectedSeries?.id || ''}
                  onChange={(e) => {
                    const series = billSeries.find(s => s.id === parseInt(e.target.value));
                    setSelectedSeries(series);
                  }}
                >
                  {billSeries.map(series => (
                    <option key={series.id} value={series.id}>
                      {series.prefix} - {series.description}
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>

          {/* Quick Barcode Scan */}
          <div className="barcode-scan-group">
            <input
              ref={barcodeInputRef}
              type="text"
              placeholder="Scan barcode to add item..."
              onKeyPress={(e) => {
                if (e.key === 'Enter' && e.target.value) {
                  handleBarcodeSearch(e.target.value);
                  e.target.value = '';
                }
              }}
              disabled={!originalSale}
            />
          </div>
        </div>

        {/* Original Sale Details */}
        {originalSale && (
          <div className="sale-details card">
            <h2>Original Sale Details</h2>
            <div className="sale-info">
              <div className="info-row">
                <div className="info-item">
                  <label>Bill No:</label>
                  <span>{originalSale.bill_no}</span>
                </div>
                <div className="info-item">
                  <label>Date:</label>
                  <span>{formatDate(originalSale.bill_date)}</span>
                </div>
                <div className="info-item">
                  <label>Amount:</label>
                  <span>{formatCurrency(originalSale.grand_total_incl)}</span>
                </div>
                <div className="info-item">
                  <label>Items:</label>
                  <span>{originalSale.items?.length || 0}</span>
                </div>
              </div>
              
              {customer && (
                <div className="customer-info">
                  <FiUser />
                  <span>{customer.name} ({customer.mobile})</span>
                  {customer.loyalty_grade_id && (
                    <span className="loyalty-badge">Loyalty Member</span>
                  )}
                  {returnCredit && returnCredit.status === 'open' && (
                    <span className="credit-badge">
                      Credit Available: {formatCurrency(returnCredit.rc_amount_incl - returnCredit.used_amount)}
                    </span>
                  )}
                </div>
              )}

              {existingReturns.length > 0 && (
                <div className="warning-box">
                  <FiAlertCircle />
                  <span>{existingReturns.length} previous return(s) found for this bill</span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Items for Return */}
        {returnItems.length > 0 && (
          <div className="return-items card">
            <h2>Select Items to Return</h2>
            <div className="items-table-container">
              <table className="items-table">
                <thead>
                  <tr>
                    <th>Select</th>
                    <th>Barcode</th>
                    <th>Style Code</th>
                    <th>Color/Size</th>
                    <th>MRP</th>
                    <th>Discount</th>
                    <th>Sold Qty</th>
                    <th>Already Returned</th>
                    <th>Available</th>
                    <th>Return Qty</th>
                    <th>Return Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {returnItems.map((item, index) => (
                    <tr key={index} className={item.selected ? 'selected' : ''}>
                      <td>
                        <input
                          type="checkbox"
                          checked={item.selected}
                          onChange={(e) => handleItemSelection(index, e.target.checked)}
                          disabled={item.available_qty <= 0}
                        />
                      </td>
                      <td className="barcode">{item.barcode}</td>
                      <td>{item.style_code}</td>
                      <td>{item.color || '-'} / {item.size || '-'}</td>
                      <td>{formatCurrency(item.mrp_incl)}</td>
                      <td>{item.disc_pct}%</td>
                      <td>{item.qty}</td>
                      <td className={item.returned_qty > 0 ? 'returned' : ''}>
                        {item.returned_qty || 0}
                      </td>
                      <td className={item.available_qty <= 0 ? 'no-stock' : ''}>
                        {item.available_qty}
                      </td>
                      <td>
                        <input
                          type="number"
                          min="0"
                          max={item.available_qty}
                          value={item.return_qty || ''}
                          onChange={(e) => updateReturnQty(index, e.target.value)}
                          disabled={item.available_qty <= 0}
                          className="qty-input"
                        />
                      </td>
                      <td className="amount">
                        {item.return_amount > 0 ? formatCurrency(item.return_amount) : '-'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Return Reason */}
            <div className="return-reason-section">
              <label>Return Reason *</label>
              <textarea
                value={returnReason}
                onChange={(e) => setReturnReason(e.target.value)}
                placeholder="Enter reason for return (e.g., Size issue, Defective product, Customer changed mind, etc.)"
                rows="3"
                required
              />
            </div>

            {/* Return Summary */}
            <div className="return-summary">
              <div className="summary-info">
                <div className="summary-item">
                  <label>Items Selected:</label>
                  <span>{totals.itemCount}</span>
                </div>
                <div className="summary-item">
                  <label>Total Quantity:</label>
                  <span>{totals.totalItems}</span>
                </div>
                <div className="summary-item highlight">
                  <label>Return Amount:</label>
                  <span className="amount">{formatCurrency(totals.totalAmount)}</span>
                </div>
              </div>

              <div className="return-actions">
                <button 
                  onClick={processReturn} 
                  className="btn btn-primary btn-large"
                  disabled={loading || totals.itemCount === 0}
                >
                  {loading ? 'Processing...' : 'Process Return'}
                </button>
              </div>
            </div>

            {/* Return Policy Note */}
            <div className="policy-note">
              <FiAlertCircle />
              <p>
                <strong>Return Policy:</strong> No cash refunds. Return amount will be issued as a Return Credit 
                which can be used for future purchases. Return credits are valid for 6 months from the date of issue.
              </p>
            </div>
          </div>
        )}

        {/* Recent Returns */}
        {recentReturns.length > 0 && !originalSale && (
          <div className="recent-returns card">
            <h2>Recent Returns</h2>
            <table className="returns-table">
              <thead>
                <tr>
                  <th>Return No</th>
                  <th>Date</th>
                  <th>Original Bill</th>
                  <th>Customer</th>
                  <th>Items</th>
                  <th>Amount</th>
                  <th>Credit No</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {recentReturns.map((ret) => (
                  <tr key={ret.id}>
                    <td className="return-no">{ret.sr_no}</td>
                    <td>{formatDate(ret.sr_date)}</td>
                    <td>{ret.original_bill_no || '-'}</td>
                    <td>{ret.customer_name || ret.customer_mobile || '-'}</td>
                    <td>{ret.item_count || 0}</td>
                    <td className="amount">{formatCurrency(ret.total_incl)}</td>
                    <td>{ret.rc_no || '-'}</td>
                    <td>
                      <button 
                        onClick={() => handlePrintReturn(ret)}
                        className="btn-icon"
                        title="Print"
                      >
                        <FiPrinter />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* History Modal */}
      {showHistoryModal && (
        <div className="modal-overlay" onClick={() => setShowHistoryModal(false)}>
          <div className="modal-content large" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h2>Return History</h2>
              <button onClick={() => setShowHistoryModal(false)} className="btn-close">
                <FiX />
              </button>
            </div>
            <div className="history-content">
              {/* Add comprehensive return history view here */}
              <p>Return history implementation would go here...</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default SaleReturn;