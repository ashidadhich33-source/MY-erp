import React, { useState, useEffect } from 'react';
import { 
  FiTrendingUp, FiUsers, FiPackage, FiDollarSign,
  FiShoppingBag, FiAlertCircle, FiRefreshCw, FiArrowUp,
  FiArrowDown, FiActivity, FiClock, FiBell, FiBarChart2,
  FiCalendar, FiTarget, FiAward, FiPieChart
} from 'react-icons/fi';
import { Link } from 'react-router-dom';
import { format, startOfDay, endOfDay, subDays } from 'date-fns';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import toast from 'react-hot-toast';
import axios from 'axios';
import './Dashboard.css';

const API_URL = 'http://localhost:8000/api/v1';

function Dashboard() {
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [timeRange, setTimeRange] = useState('today'); // today, week, month
  
  // Dashboard data
  const [stats, setStats] = useState({
    todaySales: 0,
    todayBills: 0,
    todayCustomers: 0,
    todayReturns: 0,
    weekSales: 0,
    monthSales: 0,
    salesGrowth: 0,
    customerGrowth: 0
  });

  const [alerts, setAlerts] = useState({
    lowStockItems: [],
    pendingReturns: [],
    birthdaysToday: [],
    expiredCoupons: []
  });

  const [charts, setCharts] = useState({
    salesTrend: [],
    topProducts: [],
    paymentModes: [],
    hourlySales: [],
    categoryWise: []
  });

  const [recentActivity, setRecentActivity] = useState([]);
  const [topPerformers, setTopPerformers] = useState({
    staff: [],
    customers: [],
    products: []
  });

  // Fetch all dashboard data
  const fetchDashboardData = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const today = format(new Date(), 'yyyy-MM-dd');
      
      // Fetch multiple endpoints in parallel
      const [
        statsRes,
        alertsRes,
        chartsRes,
        activityRes,
        performersRes
      ] = await Promise.all([
        axios.get(`${API_URL}/dashboard/stats?date=${today}`, {
          headers: { Authorization: `Bearer ${token}` }
        }),
        axios.get(`${API_URL}/dashboard/alerts`, {
          headers: { Authorization: `Bearer ${token}` }
        }),
        axios.get(`${API_URL}/dashboard/charts?range=${timeRange}`, {
          headers: { Authorization: `Bearer ${token}` }
        }),
        axios.get(`${API_URL}/dashboard/recent-activity`, {
          headers: { Authorization: `Bearer ${token}` }
        }),
        axios.get(`${API_URL}/dashboard/top-performers`, {
          headers: { Authorization: `Bearer ${token}` }
        })
      ]);

      setStats(statsRes.data);
      setAlerts(alertsRes.data);
      setCharts(chartsRes.data);
      setRecentActivity(activityRes.data.activities || []);
      setTopPerformers(performersRes.data);

      toast.success('Dashboard updated');
    } catch (error) {
      console.error('Dashboard fetch error:', error);
      // Use mock data for demo
      setMockData();
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  // Mock data for demo
  const setMockData = () => {
    setStats({
      todaySales: 125430,
      todayBills: 42,
      todayCustomers: 38,
      todayReturns: 2,
      weekSales: 875600,
      monthSales: 3450000,
      salesGrowth: 12.5,
      customerGrowth: 8.3
    });

    setAlerts({
      lowStockItems: [
        { barcode: 'ABC123', name: 'Premium Shirt', quantity: 5 },
        { barcode: 'DEF456', name: 'Designer Jeans', quantity: 3 }
      ],
      pendingReturns: 2,
      birthdaysToday: [
        { name: 'Priya Sharma', mobile: '9876543210' }
      ],
      expiredCoupons: 1
    });

    setCharts({
      salesTrend: [
        { date: 'Mon', sales: 45000, returns: 2000 },
        { date: 'Tue', sales: 52000, returns: 1500 },
        { date: 'Wed', sales: 48000, returns: 1000 },
        { date: 'Thu', sales: 61000, returns: 2500 },
        { date: 'Fri', sales: 73000, returns: 1800 },
        { date: 'Sat', sales: 89000, returns: 2200 },
        { date: 'Sun', sales: 125430, returns: 1200 }
      ],
      topProducts: [
        { name: 'Premium Shirt', sales: 45 },
        { name: 'Designer Jeans', sales: 38 },
        { name: 'Casual T-Shirt', sales: 32 },
        { name: 'Formal Pants', sales: 28 },
        { name: 'Summer Dress', sales: 25 }
      ],
      paymentModes: [
        { name: 'Cash', value: 45, fill: '#10b981' },
        { name: 'Card', value: 30, fill: '#3b82f6' },
        { name: 'UPI', value: 20, fill: '#9333ea' },
        { name: 'Other', value: 5, fill: '#f59e0b' }
      ],
      hourlySales: [
        { hour: '10AM', sales: 5 },
        { hour: '11AM', sales: 8 },
        { hour: '12PM', sales: 12 },
        { hour: '1PM', sales: 15 },
        { hour: '2PM', sales: 10 },
        { hour: '3PM', sales: 18 },
        { hour: '4PM', sales: 22 },
        { hour: '5PM', sales: 28 },
        { hour: '6PM', sales: 35 },
        { hour: '7PM', sales: 42 },
        { hour: '8PM', sales: 38 },
        { hour: '9PM', sales: 25 }
      ],
      categoryWise: [
        { category: 'Men', value: 40 },
        { category: 'Women', value: 35 },
        { category: 'Kids', value: 15 },
        { category: 'Accessories', value: 10 }
      ]
    });

    setRecentActivity([
      { type: 'sale', message: 'New sale #SALE/2024/001245', amount: 4500, time: '2 mins ago' },
      { type: 'return', message: 'Return processed #RET/2024/00045', amount: -1200, time: '15 mins ago' },
      { type: 'customer', message: 'New customer registered', time: '30 mins ago' },
      { type: 'stock', message: 'Low stock alert: Premium Shirt', time: '1 hour ago' }
    ]);

    setTopPerformers({
      staff: [
        { name: 'Rahul Kumar', sales: 45000, bills: 12 },
        { name: 'Priya Patel', sales: 38000, bills: 10 }
      ],
      customers: [
        { name: 'Amit Shah', purchase: 25000, visits: 5 },
        { name: 'Neha Gupta', purchase: 18000, visits: 3 }
      ],
      products: [
        { name: 'Premium Shirt', quantity: 25, revenue: 37500 },
        { name: 'Designer Jeans', quantity: 18, revenue: 45000 }
      ]
    });
  };

  useEffect(() => {
    fetchDashboardData();
    // Auto-refresh every 5 minutes
    const interval = setInterval(fetchDashboardData, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, [timeRange]);

  // Quick actions
  const quickActions = [
    { icon: <FiShoppingBag />, label: 'New Sale', path: '/pos', color: 'green' },
    { icon: <FiPackage />, label: 'Add Stock', path: '/setup/stock-adjustment', color: 'blue' },
    { icon: <FiUsers />, label: 'Add Customer', path: '/setup/customers', color: 'purple' },
    { icon: <FiBarChart2 />, label: 'Reports', path: '/reports/sales', color: 'orange' }
  ];

  // Get activity icon
  const getActivityIcon = (type) => {
    switch(type) {
      case 'sale': return <FiShoppingBag className="activity-icon sale" />;
      case 'return': return <FiArrowDown className="activity-icon return" />;
      case 'customer': return <FiUsers className="activity-icon customer" />;
      case 'stock': return <FiPackage className="activity-icon stock" />;
      default: return <FiActivity className="activity-icon" />;
    }
  };

  return (
    <div className="dashboard-container">
      {/* Header */}
      <div className="dashboard-header">
        <div className="header-left">
          <h1 className="dashboard-title">
            <FiActivity className="title-icon" />
            Dashboard
          </h1>
          <p className="dashboard-subtitle">
            Welcome back! Here's your business overview
          </p>
        </div>
        <div className="header-actions">
          <select 
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value)}
            className="time-selector"
          >
            <option value="today">Today</option>
            <option value="week">This Week</option>
            <option value="month">This Month</option>
          </select>
          <button 
            className="btn-refresh"
            onClick={() => {
              setRefreshing(true);
              fetchDashboardData();
            }}
            disabled={refreshing}
          >
            <FiRefreshCw className={refreshing ? 'spinning' : ''} />
            {refreshing ? 'Refreshing...' : 'Refresh'}
          </button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="stats-grid">
        <div className="stat-card primary">
          <div className="stat-icon">
            <FiDollarSign />
          </div>
          <div className="stat-content">
            <p className="stat-label">Today's Sales</p>
            <p className="stat-value">₹{stats.todaySales.toLocaleString()}</p>
            <p className="stat-change positive">
              <FiArrowUp /> {stats.salesGrowth}% from yesterday
            </p>
          </div>
        </div>

        <div className="stat-card success">
          <div className="stat-icon">
            <FiShoppingBag />
          </div>
          <div className="stat-content">
            <p className="stat-label">Bills Today</p>
            <p className="stat-value">{stats.todayBills}</p>
            <p className="stat-change">
              {stats.todayCustomers} customers
            </p>
          </div>
        </div>

        <div className="stat-card warning">
          <div className="stat-icon">
            <FiTrendingUp />
          </div>
          <div className="stat-content">
            <p className="stat-label">Week Sales</p>
            <p className="stat-value">₹{stats.weekSales.toLocaleString()}</p>
            <p className="stat-change positive">
              <FiArrowUp /> On target
            </p>
          </div>
        </div>

        <div className="stat-card danger">
          <div className="stat-icon">
            <FiArrowDown />
          </div>
          <div className="stat-content">
            <p className="stat-label">Returns Today</p>
            <p className="stat-value">{stats.todayReturns}</p>
            <p className="stat-change negative">
              2% of sales
            </p>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="quick-actions-section">
        <h2 className="section-title">Quick Actions</h2>
        <div className="quick-actions-grid">
          {quickActions.map((action, index) => (
            <Link 
              key={index}
              to={action.path}
              className={`quick-action-card ${action.color}`}
            >
              <div className="action-icon">{action.icon}</div>
              <span className="action-label">{action.label}</span>
            </Link>
          ))}
        </div>
      </div>

      {/* Alerts Section */}
      {(alerts.lowStockItems?.length > 0 || alerts.birthdaysToday?.length > 0) && (
        <div className="alerts-section">
          <h2 className="section-title">
            <FiBell /> Alerts & Notifications
          </h2>
          <div className="alerts-grid">
            {alerts.lowStockItems?.length > 0 && (
              <div className="alert-card warning">
                <FiAlertCircle className="alert-icon" />
                <div className="alert-content">
                  <p className="alert-title">Low Stock Alert</p>
                  <p className="alert-message">
                    {alerts.lowStockItems.length} items running low
                  </p>
                  <Link to="/reports/stock" className="alert-link">
                    View Items →
                  </Link>
                </div>
              </div>
            )}

            {alerts.birthdaysToday?.length > 0 && (
              <div className="alert-card info">
                <FiAward className="alert-icon" />
                <div className="alert-content">
                  <p className="alert-title">Birthdays Today</p>
                  <p className="alert-message">
                    {alerts.birthdaysToday.length} customer birthdays
                  </p>
                  <Link to="/reports/birthday" className="alert-link">
                    Send Wishes →
                  </Link>
                </div>
              </div>
            )}

            {alerts.pendingReturns > 0 && (
              <div className="alert-card danger">
                <FiArrowDown className="alert-icon" />
                <div className="alert-content">
                  <p className="alert-title">Pending Returns</p>
                  <p className="alert-message">
                    {alerts.pendingReturns} returns to process
                  </p>
                  <Link to="/sale-return" className="alert-link">
                    Process Now →
                  </Link>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Charts Section */}
      <div className="charts-section">
        <div className="chart-row">
          <div className="chart-card large">
            <h3 className="chart-title">
              <FiTrendingUp /> Sales Trend
            </h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={charts.salesTrend}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="date" stroke="#6b7280" />
                <YAxis stroke="#6b7280" />
                <Tooltip 
                  contentStyle={{ 
                    background: 'white', 
                    border: '1px solid #e5e7eb',
                    borderRadius: '8px'
                  }}
                />
                <Legend />
                <Line 
                  type="monotone" 
                  dataKey="sales" 
                  stroke="#9333ea" 
                  strokeWidth={2}
                  name="Sales"
                />
                <Line 
                  type="monotone" 
                  dataKey="returns" 
                  stroke="#ef4444" 
                  strokeWidth={2}
                  name="Returns"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="chart-card small">
            <h3 className="chart-title">
              <FiPieChart /> Payment Modes
            </h3>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={charts.paymentModes}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={(entry) => `${entry.name} ${entry.value}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {charts.paymentModes.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="chart-row">
          <div className="chart-card medium">
            <h3 className="chart-title">
              <FiClock /> Hourly Sales
            </h3>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={charts.hourlySales}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="hour" stroke="#6b7280" />
                <YAxis stroke="#6b7280" />
                <Tooltip />
                <Bar dataKey="sales" fill="#9333ea" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="chart-card medium">
            <h3 className="chart-title">
              <FiPackage /> Top Products
            </h3>
            <div className="top-products-list">
              {charts.topProducts.map((product, index) => (
                <div key={index} className="product-item">
                  <span className="product-rank">#{index + 1}</span>
                  <span className="product-name">{product.name}</span>
                  <span className="product-sales">{product.sales} sold</span>
                  <div className="product-bar">
                    <div 
                      className="bar-fill"
                      style={{ 
                        width: `${(product.sales / charts.topProducts[0].sales) * 100}%` 
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Section */}
      <div className="bottom-section">
        {/* Recent Activity */}
        <div className="activity-card">
          <h3 className="card-title">
            <FiClock /> Recent Activity
          </h3>
          <div className="activity-list">
            {recentActivity.map((activity, index) => (
              <div key={index} className="activity-item">
                {getActivityIcon(activity.type)}
                <div className="activity-content">
                  <p className="activity-message">{activity.message}</p>
                  <p className="activity-time">{activity.time}</p>
                </div>
                {activity.amount && (
                  <span className={`activity-amount ${activity.amount < 0 ? 'negative' : 'positive'}`}>
                    {activity.amount < 0 ? '-' : '+'}₹{Math.abs(activity.amount)}
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Top Performers */}
        <div className="performers-card">
          <h3 className="card-title">
            <FiAward /> Top Performers Today
          </h3>
          
          <div className="performer-section">
            <h4>Top Staff</h4>
            {topPerformers.staff?.map((staff, index) => (
              <div key={index} className="performer-item">
                <span className="performer-badge">{index + 1}</span>
                <div className="performer-info">
                  <p className="performer-name">{staff.name}</p>
                  <p className="performer-stats">
                    ₹{staff.sales.toLocaleString()} • {staff.bills} bills
                  </p>
                </div>
              </div>
            ))}
          </div>

          <div className="performer-section">
            <h4>Top Customers</h4>
            {topPerformers.customers?.map((customer, index) => (
              <div key={index} className="performer-item">
                <span className="performer-badge">{index + 1}</span>
                <div className="performer-info">
                  <p className="performer-name">{customer.name}</p>
                  <p className="performer-stats">
                    ₹{customer.purchase.toLocaleString()} • {customer.visits} visits
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;