// frontend/src/screens/POS.jsx
// Complete Modern Fashion POS System with all requirements

import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import './POS.css';
import { API_URL } from '../services/api';

const POS = () => {
  // ===== STATE MANAGEMENT =====
  // Bill Header State
  const [billSeries, setBillSeries] = useState('INV');
  const [billDate, setBillDate] = useState(new Date().toISOString().split('T')[0]);
  const [billNo, setBillNo] = useState('');
  const [billCounter, setBillCounter] = useState(1);
  const [taxRegion, setTaxRegion] = useState('CGST/SGST');
  const [agent, setAgent] = useState('');
  const [selectedStaff, setSelectedStaff] = useState('');
  
  // Customer State
  const [customerMobile, setCustomerMobile] = useState('');
  const [customer, setCustomer] = useState(null);
  const [customerStats, setCustomerStats] = useState({
    totalSale: 0,
    loyaltyPoints: 0,
    currentGrade: 'Regular'
  });
  
  // Cart State
  const [cartItems, setCartItems] = useState([]);
  const [defaultQty, setDefaultQty] = useState(1);
  const [currentBarcode, setCurrentBarcode] = useState('');
  
  // Coupon & Discounts
  const [appliedCoupon, setAppliedCoupon] = useState(null);
  const [couponCode, setCouponCode] = useState('');
  const [redeemPoints, setRedeemPoints] = useState(0);
  const [returnCredit, setReturnCredit] = useState(null);
  
  // UI State
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [showCouponModal, setShowCouponModal] = useState(false);
  const [showStaffModal, setShowStaffModal] = useState(false);
  const [showModifyModal, setShowModifyModal] = useState(false);
  const [showHistoryModal, setShowHistoryModal] = useState(false);
  const [showHoldBills, setShowHoldBills] = useState(false);
  const [holdBills, setHoldBills] = useState([]);
  const [isEditMode, setIsEditMode] = useState(false);
  const [loading, setLoading] = useState(false);
  
  // Payment State
  const [paymentSplits, setPaymentSplits] = useState([
    { mode: 'CASH', amount: 0 }
  ]);
  const [otpSent, setOtpSent] = useState(false);
  const [otpValue, setOtpValue] = useState('');
  const [availableReturnCredits, setAvailableReturnCredits] = useState([]);
  
  // Staff list and Bill Series
  const [staffList, setStaffList] = useState([]);
  const [billSeriesList, setBillSeriesList] = useState([]);
  
  // Refs
  const barcodeInputRef = useRef(null);
  const printRef = useRef(null);
  
  // ===== INITIALIZATION =====
  useEffect(() => {
    initializeBill();
    loadHoldBills();
    setupKeyboardShortcuts();
    focusBarcode();
    fetchBillSeries();
    fetchStaffList();
  }, []);
  
  // Fetch Bill Series
  const fetchBillSeries = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${API_URL}/setup/bill-series`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setBillSeriesList(response.data || []);
      if (response.data && response.data.length > 0) {
        setBillSeries(response.data[0].prefix);
      }
    } catch (error) {
      console.error('Failed to fetch bill series');
    }
  };
  
  // Fetch Staff List
  const fetchStaffList = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${API_URL}/setup/staff`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setStaffList(response.data || []);
    } catch (error) {
      console.error('Failed to fetch staff');
    }
  };
  
  const initializeBill = () => {
    const today = new Date();
    const billNumber = `${billSeries}/${today.getFullYear()}/${String(today.getMonth() + 1).padStart(2, '0')}/${String(Date.now()).slice(-6)}`;
    setBillNo(billNumber);
    
    // Set tax region based on company state (default CGST/SGST for same state)
    setTaxRegion('CGST/SGST');
  };
  
  const loadHoldBills = () => {
    const saved = localStorage.getItem('holdBills');
    if (saved) {
      setHoldBills(JSON.parse(saved));
    }
  };
  
  const setupKeyboardShortcuts = () => {
    const handleKeyPress = (e) => {
      if (e.key === 'F1') {
        e.preventDefault();
        handleHoldBill();
      } else if (e.key === 'F2') {
        e.preventDefault();
        handleNewBill();
      } else if (e.key === 'F3') {
        e.preventDefault();
        document.getElementById('customer-mobile')?.focus();
      } else if (e.key === 'F4') {
        e.preventDefault();
        if (cartItems.length > 0) handlePaymentClick();
      } else if (e.key === 'F5') {
        e.preventDefault();
        setShowModifyModal(true);
      } else if (e.key === 'F6') {
        e.preventDefault();
        setShowStaffModal(true);
      } else if (e.key === 'Escape') {
        closeAllModals();
      }
    };
    
    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  };
  
  const focusBarcode = () => {
    setTimeout(() => barcodeInputRef.current?.focus(), 100);
  };
  
  const closeAllModals = () => {
    setShowPaymentModal(false);
    setShowCouponModal(false);
    setShowStaffModal(false);
    setShowModifyModal(false);
    setShowHistoryModal(false);
    setShowHoldBills(false);
  };
  
  // ===== CUSTOMER FUNCTIONS =====
  const handleCustomerSearch = async () => {
    if (!customerMobile || customerMobile.length !== 10) {
      toast.error('Please enter valid 10-digit mobile number');
      return;
    }
    
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      
      // Try to fetch from real backend first
      try {
        const response = await axios.get(
          `${API_URL}/setup/customers/search?mobile=${customerMobile}`,
          { headers: { Authorization: `Bearer ${token}` } }
        );
        
        if (response.data) {
          setCustomer(response.data);
          setCustomerStats({
            totalSale: response.data.total_sale || 0,
            loyaltyPoints: response.data.loyalty_points || 0,
            currentGrade: response.data.grade_name || 'Regular'
          });
          
          // Load return credits if any
          if (response.data.return_credits) {
            setAvailableReturnCredits(response.data.return_credits);
          }
          
          toast.success(`Customer: ${response.data.name}`);
        } else {
          handleNewCustomerCreation();
        }
      } catch (backendError) {
        // If backend fails, ask to create new customer
        if (window.confirm('Customer not found. Create new customer?')) {
          const name = prompt('Enter customer name:');
          if (name) {
            try {
              const newCustomerResponse = await axios.post(
                `${API_URL}/setup/customers`,
                { mobile: customerMobile, name },
                { headers: { Authorization: `Bearer ${token}` } }
              );
              
              setCustomer(newCustomerResponse.data);
              setCustomerStats({
                totalSale: 0,
                loyaltyPoints: 0,
                currentGrade: 'Regular'
              });
              toast.success('Customer created successfully');
            } catch (createError) {
              toast.error('Failed to create customer');
            }
          }
        }
      }
    } catch (error) {
      toast.error('Customer search failed');
    } finally {
      setLoading(false);
    }
  };
  
  const handleNewCustomerCreation = async () => {
    if (window.confirm('Customer not found. Create new customer?')) {
      const name = prompt('Enter customer name:');
      if (name) {
        try {
          const token = localStorage.getItem('token');
          const response = await axios.post(
            `${API_URL}/setup/customers`,
            { mobile: customerMobile, name },
            { headers: { Authorization: `Bearer ${token}` } }
          );
          
          setCustomer(response.data);
          setCustomerStats({
            totalSale: 0,
            loyaltyPoints: 0,
            currentGrade: 'Regular'
          });
          toast.success('Customer created successfully');
        } catch (error) {
          toast.error('Failed to create customer');
        }
      }
    }
  };
  
  const handleSaveCustomer = () => {
    if (!customer) {
      toast.error('No customer to save');
      return;
    }
    toast.success('Customer details updated');
  };
  
  const handleNewCustomer = () => {
    setCustomer(null);
    setCustomerMobile('');
    setCustomerStats({
      totalSale: 0,
      loyaltyPoints: 0,
      currentGrade: 'Regular'
    });
  };
  
  // ===== BARCODE & ITEM FUNCTIONS =====
  const handleBarcodeSubmit = (e) => {
    e.preventDefault();
    if (!currentBarcode) return;
    
    // Simulate item lookup
    const mockItem = {
      barcode: currentBarcode,
      styleCode: 'SR' + currentBarcode.slice(-4),
      color: 'Red',
      size: 'M',
      mrp: currentBarcode.startsWith('1') ? 1299 : 899,
      hsn: '6109',
      stockQty: 10
    };
    
    addItemToCart(mockItem);
    setCurrentBarcode('');
    focusBarcode();
  };
  
  const addItemToCart = (item) => {
    const existingIndex = cartItems.findIndex(i => i.barcode === item.barcode);
    
    if (existingIndex !== -1) {
      const updatedItems = [...cartItems];
      const existingItem = updatedItems[existingIndex];
      
      if (existingItem.qty + defaultQty > item.stockQty) {
        toast.error(`Only ${item.stockQty} units available`);
        return;
      }
      
      updatedItems[existingIndex].qty += defaultQty;
      setCartItems(updatedItems);
    } else {
      if (defaultQty > item.stockQty) {
        toast.error(`Only ${item.stockQty} units available`);
        return;
      }
      
      const gstRate = item.mrp <= 999 ? 5 : 12;
      const cgst = taxRegion === 'CGST/SGST' ? gstRate / 2 : 0;
      const sgst = taxRegion === 'CGST/SGST' ? gstRate / 2 : 0;
      const igst = taxRegion === 'IGST' ? gstRate : 0;
      
      setCartItems([...cartItems, {
        ...item,
        qty: defaultQty,
        discount: 0,
        cgst,
        sgst,
        igst,
        amount: item.mrp * defaultQty
      }]);
    }
    
    toast.success(`Added: ${item.styleCode}`);
  };
  
  const updateItemQty = (index, qty) => {
    const updatedItems = [...cartItems];
    const item = updatedItems[index];
    
    if (qty > item.stockQty) {
      toast.error(`Only ${item.stockQty} units available`);
      return;
    }
    
    if (qty <= 0) {
      removeItem(index);
      return;
    }
    
    item.qty = qty;
    item.amount = calculateLineAmount(item);
    setCartItems(updatedItems);
  };
  
  const updateItemDiscount = (index, discount) => {
    const updatedItems = [...cartItems];
    const item = updatedItems[index];
    item.discount = Math.min(100, Math.max(0, discount));
    item.amount = calculateLineAmount(item);
    setCartItems(updatedItems);
  };
  
  const removeItem = (index) => {
    const updatedItems = cartItems.filter((_, i) => i !== index);
    setCartItems(updatedItems);
    toast.info('Item removed');
  };
  
  const calculateLineAmount = (item) => {
    const discountedUnit = item.mrp * (1 - item.discount / 100);
    return discountedUnit * item.qty;
  };
  
  // ===== CALCULATIONS =====
  const calculateTotals = () => {
    let grossAmount = 0;
    let discountAmount = 0;
    let taxAmount = 0;
    
    cartItems.forEach(item => {
      const lineGross = item.mrp * item.qty;
      const lineDiscount = lineGross * (item.discount / 100);
      const lineNet = lineGross - lineDiscount;
      
      // Extract tax from inclusive amount
      const gstRate = item.mrp <= 999 ? 0.05 : 0.12;
      const baseAmount = lineNet / (1 + gstRate);
      const lineTax = lineNet - baseAmount;
      
      grossAmount += lineGross;
      discountAmount += lineDiscount;
      taxAmount += lineTax;
    });
    
    let netAmount = grossAmount - discountAmount;
    
    // Apply coupon
    let couponAmount = 0;
    if (appliedCoupon) {
      if (appliedCoupon.type === 'percent') {
        couponAmount = netAmount * (appliedCoupon.value / 100);
        if (appliedCoupon.maxCap) {
          couponAmount = Math.min(couponAmount, appliedCoupon.maxCap);
        }
      } else {
        couponAmount = appliedCoupon.value;
      }
    }
    
    // Final payable
    let payable = netAmount - couponAmount - redeemPoints;
    if (returnCredit) {
      payable -= returnCredit.amount;
    }
    
    // Points to earn (on base amount after coupon)
    const billBase = (netAmount - couponAmount) / 1.12; // Approximate base
    const pointsEarned = Math.floor(billBase * 0.02); // 2% points
    
    return {
      grossAmount,
      discountAmount,
      taxAmount,
      netAmount,
      couponAmount,
      redeemValue: redeemPoints,
      returnCreditAmount: returnCredit?.amount || 0,
      payable: Math.round(payable),
      pointsEarned
    };
  };
  
  // ===== COUPON FUNCTIONS =====
  const handleApplyCoupon = () => {
    if (!couponCode) {
      toast.error('Please enter coupon code');
      return;
    }
    
    // Simulate coupon validation
    const mockCoupon = {
      code: couponCode,
      type: 'percent',
      value: 10,
      maxCap: 500,
      minBill: 2000,
      boundMobile: null
    };
    
    const totals = calculateTotals();
    if (totals.netAmount < mockCoupon.minBill) {
      toast.error(`Minimum bill amount is ₹${mockCoupon.minBill}`);
      return;
    }
    
    if (mockCoupon.boundMobile && mockCoupon.boundMobile !== customerMobile) {
      toast.error('Coupon is bound to different mobile');
      return;
    }
    
    setAppliedCoupon(mockCoupon);
    toast.success('Coupon applied successfully');
    setShowCouponModal(false);
  };
  
  const removeCoupon = () => {
    setAppliedCoupon(null);
    setCouponCode('');
    toast.info('Coupon removed');
  };
  
  // ===== LOYALTY POINTS =====
  const handleSendOTP = () => {
    if (!customer) {
      toast.error('Please select customer first');
      return;
    }
    
    if (redeemPoints > customerStats.loyaltyPoints) {
      toast.error('Insufficient loyalty points');
      return;
    }
    
    // Simulate OTP send
    setOtpSent(true);
    toast.success(`OTP sent to ${customer.mobile}`);
  };
  
  const handleVerifyOTP = () => {
    if (otpValue === '123456') {
      toast.success('Points redeemed successfully');
      setOtpSent(false);
      setOtpValue('');
    } else {
      toast.error('Invalid OTP');
    }
  };
  
  // ===== HOLD & RECALL =====
  const handleHoldBill = () => {
    if (cartItems.length === 0) {
      toast.error('No items to hold');
      return;
    }
    
    const holdData = {
      id: `HOLD_${Date.now()}`,
      date: new Date().toISOString(),
      customer,
      customerMobile,
      items: cartItems,
      coupon: appliedCoupon,
      staff: selectedStaff,
      totals: calculateTotals()
    };
    
    const updatedHolds = [...holdBills, holdData];
    setHoldBills(updatedHolds);
    localStorage.setItem('holdBills', JSON.stringify(updatedHolds));
    
    toast.success('Bill held successfully');
    handleNewBill();
  };
  
  const handleRecallBill = (holdBill) => {
    setCustomer(holdBill.customer);
    setCustomerMobile(holdBill.customerMobile || '');
    setCartItems(holdBill.items);
    setAppliedCoupon(holdBill.coupon);
    setSelectedStaff(holdBill.staff);
    
    // Remove from hold bills
    const updatedHolds = holdBills.filter(h => h.id !== holdBill.id);
    setHoldBills(updatedHolds);
    localStorage.setItem('holdBills', JSON.stringify(updatedHolds));
    
    setShowHoldBills(false);
    toast.success('Bill recalled');
  };
  
  // ===== BILL OPERATIONS =====
  const handleNewBill = () => {
    if (cartItems.length > 0 && !window.confirm('Clear current bill and start new?')) {
      return;
    }
    
    setCartItems([]);
    setCustomer(null);
    setCustomerMobile('');
    setAppliedCoupon(null);
    setCouponCode('');
    setRedeemPoints(0);
    setReturnCredit(null);
    setSelectedStaff('');
    setIsEditMode(false);
    initializeBill();
    focusBarcode();
  };
  
  const handleModifyBill = () => {
    const billToModify = prompt('Enter bill number to modify:');
    if (!billToModify) return;
    
    // Check if bill is from today
    // In real app, load bill from backend
    toast.info(`Loading bill ${billToModify} for modification`);
    setIsEditMode(true);
    setShowModifyModal(false);
  };
  
  // ===== PAYMENT =====
  const handlePaymentClick = () => {
    if (cartItems.length === 0) {
      toast.error('No items in cart');
      return;
    }
    
    const totals = calculateTotals();
    setPaymentSplits([{ mode: 'CASH', amount: totals.payable }]);
    setShowPaymentModal(true);
  };
  
  const addPaymentSplit = () => {
    setPaymentSplits([...paymentSplits, { mode: 'CARD', amount: 0 }]);
  };
  
  const updatePaymentSplit = (index, field, value) => {
    const updated = [...paymentSplits];
    updated[index][field] = value;
    setPaymentSplits(updated);
  };
  
  const removePaymentSplit = (index) => {
    if (paymentSplits.length > 1) {
      setPaymentSplits(paymentSplits.filter((_, i) => i !== index));
    }
  };
  
  const handleSaveBill = () => {
    const totals = calculateTotals();
    const totalPaid = paymentSplits.reduce((sum, split) => sum + parseFloat(split.amount || 0), 0);
    
    if (Math.abs(totalPaid - totals.payable) > 0.01) {
      toast.error(`Payment mismatch. Required: ₹${totals.payable}, Entered: ₹${totalPaid}`);
      return;
    }
    
    // Save bill logic here
    toast.success('Bill saved successfully');
    handlePrint();
    handleWhatsApp();
    
    // Update loyalty points
    if (customer) {
      const newBalance = customerStats.loyaltyPoints - redeemPoints + totals.pointsEarned;
      setCustomerStats(prev => ({ ...prev, loyaltyPoints: newBalance }));
    }
    
    setShowPaymentModal(false);
    handleNewBill();
  };
  
  const handlePrint = () => {
    window.print();
  };
  
  const handleWhatsApp = () => {
    if (customer?.mobile) {
      toast.success(`Invoice sent to ${customer.mobile}`);
    }
  };
  
  const totals = calculateTotals();
  
  return (
    <div className="pos-container">
      <ToastContainer position="top-right" autoClose={3000} />
      
      {/* Header Section */}
      <div className="pos-header">
        <div className="header-left">
          <div className="bill-info">
            <div className="info-group">
              <label>Series</label>
              <select 
                value={billSeries} 
                onChange={(e) => setBillSeries(e.target.value)}
                className="input-small"
              >
                {billSeriesList.map(series => (
                  <option key={series.id} value={series.prefix}>
                    {series.prefix}
                  </option>
                ))}
              </select>
            </div>
            <div className="info-group">
              <label>Date</label>
              <input 
                type="date" 
                value={billDate} 
                onChange={(e) => setBillDate(e.target.value)}
                className="input-medium"
              />
            </div>
            <div className="info-group">
              <label>Bill No</label>
              <input 
                type="text" 
                value={billNo} 
                readOnly={!isEditMode}
                className="input-large"
              />
            </div>
            <div className="info-group">
              <label>Tax Region</label>
              <select 
                value={taxRegion} 
                onChange={(e) => setTaxRegion(e.target.value)}
                className="input-medium"
              >
                <option>CGST/SGST</option>
                <option>IGST</option>
              </select>
            </div>
            <div className="info-group">
              <label>Agent/Broker</label>
              <input 
                type="text" 
                value={agent} 
                onChange={(e) => setAgent(e.target.value)}
                placeholder="Optional"
                className="input-medium"
              />
            </div>
          </div>
        </div>
      </div>
      
      {/* Main Content */}
      <div className="pos-main">
        {/* Left Panel - Items Grid */}
        <div className="pos-left-panel">
          {/* Barcode Scanner */}
          <div className="barcode-section">
            <form onSubmit={handleBarcodeSubmit} className="barcode-form">
              <input
                ref={barcodeInputRef}
                type="text"
                value={currentBarcode}
                onChange={(e) => setCurrentBarcode(e.target.value)}
                placeholder="Scan or enter barcode..."
                className="barcode-input"
              />
              <div className="qty-control">
                <label>Default QTY:</label>
                <input
                  type="number"
                  value={defaultQty}
                  onChange={(e) => setDefaultQty(parseInt(e.target.value) || 1)}
                  min="1"
                  className="qty-input"
                />
              </div>
            </form>
          </div>
          
          {/* Items Grid */}
          <div className="items-grid-container">
            <table className="items-grid">
              <thead>
                <tr>
                  <th>Barcode</th>
                  <th>Style Code</th>
                  <th>Color</th>
                  <th>Size</th>
                  <th>QTY</th>
                  <th>MRP</th>
                  <th>DISC%</th>
                  <th>Amount</th>
                  <th>{taxRegion === 'CGST/SGST' ? 'CGST%' : 'IGST%'}</th>
                  {taxRegion === 'CGST/SGST' && <th>SGST%</th>}
                  <th>HSN</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {cartItems.map((item, index) => (
                  <tr key={index}>
                    <td>{item.barcode}</td>
                    <td>{item.styleCode}</td>
                    <td>{item.color}</td>
                    <td>{item.size}</td>
                    <td>
                      <input
                        type="number"
                        value={item.qty}
                        onChange={(e) => updateItemQty(index, parseInt(e.target.value) || 0)}
                        min="1"
                        max={item.stockQty}
                        className="grid-input"
                      />
                    </td>
                    <td>₹{item.mrp}</td>
                    <td>
                      <input
                        type="number"
                        value={item.discount}
                        onChange={(e) => updateItemDiscount(index, parseFloat(e.target.value) || 0)}
                        min="0"
                        max="100"
                        className="grid-input"
                      />
                    </td>
                    <td>₹{item.amount.toFixed(2)}</td>
                    <td>{taxRegion === 'CGST/SGST' ? item.cgst : item.igst}</td>
                    {taxRegion === 'CGST/SGST' && <td>{item.sgst}</td>}
                    <td>{item.hsn}</td>
                    <td>
                      <button 
                        onClick={() => removeItem(index)}
                        className="remove-btn"
                      >
                        ×
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            
            {cartItems.length === 0 && (
              <div className="empty-grid">
                <p>No items in cart</p>
                <small>Scan barcode to add items</small>
              </div>
            )}
          </div>
          
          {/* Totals */}
          <div className="totals-section">
            <div className="totals-grid">
              <div className="total-item">
                <span>Gross Amt:</span>
                <span>₹{totals.grossAmount.toFixed(2)}</span>
              </div>
              <div className="total-item">
                <span>Disc Amt:</span>
                <span>₹{totals.discountAmount.toFixed(2)}</span>
              </div>
              <div className="total-item">
                <span>Tax Amt (Info):</span>
                <span>₹{totals.taxAmount.toFixed(2)}</span>
              </div>
              <div className="total-item">
                <span>Net Amt (Incl. GST):</span>
                <span>₹{totals.netAmount.toFixed(2)}</span>
              </div>
              {appliedCoupon && (
                <div className="total-item">
                  <span>Coupon ({appliedCoupon.code}):</span>
                  <span>-₹{totals.couponAmount.toFixed(2)}</span>
                </div>
              )}
              {redeemPoints > 0 && (
                <div className="total-item">
                  <span>Redeem Points:</span>
                  <span>-₹{totals.redeemValue.toFixed(2)}</span>
                </div>
              )}
              {returnCredit && (
                <div className="total-item">
                  <span>Return Credit:</span>
                  <span>-₹{totals.returnCreditAmount.toFixed(2)}</span>
                </div>
              )}
              <div className="total-item payable">
                <span>Payable:</span>
                <span>₹{totals.payable.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>
        
        {/* Right Panel - Customer */}
        <div className="pos-right-panel">
          <div className="customer-panel">
            <h3>Customer Details</h3>
            
            <div className="customer-search">
              <input
                id="customer-mobile"
                type="text"
                value={customerMobile}
                onChange={(e) => setCustomerMobile(e.target.value)}
                placeholder="Mobile (10 digits)"
                maxLength="10"
                className="mobile-input"
              />
              <button onClick={handleCustomerSearch} className="btn-search">
                Search (F3)
              </button>
            </div>
            
            {customer && (
              <div className="customer-info">
                <div className="info-row">
                  <strong>Name:</strong> {customer.name}
                </div>
                <div className="info-row">
                  <strong>Email:</strong> {customer.email}
                </div>
                <div className="info-row">
                  <strong>DOB:</strong> {customer.dob}
                </div>
                {customer.kids && customer.kids.length > 0 && (
                  <div className="info-row">
                    <strong>Kids:</strong>
                    {customer.kids.map((kid, i) => (
                      <div key={i} className="kid-info">
                        {kid.name} ({kid.dob})
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
            
            <div className="customer-stats">
              <div className="stat">
                <label>Total Sale</label>
                <span>₹{customerStats.totalSale.toLocaleString()}</span>
              </div>
              <div className="stat">
                <label>Loyalty Points</label>
                <span>{customerStats.loyaltyPoints}</span>
              </div>
              <div className="stat">
                <label>Current Grade</label>
                <span className={`grade ${customerStats.currentGrade.toLowerCase()}`}>
                  {customerStats.currentGrade}
                </span>
              </div>
            </div>
            
            <div className="customer-actions">
              <button onClick={handleSaveCustomer} className="btn-action">
                Save
              </button>
              <button onClick={handleNewCustomer} className="btn-action">
                New
              </button>
              <button onClick={() => setShowCouponModal(true)} className="btn-action">
                Coupon
              </button>
              <button onClick={() => setShowHistoryModal(true)} className="btn-action">
                History
              </button>
            </div>
            
            {/* Loyalty Points Section */}
            {customer && customerStats.loyaltyPoints > 0 && (
              <div className="loyalty-section">
                <h4>Points Redemption</h4>
                <div className="points-info">
                  <div className="points-balance">
                    <span>Available Points:</span>
                    <strong>{customerStats.loyaltyPoints}</strong>
                  </div>
                  <div className="points-value">
                    <span>Points Value:</span>
                    <strong>₹{customerStats.loyaltyPoints}</strong>
                  </div>
                </div>
                <div className="redeem-controls">
                  <input
                    type="number"
                    value={redeemPoints}
                    onChange={(e) => setRedeemPoints(Math.min(parseInt(e.target.value) || 0, customerStats.loyaltyPoints))}
                    placeholder="Points to redeem"
                    max={customerStats.loyaltyPoints}
                    className="redeem-input"
                  />
                  <button 
                    onClick={handleSendOTP} 
                    className="btn-redeem"
                    disabled={redeemPoints <= 0}
                  >
                    Redeem
                  </button>
                </div>
                {otpSent && (
                  <div className="otp-section">
                    <input
                      type="text"
                      value={otpValue}
                      onChange={(e) => setOtpValue(e.target.value)}
                      placeholder="Enter OTP"
                      maxLength="6"
                      className="otp-input"
                    />
                    <button onClick={handleVerifyOTP} className="btn-verify">
                      Verify OTP
                    </button>
                  </div>
                )}
              </div>
            )}
            
            {/* Return Credits */}
            {availableReturnCredits.length > 0 && (
              <div className="return-credit-section">
                <h4>Return Credits</h4>
                {availableReturnCredits.map(rc => (
                  <div key={rc.id} className="return-credit-item">
                    <input
                      type="radio"
                      name="returnCredit"
                      checked={returnCredit?.id === rc.id}
                      onChange={() => setReturnCredit(rc)}
                    />
                    <span>{rc.id}</span>
                    <span>₹{rc.amount}</span>
                  </div>
                ))}
              </div>
            )}
            
            {/* Staff Selection */}
            <div className="staff-section">
              <label>Staff</label>
              <div className="staff-select">
                <select 
                  value={selectedStaff} 
                  onChange={(e) => setSelectedStaff(e.target.value)}
                  className="staff-dropdown"
                >
                  <option value="">Select Staff</option>
                  {staffList.map(staff => (
                    <option key={staff.id} value={staff.code}>
                      {staff.name} ({staff.code})
                    </option>
                  ))}
                </select>
                <button 
                  onClick={() => setShowStaffModal(true)}
                  className="btn-staff"
                >
                  F6
                </button>
              </div>
            </div>
            
            {/* Hold Bills */}
            <div className="hold-bills-section">
              <button 
                onClick={() => setShowHoldBills(!showHoldBills)}
                className="btn-hold-toggle"
              >
                Hold Bills ({holdBills.length})
              </button>
              
              {showHoldBills && holdBills.length > 0 && (
                <div className="hold-bills-list">
                  {holdBills.map(bill => (
                    <div key={bill.id} className="hold-bill-item">
                      <div className="hold-info">
                        <span>{new Date(bill.date).toLocaleTimeString()}</span>
                        <span>{bill.customer?.name || 'Walk-in'}</span>
                        <span>₹{bill.totals.payable.toFixed(2)}</span>
                      </div>
                      <button 
                        onClick={() => handleRecallBill(bill)}
                        className="btn-recall"
                      >
                        Recall
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      
      {/* Bottom Action Bar */}
      <div className="pos-footer">
        <button onClick={handleNewBill} className="footer-btn">
          NEW BILL (F2)
        </button>
        <button onClick={handleHoldBill} className="footer-btn">
          HOLD BILL (F1)
        </button>
        <button onClick={() => setShowModifyModal(true)} className="footer-btn">
          MODIFY (F5)
        </button>
        <button onClick={handlePaymentClick} className="footer-btn primary">
          PAYMENT (F4)
        </button>
        <button onClick={() => setShowStaffModal(true)} className="footer-btn">
          STAFF (F6)
        </button>
        <button className="footer-btn" disabled>
          Previous Bill
        </button>
        <button className="footer-btn" disabled>
          Next Bill
        </button>
        <button onClick={() => setShowCouponModal(true)} className="footer-btn">
          COUPON
        </button>
      </div>
      
      {/* Payment Modal */}
      {showPaymentModal && (
        <div className="modal-overlay">
          <div className="modal-large">
            <div className="modal-header">
              <h2>Payment - Bill Total: ₹{totals.payable}</h2>
              <button onClick={() => setShowPaymentModal(false)} className="modal-close">×</button>
            </div>
            
            <div className="modal-body">
              {/* Payment Splits */}
              <div className="payment-section">
                <h3>A) Tender Split</h3>
                {paymentSplits.map((split, index) => (
                  <div key={index} className="payment-split-row">
                    <select 
                      value={split.mode}
                      onChange={(e) => updatePaymentSplit(index, 'mode', e.target.value)}
                      className="payment-mode-select"
                    >
                      <option>CASH</option>
                      <option>CARD</option>
                      <option>UPI</option>
                      <option>BANK_TRANSFER</option>
                    </select>
                    <input
                      type="number"
                      value={split.amount}
                      onChange={(e) => updatePaymentSplit(index, 'amount', parseFloat(e.target.value) || 0)}
                      className="payment-amount-input"
                    />
                    {paymentSplits.length > 1 && (
                      <button onClick={() => removePaymentSplit(index)} className="btn-remove">×</button>
                    )}
                  </div>
                ))}
                <button onClick={addPaymentSplit} className="btn-add-split">+ Add Split</button>
                <div className="payment-remaining">
                  Remaining: ₹{(totals.payable - paymentSplits.reduce((sum, s) => sum + parseFloat(s.amount || 0), 0)).toFixed(2)}
                </div>
              </div>
              
              {/* Loyalty Redemption */}
              {customer && (
                <div className="payment-section">
                  <h3>B) Loyalty Redemption</h3>
                  <div className="loyalty-redeem">
                    <p>Available Points: {customerStats.loyaltyPoints}</p>
                    <div className="redeem-controls">
                      <input
                        type="number"
                        value={redeemPoints}
                        onChange={(e) => setRedeemPoints(Math.min(parseInt(e.target.value) || 0, customerStats.loyaltyPoints))}
                        max={customerStats.loyaltyPoints}
                        placeholder="Points to redeem"
                      />
                      {!otpSent ? (
                        <button onClick={handleSendOTP} className="btn-otp">Send OTP</button>
                      ) : (
                        <div className="otp-verify">
                          <input
                            type="text"
                            value={otpValue}
                            onChange={(e) => setOtpValue(e.target.value)}
                            placeholder="Enter OTP"
                            maxLength="6"
                          />
                          <button onClick={handleVerifyOTP} className="btn-verify">Verify</button>
                        </div>
                      )}
                    </div>
                    <p>Redeem Value: ₹{redeemPoints}</p>
                  </div>
                </div>
              )}
              
              {/* Return Credit */}
              {availableReturnCredits.length > 0 && (
                <div className="payment-section">
                  <h3>C) Return Credit</h3>
                  <div className="return-credits">
                    {availableReturnCredits.map(rc => (
                      <div key={rc.id} className="return-credit-item">
                        <input
                          type="radio"
                          name="returnCredit"
                          checked={returnCredit?.id === rc.id}
                          onChange={() => setReturnCredit(rc)}
                        />
                        <span>{rc.id}</span>
                        <span>{rc.date}</span>
                        <span>₹{rc.amount}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              {/* Coupon */}
              {appliedCoupon && (
                <div className="payment-section">
                  <h3>D) Coupon Amount</h3>
                  <p>Applied: {appliedCoupon.code} - ₹{totals.couponAmount.toFixed(2)}</p>
                </div>
              )}
              
              {/* Points Earned */}
              <div className="payment-section">
                <h3>Points Earned</h3>
                <p>{totals.pointsEarned} points will be added</p>
              </div>
            </div>
            
            <div className="modal-footer">
              <button onClick={() => setShowPaymentModal(false)} className="btn-cancel">Cancel</button>
              <button onClick={handlePrint} className="btn-print">Print</button>
              <button onClick={handleWhatsApp} className="btn-whatsapp">WhatsApp</button>
              <button onClick={handleSaveBill} className="btn-save">Save & Print</button>
            </div>
          </div>
        </div>
      )}
      
      {/* Coupon Modal */}
      {showCouponModal && (
        <div className="modal-overlay">
          <div className="modal-medium">
            <div className="modal-header">
              <h2>Apply Coupon</h2>
              <button onClick={() => setShowCouponModal(false)} className="modal-close">×</button>
            </div>
            <div className="modal-body">
              <input
                type="text"
                value={couponCode}
                onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                placeholder="Enter coupon code"
                className="coupon-input"
              />
              {appliedCoupon && (
                <div className="applied-coupon-info">
                  <p>Applied: {appliedCoupon.code}</p>
                  <p>Discount: {appliedCoupon.type === 'percent' ? `${appliedCoupon.value}%` : `₹${appliedCoupon.value}`}</p>
                  <button onClick={removeCoupon} className="btn-remove-coupon">Remove Coupon</button>
                </div>
              )}
            </div>
            <div className="modal-footer">
              <button onClick={() => setShowCouponModal(false)} className="btn-cancel">Cancel</button>
              <button onClick={handleApplyCoupon} className="btn-apply">Apply</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default POS;