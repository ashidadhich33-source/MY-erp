import React from 'react';
import { FiTruck } from 'react-icons/fi';

function PurchaseReport() {
  return (
    <div className="report-placeholder">
      <div className="placeholder-content">
        <FiTruck size={48} />
        <h2>Purchase Report</h2>
        <p>Purchase report feature coming soon...</p>
      </div>
    </div>
  );
}

export default PurchaseReport;