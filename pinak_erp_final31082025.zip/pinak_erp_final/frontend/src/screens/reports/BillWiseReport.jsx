import React, { useState, useEffect } from 'react';
import { 
  FiFileText, FiDownload, FiPrinter, FiCalendar,
  FiSearch, FiRefreshCw, FiHash, FiEye
} from 'react-icons/fi';
import { format, startOfMonth, endOfMonth, parseISO } from 'date-fns';
import toast from 'react-hot-toast';
import axios from 'axios';
import * as XLSX from 'xlsx';
import './Reports.css';

const API_URL = 'http://localhost:8000/api/v1';

function BillWiseReport() {
  const [loading, setLoading] = useState(false);
  const [billData, setBillData] = useState([]);
  const [selectedBill, setSelectedBill] = useState(null);
  const [showDetails, setShowDetails] = useState(false);
  
  // Filters
  const [dateRange, setDateRange] = useState({
    startDate: format(startOfMonth(new Date()), 'yyyy-MM-dd'),
    endDate: format(endOfMonth(new Date()), 'yyyy-MM-dd')
  });
  const [searchTerm, setSearchTerm] = useState('');

  // Fetch bill data
  const fetchBillData = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const params = new URLSearchParams({
        start_date: dateRange.startDate,
        end_date: dateRange.endDate
      });

      const response = await axios.get(
        `${API_URL}/reports/bill-wise?${params}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );

      setBillData(response.data.bills || []);
      toast.success('Bill data loaded');
    } catch (error) {
      toast.error('Failed to fetch bill data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBillData();
  }, [dateRange]);

  // View bill details
  const viewBillDetails = async (billNo) => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(
        `${API_URL}/sales/bill/${billNo}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setSelectedBill(response.data);
      setShowDetails(true);
    } catch (error) {
      toast.error('Failed to fetch bill details');
    }
  };

  // Filter data
  const filteredData = billData.filter(bill => {
    if (!searchTerm) return true;
    const search = searchTerm.toLowerCase();
    return (
      bill.bill_no?.toLowerCase().includes(search) ||
      bill.customer_name?.toLowerCase().includes(search) ||
      bill.customer_mobile?.includes(search)
    );
  });

  // Export to Excel
  const exportToExcel = () => {
    const exportData = filteredData.map(bill => ({
      'Date': format(parseISO(bill.date), 'dd-MM-yyyy HH:mm'),
      'Bill No': bill.bill_no,
      'Customer': bill.customer_name || 'Walk-in',
      'Mobile': bill.customer_mobile || '-',
      'Items': bill.total_items,
      'MRP Total': bill.mrp_total,
      'Discount': bill.discount_amount,
      'GST': bill.gst_amount,
      'Net Amount': bill.net_amount,
      'Payment': bill.payment_mode,
      'Staff': bill.staff_name || '-'
    }));

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Bill Wise Report');
    
    XLSX.writeFile(wb, `Bill_Wise_Report_${format(new Date(), 'yyyyMMdd')}.xlsx`);
    toast.success('Report exported to Excel');
  };

  return (
    <div className="report-container">
      {/* Header */}
      <div className="report-header">
        <div className="header-left">
          <h1 className="report-title">
            <FiHash className="title-icon" />
            Bill Wise Sales Report
          </h1>
          <p className="report-subtitle">Detailed view of all bills</p>
        </div>
        <div className="header-actions">
          <button className="btn-refresh" onClick={fetchBillData} disabled={loading}>
            <FiRefreshCw className={loading ? 'spinning' : ''} />
          </button>
          <button className="btn-export" onClick={exportToExcel}>
            <FiDownload /> Excel
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="filters-section">
        <div className="date-range-container">
          <div className="date-inputs">
            <div className="date-input-group">
              <FiCalendar className="date-icon" />
              <input
                type="date"
                value={dateRange.startDate}
                onChange={(e) => setDateRange({...dateRange, startDate: e.target.value})}
                className="date-input"
              />
            </div>
            <span className="date-separator">to</span>
            <div className="date-input-group">
              <FiCalendar className="date-icon" />
              <input
                type="date"
                value={dateRange.endDate}
                onChange={(e) => setDateRange({...dateRange, endDate: e.target.value})}
                className="date-input"
              />
            </div>
          </div>
        </div>

        <div className="search-box">
          <FiSearch className="search-icon" />
          <input
            type="text"
            placeholder="Search bill no, customer..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="search-input"
          />
        </div>
      </div>

      {/* Table */}
      <div className="table-container">
        <table className="report-table">
          <thead>
            <tr>
              <th>Date & Time</th>
              <th>Bill No</th>
              <th>Customer</th>
              <th>Items</th>
              <th>Amount</th>
              <th>Payment</th>
              <th>Staff</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {filteredData.map((bill, index) => (
              <tr key={index}>
                <td>{format(parseISO(bill.date), 'dd-MM-yyyy HH:mm')}</td>
                <td className="bill-no">{bill.bill_no}</td>
                <td>{bill.customer_name || 'Walk-in'}</td>
                <td className="text-center">{bill.total_items}</td>
                <td className="amount">₹{bill.net_amount.toLocaleString()}</td>
                <td>{bill.payment_mode}</td>
                <td>{bill.staff_name || '-'}</td>
                <td>
                  <button 
                    className="btn-icon"
                    onClick={() => viewBillDetails(bill.bill_no)}
                  >
                    <FiEye />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Bill Details Modal */}
      {showDetails && selectedBill && (
        <div className="modal-overlay">
          <div className="modal-content modal-lg">
            <div className="modal-header">
              <h2>Bill Details - {selectedBill.bill_no}</h2>
              <button 
                className="btn-close"
                onClick={() => setShowDetails(false)}
              >×</button>
            </div>
            <div className="bill-details">
              <div className="detail-row">
                <span>Date:</span>
                <span>{format(parseISO(selectedBill.date), 'dd-MM-yyyy HH:mm')}</span>
              </div>
              <div className="detail-row">
                <span>Customer:</span>
                <span>{selectedBill.customer_name || 'Walk-in'}</span>
              </div>
              <h3>Items</h3>
              <table className="items-table">
                <thead>
                  <tr>
                    <th>Item</th>
                    <th>Qty</th>
                    <th>Rate</th>
                    <th>Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {selectedBill.items?.map((item, i) => (
                    <tr key={i}>
                      <td>{item.style_code}</td>
                      <td>{item.quantity}</td>
                      <td>₹{item.rate}</td>
                      <td>₹{item.amount}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <div className="bill-summary">
                <div className="summary-row">
                  <span>Total:</span>
                  <span>₹{selectedBill.net_amount}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default BillWiseReport;