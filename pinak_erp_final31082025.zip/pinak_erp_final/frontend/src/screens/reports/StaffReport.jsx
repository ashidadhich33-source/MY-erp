import React, { useState, useEffect } from 'react';
import { 
  FiUserCheck, FiDownload, FiPrinter, FiCalendar,
  FiSearch, FiRefreshCw, FiTrendingUp, FiAward,
  FiDollarSign, FiBarChart2, FiFileText
} from 'react-icons/fi';
import { format, startOfMonth, endOfMonth, parseISO } from 'date-fns';
import toast from 'react-hot-toast';
import axios from 'axios';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import './Reports.css';

const API_URL = 'http://localhost:8000/api/v1';

function StaffReport() {
  const [loading, setLoading] = useState(false);
  const [staffData, setStaffData] = useState([]);
  const [summary, setSummary] = useState({
    totalStaff: 0,
    totalSales: 0,
    totalTransactions: 0,
    totalCommission: 0,
    topPerformer: null,
    averageSale: 0
  });

  // Filters
  const [dateRange, setDateRange] = useState({
    startDate: format(startOfMonth(new Date()), 'yyyy-MM-dd'),
    endDate: format(endOfMonth(new Date()), 'yyyy-MM-dd')
  });
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStaff, setFilterStaff] = useState('all');
  const [staffList, setStaffList] = useState([]);

  // Fetch staff performance data
  const fetchStaffData = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const params = new URLSearchParams({
        start_date: dateRange.startDate,
        end_date: dateRange.endDate
      });

      if (filterStaff !== 'all') {
        params.append('staff_id', filterStaff);
      }

      const response = await axios.get(
        `${API_URL}/reports/staff-wise?${params}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );

      const data = response.data;
      setStaffData(data.staff_performance || []);

      // Extract staff list
      const uniqueStaff = [...new Set(data.staff_performance.map(s => ({
        id: s.staff_id,
        name: s.staff_name
      })))];
      setStaffList(uniqueStaff);

      // Calculate summary
      const totalSales = data.staff_performance.reduce((sum, staff) => sum + (staff.total_sales || 0), 0);
      const totalTransactions = data.staff_performance.reduce((sum, staff) => sum + (staff.total_bills || 0), 0);
      const totalCommission = data.staff_performance.reduce((sum, staff) => sum + (staff.commission_earned || 0), 0);
      
      // Find top performer
      const topPerformer = data.staff_performance.reduce((top, current) => {
        if (!top || current.total_sales > top.total_sales) return current;
        return top;
      }, null);

      setSummary({
        totalStaff: data.staff_performance.length,
        totalSales,
        totalTransactions,
        totalCommission,
        topPerformer,
        averageSale: totalTransactions > 0 ? (totalSales / totalTransactions).toFixed(2) : 0
      });

      toast.success('Staff report loaded');
    } catch (error) {
      toast.error('Failed to fetch staff data');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStaffData();
  }, [dateRange, filterStaff]);

  // Filter data
  const filteredData = staffData.filter(staff => {
    if (!searchTerm) return true;
    const search = searchTerm.toLowerCase();
    return staff.staff_name?.toLowerCase().includes(search);
  });

  // Calculate performance percentage
  const getPerformancePercentage = (sales) => {
    if (summary.totalSales === 0) return 0;
    return ((sales / summary.totalSales) * 100).toFixed(1);
  };

  // Export to Excel
  const exportToExcel = () => {
    const exportData = filteredData.map(staff => ({
      'Staff Name': staff.staff_name,
      'Employee Code': staff.staff_code || '-',
      'Total Bills': staff.total_bills,
      'Items Sold': staff.total_items,
      'Total Sales': staff.total_sales,
      'Average Sale': staff.average_sale,
      'Commission Rate': `${staff.commission_rate || 0}%`,
      'Commission Earned': staff.commission_earned,
      'Target': staff.target || 0,
      'Achievement': `${staff.achievement_percentage || 0}%`
    }));

    // Add summary
    exportData.push({});
    exportData.push({
      'Staff Name': 'TOTAL',
      'Employee Code': `${summary.totalStaff} Staff`,
      'Total Bills': summary.totalTransactions,
      'Items Sold': '',
      'Total Sales': summary.totalSales,
      'Average Sale': summary.averageSale,
      'Commission Rate': '',
      'Commission Earned': summary.totalCommission,
      'Target': '',
      'Achievement': ''
    });

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Staff Report');
    
    XLSX.writeFile(wb, `Staff_Report_${format(new Date(), 'yyyyMMdd')}.xlsx`);
    toast.success('Report exported to Excel');
  };

  return (
    <div className="report-container">
      {/* Header */}
      <div className="report-header">
        <div className="header-left">
          <h1 className="report-title">
            <FiUserCheck className="title-icon" />
            Staff Wise Sales Report
          </h1>
          <p className="report-subtitle">Track staff performance and commissions</p>
        </div>
        <div className="header-actions">
          <button className="btn-refresh" onClick={fetchStaffData} disabled={loading}>
            <FiRefreshCw className={loading ? 'spinning' : ''} />
            {loading ? 'Loading...' : 'Refresh'}
          </button>
          <button className="btn-export" onClick={exportToExcel}>
            <FiDownload /> Excel
          </button>
          <button className="btn-print" onClick={() => window.print()}>
            <FiPrinter /> Print
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="summary-grid">
        <div className="summary-card">
          <div className="summary-icon purple">
            <FiUserCheck />
          </div>
          <div className="summary-content">
            <p className="summary-label">Total Staff</p>
            <p className="summary-value">{summary.totalStaff}</p>
            <p className="summary-change">Active sellers</p>
          </div>
        </div>

        <div className="summary-card">
          <div className="summary-icon green">
            <FiDollarSign />
          </div>
          <div className="summary-content">
            <p className="summary-label">Total Sales</p>
            <p className="summary-value">₹{summary.totalSales.toLocaleString()}</p>
            <p className="summary-change">
              {summary.totalTransactions} transactions
            </p>
          </div>
        </div>

        <div className="summary-card">
          <div className="summary-icon blue">
            <FiBarChart2 />
          </div>
          <div className="summary-content">
            <p className="summary-label">Commissions</p>
            <p className="summary-value">₹{summary.totalCommission.toLocaleString()}</p>
            <p className="summary-change">Total earned</p>
          </div>
        </div>

        <div className="summary-card">
          <div className="summary-icon orange">
            <FiAward />
          </div>
          <div className="summary-content">
            <p className="summary-label">Top Performer</p>
            <p className="summary-value">
              {summary.topPerformer ? summary.topPerformer.staff_name : '-'}
            </p>
            <p className="summary-change">
              {summary.topPerformer ? 
                `₹${summary.topPerformer.total_sales.toLocaleString()}` : '-'}
            </p>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="filters-section">
        <div className="date-range-container">
          <div className="date-inputs">
            <div className="date-input-group">
              <FiCalendar className="date-icon" />
              <input
                type="date"
                value={dateRange.startDate}
                onChange={(e) => setDateRange({...dateRange, startDate: e.target.value})}
                className="date-input"
              />
            </div>
            <span className="date-separator">to</span>
            <div className="date-input-group">
              <FiCalendar className="date-icon" />
              <input
                type="date"
                value={dateRange.endDate}
                onChange={(e) => setDateRange({...dateRange, endDate: e.target.value})}
                className="date-input"
              />
            </div>
          </div>
        </div>

        <div className="filters-row">
          <div className="search-box">
            <FiSearch className="search-icon" />
            <input
              type="text"
              placeholder="Search staff name..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="search-input"
            />
          </div>

          <select 
            value={filterStaff}
            onChange={(e) => setFilterStaff(e.target.value)}
            className="filter-select"
          >
            <option value="all">All Staff</option>
            {staffList.map(staff => (
              <option key={staff.id} value={staff.id}>
                {staff.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Data Table */}
      <div className="table-container">
        <table className="report-table">
          <thead>
            <tr>
              <th>Staff Name</th>
              <th>Code</th>
              <th>Bills</th>
              <th>Items Sold</th>
              <th>Total Sales</th>
              <th>Avg Sale</th>
              <th>Commission %</th>
              <th>Commission</th>
              <th>Target</th>
              <th>Achievement</th>
              <th>Performance</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan="11" className="text-center">
                  <div className="loading-spinner">Loading...</div>
                </td>
              </tr>
            ) : filteredData.length === 0 ? (
              <tr>
                <td colSpan="11" className="text-center empty-state">
                  <FiUserCheck size={48} />
                  <p>No staff data found</p>
                </td>
              </tr>
            ) : (
              filteredData.map((staff, index) => (
                <tr key={index}>
                  <td className="staff-name">{staff.staff_name}</td>
                  <td>{staff.staff_code || '-'}</td>
                  <td className="text-center">{staff.total_bills}</td>
                  <td className="text-center">{staff.total_items}</td>
                  <td className="amount">₹{staff.total_sales.toLocaleString()}</td>
                  <td className="amount">₹{staff.average_sale.toFixed(2)}</td>
                  <td className="text-center">{staff.commission_rate || 0}%</td>
                  <td className="amount">₹{staff.commission_earned.toLocaleString()}</td>
                  <td className="amount">₹{staff.target?.toLocaleString() || '0'}</td>
                  <td className="text-center">
                    <span className={`achievement-badge ${
                      staff.achievement_percentage >= 100 ? 'achieved' : 'pending'
                    }`}>
                      {staff.achievement_percentage || 0}%
                    </span>
                  </td>
                  <td>
                    <div className="performance-bar">
                      <div 
                        className="performance-fill"
                        style={{ width: `${getPerformancePercentage(staff.total_sales)}%` }}
                      />
                      <span className="performance-text">
                        {getPerformancePercentage(staff.total_sales)}%
                      </span>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
          {filteredData.length > 0 && (
            <tfoot>
              <tr className="total-row">
                <td><strong>TOTAL</strong></td>
                <td></td>
                <td className="text-center">
                  <strong>{summary.totalTransactions}</strong>
                </td>
                <td></td>
                <td className="amount">
                  <strong>₹{summary.totalSales.toLocaleString()}</strong>
                </td>
                <td className="amount">
                  <strong>₹{summary.averageSale}</strong>
                </td>
                <td></td>
                <td className="amount">
                  <strong>₹{summary.totalCommission.toLocaleString()}</strong>
                </td>
                <td colSpan="3"></td>
              </tr>
            </tfoot>
          )}
        </table>
      </div>
    </div>
  );
}

export default StaffReport;