import React, { useState, useEffect } from 'react';
import { 
  FiDollarSign, FiDownload, FiPrinter, FiCalendar,
  FiSearch, FiFilter, FiRefreshCw, FiTrendingUp,
  FiPieChart, FiFileText, FiTrendingDown
} from 'react-icons/fi';
import { format, startOfMonth, endOfMonth, parseISO } from 'date-fns';
import toast from 'react-hot-toast';
import axios from 'axios';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import './Reports.css';

const API_URL = 'http://localhost:8000/api/v1';

function ExpensesReport() {
  const [loading, setLoading] = useState(false);
  const [expenseData, setExpenseData] = useState([]);
  const [summary, setSummary] = useState({
    totalExpenses: 0,
    totalCategories: 0,
    averageDaily: 0,
    highestCategory: null,
    monthlyComparison: 0,
    categoryBreakdown: {}
  });

  // Filters
  const [dateRange, setDateRange] = useState({
    startDate: format(startOfMonth(new Date()), 'yyyy-MM-dd'),
    endDate: format(endOfMonth(new Date()), 'yyyy-MM-dd')
  });
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState('all');
  const [filterPaymentMode, setFilterPaymentMode] = useState('all');
  const [categories, setCategories] = useState([]);

  // Fetch expense data
  const fetchExpenseData = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const params = new URLSearchParams({
        start_date: dateRange.startDate,
        end_date: dateRange.endDate
      });

      if (filterCategory !== 'all') {
        params.append('category', filterCategory);
      }
      if (filterPaymentMode !== 'all') {
        params.append('payment_mode', filterPaymentMode);
      }

      const response = await axios.get(
        `${API_URL}/reports/expenses?${params}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );

      const data = response.data;
      setExpenseData(data.expenses || []);

      // Extract categories
      const uniqueCategories = [...new Set(data.expenses.map(e => e.category).filter(Boolean))];
      setCategories(uniqueCategories);

      // Calculate summary
      const totalExpenses = data.expenses.reduce((sum, e) => sum + (e.amount || 0), 0);
      const days = Math.ceil((new Date(dateRange.endDate) - new Date(dateRange.startDate)) / (1000 * 60 * 60 * 24)) + 1;
      
      // Category breakdown
      const categoryBreakdown = {};
      data.expenses.forEach(expense => {
        const cat = expense.category || 'Uncategorized';
        if (!categoryBreakdown[cat]) {
          categoryBreakdown[cat] = { amount: 0, count: 0 };
        }
        categoryBreakdown[cat].amount += expense.amount;
        categoryBreakdown[cat].count += 1;
      });

      // Find highest category
      let highestCategory = null;
      let highestAmount = 0;
      Object.entries(categoryBreakdown).forEach(([cat, data]) => {
        if (data.amount > highestAmount) {
          highestAmount = data.amount;
          highestCategory = { name: cat, amount: data.amount };
        }
      });

      setSummary({
        totalExpenses,
        totalCategories: Object.keys(categoryBreakdown).length,
        averageDaily: days > 0 ? (totalExpenses / days).toFixed(2) : 0,
        highestCategory,
        monthlyComparison: data.monthly_comparison || 0,
        categoryBreakdown
      });

      toast.success('Expense data loaded');
    } catch (error) {
      toast.error('Failed to fetch expense data');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchExpenseData();
  }, [dateRange, filterCategory, filterPaymentMode]);

  // Filter data based on search
  const filteredData = expenseData.filter(expense => {
    if (!searchTerm) return true;
    
    const search = searchTerm.toLowerCase();
    return (
      expense.category?.toLowerCase().includes(search) ||
      expense.description?.toLowerCase().includes(search) ||
      expense.created_by?.toLowerCase().includes(search)
    );
  });

  // Export to Excel
  const exportToExcel = () => {
    const exportData = filteredData.map(expense => ({
      'Date': format(parseISO(expense.date), 'dd-MM-yyyy'),
      'Category': expense.category || 'Uncategorized',
      'Description': expense.description || '-',
      'Amount': expense.amount,
      'Payment Mode': expense.payment_mode,
      'Created By': expense.created_by || '-',
      'Notes': expense.notes || '-'
    }));

    // Add summary
    exportData.push({});
    exportData.push({
      'Date': 'SUMMARY',
      'Category': `Categories: ${summary.totalCategories}`,
      'Description': '',
      'Amount': summary.totalExpenses,
      'Payment Mode': '',
      'Created By': `Avg Daily: ${summary.averageDaily}`,
      'Notes': ''
    });

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Expenses Report');
    
    XLSX.writeFile(wb, `Expenses_Report_${format(new Date(), 'yyyyMMdd')}.xlsx`);
    toast.success('Report exported to Excel');
  };

  // Export to PDF
  const exportToPDF = () => {
    const doc = new jsPDF();
    
    doc.setFontSize(18);
    doc.text('Expenses Report', 14, 20);
    
    doc.setFontSize(10);
    doc.text(`Period: ${format(parseISO(dateRange.startDate), 'dd-MM-yyyy')} to ${format(parseISO(dateRange.endDate), 'dd-MM-yyyy')}`, 14, 30);
    
    // Summary
    doc.setFontSize(12);
    doc.text('Summary:', 14, 40);
    doc.setFontSize(10);
    doc.text(`Total Expenses: ₹${summary.totalExpenses.toLocaleString()}`, 14, 47);
    doc.text(`Categories: ${summary.totalCategories}`, 14, 54);
    doc.text(`Daily Average: ₹${summary.averageDaily}`, 80, 47);
    if (summary.highestCategory) {
      doc.text(`Highest Category: ${summary.highestCategory.name} (₹${summary.highestCategory.amount.toLocaleString()})`, 80, 54);
    }

    // Table
    const tableColumn = ['Date', 'Category', 'Description', 'Amount', 'Mode'];
    const tableRows = filteredData.map(expense => [
      format(parseISO(expense.date), 'dd-MM-yyyy'),
      expense.category || 'Uncategorized',
      expense.description || '-',
      `₹${expense.amount}`,
      expense.payment_mode
    ]);

    doc.autoTable({
      head: [tableColumn],
      body: tableRows,
      startY: 65,
      theme: 'grid',
      styles: { fontSize: 8 },
      headStyles: { fillColor: [147, 51, 234] }
    });

    doc.save(`Expenses_Report_${format(new Date(), 'yyyyMMdd')}.pdf`);
    toast.success('Report exported to PDF');
  };

  // Calculate category percentage
  const getCategoryPercentage = (amount) => {
    if (summary.totalExpenses === 0) return 0;
    return ((amount / summary.totalExpenses) * 100).toFixed(1);
  };

  return (
    <div className="report-container">
      {/* Header */}
      <div className="report-header">
        <div className="header-left">
          <h1 className="report-title">
            <FiDollarSign className="title-icon" />
            Expenses Report
          </h1>
          <p className="report-subtitle">Track and analyze business expenses</p>
        </div>
        <div className="header-actions">
          <button className="btn-refresh" onClick={fetchExpenseData} disabled={loading}>
            <FiRefreshCw className={loading ? 'spinning' : ''} />
            {loading ? 'Loading...' : 'Refresh'}
          </button>
          <button className="btn-export" onClick={exportToExcel}>
            <FiDownload /> Excel
          </button>
          <button className="btn-export" onClick={exportToPDF}>
            <FiFileText /> PDF
          </button>
          <button className="btn-print" onClick={() => window.print()}>
            <FiPrinter /> Print
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="summary-grid">
        <div className="summary-card">
          <div className="summary-icon red">
            <FiTrendingDown />
          </div>
          <div className="summary-content">
            <p className="summary-label">Total Expenses</p>
            <p className="summary-value">₹{summary.totalExpenses.toLocaleString()}</p>
            <p className="summary-change negative">
              {summary.monthlyComparison > 0 ? '+' : ''}{summary.monthlyComparison}% vs last month
            </p>
          </div>
        </div>

        <div className="summary-card">
          <div className="summary-icon blue">
            <FiPieChart />
          </div>
          <div className="summary-content">
            <p className="summary-label">Categories</p>
            <p className="summary-value">{summary.totalCategories}</p>
            <p className="summary-change">
              Active expense heads
            </p>
          </div>
        </div>

        <div className="summary-card">
          <div className="summary-icon purple">
            <FiCalendar />
          </div>
          <div className="summary-content">
            <p className="summary-label">Daily Average</p>
            <p className="summary-value">₹{summary.averageDaily}</p>
            <p className="summary-change">
              Per day expense
            </p>
          </div>
        </div>

        <div className="summary-card">
          <div className="summary-icon orange">
            <FiTrendingUp />
          </div>
          <div className="summary-content">
            <p className="summary-label">Highest Category</p>
            <p className="summary-value">
              {summary.highestCategory ? summary.highestCategory.name : 'N/A'}
            </p>
            <p className="summary-change">
              {summary.highestCategory ? 
                `₹${summary.highestCategory.amount.toLocaleString()}` : '-'}
            </p>
          </div>
        </div>
      </div>

      {/* Category Breakdown */}
      {Object.keys(summary.categoryBreakdown).length > 0 && (
        <div className="category-breakdown">
          <h3>Category Breakdown</h3>
          <div className="breakdown-grid">
            {Object.entries(summary.categoryBreakdown).map(([category, data]) => (
              <div key={category} className="breakdown-card">
                <div className="breakdown-header">
                  <span className="breakdown-category">{category}</span>
                  <span className="breakdown-percentage">
                    {getCategoryPercentage(data.amount)}%
                  </span>
                </div>
                <div className="breakdown-amount">
                  ₹{data.amount.toLocaleString()}
                </div>
                <div className="breakdown-count">
                  {data.count} transactions
                </div>
                <div className="breakdown-bar">
                  <div 
                    className="bar-fill"
                    style={{ width: `${getCategoryPercentage(data.amount)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Filters Section */}
      <div className="filters-section">
        <div className="date-range-container">
          <div className="date-inputs">
            <div className="date-input-group">
              <FiCalendar className="date-icon" />
              <input
                type="date"
                value={dateRange.startDate}
                onChange={(e) => setDateRange({...dateRange, startDate: e.target.value})}
                className="date-input"
              />
            </div>
            <span className="date-separator">to</span>
            <div className="date-input-group">
              <FiCalendar className="date-icon" />
              <input
                type="date"
                value={dateRange.endDate}
                onChange={(e) => setDateRange({...dateRange, endDate: e.target.value})}
                className="date-input"
              />
            </div>
          </div>
        </div>

        <div className="filters-row">
          <div className="search-box">
            <FiSearch className="search-icon" />
            <input
              type="text"
              placeholder="Search by category, description..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="search-input"
            />
          </div>

          <select 
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="filter-select"
          >
            <option value="all">All Categories</option>
            {categories.map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>

          <select 
            value={filterPaymentMode}
            onChange={(e) => setFilterPaymentMode(e.target.value)}
            className="filter-select"
          >
            <option value="all">All Payment Modes</option>
            <option value="cash">Cash</option>
            <option value="bank">Bank</option>
            <option value="card">Card</option>
            <option value="upi">UPI</option>
          </select>
        </div>
      </div>

      {/* Data Table */}
      <div className="table-container">
        <table className="report-table">
          <thead>
            <tr>
              <th>Date</th>
              <th>Category</th>
              <th>Description</th>
              <th>Amount</th>
              <th>Payment Mode</th>
              <th>Created By</th>
              <th>Notes</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan="7" className="text-center">
                  <div className="loading-spinner">Loading...</div>
                </td>
              </tr>
            ) : filteredData.length === 0 ? (
              <tr>
                <td colSpan="7" className="text-center empty-state">
                  <FiDollarSign size={48} />
                  <p>No expenses found for the selected period</p>
                </td>
              </tr>
            ) : (
              filteredData.map((expense, index) => (
                <tr key={index}>
                  <td>{format(parseISO(expense.date), 'dd-MM-yyyy')}</td>
                  <td>
                    <span className="category-badge">
                      {expense.category || 'Uncategorized'}
                    </span>
                  </td>
                  <td>{expense.description || '-'}</td>
                  <td className="amount">₹{expense.amount.toLocaleString()}</td>
                  <td>
                    <span className="payment-mode">
                      {expense.payment_mode}
                    </span>
                  </td>
                  <td>{expense.created_by || '-'}</td>
                  <td className="notes-cell">{expense.notes || '-'}</td>
                </tr>
              ))
            )}
          </tbody>
          {filteredData.length > 0 && (
            <tfoot>
              <tr className="total-row">
                <td colSpan="3"><strong>TOTAL</strong></td>
                <td className="amount">
                  <strong>₹{filteredData.reduce((sum, e) => sum + e.amount, 0).toLocaleString()}</strong>
                </td>
                <td colSpan="3"></td>
              </tr>
            </tfoot>
          )}
        </table>
      </div>
    </div>
  );
}

export default ExpensesReport;