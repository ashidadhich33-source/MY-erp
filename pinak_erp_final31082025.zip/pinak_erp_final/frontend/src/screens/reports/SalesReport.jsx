import React, { useState, useEffect } from 'react';
import { 
  FiTrendingUp, FiCalendar, FiDownload, FiFilter, 
  FiPrinter, FiSearch, FiBarChart2, FiRefreshCw 
} from 'react-icons/fi';
import toast from 'react-hot-toast';
import { reportsAPI, setupAPI, formatCurrency, formatDate, downloadFile } from '../../services/api';
import { FiDollarSign } from 'react-icons/fi';

function SalesReport() {
  const [loading, setLoading] = useState(false);
  const [reportData, setReportData] = useState([]);
  const [summary, setSummary] = useState({
    total_sales: 0,
    total_returns: 0,
    net_sales: 0,
    total_cash: 0,
    total_card: 0,
    total_other: 0,
    total_items: 0,
    total_bills: 0,
    average_bill_value: 0
  });

  // Filters
  const [filters, setFilters] = useState({
    from_date: new Date(new Date().setDate(1)).toISOString().split('T')[0], // First day of month
    to_date: new Date().toISOString().split('T')[0], // Today
    brand_filter: '',
    staff_filter: '',
    series_filter: '',
    item_filter: ''
  });

  const [brands, setBrands] = useState([]);
  const [staff, setStaff] = useState([]);
  const [billSeries, setBillSeries] = useState([]);

  useEffect(() => {
    fetchInitialData();
    generateReport();
  }, []);

  const fetchInitialData = async () => {
    try {
      // Fetch brands (would come from items unique brands)
      setBrands(['Nike', 'Adidas', 'Puma', 'Levis', 'Allen Solly']);
      
      // Fetch staff
      const staffResponse = await setupAPI.getStaff();
      setStaff(staffResponse.data || []);
      
      // Fetch bill series
      const seriesResponse = await setupAPI.getBillSeries();
      setBillSeries(seriesResponse.data || []);
    } catch (error) {
      console.error('Error fetching initial data:', error);
    }
  };

  const generateReport = async () => {
    setLoading(true);
    try {
      const response = await reportsAPI.getSaleReturnReport(filters);
      
      if (response.data) {
        setReportData(response.data.data || []);
        setSummary(response.data.summary || {
          total_sales: 0,
          total_returns: 0,
          net_sales: 0,
          total_cash: 0,
          total_card: 0,
          total_other: 0,
          total_items: 0,
          total_bills: 0,
          average_bill_value: 0
        });
      }
      
      toast.success('Report generated successfully');
    } catch (error) {
      console.error('Error generating report:', error);
      toast.error('Failed to generate report');
    } finally {
      setLoading(false);
    }
  };

  const exportToExcel = async () => {
    setLoading(true);
    try {
      const response = await reportsAPI.exportReport('/reports/sale-return-detailed', filters);
      downloadFile(response.data, `sales_report_${filters.from_date}_to_${filters.to_date}.xlsx`);
      toast.success('Report exported successfully');
    } catch (error) {
      toast.error('Failed to export report');
    } finally {
      setLoading(false);
    }
  };

  const printReport = () => {
    window.print();
    toast.success('Sending to printer...');
  };

  // Group data by bill for display
  const groupedData = reportData.reduce((acc, item) => {
    if (!acc[item.bill_no]) {
      acc[item.bill_no] = {
        bill_no: item.bill_no,
        bill_date: item.bill_date,
        staff: item.staff,
        items: [],
        total: 0,
        cash: item.cash || 0,
        card: item.card || 0,
        other: item.other || 0
      };
    }
    acc[item.bill_no].items.push(item);
    acc[item.bill_no].total += item.amount;
    return acc;
  }, {});

  const bills = Object.values(groupedData);

  return (
    <div className="sales-report">
      {/* Report Header */}
      <div className="report-header">
        <h2>
          <FiTrendingUp /> Sales & Return Report
        </h2>
        <div className="report-actions">
          <button onClick={printReport} className="btn btn-secondary">
            <FiPrinter /> Print
          </button>
          <button onClick={exportToExcel} className="btn btn-primary" disabled={loading}>
            <FiDownload /> Export Excel
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="report-filters">
        <div className="filter-row">
          <div className="filter-group">
            <label>From Date</label>
            <input
              type="date"
              value={filters.from_date}
              onChange={(e) => setFilters({...filters, from_date: e.target.value})}
            />
          </div>
          <div className="filter-group">
            <label>To Date</label>
            <input
              type="date"
              value={filters.to_date}
              onChange={(e) => setFilters({...filters, to_date: e.target.value})}
            />
          </div>
          <div className="filter-group">
            <label>Brand</label>
            <select
              value={filters.brand_filter}
              onChange={(e) => setFilters({...filters, brand_filter: e.target.value})}
            >
              <option value="">All Brands</option>
              {brands.map(brand => (
                <option key={brand} value={brand}>{brand}</option>
              ))}
            </select>
          </div>
          <div className="filter-group">
            <label>Staff</label>
            <select
              value={filters.staff_filter}
              onChange={(e) => setFilters({...filters, staff_filter: e.target.value})}
            >
              <option value="">All Staff</option>
              {staff.map(s => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>
          </div>
          <div className="filter-group">
            <label>Bill Series</label>
            <select
              value={filters.series_filter}
              onChange={(e) => setFilters({...filters, series_filter: e.target.value})}
            >
              <option value="">All Series</option>
              {billSeries.map(series => (
                <option key={series.id} value={series.id}>{series.prefix}</option>
              ))}
            </select>
          </div>
          <button onClick={generateReport} className="btn btn-primary" disabled={loading}>
            <FiRefreshCw /> Generate
          </button>
        </div>
        
        <div className="filter-row">
          <div className="search-group">
            <FiSearch />
            <input
              type="text"
              placeholder="Search by style code..."
              value={filters.item_filter}
              onChange={(e) => setFilters({...filters, item_filter: e.target.value})}
            />
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="report-summary-cards">
        <div className="summary-card">
          <label>Total Sales</label>
          <span className="positive">{formatCurrency(summary.total_sales)}</span>
        </div>
        <div className="summary-card">
          <label>Total Returns</label>
          <span className="negative">{formatCurrency(Math.abs(summary.total_returns))}</span>
        </div>
        <div className="summary-card">
          <label>Net Sales</label>
          <span className="primary">{formatCurrency(summary.net_sales)}</span>
        </div>
        <div className="summary-card">
          <label>Total Bills</label>
          <span>{summary.total_bills || bills.length}</span>
        </div>
        <div className="summary-card">
          <label>Total Items</label>
          <span>{summary.total_items || reportData.length}</span>
        </div>
        <div className="summary-card">
          <label>Avg Bill Value</label>
          <span>{formatCurrency(summary.average_bill_value || (summary.net_sales / bills.length) || 0)}</span>
        </div>
      </div>

      {/* Payment Mode Summary */}
      <div className="payment-summary">
        <div className="payment-card">
          <FiDollarSign />
          <div>
            <label>Cash</label>
            <span>{formatCurrency(summary.total_cash)}</span>
          </div>
        </div>
        <div className="payment-card">
          <FiDollarSign />
          <div>
            <label>Card</label>
            <span>{formatCurrency(summary.total_card)}</span>
          </div>
        </div>
        <div className="payment-card">
          <FiDollarSign />
          <div>
            <label>Other</label>
            <span>{formatCurrency(summary.total_other)}</span>
          </div>
        </div>
      </div>

      {/* Report Table */}
      <div className="report-table-container">
        {loading ? (
          <div className="loading-state">Generating report...</div>
        ) : reportData.length > 0 ? (
          <table className="report-table">
            <thead>
              <tr>
                <th>Date</th>
                <th>Bill No</th>
                <th>Staff</th>
                <th>Barcode</th>
                <th>Style Code</th>
                <th>Brand</th>
                <th>Size</th>
                <th>Qty</th>
                <th>MRP</th>
                <th>Disc %</th>
                <th>GST</th>
                <th>Amount</th>
                <th>Cash</th>
                <th>Card</th>
                <th>Other</th>
              </tr>
            </thead>
            <tbody>
              {reportData.map((item, index) => (
                <tr key={index} className={item.qty < 0 ? 'return-row' : ''}>
                  <td>{formatDate(item.bill_date)}</td>
                  <td className="bill-no">{item.bill_no}</td>
                  <td>{item.staff || '-'}</td>
                  <td className="barcode">{item.barcode}</td>
                  <td>{item.style_code}</td>
                  <td>{item.brand || '-'}</td>
                  <td>{item.size || '-'}</td>
                  <td className={item.qty < 0 ? 'negative' : ''}>{item.qty}</td>
                  <td>{formatCurrency(item.mrp)}</td>
                  <td>{item.discount_percent || 0}%</td>
                  <td>{item.cgst + item.sgst + item.igst}%</td>
                  <td className={item.amount < 0 ? 'negative' : 'positive'}>
                    {formatCurrency(item.amount)}
                  </td>
                  <td>{item.sno === 1 ? formatCurrency(item.cash || 0) : '-'}</td>
                  <td>{item.sno === 1 ? formatCurrency(item.card || 0) : '-'}</td>
                  <td>{item.sno === 1 ? formatCurrency(item.other || 0) : '-'}</td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="total-row">
                <td colSpan="7">Total</td>
                <td>{reportData.reduce((sum, item) => sum + item.qty, 0)}</td>
                <td colSpan="3"></td>
                <td className="total-amount">{formatCurrency(summary.net_sales)}</td>
                <td>{formatCurrency(summary.total_cash)}</td>
                <td>{formatCurrency(summary.total_card)}</td>
                <td>{formatCurrency(summary.total_other)}</td>
              </tr>
            </tfoot>
          </table>
        ) : (
          <div className="empty-state">
            <FiBarChart2 size={48} />
            <h3>No data available</h3>
            <p>Adjust filters and generate report</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default SalesReport;