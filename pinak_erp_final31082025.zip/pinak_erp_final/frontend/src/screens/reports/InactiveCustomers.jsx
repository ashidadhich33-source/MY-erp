import React from 'react';
import CustomerReport from './CustomerReport'; // Reuse CustomerReport with inactive filter

function InactiveCustomers() {
  return <CustomerReport filterStatus="inactive" />;
}
export default InactiveCustomers;