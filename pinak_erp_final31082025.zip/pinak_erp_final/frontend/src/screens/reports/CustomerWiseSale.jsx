import React from 'react';
import CustomerReport from './CustomerReport'; // Reuse CustomerReport with sales data

function CustomerWiseSale() {
  return <CustomerReport reportType="sales" />;
}
export default CustomerWiseSale;