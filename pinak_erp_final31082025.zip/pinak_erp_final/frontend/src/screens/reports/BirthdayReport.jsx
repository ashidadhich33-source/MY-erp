import React from 'react';
import CustomerReport from './CustomerReport'; // Reuse CustomerReport with birthday filter

function BirthdayReport() {
  return <CustomerReport reportType="birthdays" />;
}
export default BirthdayReport;