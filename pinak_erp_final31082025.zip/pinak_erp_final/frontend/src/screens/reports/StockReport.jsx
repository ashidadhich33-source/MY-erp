import React, { useState, useEffect } from 'react';
import { 
  FiPackage, FiAlertTriangle, FiTrendingDown, FiDownload,
  FiFilter, FiSearch, FiBarChart, FiRefreshCw 
} from 'react-icons/fi';
import toast from 'react-hot-toast';
import { reportsAPI, itemsAPI, formatCurrency, downloadFile } from '../../services/api';

function StockReport() {
  const [loading, setLoading] = useState(false);
  const [stockData, setStockData] = useState([]);
  const [summary, setSummary] = useState({
    total_items: 0,
    total_quantity: 0,
    total_value: 0,
    out_of_stock: 0,
    low_stock: 0,
    overstocked: 0
  });

  // Filters
  const [filters, setFilters] = useState({
    search: '',
    brand: '',
    category: '',
    stock_status: '',
    min_qty: '',
    max_qty: '',
    sort_by: 'style_code'
  });

  const [brands, setBrands] = useState([]);
  const [categories, setCategories] = useState([]);

  useEffect(() => {
    fetchInitialData();
    generateReport();
  }, []);

  const fetchInitialData = async () => {
    try {
      // Fetch unique brands and categories from items
      setBrands(['Nike', 'Adidas', 'Puma', 'Levis', 'Allen Solly']);
      setCategories(['Shirts', 'T-Shirts', 'Jeans', 'Trousers', 'Dresses']);
    } catch (error) {
      console.error('Error fetching initial data:', error);
    }
  };

  const generateReport = async () => {
    setLoading(true);
    try {
      const response = await reportsAPI.getStockReport(filters);
      
      if (response.data) {
        const items = response.data.items || [];
        setStockData(items);
        
        // Calculate summary
        const summary = items.reduce((acc, item) => {
          acc.total_items++;
          acc.total_quantity += item.qty_on_hand || 0;
          acc.total_value += (item.qty_on_hand || 0) * (item.mrp_incl || 0);
          
          if (item.qty_on_hand === 0) acc.out_of_stock++;
          else if (item.qty_on_hand < 5) acc.low_stock++;
          else if (item.qty_on_hand > 100) acc.overstocked++;
          
          return acc;
        }, {
          total_items: 0,
          total_quantity: 0,
          total_value: 0,
          out_of_stock: 0,
          low_stock: 0,
          overstocked: 0
        });
        
        setSummary(summary);
      }
      
      toast.success('Stock report generated');
    } catch (error) {
      console.error('Error generating report:', error);
      toast.error('Failed to generate report');
    } finally {
      setLoading(false);
    }
  };

  const exportToExcel = async () => {
    setLoading(true);
    try {
      const response = await itemsAPI.exportItems(filters);
      downloadFile(response.data, `stock_report_${Date.now()}.xlsx`);
      toast.success('Report exported successfully');
    } catch (error) {
      toast.error('Failed to export report');
    } finally {
      setLoading(false);
    }
  };

  // Filter stock data
  const filteredData = stockData.filter(item => {
    if (filters.search && !item.style_code.toLowerCase().includes(filters.search.toLowerCase()) &&
        !item.barcode.includes(filters.search)) {
      return false;
    }
    if (filters.brand && item.brand !== filters.brand) return false;
    if (filters.category && item.category !== filters.category) return false;
    if (filters.stock_status) {
      if (filters.stock_status === 'out' && item.qty_on_hand !== 0) return false;
      if (filters.stock_status === 'low' && (item.qty_on_hand === 0 || item.qty_on_hand >= 5)) return false;
      if (filters.stock_status === 'normal' && (item.qty_on_hand < 5 || item.qty_on_hand > 100)) return false;
      if (filters.stock_status === 'over' && item.qty_on_hand <= 100) return false;
    }
    if (filters.min_qty && item.qty_on_hand < parseInt(filters.min_qty)) return false;
    if (filters.max_qty && item.qty_on_hand > parseInt(filters.max_qty)) return false;
    return true;
  });

  // Sort data
  const sortedData = [...filteredData].sort((a, b) => {
    switch (filters.sort_by) {
      case 'style_code':
        return a.style_code.localeCompare(b.style_code);
      case 'qty_asc':
        return a.qty_on_hand - b.qty_on_hand;
      case 'qty_desc':
        return b.qty_on_hand - a.qty_on_hand;
      case 'value_desc':
        return (b.qty_on_hand * b.mrp_incl) - (a.qty_on_hand * a.mrp_incl);
      default:
        return 0;
    }
  });

  return (
    <div className="stock-report">
      {/* Report Header */}
      <div className="report-header">
        <h2>
          <FiPackage /> Stock Report
        </h2>
        <div className="report-actions">
          <button onClick={exportToExcel} className="btn btn-primary" disabled={loading}>
            <FiDownload /> Export Excel
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="stock-summary-cards">
        <div className="summary-card">
          <div className="card-icon blue">
            <FiPackage />
          </div>
          <div className="card-content">
            <label>Total Items</label>
            <span>{summary.total_items}</span>
          </div>
        </div>
        <div className="summary-card">
          <div className="card-icon green">
            <FiBarChart />
          </div>
          <div className="card-content">
            <label>Total Quantity</label>
            <span>{summary.total_quantity}</span>
          </div>
        </div>
        <div className="summary-card">
          <div className="card-icon purple">
            <FiTrendingDown />
          </div>
          <div className="card-content">
            <label>Stock Value</label>
            <span>{formatCurrency(summary.total_value)}</span>
          </div>
        </div>
        <div className="summary-card alert">
          <div className="card-icon red">
            <FiAlertTriangle />
          </div>
          <div className="card-content">
            <label>Out of Stock</label>
            <span className="danger">{summary.out_of_stock}</span>
          </div>
        </div>
        <div className="summary-card">
          <div className="card-icon orange">
            <FiAlertTriangle />
          </div>
          <div className="card-content">
            <label>Low Stock</label>
            <span className="warning">{summary.low_stock}</span>
          </div>
        </div>
        <div className="summary-card">
          <div className="card-icon green">
            <FiPackage />
          </div>
          <div className="card-content">
            <label>Overstocked</label>
            <span>{summary.overstocked}</span>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="report-filters">
        <div className="filter-row">
          <div className="search-group">
            <FiSearch />
            <input
              type="text"
              placeholder="Search by style code or barcode..."
              value={filters.search}
              onChange={(e) => setFilters({...filters, search: e.target.value})}
            />
          </div>
          <select
            value={filters.brand}
            onChange={(e) => setFilters({...filters, brand: e.target.value})}
          >
            <option value="">All Brands</option>
            {brands.map(brand => (
              <option key={brand} value={brand}>{brand}</option>
            ))}
          </select>
          <select
            value={filters.category}
            onChange={(e) => setFilters({...filters, category: e.target.value})}
          >
            <option value="">All Categories</option>
            {categories.map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
          <select
            value={filters.stock_status}
            onChange={(e) => setFilters({...filters, stock_status: e.target.value})}
          >
            <option value="">All Status</option>
            <option value="out">Out of Stock</option>
            <option value="low">Low Stock (&lt; 5)</option>
            <option value="normal">Normal Stock</option>
            <option value="over">Overstocked (&gt; 100)</option>
          </select>
          <select
            value={filters.sort_by}
            onChange={(e) => setFilters({...filters, sort_by: e.target.value})}
          >
            <option value="style_code">Sort by Style Code</option>
            <option value="qty_asc">Quantity (Low to High)</option>
            <option value="qty_desc">Quantity (High to Low)</option>
            <option value="value_desc">Value (High to Low)</option>
          </select>
          <button onClick={generateReport} className="btn btn-primary" disabled={loading}>
            <FiRefreshCw /> Refresh
          </button>
        </div>
      </div>

      {/* Stock Table */}
      <div className="report-table-container">
        {loading ? (
          <div className="loading-state">Loading stock data...</div>
        ) : sortedData.length > 0 ? (
          <table className="report-table">
            <thead>
              <tr>
                <th>Barcode</th>
                <th>Style Code</th>
                <th>Color</th>
                <th>Size</th>
                <th>Brand</th>
                <th>Category</th>
                <th>HSN</th>
                <th>MRP</th>
                <th>Purchase Rate</th>
                <th>Stock Qty</th>
                <th>Stock Value</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {sortedData.map((item, index) => (
                <tr key={index} className={item.qty_on_hand === 0 ? 'out-of-stock' : item.qty_on_hand < 5 ? 'low-stock' : ''}>
                  <td className="barcode">{item.barcode}</td>
                  <td className="style-code">{item.style_code}</td>
                  <td>{item.color || '-'}</td>
                  <td>{item.size || '-'}</td>
                  <td>{item.brand || '-'}</td>
                  <td>{item.category || '-'}</td>
                  <td>{item.hsn || '-'}</td>
                  <td>{formatCurrency(item.mrp_incl)}</td>
                  <td>{item.purchase_rate_basic ? formatCurrency(item.purchase_rate_basic) : '-'}</td>
                  <td className={`qty ${item.qty_on_hand === 0 ? 'danger' : item.qty_on_hand < 5 ? 'warning' : ''}`}>
                    {item.qty_on_hand || 0}
                  </td>
                  <td className="amount">
                    {formatCurrency((item.qty_on_hand || 0) * (item.mrp_incl || 0))}
                  </td>
                  <td>
                    {item.qty_on_hand === 0 ? (
                      <span className="status out">Out of Stock</span>
                    ) : item.qty_on_hand < 5 ? (
                      <span className="status low">Low Stock</span>
                    ) : item.qty_on_hand > 100 ? (
                      <span className="status over">Overstocked</span>
                    ) : (
                      <span className="status normal">In Stock</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="total-row">
                <td colSpan="9">Total</td>
                <td className="total-qty">
                  {sortedData.reduce((sum, item) => sum + (item.qty_on_hand || 0), 0)}
                </td>
                <td className="total-amount">
                  {formatCurrency(sortedData.reduce((sum, item) => 
                    sum + ((item.qty_on_hand || 0) * (item.mrp_incl || 0)), 0
                  ))}
                </td>
                <td></td>
              </tr>
            </tfoot>
          </table>
        ) : (
          <div className="empty-state">
            <FiPackage size={48} />
            <h3>No stock data available</h3>
            <p>Adjust filters or add items to inventory</p>
          </div>
        )}
      </div>

      {/* Low Stock Alert */}
      {summary.low_stock > 0 && (
        <div className="alert-box warning">
          <FiAlertTriangle />
          <span>
            <strong>{summary.low_stock} items</strong> are running low on stock. 
            Consider placing purchase orders soon.
          </span>
        </div>
      )}
    </div>
  );
}

export default StockReport;