import React, { useState, useEffect } from 'react';
import { 
  FiUsers, FiDownload, FiPrinter, FiSearch, 
  FiFilter, FiRefreshCw, FiUser, FiPhone,
  FiMail, FiGift, FiAward, FiMapPin, FiFileText
} from 'react-icons/fi';
import { format } from 'date-fns';
import toast from 'react-hot-toast';
import axios from 'axios';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import './Reports.css';

const API_URL = 'http://localhost:8000/api/v1';

function CustomerReport() {
  const [loading, setLoading] = useState(false);
  const [customerData, setCustomerData] = useState([]);
  const [summary, setSummary] = useState({
    totalCustomers: 0,
    activeCustomers: 0,
    newCustomers: 0,
    totalPoints: 0,
    totalLifetimeValue: 0,
    averagePurchase: 0,
    birthdaysThisMonth: 0,
    loyaltyDistribution: {}
  });

  // Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [filterGrade, setFilterGrade] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all'); // all, active, inactive
  const [sortBy, setSortBy] = useState('name'); // name, mobile, lifetime, points
  const [loyaltyGrades, setLoyaltyGrades] = useState([]);

  // Fetch customer data
  const fetchCustomerData = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      
      // Use POST endpoint with empty filters to get all customers
      const response = await axios.post(
        `${API_URL}/reports/customer-report`,
        {
          // You can add filters here if needed
          loyalty_grade_id: null,
          min_lifetime_purchase: null,
          has_kids: null,
          export_format: null
        },
        { 
          headers: { 
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json'
          } 
        }
      );

      const data = response.data;
      
      // Check if data exists and has the expected structure
      if (data && data.data) {
        const customers = data.data;
        
        // Log first customer to see available fields
        if (customers.length > 0) {
          console.log('Sample customer data:', customers[0]);
          console.log('Available fields:', Object.keys(customers[0]));
        }
        
        setCustomerData(customers);

        // Extract unique loyalty grades
        const grades = [...new Set(customers.map(c => c.loyalty_grade).filter(Boolean))];
        setLoyaltyGrades(grades);

        // Calculate summary
        const activeCustomers = customers.filter(c => c.lifetime_purchase > 0).length;
        const totalPoints = customers.reduce((sum, c) => sum + (c.points_balance || 0), 0);
        const totalLifetime = customers.reduce((sum, c) => sum + (c.lifetime_purchase || 0), 0);
        
        // Calculate birthdays this month - only if birthday field exists
        const currentMonth = new Date().getMonth();
        const birthdaysThisMonth = customers.filter(c => {
          if (!c.birthday) return false;
          try {
            const birthDate = new Date(c.birthday);
            if (isNaN(birthDate.getTime())) return false;
            const birthMonth = birthDate.getMonth();
            return birthMonth === currentMonth;
          } catch (error) {
            return false;
          }
        }).length;

        // Calculate loyalty distribution
        const loyaltyDist = customers.reduce((acc, c) => {
          const grade = c.loyalty_grade || 'None';
          acc[grade] = (acc[grade] || 0) + 1;
          return acc;
        }, {});

        setSummary({
          totalCustomers: customers.length,
          activeCustomers,
          newCustomers: 0, // This would need a date filter
          totalPoints,
          totalLifetimeValue: totalLifetime,
          averagePurchase: activeCustomers > 0 ? (totalLifetime / activeCustomers).toFixed(2) : 0,
          birthdaysThisMonth,
          loyaltyDistribution: loyaltyDist
        });

        toast.success('Customer data loaded');
      } else {
        // If no data, set empty arrays
        setCustomerData([]);
        setSummary({
          totalCustomers: 0,
          activeCustomers: 0,
          newCustomers: 0,
          totalPoints: 0,
          totalLifetimeValue: 0,
          averagePurchase: 0,
          birthdaysThisMonth: 0,
          loyaltyDistribution: {}
        });
      }
    } catch (error) {
      toast.error('Failed to fetch customer data');
      console.error('Error details:', error);
      
      // Set empty data on error
      setCustomerData([]);
      setSummary({
        totalCustomers: 0,
        activeCustomers: 0,
        newCustomers: 0,
        totalPoints: 0,
        totalLifetimeValue: 0,
        averagePurchase: 0,
        birthdaysThisMonth: 0,
        loyaltyDistribution: {}
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCustomerData();
  }, []);

  // Filter and sort data
  const filteredData = customerData
    .filter(customer => {
      // Search filter
      if (searchTerm) {
        const search = searchTerm.toLowerCase();
        if (
          !customer.name?.toLowerCase().includes(search) &&
          !customer.mobile?.includes(search) &&
          !customer.email?.toLowerCase().includes(search) &&
          !customer.city?.toLowerCase().includes(search)
        ) {
          return false;
        }
      }

      // Grade filter
      if (filterGrade !== 'all' && customer.loyalty_grade !== filterGrade) {
        return false;
      }

      // Status filter
      if (filterStatus === 'active' && customer.lifetime_purchase === 0) return false;
      if (filterStatus === 'inactive' && customer.lifetime_purchase > 0) return false;

      return true;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'mobile':
          return a.mobile.localeCompare(b.mobile);
        case 'lifetime':
          return b.lifetime_purchase - a.lifetime_purchase;
        case 'points':
          return b.points_balance - a.points_balance;
        default:
          return a.name.localeCompare(b.name);
      }
    });

  // Get loyalty grade color
  const getGradeColor = (grade) => {
    const colors = {
      'Gold': 'gold',
      'Silver': 'silver',
      'Platinum': 'platinum',
      'Bronze': 'bronze'
    };
    return colors[grade] || 'default';
  };

  // Helper function to safely format dates
  const formatDateSafe = (dateValue) => {
    if (!dateValue) return '-';
    try {
      const date = new Date(dateValue);
      if (isNaN(date.getTime())) return '-';
      return format(date, 'dd-MM-yyyy');
    } catch (error) {
      return '-';
    }
  };

  // Export to Excel - fetch complete data
  const exportToExcel = async () => {
    if (filteredData.length === 0) {
      toast.error('No data to export');
      return;
    }

    try {
      // Get mobile numbers of filtered customers
      const filteredMobiles = filteredData.map(c => c.mobile);
      
      toast.loading('Fetching complete customer data...');
      
      const token = localStorage.getItem('token');
      
      // Fetch complete customer data from setup endpoint with proper limit
      const response = await axios.get(
        `${API_URL}/setup/customers`,
        { 
          params: { skip: 0, limit: 100 },
          headers: { Authorization: `Bearer ${token}` }
        }
      );

      const allCustomers = response.data || [];
      
      // Filter to only include customers that were in the filtered list
      const customersToExport = allCustomers.filter(c => 
        filteredMobiles.includes(c.mobile)
      );

      console.log('Exporting customer data:', customersToExport[0]); // Debug log

      if (customersToExport.length === 0) {
        toast.dismiss();
        toast.error('No customer data found');
        return;
      }

      const exportData = customersToExport.map(customer => ({
        'Mobile': customer.mobile || '',
        'Name': customer.name || '',
        'Email': customer.email || '-',
        'Address': customer.address || '-',
        'City': customer.city || '-',
        'Pincode': customer.pincode || '-',
        'Birthday': customer.birthday || '-',
        'Anniversary': customer.anniversary || '-',
        'Kid 1 Name': customer.kid1_name || '-',
        'Kid 1 DOB': customer.kid1_dob || '-',
        'Kid 2 Name': customer.kid2_name || '-',
        'Kid 2 DOB': customer.kid2_dob || '-',
        'Kid 3 Name': customer.kid3_name || '-',
        'Kid 3 DOB': customer.kid3_dob || '-',
        'Lifetime Purchase (₹)': customer.lifetime_purchase || 0,
        'Points Balance': customer.loyalty_points || customer.points_balance || 0,
        'Loyalty Grade': customer.current_grade || customer.loyalty_grade || 'Regular',
        'Last Visit': customer.last_visit_date || customer.last_visit || '-',
        'Status': customer.active === false ? 'Inactive' : 'Active'
      }));

      const ws = XLSX.utils.json_to_sheet(exportData);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Customer Report');

      // Set column widths
      ws['!cols'] = [
        { wch: 12 }, // Mobile
        { wch: 25 }, // Name
        { wch: 30 }, // Email
        { wch: 40 }, // Address
        { wch: 15 }, // City
        { wch: 8 },  // Pincode
        { wch: 12 }, // Birthday
        { wch: 12 }, // Anniversary
        { wch: 20 }, // Kid 1 Name
        { wch: 12 }, // Kid 1 DOB
        { wch: 20 }, // Kid 2 Name
        { wch: 12 }, // Kid 2 DOB
        { wch: 20 }, // Kid 3 Name
        { wch: 12 }, // Kid 3 DOB
        { wch: 18 }, // Lifetime Purchase
        { wch: 14 }, // Points Balance
        { wch: 14 }, // Loyalty Grade
        { wch: 14 }, // Last Visit
        { wch: 10 }  // Status
      ];

      // Generate filename with current date
      const fileName = `Customer_Report_${format(new Date(), 'yyyy-MM-dd_HHmmss')}.xlsx`;
      
      XLSX.writeFile(wb, fileName);
      
      toast.dismiss();
      toast.success('Customer report exported successfully');
      
    } catch (error) {
      console.error('Export error:', error);
      toast.dismiss();
      
      // If API call fails, use the data we already have
      try {
        const exportData = filteredData.map(customer => ({
          'Mobile': customer.mobile || '',
          'Name': customer.name || '',
          'Email': customer.email || '-',
          'City': customer.city || '-',
          'Lifetime Purchase (₹)': customer.lifetime_purchase || 0,
          'Points Balance': customer.points_balance || 0,
          'Loyalty Grade': customer.loyalty_grade || '-',
          'Last Visit': formatDateSafe(customer.last_visit || customer.last_visit_date),
          'Kids Count': customer.kids || 0
        }));

        const ws = XLSX.utils.json_to_sheet(exportData);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Customer Report');
        
        const fileName = `Customer_Report_${format(new Date(), 'yyyy-MM-dd_HHmmss')}.xlsx`;
        XLSX.writeFile(wb, fileName);
        
        toast.success('Customer report exported (limited fields)');
      } catch (err) {
        toast.error('Failed to export report. Please try again.');
      }
    }
  };

  // Export to Excel with all details - fetch from customers endpoint
  const exportDetailedExcel = async () => {
    if (customerData.length === 0) {
      toast.error('No data to export');
      return;
    }

    try {
      // Show loading
      toast.loading('Fetching complete customer data...');
      
      const token = localStorage.getItem('token');
      
      // Fetch complete customer data from setup endpoint which has all fields
      // Use limit of 100 as per backend restriction
      const response = await axios.get(
        `${API_URL}/setup/customers`,
        { 
          params: { skip: 0, limit: 100 },
          headers: { Authorization: `Bearer ${token}` }
        }
      );

      const allCustomers = response.data || [];
      
      console.log('Full customer data:', allCustomers[0]); // Debug log
      
      if (allCustomers.length === 0) {
        toast.dismiss();
        toast.error('No customer data found');
        return;
      }

      // Export ALL customers with ALL available fields
      const exportData = allCustomers.map((customer, index) => ({
        'S.No': index + 1,
        'Mobile': customer.mobile || '',
        'Name': customer.name || '',
        'Email': customer.email || '-',
        'Address': customer.address || '-',
        'City': customer.city || '-',
        'Pincode': customer.pincode || '-',
        'Birthday': customer.birthday || '-',
        'Anniversary': customer.anniversary || '-',
        'Kid 1 Name': customer.kid1_name || '-',
        'Kid 1 DOB': customer.kid1_dob || '-',
        'Kid 2 Name': customer.kid2_name || '-',
        'Kid 2 DOB': customer.kid2_dob || '-',
        'Kid 3 Name': customer.kid3_name || '-',
        'Kid 3 DOB': customer.kid3_dob || '-',
        'Lifetime Purchase (₹)': customer.lifetime_purchase || 0,
        'Points Balance': customer.loyalty_points || customer.points_balance || 0,
        'Loyalty Grade': customer.current_grade || customer.loyalty_grade || 'Regular',
        'Last Visit': customer.last_visit_date || customer.last_visit || '-',
        'Status': customer.active === false ? 'Inactive' : 'Active',
        'Created Date': customer.created_at || '-'
      }));

      // Create workbook
      const wb = XLSX.utils.book_new();
      
      // Sheet 1: Customer Details
      const wsCustomers = XLSX.utils.json_to_sheet(exportData);
      XLSX.utils.book_append_sheet(wb, wsCustomers, 'Customers');

      // Sheet 2: Summary Statistics
      const totalCustomers = allCustomers.length;
      const activeCustomers = allCustomers.filter(c => c.active !== false).length;
      const totalLifetime = allCustomers.reduce((sum, c) => sum + (c.lifetime_purchase || 0), 0);
      const totalPoints = allCustomers.reduce((sum, c) => sum + (c.loyalty_points || c.points_balance || 0), 0);
      
      const summaryData = [
        { 'Metric': 'Total Customers', 'Value': totalCustomers },
        { 'Metric': 'Active Customers', 'Value': activeCustomers },
        { 'Metric': 'Inactive Customers', 'Value': totalCustomers - activeCustomers },
        { 'Metric': 'Total Lifetime Value', 'Value': `₹${totalLifetime.toLocaleString()}` },
        { 'Metric': 'Average Purchase per Customer', 'Value': activeCustomers > 0 ? `₹${(totalLifetime / activeCustomers).toFixed(2)}` : '₹0' },
        { 'Metric': 'Total Points Issued', 'Value': totalPoints }
      ];
      
      const wsSummary = XLSX.utils.json_to_sheet(summaryData);
      XLSX.utils.book_append_sheet(wb, wsSummary, 'Summary');

      // Set column widths
      wsCustomers['!cols'] = [
        { wch: 6 },  // S.No
        { wch: 12 }, // Mobile
        { wch: 25 }, // Name
        { wch: 30 }, // Email
        { wch: 40 }, // Address
        { wch: 15 }, // City
        { wch: 8 },  // Pincode
        { wch: 12 }, // Birthday
        { wch: 12 }, // Anniversary
        { wch: 20 }, // Kid 1 Name
        { wch: 12 }, // Kid 1 DOB
        { wch: 20 }, // Kid 2 Name
        { wch: 12 }, // Kid 2 DOB
        { wch: 20 }, // Kid 3 Name
        { wch: 12 }, // Kid 3 DOB
        { wch: 18 }, // Lifetime Purchase
        { wch: 14 }, // Points Balance
        { wch: 14 }, // Loyalty Grade
        { wch: 14 }, // Last Visit
        { wch: 10 }, // Status
        { wch: 15 }  // Created Date
      ];

      wsSummary['!cols'] = [
        { wch: 35 }, // Metric
        { wch: 25 }  // Value
      ];

      // Generate filename with timestamp
      const fileName = `Customer_Report_Complete_${format(new Date(), 'yyyy-MM-dd_HHmmss')}.xlsx`;
      
      // Write file
      XLSX.writeFile(wb, fileName);
      
      toast.dismiss();
      toast.success('Complete customer report exported successfully');
      
    } catch (error) {
      console.error('Export error:', error);
      toast.dismiss();
      
      // If the error is because of API failure, try alternative approach
      if (error.response) {
        // Use the data already loaded in the component
        exportFromCurrentData();
      } else {
        toast.error('Failed to export complete report. Please try again.');
      }
    }
  };

  // Fallback export function using current data
  const exportFromCurrentData = () => {
    try {
      const exportData = customerData.map((customer, index) => ({
        'S.No': index + 1,
        'Mobile': customer.mobile || '',
        'Name': customer.name || '',
        'Email': customer.email || '-',
        'City': customer.city || '-',
        'Lifetime Purchase (₹)': customer.lifetime_purchase || 0,
        'Points Balance': customer.points_balance || 0,
        'Loyalty Grade': customer.loyalty_grade || '-',
        'Last Visit': formatDateSafe(customer.last_visit || customer.last_visit_date),
        'Kids Count': customer.kids || 0
      }));

      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.json_to_sheet(exportData);
      XLSX.utils.book_append_sheet(wb, ws, 'Customer Report');
      
      const fileName = `Customer_Report_${format(new Date(), 'yyyy-MM-dd_HHmmss')}.xlsx`;
      XLSX.writeFile(wb, fileName);
      
      toast.success('Customer report exported (limited fields)');
    } catch (err) {
      toast.error('Export failed. Please try again.');
    }
  };
  const exportToPDF = () => {
    if (filteredData.length === 0) {
      toast.error('No data to export');
      return;
    }

    const doc = new jsPDF('l', 'mm', 'a4');
    
    // Title
    doc.setFontSize(18);
    doc.text('Customer Report', 14, 20);
    
    // Date
    doc.setFontSize(10);
    doc.text(`Generated on: ${format(new Date(), 'dd-MM-yyyy HH:mm')}`, 14, 30);
    
    // Summary
    doc.setFontSize(12);
    doc.text('Summary:', 14, 40);
    doc.setFontSize(10);
    doc.text(`Total Customers: ${summary.totalCustomers}`, 14, 47);
    doc.text(`Active Customers: ${summary.activeCustomers}`, 70, 47);
    doc.text(`Total Lifetime Value: ₹${summary.totalLifetimeValue.toLocaleString()}`, 126, 47);
    doc.text(`Total Points: ${summary.totalPoints.toLocaleString()}`, 200, 47);

    // Table
    const tableColumn = ['Mobile', 'Name', 'City', 'Lifetime Purchase', 'Points', 'Grade', 'Last Visit'];
    const tableRows = filteredData.slice(0, 100).map(customer => [
      customer.mobile,
      customer.name,
      customer.city || '-',
      `₹${customer.lifetime_purchase.toLocaleString()}`,
      customer.points_balance,
      customer.loyalty_grade || 'None',
      formatDateSafe(customer.last_visit)
    ]);

    doc.autoTable({
      head: [tableColumn],
      body: tableRows,
      startY: 55,
      theme: 'grid',
      styles: { fontSize: 8 },
      headStyles: { fillColor: [66, 66, 66] }
    });

    doc.save(`Customer_Report_${format(new Date(), 'yyyyMMdd')}.pdf`);
    toast.success('Report exported to PDF');
  };

  // Print report
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="report-container">
      {/* Header */}
      <div className="report-header">
        <div className="header-left">
          <h1 className="report-title">
            <FiUsers className="title-icon" />
            Customer Report
          </h1>
          <p className="report-subtitle">Complete customer database with loyalty insights</p>
        </div>
        <div className="header-actions">
          <button 
            className="btn btn-secondary"
            onClick={fetchCustomerData}
            disabled={loading}
          >
            <FiRefreshCw className={loading ? 'spinning' : ''} /> Refresh
          </button>
          <div className="dropdown-container" style={{ position: 'relative', display: 'inline-block' }}>
            <button 
              className="btn btn-primary"
              onClick={exportToExcel}
              disabled={filteredData.length === 0}
              title="Export filtered data"
            >
              <FiDownload /> Export
            </button>
          </div>
          <button 
            className="btn btn-primary"
            onClick={exportDetailedExcel}
            disabled={customerData.length === 0}
            title="Export all customer data with complete details"
          >
            <FiFileText /> Full Export
          </button>
          <button 
            className="btn btn-primary"
            onClick={exportToPDF}
            disabled={filteredData.length === 0}
          >
            <FiFileText /> PDF
          </button>
          <button 
            className="btn btn-primary"
            onClick={handlePrint}
            disabled={filteredData.length === 0}
          >
            <FiPrinter /> Print
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="summary-cards">
        <div className="summary-card">
          <div className="card-icon blue">
            <FiUsers />
          </div>
          <div className="card-content">
            <span className="card-label">TOTAL CUSTOMERS</span>
            <span className="card-value">{summary.totalCustomers}</span>
            <span className="card-sub">0 new this month</span>
          </div>
        </div>
        <div className="summary-card">
          <div className="card-icon green">
            <FiUser />
          </div>
          <div className="card-content">
            <span className="card-label">ACTIVE CUSTOMERS</span>
            <span className="card-value">{summary.activeCustomers}</span>
            <span className="card-sub">{summary.totalCustomers > 0 ? `${((summary.activeCustomers / summary.totalCustomers) * 100).toFixed(0)}% active` : '0% active'}</span>
          </div>
        </div>
        <div className="summary-card">
          <div className="card-icon purple">
            <FiAward />
          </div>
          <div className="card-content">
            <span className="card-label">TOTAL POINTS</span>
            <span className="card-value">{summary.totalPoints.toLocaleString()}</span>
            <span className="card-sub">Avg: {summary.activeCustomers > 0 ? Math.round(summary.totalPoints / summary.activeCustomers) : 0} pts</span>
          </div>
        </div>
        <div className="summary-card">
          <div className="card-icon orange">
            <FiGift />
          </div>
          <div className="card-content">
            <span className="card-label">BIRTHDAYS</span>
            <span className="card-value">{summary.birthdaysThisMonth}</span>
            <span className="card-sub">This month</span>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="report-filters">
        <div className="filter-group">
          <FiSearch className="filter-icon" />
          <input
            type="text"
            placeholder="Search by name, mobile, email, city..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="filter-input"
          />
        </div>
        
        <select
          value={filterGrade}
          onChange={(e) => setFilterGrade(e.target.value)}
          className="filter-select"
        >
          <option value="all">All Grades</option>
          {loyaltyGrades.map(grade => (
            <option key={grade} value={grade}>{grade}</option>
          ))}
        </select>

        <select
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
          className="filter-select"
        >
          <option value="all">All Customers</option>
          <option value="active">Active Only</option>
          <option value="inactive">Inactive Only</option>
        </select>

        <select
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value)}
          className="filter-select"
        >
          <option value="name">Sort by Name</option>
          <option value="mobile">Sort by Mobile</option>
          <option value="lifetime">Sort by Lifetime Purchase</option>
          <option value="points">Sort by Points</option>
        </select>
      </div>

      {/* Data Table */}
      <div className="report-table-container">
        <table className="report-table">
          <thead>
            <tr>
              <th>MOBILE</th>
              <th>NAME</th>
              <th>EMAIL</th>
              <th>CITY</th>
              <th>KIDS</th>
              <th>LIFETIME PURCHASE</th>
              <th>POINTS</th>
              <th>LOYALTY GRADE</th>
              <th>LAST VISIT</th>
              <th>STATUS</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan="10" className="text-center">
                  <div className="loading-spinner">Loading...</div>
                </td>
              </tr>
            ) : filteredData.length === 0 ? (
              <tr>
                <td colSpan="10" className="text-center empty-state">
                  <FiUsers size={48} />
                  <p>No customers found</p>
                </td>
              </tr>
            ) : (
              filteredData.map((customer, index) => (
                <tr key={index}>
                  <td className="mobile-cell">
                    <FiPhone size={12} /> {customer.mobile}
                  </td>
                  <td className="name-cell">{customer.name}</td>
                  <td>
                    {customer.email ? (
                      <span className="email-cell">
                        <FiMail size={12} /> {customer.email}
                      </span>
                    ) : '-'}
                  </td>
                  <td>
                    {customer.city ? (
                      <span className="city-cell">
                        <FiMapPin size={12} /> {customer.city}
                      </span>
                    ) : '-'}
                  </td>
                  <td>
                    <div className="kids-info">
                      {customer.kids || 0}
                    </div>
                  </td>
                  <td className="amount">₹{customer.lifetime_purchase.toLocaleString()}</td>
                  <td className="points-cell">
                    <span className="points-badge">
                      {customer.points_balance.toLocaleString()}
                    </span>
                  </td>
                  <td>
                    <span className={`grade-badge ${getGradeColor(customer.loyalty_grade)}`}>
                      {customer.loyalty_grade || 'None'}
                    </span>
                  </td>
                  <td>
                    {formatDateSafe(customer.last_visit)}
                  </td>
                  <td>
                    <span className={`status-badge ${customer.lifetime_purchase > 0 ? 'active' : 'inactive'}`}>
                      {customer.lifetime_purchase > 0 ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Footer */}
      {filteredData.length > 0 && (
        <div className="report-footer">
          <span>Showing {filteredData.length} of {customerData.length} customers</span>
          <span>Total Lifetime Value: ₹{summary.totalLifetimeValue.toLocaleString()}</span>
        </div>
      )}
    </div>
  );
}

export default CustomerReport;