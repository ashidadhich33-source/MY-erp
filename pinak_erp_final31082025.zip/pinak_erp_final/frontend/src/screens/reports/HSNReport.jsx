import React, { useState, useEffect } from 'react';
import { 
  FiGrid, FiDownload, FiPrinter, FiCalendar,
  FiSearch, FiRefreshCw, FiPercent, FiFileText,
  FiTrendingUp, FiBarChart
} from 'react-icons/fi';
import { format, startOfMonth, endOfMonth, parseISO } from 'date-fns';
import toast from 'react-hot-toast';
import axios from 'axios';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import './Reports.css';

const API_URL = 'http://localhost:8000/api/v1';

function HSNReport() {
  const [loading, setLoading] = useState(false);
  const [hsnData, setHsnData] = useState([]);
  const [summary, setSummary] = useState({
    totalTaxableValue: 0,
    totalCGST: 0,
    totalSGST: 0,
    totalIGST: 0,
    totalGST: 0,
    uniqueHSNCodes: 0,
    totalQuantity: 0
  });

  // Filters
  const [dateRange, setDateRange] = useState({
    startDate: format(startOfMonth(new Date()), 'yyyy-MM-dd'),
    endDate: format(endOfMonth(new Date()), 'yyyy-MM-dd')
  });
  const [searchTerm, setSearchTerm] = useState('');
  const [filterGSTRate, setFilterGSTRate] = useState('all');

  // Fetch HSN data
  const fetchHSNData = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const params = new URLSearchParams({
        start_date: dateRange.startDate,
        end_date: dateRange.endDate
      });

      const response = await axios.get(
        `${API_URL}/reports/hsn-wise?${params}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );

      const data = response.data;
      setHsnData(data.hsn_details || []);

      // Calculate summary
      const totalTaxableValue = data.hsn_details.reduce((sum, item) => sum + (item.taxable_value || 0), 0);
      const totalCGST = data.hsn_details.reduce((sum, item) => sum + (item.cgst || 0), 0);
      const totalSGST = data.hsn_details.reduce((sum, item) => sum + (item.sgst || 0), 0);
      const totalIGST = data.hsn_details.reduce((sum, item) => sum + (item.igst || 0), 0);
      const totalQuantity = data.hsn_details.reduce((sum, item) => sum + (item.quantity || 0), 0);

      setSummary({
        totalTaxableValue,
        totalCGST,
        totalSGST,
        totalIGST,
        totalGST: totalCGST + totalSGST + totalIGST,
        uniqueHSNCodes: data.hsn_details.length,
        totalQuantity
      });

      toast.success('HSN data loaded');
    } catch (error) {
      toast.error('Failed to fetch HSN data');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHSNData();
  }, [dateRange]);

  // Filter data
  const filteredData = hsnData.filter(item => {
    if (searchTerm && !item.hsn_code?.includes(searchTerm)) return false;
    if (filterGSTRate !== 'all' && item.gst_rate?.toString() !== filterGSTRate) return false;
    return true;
  });

  // Export to Excel
  const exportToExcel = () => {
    const exportData = filteredData.map(item => ({
      'HSN Code': item.hsn_code,
      'Description': item.description || '-',
      'Quantity': item.quantity,
      'Unit': item.unit || 'PCS',
      'Taxable Value': item.taxable_value,
      'GST Rate': `${item.gst_rate}%`,
      'CGST': item.cgst,
      'SGST': item.sgst,
      'IGST': item.igst,
      'Total Tax': item.cgst + item.sgst + item.igst,
      'Total Value': item.total_value
    }));

    // Add summary
    exportData.push({});
    exportData.push({
      'HSN Code': 'TOTAL',
      'Description': `${summary.uniqueHSNCodes} HSN Codes`,
      'Quantity': summary.totalQuantity,
      'Unit': '',
      'Taxable Value': summary.totalTaxableValue,
      'GST Rate': '',
      'CGST': summary.totalCGST,
      'SGST': summary.totalSGST,
      'IGST': summary.totalIGST,
      'Total Tax': summary.totalGST,
      'Total Value': summary.totalTaxableValue + summary.totalGST
    });

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'HSN Report');
    
    XLSX.writeFile(wb, `HSN_Report_${format(new Date(), 'yyyyMMdd')}.xlsx`);
    toast.success('Report exported to Excel');
  };

  // Export to PDF
  const exportToPDF = () => {
    const doc = new jsPDF('l', 'mm', 'a4');
    
    doc.setFontSize(18);
    doc.text('HSN Wise Sales Report', 14, 20);
    
    doc.setFontSize(10);
    doc.text(`Period: ${format(parseISO(dateRange.startDate), 'dd-MM-yyyy')} to ${format(parseISO(dateRange.endDate), 'dd-MM-yyyy')}`, 14, 30);
    
    // Summary
    doc.setFontSize(12);
    doc.text('Tax Summary:', 14, 40);
    doc.setFontSize(10);
    doc.text(`Taxable Value: ₹${summary.totalTaxableValue.toLocaleString()}`, 14, 47);
    doc.text(`Total GST: ₹${summary.totalGST.toLocaleString()}`, 90, 47);
    doc.text(`CGST: ₹${summary.totalCGST.toLocaleString()}`, 14, 54);
    doc.text(`SGST: ₹${summary.totalSGST.toLocaleString()}`, 60, 54);
    doc.text(`IGST: ₹${summary.totalIGST.toLocaleString()}`, 106, 54);

    // Table
    const tableColumn = ['HSN Code', 'Description', 'Qty', 'Taxable Value', 'Rate', 'CGST', 'SGST', 'IGST', 'Total'];
    const tableRows = filteredData.map(item => [
      item.hsn_code,
      item.description || '-',
      item.quantity,
      `₹${item.taxable_value}`,
      `${item.gst_rate}%`,
      `₹${item.cgst}`,
      `₹${item.sgst}`,
      `₹${item.igst}`,
      `₹${item.total_value}`
    ]);

    doc.autoTable({
      head: [tableColumn],
      body: tableRows,
      startY: 62,
      theme: 'grid',
      styles: { fontSize: 8 },
      headStyles: { fillColor: [147, 51, 234] }
    });

    doc.save(`HSN_Report_${format(new Date(), 'yyyyMMdd')}.pdf`);
    toast.success('Report exported to PDF');
  };

  return (
    <div className="report-container">
      {/* Header */}
      <div className="report-header">
        <div className="header-left">
          <h1 className="report-title">
            <FiGrid className="title-icon" />
            HSN Wise Sales Report
          </h1>
          <p className="report-subtitle">GST tax breakdown by HSN codes</p>
        </div>
        <div className="header-actions">
          <button className="btn-refresh" onClick={fetchHSNData} disabled={loading}>
            <FiRefreshCw className={loading ? 'spinning' : ''} />
            {loading ? 'Loading...' : 'Refresh'}
          </button>
          <button className="btn-export" onClick={exportToExcel}>
            <FiDownload /> Excel
          </button>
          <button className="btn-export" onClick={exportToPDF}>
            <FiFileText /> PDF
          </button>
          <button className="btn-print" onClick={() => window.print()}>
            <FiPrinter /> Print
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="summary-grid">
        <div className="summary-card">
          <div className="summary-icon purple">
            <FiGrid />
          </div>
          <div className="summary-content">
            <p className="summary-label">HSN Codes</p>
            <p className="summary-value">{summary.uniqueHSNCodes}</p>
            <p className="summary-change">
              {summary.totalQuantity} items sold
            </p>
          </div>
        </div>

        <div className="summary-card">
          <div className="summary-icon green">
            <FiBarChart />
          </div>
          <div className="summary-content">
            <p className="summary-label">Taxable Value</p>
            <p className="summary-value">₹{summary.totalTaxableValue.toLocaleString()}</p>
            <p className="summary-change">
              Before GST
            </p>
          </div>
        </div>

        <div className="summary-card">
          <div className="summary-icon blue">
            <FiPercent />
          </div>
          <div className="summary-content">
            <p className="summary-label">Total GST</p>
            <p className="summary-value">₹{summary.totalGST.toLocaleString()}</p>
            <p className="summary-change">
              CGST + SGST + IGST
            </p>
          </div>
        </div>

        <div className="summary-card">
          <div className="summary-icon orange">
            <FiTrendingUp />
          </div>
          <div className="summary-content">
            <p className="summary-label">Total Value</p>
            <p className="summary-value">
              ₹{(summary.totalTaxableValue + summary.totalGST).toLocaleString()}
            </p>
            <p className="summary-change">
              Including GST
            </p>
          </div>
        </div>
      </div>

      {/* Filters Section */}
      <div className="filters-section">
        <div className="date-range-container">
          <div className="date-inputs">
            <div className="date-input-group">
              <FiCalendar className="date-icon" />
              <input
                type="date"
                value={dateRange.startDate}
                onChange={(e) => setDateRange({...dateRange, startDate: e.target.value})}
                className="date-input"
              />
            </div>
            <span className="date-separator">to</span>
            <div className="date-input-group">
              <FiCalendar className="date-icon" />
              <input
                type="date"
                value={dateRange.endDate}
                onChange={(e) => setDateRange({...dateRange, endDate: e.target.value})}
                className="date-input"
              />
            </div>
          </div>
        </div>

        <div className="filters-row">
          <div className="search-box">
            <FiSearch className="search-icon" />
            <input
              type="text"
              placeholder="Search HSN code..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="search-input"
            />
          </div>

          <select 
            value={filterGSTRate}
            onChange={(e) => setFilterGSTRate(e.target.value)}
            className="filter-select"
          >
            <option value="all">All GST Rates</option>
            <option value="5">5%</option>
            <option value="12">12%</option>
            <option value="18">18%</option>
            <option value="28">28%</option>
          </select>
        </div>
      </div>

      {/* Data Table */}
      <div className="table-container">
        <table className="report-table">
          <thead>
            <tr>
              <th>HSN Code</th>
              <th>Description</th>
              <th>Quantity</th>
              <th>Unit</th>
              <th>Taxable Value</th>
              <th>GST Rate</th>
              <th>CGST</th>
              <th>SGST</th>
              <th>IGST</th>
              <th>Total Tax</th>
              <th>Total Value</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan="11" className="text-center">
                  <div className="loading-spinner">Loading...</div>
                </td>
              </tr>
            ) : filteredData.length === 0 ? (
              <tr>
                <td colSpan="11" className="text-center empty-state">
                  <FiGrid size={48} />
                  <p>No HSN data found for the selected period</p>
                </td>
              </tr>
            ) : (
              filteredData.map((item, index) => (
                <tr key={index}>
                  <td className="hsn-code">{item.hsn_code}</td>
                  <td>{item.description || '-'}</td>
                  <td className="text-center">{item.quantity}</td>
                  <td className="text-center">{item.unit || 'PCS'}</td>
                  <td className="amount">₹{item.taxable_value.toLocaleString()}</td>
                  <td className="text-center">
                    <span className="gst-rate-badge">{item.gst_rate}%</span>
                  </td>
                  <td className="amount">₹{item.cgst.toLocaleString()}</td>
                  <td className="amount">₹{item.sgst.toLocaleString()}</td>
                  <td className="amount">₹{item.igst.toLocaleString()}</td>
                  <td className="amount">
                    ₹{(item.cgst + item.sgst + item.igst).toLocaleString()}
                  </td>
                  <td className="amount net-amount">
                    ₹{item.total_value.toLocaleString()}
                  </td>
                </tr>
              ))
            )}
          </tbody>
          {filteredData.length > 0 && (
            <tfoot>
              <tr className="total-row">
                <td colSpan="2"><strong>TOTAL</strong></td>
                <td className="text-center"><strong>{summary.totalQuantity}</strong></td>
                <td></td>
                <td className="amount">
                  <strong>₹{summary.totalTaxableValue.toLocaleString()}</strong>
                </td>
                <td></td>
                <td className="amount">
                  <strong>₹{summary.totalCGST.toLocaleString()}</strong>
                </td>
                <td className="amount">
                  <strong>₹{summary.totalSGST.toLocaleString()}</strong>
                </td>
                <td className="amount">
                  <strong>₹{summary.totalIGST.toLocaleString()}</strong>
                </td>
                <td className="amount">
                  <strong>₹{summary.totalGST.toLocaleString()}</strong>
                </td>
                <td className="amount net-amount">
                  <strong>₹{(summary.totalTaxableValue + summary.totalGST).toLocaleString()}</strong>
                </td>
              </tr>
            </tfoot>
          )}
        </table>
      </div>
    </div>
  );
}

export default HSNReport;