import React, { useState, useEffect } from 'react';
import { 
  FiCreditCard, FiDownload, FiPrinter, FiCalendar,
  FiSearch, FiRefreshCw, FiDollarSign, FiPercent,
  FiTrendingUp, FiPieChart, FiFileText
} from 'react-icons/fi';
import { format, startOfMonth, endOfMonth, parseISO } from 'date-fns';
import toast from 'react-hot-toast';
import axios from 'axios';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import './Reports.css';

const API_URL = 'http://localhost:8000/api/v1';

function PaymentModeReport() {
  const [loading, setLoading] = useState(false);
  const [paymentData, setPaymentData] = useState([]);
  const [summary, setSummary] = useState({
    totalAmount: 0,
    totalTransactions: 0,
    cashAmount: 0,
    cardAmount: 0,
    upiAmount: 0,
    otherAmount: 0,
    averageTransaction: 0,
    modeBreakdown: {}
  });

  // Filters
  const [dateRange, setDateRange] = useState({
    startDate: format(startOfMonth(new Date()), 'yyyy-MM-dd'),
    endDate: format(endOfMonth(new Date()), 'yyyy-MM-dd')
  });
  const [filterMode, setFilterMode] = useState('all');
  const [groupBy, setGroupBy] = useState('date'); // date, mode, bill

  // Fetch payment data
  const fetchPaymentData = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const params = new URLSearchParams({
        start_date: dateRange.startDate,
        end_date: dateRange.endDate,
        group_by: groupBy
      });

      if (filterMode !== 'all') {
        params.append('payment_mode', filterMode);
      }

      const response = await axios.get(
        `${API_URL}/reports/payment-modes?${params}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );

      const data = response.data;
      setPaymentData(data.details || []);

      // Calculate summary
      const modeBreakdown = {};
      let totalAmount = 0;
      let totalTransactions = 0;

      data.details.forEach(payment => {
        const mode = payment.payment_mode || 'Other';
        if (!modeBreakdown[mode]) {
          modeBreakdown[mode] = { amount: 0, count: 0 };
        }
        modeBreakdown[mode].amount += payment.amount || 0;
        modeBreakdown[mode].count += 1;
        totalAmount += payment.amount || 0;
        totalTransactions += 1;
      });

      setSummary({
        totalAmount,
        totalTransactions,
        cashAmount: modeBreakdown['Cash']?.amount || 0,
        cardAmount: modeBreakdown['Card']?.amount || 0,
        upiAmount: modeBreakdown['UPI']?.amount || 0,
        otherAmount: modeBreakdown['Other']?.amount || 0,
        averageTransaction: totalTransactions > 0 ? (totalAmount / totalTransactions).toFixed(2) : 0,
        modeBreakdown
      });

      toast.success('Payment data loaded');
    } catch (error) {
      toast.error('Failed to fetch payment data');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPaymentData();
  }, [dateRange, filterMode, groupBy]);

  // Calculate mode percentage
  const getModePercentage = (amount) => {
    if (summary.totalAmount === 0) return 0;
    return ((amount / summary.totalAmount) * 100).toFixed(1);
  };

  // Get mode icon
  const getModeIcon = (mode) => {
    const icons = {
      'Cash': '💵',
      'Card': '💳',
      'UPI': '📱',
      'Bank': '🏦',
      'Wallet': '👛',
      'Other': '💰'
    };
    return icons[mode] || '💰';
  };

  // Export to Excel
  const exportToExcel = () => {
    const exportData = paymentData.map(payment => ({
      'Date': format(parseISO(payment.date), 'dd-MM-yyyy'),
      'Bill No': payment.bill_no || '-',
      'Payment Mode': payment.payment_mode,
      'Amount': payment.amount,
      'Transaction ID': payment.transaction_id || '-',
      'Customer': payment.customer_name || 'Walk-in',
      'Status': payment.status || 'Completed'
    }));

    // Add summary
    exportData.push({});
    exportData.push({
      'Date': 'SUMMARY',
      'Bill No': `Total Transactions: ${summary.totalTransactions}`,
      'Payment Mode': '',
      'Amount': summary.totalAmount,
      'Transaction ID': '',
      'Customer': `Avg Transaction: ${summary.averageTransaction}`,
      'Status': ''
    });

    // Add mode breakdown
    exportData.push({});
    exportData.push({ 'Date': 'PAYMENT MODE BREAKDOWN' });
    Object.entries(summary.modeBreakdown).forEach(([mode, data]) => {
      exportData.push({
        'Date': '',
        'Bill No': mode,
        'Payment Mode': `${data.count} transactions`,
        'Amount': data.amount,
        'Transaction ID': `${getModePercentage(data.amount)}%`,
        'Customer': '',
        'Status': ''
      });
    });

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Payment Mode Report');
    
    XLSX.writeFile(wb, `Payment_Mode_Report_${format(new Date(), 'yyyyMMdd')}.xlsx`);
    toast.success('Report exported to Excel');
  };

  // Export to PDF
  const exportToPDF = () => {
    const doc = new jsPDF();
    
    doc.setFontSize(18);
    doc.text('Payment Mode Report', 14, 20);
    
    doc.setFontSize(10);
    doc.text(`Period: ${format(parseISO(dateRange.startDate), 'dd-MM-yyyy')} to ${format(parseISO(dateRange.endDate), 'dd-MM-yyyy')}`, 14, 30);
    
    // Summary
    doc.setFontSize(12);
    doc.text('Summary:', 14, 40);
    doc.setFontSize(10);
    doc.text(`Total Amount: ₹${summary.totalAmount.toLocaleString()}`, 14, 47);
    doc.text(`Transactions: ${summary.totalTransactions}`, 80, 47);
    doc.text(`Average: ₹${summary.averageTransaction}`, 140, 47);
    
    // Mode breakdown
    doc.text('Payment Mode Breakdown:', 14, 57);
    let yPos = 64;
    Object.entries(summary.modeBreakdown).forEach(([mode, data]) => {
      doc.text(`${mode}: ₹${data.amount.toLocaleString()} (${getModePercentage(data.amount)}%)`, 14, yPos);
      yPos += 7;
    });

    // Table
    const tableColumn = ['Date', 'Bill No', 'Mode', 'Amount', 'Customer'];
    const tableRows = paymentData.slice(0, 50).map(payment => [
      format(parseISO(payment.date), 'dd-MM-yyyy'),
      payment.bill_no || '-',
      payment.payment_mode,
      `₹${payment.amount}`,
      payment.customer_name || 'Walk-in'
    ]);

    doc.autoTable({
      head: [tableColumn],
      body: tableRows,
      startY: yPos + 10,
      theme: 'grid',
      styles: { fontSize: 8 },
      headStyles: { fillColor: [147, 51, 234] }
    });

    doc.save(`Payment_Mode_Report_${format(new Date(), 'yyyyMMdd')}.pdf`);
    toast.success('Report exported to PDF');
  };

  return (
    <div className="report-container">
      {/* Header */}
      <div className="report-header">
        <div className="header-left">
          <h1 className="report-title">
            <FiCreditCard className="title-icon" />
            Payment Mode Report
          </h1>
          <p className="report-subtitle">Analyze payment methods and reconciliation</p>
        </div>
        <div className="header-actions">
          <button className="btn-refresh" onClick={fetchPaymentData} disabled={loading}>
            <FiRefreshCw className={loading ? 'spinning' : ''} />
            {loading ? 'Loading...' : 'Refresh'}
          </button>
          <button className="btn-export" onClick={exportToExcel}>
            <FiDownload /> Excel
          </button>
          <button className="btn-export" onClick={exportToPDF}>
            <FiFileText /> PDF
          </button>
          <button className="btn-print" onClick={() => window.print()}>
            <FiPrinter /> Print
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="summary-grid">
        <div className="summary-card">
          <div className="summary-icon green">
            <FiDollarSign />
          </div>
          <div className="summary-content">
            <p className="summary-label">Total Amount</p>
            <p className="summary-value">₹{summary.totalAmount.toLocaleString()}</p>
            <p className="summary-change">
              {summary.totalTransactions} transactions
            </p>
          </div>
        </div>

        <div className="summary-card">
          <div className="summary-icon blue">
            💵
          </div>
          <div className="summary-content">
            <p className="summary-label">Cash</p>
            <p className="summary-value">₹{summary.cashAmount.toLocaleString()}</p>
            <p className="summary-change">
              {getModePercentage(summary.cashAmount)}% of total
            </p>
          </div>
        </div>

        <div className="summary-card">
          <div className="summary-icon purple">
            💳
          </div>
          <div className="summary-content">
            <p className="summary-label">Card</p>
            <p className="summary-value">₹{summary.cardAmount.toLocaleString()}</p>
            <p className="summary-change">
              {getModePercentage(summary.cardAmount)}% of total
            </p>
          </div>
        </div>

        <div className="summary-card">
          <div className="summary-icon orange">
            📱
          </div>
          <div className="summary-content">
            <p className="summary-label">UPI</p>
            <p className="summary-value">₹{summary.upiAmount.toLocaleString()}</p>
            <p className="summary-change">
              {getModePercentage(summary.upiAmount)}% of total
            </p>
          </div>
        </div>
      </div>

      {/* Payment Mode Distribution */}
      {Object.keys(summary.modeBreakdown).length > 0 && (
        <div className="mode-distribution">
          <h3>Payment Mode Distribution</h3>
          <div className="distribution-chart">
            {Object.entries(summary.modeBreakdown).map(([mode, data]) => (
              <div key={mode} className="mode-item">
                <div className="mode-header">
                  <span className="mode-icon">{getModeIcon(mode)}</span>
                  <span className="mode-name">{mode}</span>
                  <span className="mode-percentage">{getModePercentage(data.amount)}%</span>
                </div>
                <div className="mode-bar">
                  <div 
                    className="bar-fill"
                    style={{ 
                      width: `${getModePercentage(data.amount)}%`,
                      background: `linear-gradient(90deg, #9333ea, #4f46e5)`
                    }}
                  />
                </div>
                <div className="mode-stats">
                  <span>₹{data.amount.toLocaleString()}</span>
                  <span>{data.count} transactions</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Filters Section */}
      <div className="filters-section">
        <div className="date-range-container">
          <div className="date-inputs">
            <div className="date-input-group">
              <FiCalendar className="date-icon" />
              <input
                type="date"
                value={dateRange.startDate}
                onChange={(e) => setDateRange({...dateRange, startDate: e.target.value})}
                className="date-input"
              />
            </div>
            <span className="date-separator">to</span>
            <div className="date-input-group">
              <FiCalendar className="date-icon" />
              <input
                type="date"
                value={dateRange.endDate}
                onChange={(e) => setDateRange({...dateRange, endDate: e.target.value})}
                className="date-input"
              />
            </div>
          </div>
        </div>

        <div className="filters-row">
          <select 
            value={filterMode}
            onChange={(e) => setFilterMode(e.target.value)}
            className="filter-select"
          >
            <option value="all">All Payment Modes</option>
            <option value="cash">Cash Only</option>
            <option value="card">Card Only</option>
            <option value="upi">UPI Only</option>
            <option value="bank">Bank Transfer</option>
            <option value="other">Other</option>
          </select>

          <select 
            value={groupBy}
            onChange={(e) => setGroupBy(e.target.value)}
            className="filter-select"
          >
            <option value="date">Group by Date</option>
            <option value="mode">Group by Mode</option>
            <option value="bill">Group by Bill</option>
          </select>
        </div>
      </div>

      {/* Data Table */}
      <div className="table-container">
        <table className="report-table">
          <thead>
            <tr>
              <th>Date</th>
              <th>Bill No</th>
              <th>Payment Mode</th>
              <th>Amount</th>
              <th>Transaction ID</th>
              <th>Customer</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan="7" className="text-center">
                  <div className="loading-spinner">Loading...</div>
                </td>
              </tr>
            ) : paymentData.length === 0 ? (
              <tr>
                <td colSpan="7" className="text-center empty-state">
                  <FiCreditCard size={48} />
                  <p>No payment data found for the selected period</p>
                </td>
              </tr>
            ) : (
              paymentData.map((payment, index) => (
                <tr key={index}>
                  <td>{format(parseISO(payment.date), 'dd-MM-yyyy')}</td>
                  <td className="bill-no">{payment.bill_no || '-'}</td>
                  <td>
                    <span className="payment-mode-badge">
                      {getModeIcon(payment.payment_mode)} {payment.payment_mode}
                    </span>
                  </td>
                  <td className="amount">₹{payment.amount.toLocaleString()}</td>
                  <td className="transaction-id">{payment.transaction_id || '-'}</td>
                  <td>{payment.customer_name || 'Walk-in'}</td>
                  <td>
                    <span className="status-badge success">
                      {payment.status || 'Completed'}
                    </span>
                  </td>
                </tr>
              ))
            )}
          </tbody>
          {paymentData.length > 0 && (
            <tfoot>
              <tr className="total-row">
                <td colSpan="3"><strong>TOTAL</strong></td>
                <td className="amount">
                  <strong>₹{summary.totalAmount.toLocaleString()}</strong>
                </td>
                <td colSpan="3">
                  <strong>{summary.totalTransactions} transactions</strong>
                </td>
              </tr>
            </tfoot>
          )}
        </table>
      </div>
    </div>
  );
}

export default PaymentModeReport;