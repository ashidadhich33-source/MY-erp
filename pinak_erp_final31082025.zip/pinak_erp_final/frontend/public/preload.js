// preload.js - Electron preload script for secure IPC
const { contextBridge, ipcRenderer } = require('electron');

// Expose protected methods that allow the renderer process to use
// the ipcRenderer without exposing the entire object
contextBridge.exposeInMainWorld('electron', {
  // Printer APIs
  getPrinters: () => ipcRenderer.invoke('get-printers'),
  printReceipt: (data) => ipcRenderer.invoke('print-receipt', data),
  printDocument: (data) => ipcRenderer.invoke('print-document', data),
  
  // File System APIs
  readFile: (path) => ipcRenderer.invoke('read-file', path),
  writeFile: (path, data) => ipcRenderer.invoke('write-file', path, data),
  selectFile: () => ipcRenderer.invoke('select-file'),
  selectFolder: () => ipcRenderer.invoke('select-folder'),
  
  // Barcode Scanner APIs
  onBarcodeScanned: (callback) => {
    ipcRenderer.on('barcode-scanned', (event, data) => callback(data));
  },
  startScanner: () => ipcRenderer.send('start-scanner'),
  stopScanner: () => ipcRenderer.send('stop-scanner'),
  
  // Database Backup APIs
  backupDatabase: () => ipcRenderer.invoke('backup-database'),
  restoreDatabase: (backupPath) => ipcRenderer.invoke('restore-database', backupPath),
  
  // System APIs
  getSystemInfo: () => ipcRenderer.invoke('get-system-info'),
  minimizeWindow: () => ipcRenderer.send('minimize-window'),
  maximizeWindow: () => ipcRenderer.send('maximize-window'),
  closeWindow: () => ipcRenderer.send('close-window'),
  
  // Update APIs
  checkForUpdates: () => ipcRenderer.invoke('check-updates'),
  downloadUpdate: () => ipcRenderer.send('download-update'),
  installUpdate: () => ipcRenderer.send('install-update'),
  
  // Settings APIs
  getSettings: () => ipcRenderer.invoke('get-settings'),
  saveSettings: (settings) => ipcRenderer.invoke('save-settings', settings),
  
  // Network APIs
  isOnline: () => ipcRenderer.invoke('is-online'),
  onNetworkChange: (callback) => {
    ipcRenderer.on('network-change', (event, isOnline) => callback(isOnline));
  }
});

// Window file system API for compatibility
window.fs = {
  readFile: async (filepath, options = {}) => {
    try {
      return await ipcRenderer.invoke('read-file', { filepath, options });
    } catch (error) {
      console.error('Error reading file:', error);
      throw error;
    }
  },
  writeFile: async (filepath, data) => {
    try {
      return await ipcRenderer.invoke('write-file', { filepath, data });
    } catch (error) {
      console.error('Error writing file:', error);
      throw error;
    }
  }
};