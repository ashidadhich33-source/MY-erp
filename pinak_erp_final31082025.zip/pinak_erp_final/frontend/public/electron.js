const { app, BrowserWindow, Menu, ipcMain, dialog } = require('electron');
const path = require('path');
const isDev = require('electron-is-dev');
const { exec } = require('child_process');

let mainWindow;
let backendProcess;

// Start backend server
function startBackend() {
  const backendPath = path.join(__dirname, '../../backend/run.py');
  
  // Start Python backend
  backendProcess = exec(`python ${backendPath}`, (error, stdout, stderr) => {
    if (error) {
      console.error(`Backend error: ${error}`);
      dialog.showErrorBox('Backend Error', 'Failed to start backend server. Please ensure Python is installed.');
      return;
    }
    console.log(`Backend: ${stdout}`);
  });
}

function createWindow() {
  // Create the browser window
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1024,
    minHeight: 768,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    },
    icon: path.join(__dirname, '../build/icon.ico'),
    show: false,
    titleBarStyle: 'default',
    backgroundColor: '#ffffff'
  });

  // Load the app
  mainWindow.loadURL(
    isDev 
      ? 'http://localhost:3000' 
      : `file://${path.join(__dirname, '../build/index.html')}`
  );

  // Show window when ready
  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    if (isDev) {
      mainWindow.webContents.openDevTools();
    }
  });

  // Handle window closed
  mainWindow.on('closed', () => {
    mainWindow = null;
  });

  // Create application menu
  const template = [
    {
      label: 'File',
      submenu: [
        {
          label: 'New Sale',
          accelerator: 'CmdOrCtrl+N',
          click: () => {
            mainWindow.webContents.send('menu-new-sale');
          }
        },
        {
          label: 'Print',
          accelerator: 'CmdOrCtrl+P',
          click: () => {
            mainWindow.webContents.send('menu-print');
          }
        },
        { type: 'separator' },
        {
          label: 'Exit',
          accelerator: 'CmdOrCtrl+Q',
          click: () => {
            app.quit();
          }
        }
      ]
    },
    {
      label: 'Master',
      submenu: [
        {
          label: 'Items',
          click: () => {
            mainWindow.webContents.send('navigate', '/items');
          }
        },
        {
          label: 'Customers',
          click: () => {
            mainWindow.webContents.send('navigate', '/customers');
          }
        },
        {
          label: 'Suppliers',
          click: () => {
            mainWindow.webContents.send('navigate', '/suppliers');
          }
        }
      ]
    },
    {
      label: 'Transactions',
      submenu: [
        {
          label: 'POS / Sale',
          accelerator: 'F2',
          click: () => {
            mainWindow.webContents.send('navigate', '/pos');
          }
        },
        {
          label: 'Sale Return',
          click: () => {
            mainWindow.webContents.send('navigate', '/sale-return');
          }
        },
        { type: 'separator' },
        {
          label: 'Purchase',
          click: () => {
            mainWindow.webContents.send('navigate', '/purchase');
          }
        },
        {
          label: 'Purchase Return',
          click: () => {
            mainWindow.webContents.send('navigate', '/purchase-return');
          }
        }
      ]
    },
    {
      label: 'Reports',
      submenu: [
        {
          label: 'Sale Report',
          click: () => {
            mainWindow.webContents.send('navigate', '/reports/sales');
          }
        },
        {
          label: 'Stock Report',
          click: () => {
            mainWindow.webContents.send('navigate', '/reports/stock');
          }
        },
        {
          label: 'Customer Report',
          click: () => {
            mainWindow.webContents.send('navigate', '/reports/customers');
          }
        }
      ]
    },
    {
      label: 'Help',
      submenu: [
        {
          label: 'About',
          click: () => {
            dialog.showMessageBox(mainWindow, {
              type: 'info',
              title: 'About',
              message: 'ERP System v1.0.0',
              detail: 'Retail POS and Inventory Management System',
              buttons: ['OK']
            });
          }
        }
      ]
    }
  ];

  const menu = Menu.buildFromTemplate(template);
  Menu.setApplicationMenu(menu);
}

// This method will be called when Electron has finished initialization
app.whenReady().then(() => {
  startBackend();
  createWindow();
});

// Quit when all windows are closed
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    if (backendProcess) {
      backendProcess.kill();
    }
    app.quit();
  }
});

app.on('activate', () => {
  if (mainWindow === null) {
    createWindow();
  }
});

// IPC handlers for renderer communication
ipcMain.handle('get-printers', async () => {
  const printers = await mainWindow.webContents.getPrintersAsync();
  return printers;
});

ipcMain.handle('print-receipt', async (event, data) => {
  // Direct printing to thermal printer
  const options = {
    silent: true,
    deviceName: data.printerName || '',
    pageSize: { width: 80000, height: 297000 } // 80mm width
  };
  
  mainWindow.webContents.print(options, (success, errorType) => {
    if (!success) {
      console.error('Print failed:', errorType);
    }
  });
  
  return { success: true };
});

// Handle barcode scanner input
ipcMain.handle('barcode-scanned', async (event, barcode) => {
  // Process barcode
  return { barcode, timestamp: new Date() };
});