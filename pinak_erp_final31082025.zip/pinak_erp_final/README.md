# ERP System - Retail Apparel POS

A comprehensive ERP system for retail apparel with barcode-led POS, purchases, loyalty, coupons, WhatsApp integration, and detailed reporting.

## Features

- **Item Master Management** - Style Code based inventory with barcode tracking
- **POS System** - GST-inclusive pricing, multi-payment modes, loyalty points
- **Purchase Management** - GST-exclusive pricing, supplier management
- **Sales Returns** - Return credit system with no refunds
- **Customer Loyalty** - Points system with automatic grade upgrades
- **Coupons** - Percentage/flat discounts with mobile binding
- **WhatsApp Integration** - OTP verification, invoice sending
- **Comprehensive Reports** - Sales, purchases, HSN-wise, staff-wise reports
- **User Management** - Role-based access control (RBAC)

## System Requirements

- Windows 10/11 (64-bit)
- Python 3.9 or higher
- 4GB RAM minimum (8GB recommended)
- 500MB free disk space

## Quick Start

### 1. Installation

```batch
# Run the installation script
install.bat
```

This will:
- Create virtual environment
- Install all dependencies
- Create necessary directories
- Initialize database
- Create default admin user

### 2. Run Application

```batch
# Start the server
run.bat
```

The application will be available at: `http://127.0.0.1:8000`

### 3. Default Credentials

- **Username:** admin
- **Password:** admin123

**Important:** Change the admin password after first login!

## Project Structure

```
erp-system-windows/
├── backend/
│   ├── app/
│   │   ├── api/          # API endpoints
│   │   ├── core/         # Core utilities
│   │   ├── models/       # Database models
│   │   ├── schemas/      # Pydantic schemas
│   │   ├── services/     # Business logic
│   │   └── main.py       # FastAPI application
│   ├── requirements.txt  # Python dependencies
│   └── run.py           # Application runner
├── database/            # SQLite database
├── logs/               # Application logs
├── uploads/            # File uploads
├── backups/            # Database backups
├── install.bat         # Installation script
├── run.bat            # Run script
└── README.md          # This file
```

## API Documentation

Once the server is running, visit:
- Swagger UI: `http://127.0.0.1:8000/docs`
- ReDoc: `http://127.0.0.1:8000/redoc`

## Core Modules

### 1. Setup Module
- Item Master (Create, Import from Excel)
- Suppliers Management
- Customer Management
- User & Permissions
- Company Setup
- Loyalty Grades
- Coupons
- Bill Series
- Payment Modes

### 2. Purchases Module
- Purchase Bills (GST-exclusive)
- Purchase Returns
- Automatic stock updates

### 3. Sales Module
- POS Screen (GST-inclusive)
- Multi-payment support
- Loyalty points redemption
- Coupon application
- Sales Returns (Credit notes only)

### 4. Reports Module
- Sale & Sale Return Report
- Customer Reports
- Purchase Reports
- HSN-wise Sales
- Staff Performance
- Payment Mode Analysis

## Business Rules

### GST Calculation
- **Sales (Inclusive):** 
  - MRP ≤ ₹999 → 5% GST (2.5% CGST + 2.5% SGST)
  - MRP ≥ ₹1000 → 12% GST (6% CGST + 6% SGST)
- **Purchases (Exclusive):**
  - Basic Rate ≤ ₹999.99 → 5% GST
  - Basic Rate ≥ ₹1000 → 12% GST
  - Local → CGST + SGST
  - Inter-state → IGST

### Key Conventions
- **Barcode is unique** across all items
- **Style Code is displayed everywhere** (no 'Item Name')
- **Sale Returns never refund** - only create Return Credit
- **Two card machine types:** Bank-mapped (banked) and Supplier machine (off-bank)
- **All critical actions have confirm popups**
- **No delete of items** via UI - only update/disable

## Configuration

### Environment Variables (.env)

Create a `.env` file in the backend directory with:

```env
# Security (Change in production!)
SECRET_KEY=your-secret-key-here-minimum-32-chars
ACCESS_TOKEN_EXPIRE_MINUTES=10080

# WhatsApp Configuration
WHATSAPP_ACCESS_TOKEN=your_token_here
WHATSAPP_PHONE_NUMBER_ID=your_phone_id
WHATSAPP_BUSINESS_ACCOUNT_ID=your_account_id

# Database (for PostgreSQL)
# DATABASE_TYPE=postgresql
# DATABASE_URL=postgresql://user:pass@localhost/erp
```

## Development

### Running in Development Mode

```batch
# Activate virtual environment
venv\Scripts\activate

# Run with auto-reload
cd backend
python run.py
```

### Database Migrations

```batch
# Create new migration
alembic revision --autogenerate -m "Description"

# Apply migrations
alembic upgrade head

# Rollback
alembic downgrade -1
```

### Testing

```batch
# Run tests
test.bat

# Or manually
venv\Scripts\activate
cd backend
python -m pytest tests/ -v
```

## Troubleshooting

### Common Issues

1. **Port 8000 already in use**
   - Change port in `.env` file or `backend/app/config.py`
   - Or kill the process using port 8000

2. **Database locked error**
   - Close any open database connections
   - Restart the application

3. **Import Excel fails**
   - Ensure Excel file has required columns: barcode, style_code, mrp_incl
   - Check for duplicate barcodes
   - Verify numeric values are properly formatted

4. **WhatsApp OTP not sending**
   - Configure WhatsApp Cloud API credentials in .env
   - Verify phone number format (10 digits)
   - Check WhatsApp API quota

### Reset Database

```batch
# Delete and recreate database
del database\erp_system.db
cd backend
python -c "from app.database import init_db; init_db()"
```

## API Examples

### Login
```bash
curl -X POST http://127.0.0.1:8000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123"}'
```

### Create Item
```bash
curl -X POST http://127.0.0.1:8000/api/v1/items/ \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "barcode": "123456789",
    "style_code": "SHIRT-001",
    "color": "Blue",
    "size": "M",
    "mrp_incl": 999.00,
    "brand": "TestBrand"
  }'
```

### Search Customer
```bash
curl -X GET "http://127.0.0.1:8000/api/v1/setup/customers/search?mobile=9876543210" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

## Implementation Status

### Phase 1: Core Setup ✅
- Database models
- Authentication & Authorization
- User management
- Basic API structure

### Phase 2: Master Data (Next)
- Item Master CRUD
- Excel Import/Export
- Supplier Management
- Customer Management

### Phase 3: Inventory
- Opening Stock
- Stock Adjustments
- Stock Reports

### Phase 4: Purchases
- Purchase Bills
- Purchase Returns
- GST Calculations

### Phase 5: Sales/POS
- POS Screen
- Payment Processing
- Loyalty Points
- Coupons

### Phase 6: Returns
- Sale Returns
- Return Credits
- Credit Redemption

### Phase 7: WhatsApp
- Cloud API Integration
- OTP Verification
- Invoice Sending

### Phase 8: Reports
- All Reports
- Excel Export
- Dashboard

## Support

For issues or questions:
1. Check the troubleshooting section
2. Review API documentation at `/docs`
3. Check application logs in `logs/app.log`

## License

Proprietary - All rights reserved

## Version History

- **v1.0.0** - Initial release with core functionality

---

**Note:** This is Phase 1 of the implementation. Additional features will be added in subsequent phases.