"""
Database setup and migration script for PIANK ERP
Run this after installation to set up the database
"""

import sqlite3
from pathlib import Path

def create_database():
    """Create a fresh database with all required tables and columns"""
    
    # Create database directory if it doesn't exist
    Path("database").mkdir(exist_ok=True)
    
    # Connect to database
    conn = sqlite3.connect('database/erp_system.db')
    cursor = conn.cursor()
    
    # Create tables with all columns including the ones we added
    queries = [
        # Companies table
        """
        CREATE TABLE IF NOT EXISTS companies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name VARCHAR(200) NOT NULL,
            gstin VARCHAR(20) UNIQUE,
            mobile VARCHAR(15),
            logo_path VARCHAR(500),
            address TEXT,
            active BOOLEAN DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            created_by VARCHAR(100),
            updated_by VARCHAR(100)
        )
        """,
        
        # Users table
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username VARCHAR(50) UNIQUE NOT NULL,
            display_name VARCHAR(100),
            mobile VARCHAR(15),
            email VARCHAR(100),
            password_hash VARCHAR(255) NOT NULL,
            role VARCHAR(50),
            active BOOLEAN DEFAULT 1,
            company_id INTEGER,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            created_by VARCHAR(100),
            updated_by VARCHAR(100),
            FOREIGN KEY (company_id) REFERENCES companies(id)
        )
        """,
        
        # Suppliers table with all columns
        """
        CREATE TABLE IF NOT EXISTS suppliers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name VARCHAR(200) NOT NULL,
            gstin VARCHAR(20),
            email VARCHAR(100),
            phone VARCHAR(15),
            location_type VARCHAR(20) DEFAULT 'local',
            address TEXT,
            city VARCHAR(100),
            state VARCHAR(100),
            pincode VARCHAR(10),
            contact_person VARCHAR(100),
            active BOOLEAN DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            created_by VARCHAR(100),
            updated_by VARCHAR(100)
        )
        """,
        
        # Add more tables as needed...
    ]
    
    # Execute all queries
    for query in queries:
        try:
            cursor.execute(query)
            print(f"Table created/verified")
        except sqlite3.Error as e:
            print(f"Error: {e}")
    
    # Create default admin user (password: admin123)
    cursor.execute("""
        INSERT OR IGNORE INTO users (username, display_name, password_hash, role, active)
        VALUES ('admin', 'Administrator', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY/dg3N5UG/6PlK', 'admin', 1)
    """)
    
    conn.commit()
    conn.close()
    print("Database setup completed!")

if __name__ == "__main__":
    create_database()
