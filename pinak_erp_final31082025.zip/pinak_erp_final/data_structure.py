erp-system-windows/
├── backend/
│   ├── app/
│   │   ├── api/
│   │   │   ├── deps.py
│   │   │   └── endpoints/
│   │   │       ├── auth.py
│   │   │       ├── setup.py
│   │   │       ├── setup_complete.py
│   │   │       ├── items.py
│   │   │       ├── purchases_complete.py
│   │   │       ├── sales_complete.py
│   │   │       ├── sales_return.py
│   │   │       ├── reports_complete.py
│   │   │       └── reports_additional.py
│   │   ├── core/
│   │   │   ├── constants.py
│   │   │   └── security.py
│   │   ├── models/
│   │   │   ├── __init__.py (All 35+ models)
│   │   │   └── base.py
│   │   ├── schemas/
│   │   │   ├── base_schemas.py
│   │   │   ├── setup_schemas.py
│   │   │   ├── purchase_schemas.py
│   │   │   ├── sales_schemas.py
│   │   │   └── reports_schemas.py
│   │   ├── services/
│   │   │   ├── excel_service.py
│   │   │   ├── gst_service.py
│   │   │   ├── loyalty_service.py
│   │   │   ├── pdf_service.py
│   │   │   ├── stock_service.py
│   │   │   ├── user_service.py
│   │   │   └── whatsapp_service.py
│   │   ├── config.py
│   │   ├── database.py
│   │   └── main.py
│   ├── requirements.txt
│   └── run.py    
├── frontend-electron/
│   ├── public/
│   │   ├── electron.js      ✅ Main process
│   │   └── preload.js       ✅ IPC bridge
│   ├── src/
│   │   ├── App.js           ✅ Main app
│   │   ├── App.css          ✅ Global styles
│   │   ├── screens/
│   │   │   ├── Login.jsx    ✅ Login screen
│   │   │   ├── POS.jsx      ✅ Complete POS
│   │   │   └── *.jsx        (Other screens)
│   │   ├── components/
│   │   │   ├── Sidebar.jsx  ✅ Navigation
│   │   │   └── Header.jsx   ✅ Top bar
│   │   └── context/
│   │       └── AuthContext.js ✅ Auth management
│   └── package.json         ✅ All dependencies
├── setup.bat               ✅ One-click setup
├── run-all.bat            ✅ Start everything
├── run-backend.bat        ✅ Start backend
├── run-frontend.bat       ✅ Start frontend
└── build-app.bat          ✅ Create .exe installer
├── .env
├── install.bat
├── run.bat
├── update.bat
├── test.bat
└── README.md
