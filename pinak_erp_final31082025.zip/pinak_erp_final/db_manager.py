"""
Database Manager for PIANK ERP
Handles initial setup and migrations automatically
Save as: backend/app/db_manager.py
"""

import sqlite3
import json
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Tuple

class DatabaseManager:
    def __init__(self, db_path="database/erp_system.db"):
        self.db_path = db_path
        self.migrations_file = "database/migrations.json"
        Path("database").mkdir(exist_ok=True)
        
    def get_current_version(self) -> int:
        """Get current database version"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Check if migrations table exists
            cursor.execute("""
                SELECT name FROM sqlite_master 
                WHERE type='table' AND name='db_migrations'
            """)
            
            if not cursor.fetchone():
                # Create migrations table
                cursor.execute("""
                    CREATE TABLE db_migrations (
                        version INTEGER PRIMARY KEY,
                        applied_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        description TEXT
                    )
                """)
                conn.commit()
                return 0
            
            # Get latest version
            cursor.execute("SELECT MAX(version) FROM db_migrations")
            result = cursor.fetchone()
            conn.close()
            return result[0] if result[0] else 0
            
        except Exception as e:
            print(f"Error getting version: {e}")
            return 0
    
    def get_migrations(self) -> List[Dict]:
        """Get all migrations to apply"""
        migrations = [
            {
                "version": 1,
                "description": "Initial database setup",
                "queries": [
                    """CREATE TABLE IF NOT EXISTS companies (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        name VARCHAR(200) NOT NULL,
                        gstin VARCHAR(20) UNIQUE,
                        mobile VARCHAR(15),
                        logo_path VARCHAR(500),
                        address TEXT,
                        active BOOLEAN DEFAULT 1,
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        created_by VARCHAR(100),
                        updated_by VARCHAR(100)
                    )""",
                    
                    """CREATE TABLE IF NOT EXISTS users (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        username VARCHAR(50) UNIQUE NOT NULL,
                        display_name VARCHAR(100),
                        mobile VARCHAR(15),
                        email VARCHAR(100),
                        password_hash VARCHAR(255) NOT NULL,
                        role VARCHAR(50),
                        active BOOLEAN DEFAULT 1,
                        company_id INTEGER,
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        created_by VARCHAR(100),
                        updated_by VARCHAR(100),
                        FOREIGN KEY (company_id) REFERENCES companies(id)
                    )""",
                    
                    """CREATE TABLE IF NOT EXISTS suppliers (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        name VARCHAR(200) NOT NULL,
                        gstin VARCHAR(20),
                        email VARCHAR(100),
                        phone VARCHAR(15),
                        location_type VARCHAR(20) DEFAULT 'local',
                        address TEXT,
                        active BOOLEAN DEFAULT 1,
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        created_by VARCHAR(100),
                        updated_by VARCHAR(100)
                    )""",
                    
                    # Default admin user (password: admin123)
                    """INSERT OR IGNORE INTO users (username, display_name, password_hash, role, active)
                       VALUES ('admin', 'Administrator', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY/dg3N5UG/6PlK', 'admin', 1)"""
                ]
            },
            {
                "version": 2,
                "description": "Add missing columns to suppliers table",
                "queries": [
                    "ALTER TABLE suppliers ADD COLUMN city VARCHAR(100)",
                    "ALTER TABLE suppliers ADD COLUMN state VARCHAR(100)",
                    "ALTER TABLE suppliers ADD COLUMN pincode VARCHAR(10)",
                    "ALTER TABLE suppliers ADD COLUMN contact_person VARCHAR(100)"
                ]
            },
            {
                "version": 3,
                "description": "Create items and stock tables",
                "queries": [
                    """CREATE TABLE IF NOT EXISTS items (
                        barcode VARCHAR(50) PRIMARY KEY,
                        style_code VARCHAR(100) NOT NULL,
                        color VARCHAR(50),
                        size VARCHAR(20),
                        hsn VARCHAR(20),
                        mrp_incl DECIMAL(10, 2) NOT NULL,
                        purchase_rate_basic DECIMAL(10, 2),
                        brand VARCHAR(100),
                        gender VARCHAR(20),
                        category VARCHAR(100),
                        sub_category VARCHAR(100),
                        status VARCHAR(20) DEFAULT 'active',
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        created_by VARCHAR(100),
                        updated_by VARCHAR(100)
                    )""",
                    
                    """CREATE TABLE IF NOT EXISTS stock (
                        barcode VARCHAR(50) PRIMARY KEY,
                        qty_on_hand DECIMAL(10, 2) DEFAULT 0,
                        last_purchase_rate DECIMAL(10, 2),
                        last_sale_date DATETIME,
                        last_purchase_date DATETIME,
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        created_by VARCHAR(100),
                        updated_by VARCHAR(100),
                        FOREIGN KEY (barcode) REFERENCES items(barcode)
                    )"""
                ]
            },
            {
                "version": 4,
                "description": "Create customers table",
                "queries": [
                    """CREATE TABLE IF NOT EXISTS customers (
                        mobile VARCHAR(10) PRIMARY KEY,
                        name VARCHAR(100) NOT NULL,
                        email VARCHAR(100),
                        kid1_name VARCHAR(100),
                        kid1_dob DATE,
                        kid2_name VARCHAR(100),
                        kid2_dob DATE,
                        kid3_name VARCHAR(100),
                        kid3_dob DATE,
                        address TEXT,
                        city VARCHAR(100),
                        pincode VARCHAR(10),
                        birthday DATE,
                        anniversary DATE,
                        lifetime_purchase DECIMAL(12, 2) DEFAULT 0,
                        points_balance DECIMAL(10, 2) DEFAULT 0,
                        loyalty_grade_id INTEGER,
                        last_visit_date DATETIME,
                        active BOOLEAN DEFAULT 1,
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        created_by VARCHAR(100),
                        updated_by VARCHAR(100)
                    )"""
                ]
            }
            # Add more migrations as needed
        ]
        return migrations
    
    def apply_migration(self, migration: Dict) -> bool:
        """Apply a single migration"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            print(f"Applying migration {migration['version']}: {migration['description']}")
            
            for query in migration['queries']:
                try:
                    cursor.execute(query)
                except sqlite3.OperationalError as e:
                    # Ignore errors for adding columns that already exist
                    if "duplicate column name" in str(e).lower():
                        continue
                    # Ignore "no such column" errors for ALTER TABLE
                    elif "no such table" not in str(e).lower():
                        print(f"  Warning: {e}")
            
            # Record migration
            cursor.execute("""
                INSERT INTO db_migrations (version, description) 
                VALUES (?, ?)
            """, (migration['version'], migration['description']))
            
            conn.commit()
            print(f"  ✓ Migration {migration['version']} applied successfully")
            return True
            
        except Exception as e:
            conn.rollback()
            print(f"  ✗ Error applying migration {migration['version']}: {e}")
            return False
        finally:
            conn.close()
    
    def run_migrations(self):
        """Run all pending migrations"""
        current_version = self.get_current_version()
        migrations = self.get_migrations()
        
        print(f"Current database version: {current_version}")
        
        pending_migrations = [m for m in migrations if m['version'] > current_version]
        
        if not pending_migrations:
            print("Database is up to date!")
            return True
        
        print(f"Found {len(pending_migrations)} pending migrations")
        
        for migration in pending_migrations:
            if not self.apply_migration(migration):
                print("Migration failed! Stopping.")
                return False
        
        print("\nAll migrations completed successfully!")
        return True
    
    def check_and_fix(self):
        """Check database and fix any issues"""
        if not Path(self.db_path).exists():
            print("Database doesn't exist. Creating new database...")
        
        return self.run_migrations()

def main():
    """Main function to run when script is executed"""
    manager = DatabaseManager()
    success = manager.check_and_fix()
    
    if success:
        print("\nDatabase is ready!")
        return 0
    else:
        print("\nDatabase setup failed!")
        return 1

if __name__ == "__main__":
    exit(main())