from decimal import Decimal, ROUND_HALF_UP
from typing import Dict, Tuple
from ..core.constants import GST_RATE_5, GST_RATE_12, GST_THRESHOLD, TaxRegion

class GSTService:
    """Service for GST calculations"""
    
    @staticmethod
    def get_gst_rate(amount: Decimal) -> Decimal:
        """Get GST rate based on amount threshold"""
        if amount <= GST_THRESHOLD:
            return Decimal(str(GST_RATE_5))
        return Decimal(str(GST_RATE_12))
    
    @staticmethod
    def calculate_gst_exclusive(basic_rate: Decimal, qty: int, tax_region: str) -> Dict:
        """
        Calculate GST for exclusive pricing (Purchases)
        Returns: Dict with taxable, cgst, sgst/igst, total
        """
        basic_rate = Decimal(str(basic_rate))
        gst_rate = GSTService.get_gst_rate(basic_rate)
        
        line_taxable = basic_rate * qty
        tax_amount = line_taxable * gst_rate
        line_total = line_taxable + tax_amount
        
        result = {
            'line_taxable': line_taxable.quantize(Decimal('0.01'), ROUND_HALF_UP),
            'gst_rate': gst_rate * 100,
            'tax_amount': tax_amount.quantize(Decimal('0.01'), ROUND_HALF_UP),
            'line_total': line_total.quantize(Decimal('0.01'), ROUND_HALF_UP)
        }
        
        if tax_region == TaxRegion.LOCAL:
            result['cgst_rate'] = (gst_rate * 100) / 2
            result['sgst_rate'] = (gst_rate * 100) / 2
            result['cgst_amount'] = (tax_amount / 2).quantize(Decimal('0.01'), ROUND_HALF_UP)
            result['sgst_amount'] = (tax_amount / 2).quantize(Decimal('0.01'), ROUND_HALF_UP)
            result['igst_rate'] = Decimal('0')
            result['igst_amount'] = Decimal('0')
        else:
            result['cgst_rate'] = Decimal('0')
            result['sgst_rate'] = Decimal('0')
            result['cgst_amount'] = Decimal('0')
            result['sgst_amount'] = Decimal('0')
            result['igst_rate'] = gst_rate * 100
            result['igst_amount'] = tax_amount.quantize(Decimal('0.01'), ROUND_HALF_UP)
        
        return result
    
    @staticmethod
    def extract_gst_from_inclusive(mrp_incl: Decimal, qty: int, discount_pct: Decimal = Decimal('0'), 
                                   tax_region: str = TaxRegion.LOCAL) -> Dict:
        """
        Extract GST from inclusive pricing (Sales/POS)
        Returns: Dict with base_excl, tax_info, line_inclusive
        """
        mrp_incl = Decimal(str(mrp_incl))
        discount_pct = Decimal(str(discount_pct))
        
        # Apply discount to unit price
        discounted_unit = mrp_incl * (1 - discount_pct / 100)
        line_inclusive = discounted_unit * qty
        
        # Get GST rate based on original MRP (not discounted price)
        gst_rate = GSTService.get_gst_rate(mrp_incl)
        
        # Extract base from inclusive price
        base_excl = line_inclusive / (1 + gst_rate)
        tax_amount = line_inclusive - base_excl
        
        result = {
            'mrp_incl': mrp_incl,
            'discount_pct': discount_pct,
            'discounted_unit': discounted_unit.quantize(Decimal('0.01'), ROUND_HALF_UP),
            'line_inclusive': line_inclusive.quantize(Decimal('0.01'), ROUND_HALF_UP),
            'base_excl': base_excl.quantize(Decimal('0.01'), ROUND_HALF_UP),
            'tax_amount': tax_amount.quantize(Decimal('0.01'), ROUND_HALF_UP),
            'gst_rate': gst_rate * 100
        }
        
        if tax_region == TaxRegion.LOCAL:
            result['cgst_rate'] = (gst_rate * 100) / 2
            result['sgst_rate'] = (gst_rate * 100) / 2
            result['cgst_amount'] = (tax_amount / 2).quantize(Decimal('0.01'), ROUND_HALF_UP)
            result['sgst_amount'] = (tax_amount / 2).quantize(Decimal('0.01'), ROUND_HALF_UP)
            result['igst_rate'] = Decimal('0')
        else:
            result['cgst_rate'] = Decimal('0')
            result['sgst_rate'] = Decimal('0')
            result['igst_rate'] = gst_rate * 100
            result['cgst_amount'] = Decimal('0')
            result['sgst_amount'] = Decimal('0')
        
        return result
    
    @staticmethod
    def apply_coupon_to_bill(bill_total_incl: Decimal, coupon_type: str, 
                            coupon_value: Decimal, max_cap: Decimal = None) -> Tuple[Decimal, Decimal]:
        """
        Apply coupon to bill total (inclusive)
        Returns: (discounted_total, coupon_discount_amount)
        """
        bill_total_incl = Decimal(str(bill_total_incl))
        coupon_value = Decimal(str(coupon_value))
        
        if coupon_type == 'percent':
            discount = bill_total_incl * (coupon_value / 100)
            if max_cap:
                max_cap = Decimal(str(max_cap))
                discount = min(discount, max_cap)
        else:  # flat
            discount = min(coupon_value, bill_total_incl)
        
        discounted_total = bill_total_incl - discount
        
        return (
            discounted_total.quantize(Decimal('0.01'), ROUND_HALF_UP),
            discount.quantize(Decimal('0.01'), ROUND_HALF_UP)
        )
    
    @staticmethod
    def round_off_amount(amount: Decimal, round_to: Decimal = Decimal('0.01')) -> Tuple[Decimal, Decimal]:
        """
        Round off amount based on configuration
        Returns: (rounded_amount, round_off_value)
        """
        amount = Decimal(str(amount))
        round_to = Decimal(str(round_to))
        
        if round_to == Decimal('0.01'):
            rounded = amount.quantize(Decimal('0.01'), ROUND_HALF_UP)
        elif round_to == Decimal('0.50'):
            rounded = (amount / Decimal('0.50')).quantize(Decimal('1'), ROUND_HALF_UP) * Decimal('0.50')
        elif round_to == Decimal('1.00'):
            rounded = amount.quantize(Decimal('1'), ROUND_HALF_UP)
        else:
            rounded = amount.quantize(Decimal('0.01'), ROUND_HALF_UP)
        
        round_off = rounded - amount
        
        return rounded, round_off