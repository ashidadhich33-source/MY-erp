from sqlalchemy.orm import Session
from typing import Dict, List
from decimal import Decimal
from ..models import Stock, Item
from datetime import datetime

class StockService:
    """Service for stock management"""
    
    @staticmethod
    def update_stock(db: Session, barcode: str, qty_change: int, operation: str = 'add'):
        """
        Update stock quantity
        operation: 'add' or 'subtract'
        """
        stock = db.query(Stock).filter(Stock.barcode == barcode).first()
        
        if not stock:
            # Create stock entry if doesn't exist
            stock = Stock(barcode=barcode, qty_on_hand=0)
            db.add(stock)
        
        if operation == 'add':
            stock.qty_on_hand += qty_change
        elif operation == 'subtract':
            if stock.qty_on_hand < qty_change:
                raise ValueError(f"Insufficient stock. Available: {stock.qty_on_hand}, Required: {qty_change}")
            stock.qty_on_hand -= qty_change
        
        stock.last_updated = datetime.utcnow()
        db.commit()
        
        return stock
    
    @staticmethod
    def check_availability(db: Session, barcode: str, required_qty: int) -> bool:
        """Check if required quantity is available"""
        stock = db.query(Stock).filter(Stock.barcode == barcode).first()
        
        if not stock:
            return False
        
        return stock.qty_on_hand >= required_qty
    
    @staticmethod
    def bulk_update_opening_stock(db: Session, stock_data: List[Dict]):
        """Update opening stock from import"""
        results = {'updated': 0, 'errors': []}
        
        for item in stock_data:
            try:
                barcode = item['barcode']
                qty = item['qty']
                
                # Check if item exists
                item_exists = db.query(Item).filter(Item.barcode == barcode).first()
                if not item_exists:
                    results['errors'].append(f"Item {barcode} not found")
                    continue
                
                stock = db.query(Stock).filter(Stock.barcode == barcode).first()
                if not stock:
                    stock = Stock(barcode=barcode, qty_on_hand=qty)
                    db.add(stock)
                else:
                    stock.qty_on_hand = qty
                    stock.last_updated = datetime.utcnow()
                
                results['updated'] += 1
                
            except Exception as e:
                results['errors'].append(f"Error updating {item.get('barcode')}: {str(e)}")
        
        db.commit()
        return results