import os
import configparser
from pathlib import Path
from typing import Optional
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    # Application
    APP_NAME: str = "ERP System"
    VERSION: str = "1.0.0"
    DEBUG: bool = True
    
    # Database
    DATABASE_TYPE: str = "sqlite"
    DATABASE_URL: Optional[str] = None
    
    # SQLite specific
    SQLITE_PATH: str = "database/erp_system.db"
    
    # PostgreSQL specific (optional)
    PG_HOST: str = "localhost"
    PG_PORT: int = 5432
    PG_USER: str = "postgres"
    PG_PASSWORD: str = ""
    PG_DATABASE: str = "erp_system"
    
    # Security
    SECRET_KEY: str = "your-secret-key-here-change-in-production"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 10080  # 7 days
    
    # WhatsApp Cloud API
    WHATSAPP_ACCESS_TOKEN: str = ""
    WHATSAPP_PHONE_NUMBER_ID: str = ""
    WHATSAPP_BUSINESS_ACCOUNT_ID: str = ""
    
    # GST Settings
    GST_ENABLED: bool = True
    ROUND_OFF: float = 0.01
    DEFAULT_TAX_REGION: str = "local"  # local or inter
    
    # File Paths
    UPLOAD_DIR: Path = Path("uploads")
    LOG_DIR: Path = Path("logs")
    BACKUP_DIR: Path = Path("backups")
    
    # Server
    HOST: str = "127.0.0.1"
    PORT: int = 8000
    WORKERS: int = 4
    
    class Config:
        env_file = ".env"
        case_sensitive = True
    
    def get_database_url(self) -> str:
        if self.DATABASE_TYPE == "sqlite":
            return f"sqlite:///{self.SQLITE_PATH}"
        elif self.DATABASE_TYPE == "postgresql":
            return f"postgresql://{self.PG_USER}:{self.PG_PASSWORD}@{self.PG_HOST}:{self.PG_PORT}/{self.PG_DATABASE}"
        return self.DATABASE_URL

    def load_from_ini(self, ini_path: str = "config/settings.ini"):
        """Load settings from INI file"""
        if os.path.exists(ini_path):
            config = configparser.ConfigParser()
            config.read(ini_path)
            
            # Database settings
            if 'database' in config:
                self.DATABASE_TYPE = config.get('database', 'type', fallback=self.DATABASE_TYPE)
                if self.DATABASE_TYPE == 'sqlite':
                    self.SQLITE_PATH = config.get('database', 'path', fallback=self.SQLITE_PATH)
                elif self.DATABASE_TYPE == 'postgresql':
                    self.PG_HOST = config.get('database', 'host', fallback=self.PG_HOST)
                    self.PG_PORT = config.getint('database', 'port', fallback=self.PG_PORT)
                    self.PG_DATABASE = config.get('database', 'name', fallback=self.PG_DATABASE)
                    self.PG_USER = config.get('database', 'user', fallback=self.PG_USER)
                    self.PG_PASSWORD = config.get('database', 'password', fallback=self.PG_PASSWORD)
            
            # Security settings
            if 'security' in config:
                self.SECRET_KEY = config.get('security', 'secret_key', fallback=self.SECRET_KEY)
                self.ALGORITHM = config.get('security', 'algorithm', fallback=self.ALGORITHM)
                self.ACCESS_TOKEN_EXPIRE_MINUTES = config.getint('security', 'access_token_expire_minutes', fallback=self.ACCESS_TOKEN_EXPIRE_MINUTES)

settings = Settings()
settings.load_from_ini()

# Create necessary directories
for directory in [settings.UPLOAD_DIR, settings.LOG_DIR, settings.BACKUP_DIR]:
    directory.mkdir(parents=True, exist_ok=True)