from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Response
from sqlalchemy.orm import Session
from typing import List, Optional, Dict, Any
from datetime import datetime
from decimal import Decimal
import uuid

from ...database import get_db
from ...models import (
    PurchaseBill, PurchaseBillItem, PurchaseReturn, PurchaseReturnItem,
    Supplier, Item, Stock, BillSeries
)
from ...services.gst_service import GSTService
from ...services.excel_service import ExcelService
from ...services.stock_service import StockService
from ...core.security import get_current_user
from ...schemas.purchase_schema import (
    PurchaseBillCreate, PurchaseBillResponse, PurchaseBillItemCreate,
    PurchaseReturnCreate, PurchaseReturnResponse
)

router = APIRouter()

def get_next_bill_number(db: Session, series_code: str) -> str:
    """Generate next bill number"""
    series = db.query(BillSeries).filter(
        BillSeries.code == series_code,
        BillSeries.active == True
    ).first()
    
    if not series:
        raise HTTPException(status_code=404, detail=f"Bill series {series_code} not found")
    
    bill_no = f"{series.prefix}-{str(series.next_no).zfill(series.width)}"
    series.next_no += 1
    db.commit()
    
    return bill_no

@router.post("/bill", response_model=PurchaseBillResponse)
async def create_purchase_bill(
    bill_data: PurchaseBillCreate,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Create a new purchase bill with GST calculations"""
    
    # Validate supplier
    supplier = db.query(Supplier).filter(Supplier.id == bill_data.supplier_id).first()
    if not supplier:
        raise HTTPException(status_code=404, detail="Supplier not found")
    
    # Generate bill number
    bill_no = get_next_bill_number(db, "PB")
    
    # Determine tax region based on supplier
    tax_region = supplier.location_type  # 'local' or 'inter'
    
    # Create purchase bill
    purchase_bill = PurchaseBill(
        id=str(uuid.uuid4()),
        pb_series_id=bill_data.pb_series_id,
        pb_no=bill_no,
        pb_date=datetime.utcnow(),
        payment_mode=bill_data.payment_mode,
        supplier_id=bill_data.supplier_id,
        tax_region=tax_region,
        supplier_bill_no=bill_data.supplier_bill_no,
        supplier_bill_date=bill_data.supplier_bill_date,
        reverse_charge=bill_data.reverse_charge or False,
        created_by=current_user.id
    )
    
    # Process items and calculate GST
    total_taxable = Decimal('0')
    total_cgst = Decimal('0')
    total_sgst = Decimal('0')
    total_igst = Decimal('0')
    
    for item_data in bill_data.items:
        # Validate item exists
        item = db.query(Item).filter(Item.barcode == item_data.barcode).first()
        if not item:
            raise HTTPException(status_code=404, detail=f"Item {item_data.barcode} not found")
        
        # Calculate GST (exclusive)
        gst_calc = GSTService.calculate_gst_exclusive(
            basic_rate=item_data.basic_rate,
            qty=item_data.qty,
            tax_region=tax_region
        )
        
        # Create purchase bill item
        pb_item = PurchaseBillItem(
            id=str(uuid.uuid4()),
            purchase_bill_id=purchase_bill.id,
            barcode=item_data.barcode,
            style_code=item.style_code,
            size=item.size,
            hsn=item.hsn,
            qty=item_data.qty,
            basic_rate=item_data.basic_rate,
            gst_rate=gst_calc['gst_rate'],
            cgst_rate=gst_calc.get('cgst_rate', Decimal('0')),
            sgst_rate=gst_calc.get('sgst_rate', Decimal('0')),
            igst_rate=gst_calc.get('igst_rate', Decimal('0')),
            line_taxable=gst_calc['line_taxable'],
            cgst_amount=gst_calc.get('cgst_amount', Decimal('0')),
            sgst_amount=gst_calc.get('sgst_amount', Decimal('0')),
            igst_amount=gst_calc.get('igst_amount', Decimal('0')),
            line_total=gst_calc['line_total'],
            mrp=item.mrp_incl
        )
        
        purchase_bill.items.append(pb_item)
        
        # Update totals
        total_taxable += gst_calc['line_taxable']
        total_cgst += gst_calc.get('cgst_amount', Decimal('0'))
        total_sgst += gst_calc.get('sgst_amount', Decimal('0'))
        total_igst += gst_calc.get('igst_amount', Decimal('0'))
        
        # Update stock
        StockService.update_stock(db, item_data.barcode, item_data.qty, 'add')
        
        # Update item's last purchase rate
        item.purchase_rate_basic = item_data.basic_rate
    
    # Set bill totals
    purchase_bill.total_taxable = total_taxable
    purchase_bill.total_cgst = total_cgst
    purchase_bill.total_sgst = total_sgst
    purchase_bill.total_igst = total_igst
    purchase_bill.grand_total = total_taxable + total_cgst + total_sgst + total_igst
    
    db.add(purchase_bill)
    db.commit()
    db.refresh(purchase_bill)
    
    return purchase_bill

@router.get("/bill/{bill_id}", response_model=PurchaseBillResponse)
async def get_purchase_bill(
    bill_id: str,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get purchase bill by ID"""
    bill = db.query(PurchaseBill).filter(PurchaseBill.id == bill_id).first()
    
    if not bill:
        raise HTTPException(status_code=404, detail="Purchase bill not found")
    
    return bill

@router.get("/bills", response_model=List[PurchaseBillResponse])
async def get_purchase_bills(
    skip: int = 0,
    limit: int = 100,
    from_date: Optional[datetime] = None,
    to_date: Optional[datetime] = None,
    supplier_id: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get purchase bills with filters"""
    query = db.query(PurchaseBill)
    
    if from_date:
        query = query.filter(PurchaseBill.pb_date >= from_date)
    if to_date:
        query = query.filter(PurchaseBill.pb_date <= to_date)
    if supplier_id:
        query = query.filter(PurchaseBill.supplier_id == supplier_id)
    
    bills = query.offset(skip).limit(limit).all()
    return bills

@router.post("/bill/import-items")
async def import_purchase_items(
    bill_id: str,
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Import purchase items from Excel (BARCODE, QTY)"""
    # Validate bill exists
    bill = db.query(PurchaseBill).filter(PurchaseBill.id == bill_id).first()
    if not bill:
        raise HTTPException(status_code=404, detail="Purchase bill not found")
    
    # Read Excel file
    content = await file.read()
    items, errors = ExcelService.import_purchase_order(content)
    
    if errors and not items:
        return {"success": False, "errors": errors}
    
    # Process imported items
    imported = 0
    updated = 0
    
    for item_data in items:
        # Check if item exists in bill
        existing_item = None
        for bill_item in bill.items:
            if bill_item.barcode == item_data['barcode']:
                existing_item = bill_item
                break
        
        if existing_item:
            # Update quantity
            qty_diff = item_data['qty'] - existing_item.qty
            existing_item.qty = item_data['qty']
            
            # Recalculate GST
            gst_calc = GSTService.calculate_gst_exclusive(
                basic_rate=existing_item.basic_rate,
                qty=existing_item.qty,
                tax_region=bill.tax_region
            )
            
            existing_item.line_taxable = gst_calc['line_taxable']
            existing_item.cgst_amount = gst_calc.get('cgst_amount', Decimal('0'))
            existing_item.sgst_amount = gst_calc.get('sgst_amount', Decimal('0'))
            existing_item.igst_amount = gst_calc.get('igst_amount', Decimal('0'))
            existing_item.line_total = gst_calc['line_total']
            
            # Update stock
            if qty_diff != 0:
                StockService.update_stock(db, item_data['barcode'], abs(qty_diff), 
                                         'add' if qty_diff > 0 else 'subtract')
            
            updated += 1
        else:
            # Add new item
            item = db.query(Item).filter(Item.barcode == item_data['barcode']).first()
            if not item:
                errors.append(f"Item {item_data['barcode']} not found")
                continue
            
            # Use last purchase rate or default
            basic_rate = item.purchase_rate_basic or Decimal('0')
            
            # Calculate GST
            gst_calc = GSTService.calculate_gst_exclusive(
                basic_rate=basic_rate,
                qty=item_data['qty'],
                tax_region=bill.tax_region
            )
            
            # Create new bill item
            pb_item = PurchaseBillItem(
                id=str(uuid.uuid4()),
                purchase_bill_id=bill.id,
                barcode=item_data['barcode'],
                style_code=item.style_code,
                size=item.size,
                hsn=item.hsn,
                qty=item_data['qty'],
                basic_rate=basic_rate,
                gst_rate=gst_calc['gst_rate'],
                cgst_rate=gst_calc.get('cgst_rate', Decimal('0')),
                sgst_rate=gst_calc.get('sgst_rate', Decimal('0')),
                igst_rate=gst_calc.get('igst_rate', Decimal('0')),
                line_taxable=gst_calc['line_taxable'],
                cgst_amount=gst_calc.get('cgst_amount', Decimal('0')),
                sgst_amount=gst_calc.get('sgst_amount', Decimal('0')),
                igst_amount=gst_calc.get('igst_amount', Decimal('0')),
                line_total=gst_calc['line_total'],
                mrp=item.mrp_incl
            )
            
            bill.items.append(pb_item)
            
            # Update stock
            StockService.update_stock(db, item_data['barcode'], item_data['qty'], 'add')
            
            imported += 1
    
    # Recalculate bill totals
    total_taxable = Decimal('0')
    total_cgst = Decimal('0')
    total_sgst = Decimal('0')
    total_igst = Decimal('0')
    
    for item in bill.items:
        total_taxable += item.line_taxable
        total_cgst += item.cgst_amount
        total_sgst += item.sgst_amount
        total_igst += item.igst_amount
    
    bill.total_taxable = total_taxable
    bill.total_cgst = total_cgst
    bill.total_sgst = total_sgst
    bill.total_igst = total_igst
    bill.grand_total = total_taxable + total_cgst + total_sgst + total_igst
    bill.modified_at = datetime.utcnow()
    bill.modified_by = current_user.id
    
    db.commit()
    
    return {
        "success": True,
        "imported": imported,
        "updated": updated,
        "errors": errors,
        "summary": f"Imported {imported} • Updated {updated} • Errors {len(errors)}"
    }

@router.post("/return", response_model=PurchaseReturnResponse)
async def create_purchase_return(
    return_data: PurchaseReturnCreate,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Create purchase return"""
    
    # Validate supplier
    supplier = db.query(Supplier).filter(Supplier.id == return_data.supplier_id).first()
    if not supplier:
        raise HTTPException(status_code=404, detail="Supplier not found")
    
    # Generate return number
    pr_no = get_next_bill_number(db, "PR")
    
    # Create purchase return
    purchase_return = PurchaseReturn(
        id=str(uuid.uuid4()),
        pr_series_id=return_data.pr_series_id,
        pr_no=pr_no,
        pr_date=datetime.utcnow(),
        supplier_id=return_data.supplier_id,
        tax_region=supplier.location_type,
        supplier_bill_no=return_data.supplier_bill_no,
        supplier_bill_date=return_data.supplier_bill_date,
        reason=return_data.reason,
        created_by=current_user.id
    )
    
    # Process return items
    total_taxable = Decimal('0')
    total_cgst = Decimal('0')
    total_sgst = Decimal('0')
    total_igst = Decimal('0')
    
    for item_data in return_data.items:
        # Validate item and stock
        item = db.query(Item).filter(Item.barcode == item_data.barcode).first()
        if not item:
            raise HTTPException(status_code=404, detail=f"Item {item_data.barcode} not found")
        
        # Check stock availability
        if not StockService.check_availability(db, item_data.barcode, item_data.qty):
            raise HTTPException(status_code=400, 
                              detail=f"Insufficient stock for {item_data.barcode}")
        
        # Calculate GST
        gst_calc = GSTService.calculate_gst_exclusive(
            basic_rate=item_data.basic_rate,
            qty=item_data.qty,
            tax_region=supplier.location_type
        )
        
        # Create return item
        pr_item = PurchaseReturnItem(
            id=str(uuid.uuid4()),
            purchase_return_id=purchase_return.id,
            barcode=item_data.barcode,
            style_code=item.style_code,
            size=item.size,
            hsn=item.hsn,
            qty=item_data.qty,
            basic_rate=item_data.basic_rate,
            gst_rate=gst_calc['gst_rate'],
            cgst_rate=gst_calc.get('cgst_rate', Decimal('0')),
            sgst_rate=gst_calc.get('sgst_rate', Decimal('0')),
            igst_rate=gst_calc.get('igst_rate', Decimal('0')),
            line_taxable=gst_calc['line_taxable'],
            cgst_amount=gst_calc.get('cgst_amount', Decimal('0')),
            sgst_amount=gst_calc.get('sgst_amount', Decimal('0')),
            igst_amount=gst_calc.get('igst_amount', Decimal('0')),
            line_total=gst_calc['line_total'],
            mrp=item.mrp_incl
        )
        
        purchase_return.items.append(pr_item)
        
        # Update totals
        total_taxable += gst_calc['line_taxable']
        total_cgst += gst_calc.get('cgst_amount', Decimal('0'))
        total_sgst += gst_calc.get('sgst_amount', Decimal('0'))
        total_igst += gst_calc.get('igst_amount', Decimal('0'))
        
        # Reduce stock
        StockService.update_stock(db, item_data.barcode, item_data.qty, 'subtract')
    
    # Set return totals
    purchase_return.total_taxable = total_taxable
    purchase_return.total_cgst = total_cgst
    purchase_return.total_sgst = total_sgst
    purchase_return.total_igst = total_igst
    purchase_return.grand_total = total_taxable + total_cgst + total_sgst + total_igst
    
    db.add(purchase_return)
    db.commit()
    db.refresh(purchase_return)
    
    return purchase_return