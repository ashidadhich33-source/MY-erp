from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Response
from sqlalchemy.orm import Session
from sqlalchemy import func, and_
from typing import List, Optional
from datetime import datetime, timedelta
from decimal import Decimal
import pandas as pd
import io
import uuid

from ...database import get_db
from ...models import Supplier, PurchaseBill, PurchaseReturn, PaymentMode
from ...core.security import get_current_user
from ...schemas.supplier_schema import (
    SupplierCreate, SupplierUpdate, SupplierResponse,
    SupplierDetailResponse, SupplierImportResponse
)

router = APIRouter()

@router.post("/", response_model=SupplierResponse)
async def create_supplier(
    supplier_data: SupplierCreate,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Create a new supplier"""
    # Check if GSTIN already exists
    if supplier_data.gstin:
        existing = db.query(Supplier).filter(Supplier.gstin == supplier_data.gstin).first()
        if existing:
            raise HTTPException(status_code=400, detail="GSTIN already registered")
    
    supplier = Supplier(
        id=str(uuid.uuid4()),
        name=supplier_data.name,
        gstin=supplier_data.gstin,
        email=supplier_data.email,
        phone=supplier_data.phone,
        location_type=supplier_data.location_type,
        active=True,
        created_at=datetime.utcnow()
    )
    
    db.add(supplier)
    
    # Create payment mode for supplier if card machine supplier
    if supplier_data.create_payment_mode:
        payment_mode = PaymentMode(
            id=str(uuid.uuid4()),
            name=f"{supplier_data.name} Card",
            settlement_type="supplier",
            supplier_id=supplier.id,
            active=True
        )
        db.add(payment_mode)
    
    db.commit()
    db.refresh(supplier)
    
    return supplier

@router.get("/", response_model=List[SupplierResponse])
async def get_suppliers(
    skip: int = 0,
    limit: int = 100,
    search: Optional[str] = None,
    location_type: Optional[str] = None,
    active: Optional[bool] = None,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get all suppliers with filters"""
    query = db.query(Supplier)
    
    if search:
        query = query.filter(
            or_(
                Supplier.name.ilike(f"%{search}%"),
                Supplier.gstin.contains(search),
                Supplier.phone.contains(search)
            )
        )
    
    if location_type:
        query = query.filter(Supplier.location_type == location_type)
    
    if active is not None:
        query = query.filter(Supplier.active == active)
    
    suppliers = query.offset(skip).limit(limit).all()
    return suppliers

@router.get("/{supplier_id}", response_model=SupplierDetailResponse)
async def get_supplier_details(
    supplier_id: str,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get detailed supplier information"""
    supplier = db.query(Supplier).filter(Supplier.id == supplier_id).first()
    
    if not supplier:
        raise HTTPException(status_code=404, detail="Supplier not found")
    
    # Get purchase statistics
    purchase_stats = db.query(
        func.count(PurchaseBill.id).label('total_bills'),
        func.sum(PurchaseBill.grand_total).label('total_purchase'),
        func.max(PurchaseBill.pb_date).label('last_purchase')
    ).filter(PurchaseBill.supplier_id == supplier_id).first()
    
    # Get return statistics
    return_stats = db.query(
        func.count(PurchaseReturn.id).label('total_returns'),
        func.sum(PurchaseReturn.grand_total).label('total_return_amount')
    ).filter(PurchaseReturn.supplier_id == supplier_id).first()
    
    # Get pending payments (if payment_mode is 'credit')
    pending_bills = db.query(PurchaseBill).filter(
        PurchaseBill.supplier_id == supplier_id,
        PurchaseBill.payment_mode == 'credit'
    ).all()
    
    pending_amount = sum(bill.grand_total for bill in pending_bills)
    
    # Get recent transactions
    recent_bills = db.query(PurchaseBill).filter(
        PurchaseBill.supplier_id == supplier_id
    ).order_by(PurchaseBill.pb_date.desc()).limit(10).all()
    
    recent_transactions = []
    for bill in recent_bills:
        recent_transactions.append({
            "date": bill.pb_date,
            "bill_no": bill.pb_no,
            "amount": float(bill.grand_total),
            "payment_mode": bill.payment_mode,
            "type": "purchase"
        })
    
    # Get associated payment modes
    payment_modes = db.query(PaymentMode).filter(
        PaymentMode.supplier_id == supplier_id
    ).all()
    
    return SupplierDetailResponse(
        id=supplier.id,
        name=supplier.name,
        gstin=supplier.gstin,
        email=supplier.email,
        phone=supplier.phone,
        location_type=supplier.location_type,
        active=supplier.active,
        total_bills=purchase_stats.total_bills or 0,
        total_purchase=purchase_stats.total_purchase or Decimal('0'),
        last_purchase_date=purchase_stats.last_purchase,
        total_returns=return_stats.total_returns or 0,
        total_return_amount=return_stats.total_return_amount or Decimal('0'),
        pending_amount=pending_amount,
        recent_transactions=recent_transactions,
        payment_modes=[{
            "id": pm.id,
            "name": pm.name,
            "active": pm.active
        } for pm in payment_modes],
        created_at=supplier.created_at
    )

@router.put("/{supplier_id}", response_model=SupplierResponse)
async def update_supplier(
    supplier_id: str,
    supplier_update: SupplierUpdate,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Update supplier information"""
    supplier = db.query(Supplier).filter(Supplier.id == supplier_id).first()
    
    if not supplier:
        raise HTTPException(status_code=404, detail="Supplier not found")
    
    # Check GSTIN uniqueness if being updated
    if supplier_update.gstin and supplier_update.gstin != supplier.gstin:
        existing = db.query(Supplier).filter(
            Supplier.gstin == supplier_update.gstin,
            Supplier.id != supplier_id
        ).first()
        if existing:
            raise HTTPException(status_code=400, detail="GSTIN already registered")
    
    # Update fields
    for field, value in supplier_update.dict(exclude_unset=True).items():
        if field != 'create_payment_mode':  # Skip this field
            setattr(supplier, field, value)
    
    supplier.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(supplier)
    
    return supplier

@router.post("/{supplier_id}/toggle-active")
async def toggle_supplier_active(
    supplier_id: str,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Toggle supplier active status"""
    supplier = db.query(Supplier).filter(Supplier.id == supplier_id).first()
    
    if not supplier:
        raise HTTPException(status_code=404, detail="Supplier not found")
    
    supplier.active = not supplier.active
    supplier.updated_at = datetime.utcnow()
    
    # Also toggle associated payment modes
    payment_modes = db.query(PaymentMode).filter(
        PaymentMode.supplier_id == supplier_id
    ).all()
    
    for pm in payment_modes:
        pm.active = supplier.active
    
    db.commit()
    
    return {
        "success": True,
        "active": supplier.active,
        "message": f"Supplier {'activated' if supplier.active else 'deactivated'} successfully"
    }

@router.get("/outstanding/summary")
async def get_outstanding_summary(
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get summary of outstanding payments to suppliers"""
    # Get all credit purchases that are not yet paid
    outstanding = db.query(
        Supplier.name,
        func.count(PurchaseBill.id).label('bill_count'),
        func.sum(PurchaseBill.grand_total).label('total_amount')
    ).join(
        PurchaseBill, Supplier.id == PurchaseBill.supplier_id
    ).filter(
        PurchaseBill.payment_mode == 'credit'
    ).group_by(Supplier.id).all()
    
    result = []
    total_outstanding = Decimal('0')
    
    for supplier_name, bill_count, amount in outstanding:
        result.append({
            "supplier_name": supplier_name,
            "bill_count": bill_count,
            "outstanding_amount": float(amount)
        })
        total_outstanding += amount
    
    return {
        "suppliers": result,
        "total_outstanding": float(total_outstanding),
        "supplier_count": len(result)
    }

@router.post("/import", response_model=SupplierImportResponse)
async def import_suppliers(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Import suppliers from Excel file"""
    if not file.filename.endswith(('.xlsx', '.xls')):
        raise HTTPException(status_code=400, detail="Only Excel files are allowed")
    
    content = await file.read()
    
    try:
        df = pd.read_excel(io.BytesIO(content))
        df.columns = df.columns.str.strip().str.upper()
        
        required_columns = ['NAME']
        missing_columns = [col for col in required_columns if col not in df.columns]
        
        if missing_columns:
            raise HTTPException(
                status_code=400,
                detail=f"Missing required columns: {', '.join(missing_columns)}"
            )
        
        imported = 0
        updated = 0
        errors = []
        
        for idx, row in df.iterrows():
            try:
                name = str(row['NAME']).strip()
                gstin = str(row.get('GSTIN', '')).strip() if 'GSTIN' in row and pd.notna(row['GSTIN']) else None
                
                # Check if supplier exists (by GSTIN or name)
                existing = None
                if gstin:
                    existing = db.query(Supplier).filter(Supplier.gstin == gstin).first()
                if not existing:
                    existing = db.query(Supplier).filter(Supplier.name == name).first()
                
                if existing:
                    # Update existing supplier
                    if 'EMAIL' in row and pd.notna(row['EMAIL']):
                        existing.email = str(row['EMAIL']).strip()
                    if 'PHONE' in row and pd.notna(row['PHONE']):
                        existing.phone = str(row['PHONE']).strip()
                    if 'LOCATION_TYPE' in row and pd.notna(row['LOCATION_TYPE']):
                        loc_type = str(row['LOCATION_TYPE']).strip().lower()
                        if loc_type in ['local', 'inter']:
                            existing.location_type = loc_type
                    
                    existing.updated_at = datetime.utcnow()
                    updated += 1
                else:
                    # Create new supplier
                    location_type = 'local'  # Default
                    if 'LOCATION_TYPE' in row and pd.notna(row['LOCATION_TYPE']):
                        loc_type = str(row['LOCATION_TYPE']).strip().lower()
                        if loc_type in ['local', 'inter']:
                            location_type = loc_type
                    
                    new_supplier = Supplier(
                        id=str(uuid.uuid4()),
                        name=name,
                        gstin=gstin,
                        email=str(row.get('EMAIL', '')).strip() if 'EMAIL' in row and pd.notna(row['EMAIL']) else None,
                        phone=str(row.get('PHONE', '')).strip() if 'PHONE' in row and pd.notna(row['PHONE']) else None,
                        location_type=location_type,
                        active=True
                    )
                    db.add(new_supplier)
                    imported += 1
                    
            except Exception as e:
                errors.append(f"Row {idx+2}: {str(e)}")
        
        db.commit()
        
        return SupplierImportResponse(
            success=True,
            imported=imported,
            updated=updated,
            errors=errors
        )
        
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Error processing file: {str(e)}")

@router.get("/export/template")
async def export_supplier_template():
    """Download Excel template for supplier import"""
    columns = ['NAME', 'GSTIN', 'EMAIL', 'PHONE', 'LOCATION_TYPE']
    
    sample_data = {
        'NAME': 'ABC Suppliers Pvt Ltd',
        'GSTIN': '27ABCDE1234F1Z5',
        'EMAIL': 'contact@abcsuppliers.com',
        'PHONE': '9876543210',
        'LOCATION_TYPE': 'local'  # local or inter
    }
    
    df = pd.DataFrame([sample_data])
    
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, sheet_name='Suppliers', index=False)
    
    output.seek(0)
    
    return Response(
        content=output.read(),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={
            "Content-Disposition": f"attachment; filename=supplier_template_{datetime.now().strftime('%Y%m%d')}.xlsx"
        }
    )