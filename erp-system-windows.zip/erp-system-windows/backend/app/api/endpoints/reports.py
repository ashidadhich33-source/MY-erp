from fastapi import APIRouter, Depends, HTTPException, Query, Response
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, func, extract, case, distinct
from typing import List, Optional, Dict, Any
from datetime import datetime, date, timedelta
from decimal import Decimal
import pandas as pd
import io
import calendar
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

from ...database import get_db
from ...models import (
    Sale, SaleItem, SalePayment, SaleReturn, SaleReturnItem,
    PurchaseBill, PurchaseBillItem, PurchaseReturn, PurchaseReturnItem,
    Customer, Supplier, Item, Stock, Staff, StaffTarget,
    Expense, ExpenseHead, PaymentMode, LoyaltyGrade, Coupon,
    PointTransaction, ReturnCredit
)
from ...core.security import get_current_user
from ...schemas.report_schema import (
    SaleReportResponse, PurchaseReportResponse, StockReportResponse,
    CustomerReportResponse, StaffPerformanceReportResponse,
    GST_ReportResponse, ProfitLossReportResponse, DashboardMetricsResponse
)

router = APIRouter()

# =====================================
# Sales Reports

@router.get("/sales/detailed")
async def get_detailed_sales_report(
    from_date: date,
    to_date: date,
    staff_id: Optional[str] = None,
    payment_mode: Optional[str] = None,
    customer_mobile: Optional[str] = None,
    export: bool = False,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get detailed sales and sales return report"""
    
    # Sales query
    sales_query = db.query(
        Sale.bill_date,
        Sale.bill_no,
        Staff.name.label('staff_name'),
        Customer.name.label('customer_name'),
        Customer.mobile.label('customer_mobile'),
        SaleItem.barcode,
        SaleItem.style_code,
        Item.brand,
        Item.gender,
        Item.category,
        Item.sub_category,
        SaleItem.size,
        SaleItem.qty,
        SaleItem.mrp_incl,
        SaleItem.disc_pct,
        (SaleItem.mrp_incl * SaleItem.qty * SaleItem.disc_pct / 100).label('discount_amount'),
        SaleItem.cgst_rate,
        SaleItem.sgst_rate,
        SaleItem.igst_rate,
        SaleItem.line_inclusive.label('amount'),
        Item.purchase_rate_basic.label('basic_rate'),
        SalePayment.payment_mode_id,
        PaymentMode.name.label('payment_mode_name'),
        SalePayment.amount.label('payment_amount')
    ).select_from(Sale).join(
        SaleItem, Sale.id == SaleItem.sale_id
    ).join(
        Item, SaleItem.barcode == Item.barcode
    ).outerjoin(
        Staff, Sale.staff_id == Staff.id
    ).outerjoin(
        Customer, Sale.customer_mobile == Customer.mobile
    ).outerjoin(
        SalePayment, Sale.id == SalePayment.sale_id
    ).outerjoin(
        PaymentMode, SalePayment.payment_mode_id == PaymentMode.id
    ).filter(
        Sale.bill_date >= from_date,
        Sale.bill_date <= datetime.combine(to_date, datetime.max.time())
    )
    
    # Apply filters
    if staff_id:
        sales_query = sales_query.filter(Sale.staff_id == staff_id)
    if customer_mobile:
        sales_query = sales_query.filter(Sale.customer_mobile == customer_mobile)
    if payment_mode:
        sales_query = sales_query.filter(PaymentMode.name == payment_mode)
    
    sales_data = sales_query.all()
    
    # Sales returns query
    returns_query = db.query(
        SaleReturn.sr_date.label('bill_date'),
        SaleReturn.sr_no.label('bill_no'),
        Staff.name.label('staff_name'),
        Customer.name.label('customer_name'),
        Customer.mobile.label('customer_mobile'),
        SaleReturnItem.barcode,
        SaleReturnItem.style_code,
        Item.brand,
        Item.gender,
        Item.category,
        Item.sub_category,
        SaleReturnItem.size,
        (-SaleReturnItem.return_qty).label('qty'),  # Negative quantity
        SaleReturnItem.unit_mrp_incl.label('mrp_incl'),
        SaleReturnItem.disc_pct_at_sale.label('disc_pct'),
        Decimal('0').label('discount_amount'),
        Decimal('0').label('cgst_rate'),
        Decimal('0').label('sgst_rate'),
        Decimal('0').label('igst_rate'),
        (-SaleReturnItem.line_inclusive).label('amount'),  # Negative amount
        Item.purchase_rate_basic.label('basic_rate'),
        None.label('payment_mode_id'),
        'Return Credit'.label('payment_mode_name'),
        (-SaleReturnItem.line_inclusive).label('payment_amount')
    ).select_from(SaleReturn).join(
        SaleReturnItem, SaleReturn.id == SaleReturnItem.sales_return_id
    ).join(
        Item, SaleReturnItem.barcode == Item.barcode
    ).outerjoin(
        Staff, SaleReturn.created_by == Staff.id
    ).outerjoin(
        Customer, SaleReturn.customer_mobile == Customer.mobile
    ).filter(
        SaleReturn.sr_date >= from_date,
        SaleReturn.sr_date <= datetime.combine(to_date, datetime.max.time())
    )
    
    returns_data = returns_query.all()
    
    # Combine sales and returns
    all_data = sales_data + returns_data
    
    if export:
        # Create Excel file
        df = pd.DataFrame([{
            'Bill Date': row.bill_date.strftime('%Y-%m-%d'),
            'SNo': idx + 1,
            'Bill No': row.bill_no,
            'Staff': row.staff_name or '',
            'Customer': row.customer_name or '',
            'Mobile': row.customer_mobile or '',
            'Barcode': row.barcode,
            'Style Code': row.style_code,
            'Size': row.size or '',
            'Qty': row.qty,
            'MRP': float(row.mrp_incl),
            'Disc %': float(row.disc_pct),
            'Discount Amt': float(row.discount_amount),
            'CGST %': float(row.cgst_rate),
            'SGST %': float(row.sgst_rate),
            'IGST %': float(row.igst_rate),
            'Amount': float(row.amount),
            'Brand': row.brand or '',
            'Basic Rate': float(row.basic_rate) if row.basic_rate else 0,
            'Gender': row.gender or '',
            'Category': row.category or '',
            'Sub Category': row.sub_category or '',
            'Payment Mode': row.payment_mode_name or ''
        } for idx, row in enumerate(all_data)])
        
        output = io.BytesIO()
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            df.to_excel(writer, sheet_name='Sales_Report', index=False)
            
            # Format the Excel
            worksheet = writer.sheets['Sales_Report']
            for cell in worksheet[1]:
                cell.font = Font(bold=True)
                cell.fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
                cell.font = Font(color="FFFFFF", bold=True)
        
        output.seek(0)
        
        return Response(
            content=output.read(),
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={
                "Content-Disposition": f"attachment; filename=sales_report_{from_date}_{to_date}.xlsx"
            }
        )
    
    # Return JSON response
    return {
        "period": {"from": from_date, "to": to_date},
        "total_records": len(all_data),
        "total_sales": sum(row.amount for row in all_data if row.amount > 0),
        "total_returns": abs(sum(row.amount for row in all_data if row.amount < 0)),
        "net_sales": sum(row.amount for row in all_data),
        "data": all_data[:100]  # Limited for API response
    }

@router.get("/sales/summary")
async def get_sales_summary(
    from_date: date,
    to_date: date,
    group_by: str = "date",  # date, staff, category, payment_mode
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get sales summary grouped by various parameters"""
    
    base_query = db.query(Sale).filter(
        Sale.bill_date >= from_date,
        Sale.bill_date <= datetime.combine(to_date, datetime.max.time())
    )
    
    if group_by == "date":
        results = base_query.with_entities(
            func.date(Sale.bill_date).label('group_key'),
            func.count(distinct(Sale.id)).label('bill_count'),
            func.sum(Sale.final_payable).label('total_amount'),
            func.avg(Sale.final_payable).label('avg_amount')
        ).group_by(func.date(Sale.bill_date)).order_by(func.date(Sale.bill_date)).all()
        
    elif group_by == "staff":
        results = base_query.join(Staff).with_entities(
            Staff.name.label('group_key'),
            func.count(distinct(Sale.id)).label('bill_count'),
            func.sum(Sale.final_payable).label('total_amount'),
            func.avg(Sale.final_payable).label('avg_amount')
        ).group_by(Staff.id).all()
        
    elif group_by == "category":
        results = db.query(
            Item.category.label('group_key'),
            func.count(distinct(SaleItem.id)).label('bill_count'),
            func.sum(SaleItem.line_inclusive).label('total_amount'),
            func.avg(SaleItem.line_inclusive).label('avg_amount')
        ).select_from(SaleItem).join(
            Sale, Item
        ).filter(
            Sale.bill_date >= from_date,
            Sale.bill_date <= datetime.combine(to_date, datetime.max.time())
        ).group_by(Item.category).all()
        
    elif group_by == "payment_mode":
        results = db.query(
            PaymentMode.name.label('group_key'),
            func.count(distinct(SalePayment.sale_id)).label('bill_count'),
            func.sum(SalePayment.amount).label('total_amount'),
            func.avg(SalePayment.amount).label('avg_amount')
        ).select_from(SalePayment).join(
            Sale, PaymentMode
        ).filter(
            Sale.bill_date >= from_date,
            Sale.bill_date <= datetime.combine(to_date, datetime.max.time())
        ).group_by(PaymentMode.id).all()
    
    else:
        raise HTTPException(status_code=400, detail="Invalid group_by parameter")
    
    return {
        "period": {"from": from_date, "to": to_date},
        "grouped_by": group_by,
        "summary": [
            {
                "key": row.group_key,
                "bills": row.bill_count,
                "total": float(row.total_amount) if row.total_amount else 0,
                "average": float(row.avg_amount) if row.avg_amount else 0
            } for row in results
        ]
    }

# =====================================
# Purchase Reports

@router.get("/purchases/detailed")
async def get_detailed_purchase_report(
    from_date: date,
    to_date: date,
    supplier_id: Optional[str] = None,
    export: bool = False,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get detailed purchase and purchase return report"""
    
    # Purchase bills query
    purchase_query = db.query(
        PurchaseBill.pb_date,
        PurchaseBill.pb_no,
        Supplier.name.label('supplier_name'),
        Supplier.gstin,
        PurchaseBillItem.barcode,
        PurchaseBillItem.style_code,
        PurchaseBillItem.size,
        PurchaseBillItem.hsn,
        PurchaseBillItem.qty,
        PurchaseBillItem.basic_rate,
        PurchaseBillItem.gst_rate,
        PurchaseBillItem.line_taxable,
        PurchaseBillItem.cgst_amount,
        PurchaseBillItem.sgst_amount,
        PurchaseBillItem.igst_amount,
        PurchaseBillItem.line_total,
        PurchaseBill.payment_mode
    ).select_from(PurchaseBill).join(
        PurchaseBillItem, Supplier
    ).filter(
        PurchaseBill.pb_date >= from_date,
        PurchaseBill.pb_date <= datetime.combine(to_date, datetime.max.time())
    )
    
    if supplier_id:
        purchase_query = purchase_query.filter(PurchaseBill.supplier_id == supplier_id)
    
    purchases = purchase_query.all()
    
    # Purchase returns query
    return_query = db.query(
        PurchaseReturn.pr_date.label('pb_date'),
        PurchaseReturn.pr_no.label('pb_no'),
        Supplier.name.label('supplier_name'),
        Supplier.gstin,
        PurchaseReturnItem.barcode,
        PurchaseReturnItem.style_code,
        PurchaseReturnItem.size,
        PurchaseReturnItem.hsn,
        (-PurchaseReturnItem.qty).label('qty'),
        PurchaseReturnItem.basic_rate,
        PurchaseReturnItem.gst_rate,
        (-PurchaseReturnItem.line_taxable).label('line_taxable'),
        (-PurchaseReturnItem.cgst_amount).label('cgst_amount'),
        (-PurchaseReturnItem.sgst_amount).label('sgst_amount'),
        (-PurchaseReturnItem.igst_amount).label('igst_amount'),
        (-PurchaseReturnItem.line_total).label('line_total'),
        'Return'.label('payment_mode')
    ).select_from(PurchaseReturn).join(
        PurchaseReturnItem, Supplier
    ).filter(
        PurchaseReturn.pr_date >= from_date,
        PurchaseReturn.pr_date <= datetime.combine(to_date, datetime.max.time())
    )
    
    if supplier_id:
        return_query = return_query.filter(PurchaseReturn.supplier_id == supplier_id)
    
    returns = return_query.all()
    
    # Combine purchases and returns
    all_data = purchases + returns
    
    if export:
        # Create Excel file
        df = pd.DataFrame([{
            'Date': row.pb_date.strftime('%Y-%m-%d'),
            'Bill No': row.pb_no,
            'Supplier': row.supplier_name,
            'GSTIN': row.gstin or '',
            'Barcode': row.barcode,
            'Style Code': row.style_code,
            'Size': row.size or '',
            'HSN': row.hsn or '',
            'Qty': row.qty,
            'Basic Rate': float(row.basic_rate),
            'GST %': float(row.gst_rate),
            'Taxable': float(row.line_taxable),
            'CGST': float(row.cgst_amount),
            'SGST': float(row.sgst_amount),
            'IGST': float(row.igst_amount),
            'Total': float(row.line_total),
            'Payment': row.payment_mode
        } for row in all_data])
        
        output = io.BytesIO()
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            df.to_excel(writer, sheet_name='Purchase_Report', index=False)
        
        output.seek(0)
        
        return Response(
            content=output.read(),
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={
                "Content-Disposition": f"attachment; filename=purchase_report_{from_date}_{to_date}.xlsx"
            }
        )
    
    return {
        "period": {"from": from_date, "to": to_date},
        "total_purchases": sum(row.line_total for row in all_data if row.line_total > 0),
        "total_returns": abs(sum(row.line_total for row in all_data if row.line_total < 0)),
        "net_purchases": sum(row.line_total for row in all_data)
    }

# =====================================
# Stock Reports

@router.get("/stock/current")
async def get_current_stock_report(
    category: Optional[str] = None,
    brand: Optional[str] = None,
    low_stock_only: bool = False,
    export: bool = False,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get current stock report with valuation"""
    
    query = db.query(
        Item.barcode,
        Item.style_code,
        Item.color,
        Item.size,
        Item.brand,
        Item.category,
        Item.sub_category,
        Item.mrp_incl,
        Item.purchase_rate_basic,
        Stock.qty_on_hand,
        (Stock.qty_on_hand * Item.purchase_rate_basic).label('stock_value'),
        (Stock.qty_on_hand * Item.mrp_incl).label('retail_value')
    ).join(Stock)
    
    if category:
        query = query.filter(Item.category == category)
    if brand:
        query = query.filter(Item.brand == brand)
    if low_stock_only:
        query = query.filter(Stock.qty_on_hand < 10)  # Configurable threshold
    
    stock_data = query.all()
    
    if export:
        df = pd.DataFrame([{
            'Barcode': row.barcode,
            'Style Code': row.style_code,
            'Color': row.color or '',
            'Size': row.size or '',
            'Brand': row.brand or '',
            'Category': row.category or '',
            'Sub Category': row.sub_category or '',
            'MRP': float(row.mrp_incl) if row.mrp_incl else 0,
            'Cost': float(row.purchase_rate_basic) if row.purchase_rate_basic else 0,
            'Qty': row.qty_on_hand,
            'Stock Value': float(row.stock_value) if row.stock_value else 0,
            'Retail Value': float(row.retail_value) if row.retail_value else 0
        } for row in stock_data])
        
        output = io.BytesIO()
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            df.to_excel(writer, sheet_name='Stock_Report', index=False)
            
            # Add summary
            summary_df = pd.DataFrame([{
                'Total Items': len(stock_data),
                'Total Quantity': sum(row.qty_on_hand for row in stock_data),
                'Total Stock Value': sum(row.stock_value for row in stock_data if row.stock_value),
                'Total Retail Value': sum(row.retail_value for row in stock_data if row.retail_value)
            }])
            summary_df.to_excel(writer, sheet_name='Summary', index=False)
        
        output.seek(0)
        
        return Response(
            content=output.read(),
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={
                "Content-Disposition": f"attachment; filename=stock_report_{date.today()}.xlsx"
            }
        )
    
    return {
        "total_items": len(stock_data),
        "total_quantity": sum(row.qty_on_hand for row in stock_data),
        "total_stock_value": float(sum(row.stock_value for row in stock_data if row.stock_value)),
        "total_retail_value": float(sum(row.retail_value for row in stock_data if row.retail_value)),
        "items": stock_data[:100]  # Limited for API response
    }

@router.get("/stock/movement")
async def get_stock_movement_report(
    from_date: date,
    to_date: date,
    barcode: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get stock movement report (in/out analysis)"""
    
    # Stock IN (Purchases + Sale Returns)
    stock_in_purchases = db.query(
        PurchaseBillItem.barcode,
        func.sum(PurchaseBillItem.qty).label('qty_in')
    ).join(PurchaseBill).filter(
        PurchaseBill.pb_date >= from_date,
        PurchaseBill.pb_date <= datetime.combine(to_date, datetime.max.time())
    ).group_by(PurchaseBillItem.barcode)
    
    if barcode:
        stock_in_purchases = stock_in_purchases.filter(PurchaseBillItem.barcode == barcode)
    
    # Stock OUT (Sales + Purchase Returns)
    stock_out_sales = db.query(
        SaleItem.barcode,
        func.sum(SaleItem.qty).label('qty_out')
    ).join(Sale).filter(
        Sale.bill_date >= from_date,
        Sale.bill_date <= datetime.combine(to_date, datetime.max.time())
    ).group_by(SaleItem.barcode)
    
    if barcode:
        stock_out_sales = stock_out_sales.filter(SaleItem.barcode == barcode)
    
    # Combine results
    movement_data = {}
    
    for row in stock_in_purchases:
        if row.barcode not in movement_data:
            movement_data[row.barcode] = {'in': 0, 'out': 0}
        movement_data[row.barcode]['in'] = row.qty_in
    
    for row in stock_out_sales:
        if row.barcode not in movement_data:
            movement_data[row.barcode] = {'in': 0, 'out': 0}
        movement_data[row.barcode]['out'] = row.qty_out
    
    # Get current stock for comparison
    result = []
    for barcode, movement in movement_data.items():
        item = db.query(Item, Stock).join(Stock).filter(Item.barcode == barcode).first()
        if item:
            result.append({
                "barcode": barcode,
                "style_code": item.Item.style_code,
                "opening_stock": item.Stock.qty_on_hand - movement['in'] + movement['out'],
                "qty_in": movement['in'],
                "qty_out": movement['out'],
                "closing_stock": item.Stock.qty_on_hand,
                "net_movement": movement['in'] - movement['out']
            })
    
    return {
        "period": {"from": from_date, "to": to_date},
        "movements": result
    }

# =====================================
# Customer Reports

@router.get("/customers/analysis")
async def get_customer_analysis_report(
    from_date: Optional[date] = None,
    to_date: Optional[date] = None,
    top_n: int = 20,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get customer analysis report"""
    
    # Default to last 3 months
    if not to_date:
        to_date = date.today()
    if not from_date:
        from_date = to_date - timedelta(days=90)
    
    # Top customers by purchase
    top_customers = db.query(
        Customer.mobile,
        Customer.name,
        Customer.grade,
        func.count(distinct(Sale.id)).label('bill_count'),
        func.sum(Sale.final_payable).label('total_purchase'),
        func.max(Sale.bill_date).label('last_purchase')
    ).join(Sale).filter(
        Sale.bill_date >= from_date,
        Sale.bill_date <= datetime.combine(to_date, datetime.max.time())
    ).group_by(Customer.mobile).order_by(
        func.sum(Sale.final_payable).desc()
    ).limit(top_n).all()
    
    # Inactive customers
    inactive_cutoff = date.today() - timedelta(days=90)
    inactive_customers = db.query(Customer).filter(
        ~Customer.mobile.in_(
            db.query(Sale.customer_mobile).filter(
                Sale.bill_date >= inactive_cutoff
            ).distinct()
        )
    ).count()
    
    # New customers in period
    new_customers = db.query(func.count(Customer.mobile)).filter(
        Customer.created_at >= from_date,
        Customer.created_at <= datetime.combine(to_date, datetime.max.time())
    ).scalar()
    
    # Loyalty distribution
    loyalty_distribution = db.query(
        Customer.grade,
        func.count(Customer.mobile).label('count')
    ).group_by(Customer.grade).all()
    
    return {
        "period": {"from": from_date, "to": to_date},
        "top_customers": [
            {
                "mobile": c.mobile,
                "name": c.name,
                "grade": c.grade,
                "bills": c.bill_count,
                "total": float(c.total_purchase),
                "last_purchase": c.last_purchase
            } for c in top_customers
        ],
        "inactive_customers": inactive_customers,
        "new_customers": new_customers,
        "loyalty_distribution": [
            {"grade": l.grade, "count": l.count} for l in loyalty_distribution
        ]
    }

@router.get("/customers/birthdays")
async def get_birthday_report(
    month: Optional[int] = None,
    export: bool = False,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get customer kids birthday report"""
    
    if not month:
        month = date.today().month
    
    # Query customers with kids having birthdays in specified month
    customers = db.query(Customer).filter(
        or_(
            extract('month', Customer.kid1_dob) == month,
            extract('month', Customer.kid2_dob) == month,
            extract('month', Customer.kid3_dob) == month
        )
    ).all()
    
    birthday_list = []
    for customer in customers:
        if customer.kid1_dob and customer.kid1_dob.month == month:
            birthday_list.append({
                "customer_name": customer.name,
                "mobile": customer.mobile,
                "kid_name": customer.kid1_name,
                "birthday": customer.kid1_dob.day,
                "age": date.today().year - customer.kid1_dob.year
            })
        if customer.kid2_dob and customer.kid2_dob.month == month:
            birthday_list.append({
                "customer_name": customer.name,
                "mobile": customer.mobile,
                "kid_name": customer.kid2_name,
                "birthday": customer.kid2_dob.day,
                "age": date.today().year - customer.kid2_dob.year
            })
        if customer.kid3_dob and customer.kid3_dob.month == month:
            birthday_list.append({
                "customer_name": customer.name,
                "mobile": customer.mobile,
                "kid_name": customer.kid3_name,
                "birthday": customer.kid3_dob.day,
                "age": date.today().year - customer.kid3_dob.year
            })
    
    # Sort by day
    birthday_list.sort(key=lambda x: x['birthday'])
    
    if export:
        df = pd.DataFrame(birthday_list)
        output = io.BytesIO()
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            df.to_excel(writer, sheet_name=f'{calendar.month_name[month]}_Birthdays', index=False)
        output.seek(0)
        
        return Response(
            content=output.read(),
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={
                "Content-Disposition": f"attachment; filename=birthdays_{calendar.month_name[month]}.xlsx"
            }
        )
    
    return {
        "month": calendar.month_name[month],
        "total_birthdays": len(birthday_list),
        "birthdays": birthday_list
    }

# =====================================
# GST Reports

@router.get("/gst/summary")
async def get_gst_summary_report(
    from_date: date,
    to_date: date,
    export: bool = False,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get GST summary report for filing"""
    
    # Sales GST (Output Tax)
    sales_gst = db.query(
        func.sum(case((SaleItem.cgst_rate > 0, SaleItem.base_excl), else_=0)).label('cgst_base'),
        func.sum(case((SaleItem.cgst_rate > 0, SaleItem.tax_amt_info * 0.5), else_=0)).label('cgst_amount'),
        func.sum(case((SaleItem.sgst_rate > 0, SaleItem.base_excl), else_=0)).label('sgst_base'),
        func.sum(case((SaleItem.sgst_rate > 0, SaleItem.tax_amt_info * 0.5), else_=0)).label('sgst_amount'),
        func.sum(case((SaleItem.igst_rate > 0, SaleItem.base_excl), else_=0)).label('igst_base'),
        func.sum(case((SaleItem.igst_rate > 0, SaleItem.tax_amt_info), else_=0)).label('igst_amount')
    ).join(Sale).filter(
        Sale.bill_date >= from_date,
        Sale.bill_date <= datetime.combine(to_date, datetime.max.time())
    ).first()
    
    # Purchase GST (Input Tax)
    purchase_gst = db.query(
        func.sum(PurchaseBillItem.cgst_amount).label('cgst_input'),
        func.sum(PurchaseBillItem.sgst_amount).label('sgst_input'),
        func.sum(PurchaseBillItem.igst_amount).label('igst_input')
    ).join(PurchaseBill).filter(
        PurchaseBill.pb_date >= from_date,
        PurchaseBill.pb_date <= datetime.combine(to_date, datetime.max.time())
    ).first()
    
    # HSN-wise summary
    hsn_summary = db.query(
        SaleItem.hsn,
        func.sum(SaleItem.qty).label('qty'),
        func.sum(SaleItem.base_excl).label('taxable_value'),
        func.avg(SaleItem.gst_rate).label('gst_rate'),
        func.sum(SaleItem.tax_amt_info).label('tax_amount')
    ).join(Sale).filter(
        Sale.bill_date >= from_date,
        Sale.bill_date <= datetime.combine(to_date, datetime.max.time())
    ).group_by(SaleItem.hsn).all()
    
    if export:
        # Create multi-sheet Excel
        output = io.BytesIO()
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            # Summary sheet
            summary_data = {
                'Output Tax CGST': float(sales_gst.cgst_amount or 0),
                'Output Tax SGST': float(sales_gst.sgst_amount or 0),
                'Output Tax IGST': float(sales_gst.igst_amount or 0),
                'Input Tax CGST': float(purchase_gst.cgst_input or 0),
                'Input Tax SGST': float(purchase_gst.sgst_input or 0),
                'Input Tax IGST': float(purchase_gst.igst_input or 0),
                'Net CGST Payable': float((sales_gst.cgst_amount or 0) - (purchase_gst.cgst_input or 0)),
                'Net SGST Payable': float((sales_gst.sgst_amount or 0) - (purchase_gst.sgst_input or 0)),
                'Net IGST Payable': float((sales_gst.igst_amount or 0) - (purchase_gst.igst_input or 0))
            }
            pd.DataFrame([summary_data]).to_excel(writer, sheet_name='GST_Summary', index=False)
            
            # HSN summary sheet
            hsn_df = pd.DataFrame([{
                'HSN': h.hsn or 'N/A',
                'Quantity': h.qty,
                'Taxable Value': float(h.taxable_value),
                'GST Rate': float(h.gst_rate),
                'Tax Amount': float(h.tax_amount)
            } for h in hsn_summary])
            hsn_df.to_excel(writer, sheet_name='HSN_Summary', index=False)
        
        output.seek(0)
        
        return Response(
            content=output.read(),
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={
                "Content-Disposition": f"attachment; filename=gst_report_{from_date}_{to_date}.xlsx"
            }
        )
    
    return {
        "period": {"from": from_date, "to": to_date},
        "output_tax": {
            "cgst": float(sales_gst.cgst_amount or 0),
            "sgst": float(sales_gst.sgst_amount or 0),
            "igst": float(sales_gst.igst_amount or 0),
            "total": float((sales_gst.cgst_amount or 0) + (sales_gst.sgst_amount or 0) + (sales_gst.igst_amount or 0))
        },
        "input_tax": {
            "cgst": float(purchase_gst.cgst_input or 0),
            "sgst": float(purchase_gst.sgst_input or 0),
            "igst": float(purchase_gst.igst_input or 0),
            "total": float((purchase_gst.cgst_input or 0) + (purchase_gst.sgst_input or 0) + (purchase_gst.igst_input or 0))
        },
        "net_payable": {
            "cgst": float((sales_gst.cgst_amount or 0) - (purchase_gst.cgst_input or 0)),
            "sgst": float((sales_gst.sgst_amount or 0) - (purchase_gst.sgst_input or 0)),
            "igst": float((sales_gst.igst_amount or 0) - (purchase_gst.igst_input or 0))
        },
        "hsn_summary": [
            {
                "hsn": h.hsn or 'N/A',
                "qty": h.qty,
                "taxable_value": float(h.taxable_value),
                "gst_rate": float(h.gst_rate),
                "tax_amount": float(h.tax_amount)
            } for h in hsn_summary
        ]
    }

# =====================================
# Staff Performance Reports

@router.get("/staff/performance")
async def get_staff_performance_report(
    from_date: date,
    to_date: date,
    export: bool = False,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get staff performance report with target achievement"""
    
    staff_list = db.query(Staff).filter(Staff.active == True).all()
    
    performance_data = []
    
    for staff in staff_list:
        # Get sales
        sales = db.query(
            func.count(Sale.id).label('bill_count'),
            func.sum(Sale.final_payable).label('total_sales')
        ).filter(
            Sale.staff_id == staff.id,
            Sale.bill_date >= from_date,
            Sale.bill_date <= datetime.combine(to_date, datetime.max.time())
        ).first()
        
        # Get target
        target = db.query(StaffTarget).filter(
            StaffTarget.staff_id == staff.id,
            StaffTarget.period_start <= from_date,
            StaffTarget.period_end >= to_date
        ).first()
        
        achievement = 0
        if target and target.target_amount > 0 and sales.total_sales:
            achievement = (sales.total_sales / target.target_amount * 100)
        
        performance_data.append({
            "staff_code": staff.code,
            "staff_name": staff.name,
            "role": staff.role,
            "bills": sales.bill_count or 0,
            "sales": float(sales.total_sales or 0),
            "target": float(target.target_amount) if target else 0,
            "achievement": float(achievement),
            "commission_eligible": staff.commission_enabled
        })
    
    # Sort by sales
    performance_data.sort(key=lambda x: x['sales'], reverse=True)
    
    if export:
        df = pd.DataFrame(performance_data)
        output = io.BytesIO()
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            df.to_excel(writer, sheet_name='Staff_Performance', index=False)
        output.seek(0)
        
        return Response(
            content=output.read(),
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={
                "Content-Disposition": f"attachment; filename=staff_performance_{from_date}_{to_date}.xlsx"
            }
        )
    
    return {
        "period": {"from": from_date, "to": to_date},
        "staff_count": len(performance_data),
        "total_sales": sum(s['sales'] for s in performance_data),
        "performance": performance_data
    }

# =====================================
# Profit & Loss Report

@router.get("/profit-loss")
async def get_profit_loss_report(
    from_date: date,
    to_date: date,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get profit and loss report"""
    
    # Revenue (Sales)
    sales_revenue = db.query(
        func.sum(Sale.final_payable).label('gross_sales'),
        func.sum(Sale.discount_incl).label('discounts'),
        func.sum(Sale.coupon_incl).label('coupons')
    ).filter(
        Sale.bill_date >= from_date,
        Sale.bill_date <= datetime.combine(to_date, datetime.max.time())
    ).first()
    
    # Returns
    sales_returns = db.query(
        func.sum(SaleReturn.total_incl)
    ).filter(
        SaleReturn.sr_date >= from_date,
        SaleReturn.sr_date <= datetime.combine(to_date, datetime.max.time())
    ).scalar() or Decimal('0')
    
    # Cost of Goods Sold (based on purchase rate)
    cogs_query = db.query(
        func.sum(SaleItem.qty * Item.purchase_rate_basic).label('cogs')
    ).join(Sale, Item).filter(
        Sale.bill_date >= from_date,
        Sale.bill_date <= datetime.combine(to_date, datetime.max.time())
    ).first()
    
    # Expenses
    expenses = db.query(
        ExpenseHead.category,
        func.sum(Expense.amount).label('amount')
    ).join(ExpenseHead).filter(
        Expense.date >= from_date,
        Expense.date <= to_date,
        Expense.status.in_(['approved', 'pending'])
    ).group_by(ExpenseHead.category).all()
    
    # Calculate totals
    gross_sales = sales_revenue.gross_sales or Decimal('0')
    discounts = sales_revenue.discounts or Decimal('0')
    coupons = sales_revenue.coupons or Decimal('0')
    net_sales = gross_sales - sales_returns
    cogs = cogs_query.cogs or Decimal('0')
    gross_profit = net_sales - cogs
    
    total_expenses = sum(e.amount for e in expenses)
    net_profit = gross_profit - total_expenses
    
    # Margins
    gross_margin = (gross_profit / net_sales * 100) if net_sales > 0 else 0
    net_margin = (net_profit / net_sales * 100) if net_sales > 0 else 0
    
    return {
        "period": {"from": from_date, "to": to_date},
        "revenue": {
            "gross_sales": float(gross_sales),
            "discounts": float(discounts),
            "coupons": float(coupons),
            "returns": float(sales_returns),
            "net_sales": float(net_sales)
        },
        "costs": {
            "cogs": float(cogs),
            "gross_profit": float(gross_profit),
            "gross_margin": float(gross_margin)
        },
        "expenses": [
            {"category": e.category, "amount": float(e.amount)}
            for e in expenses
        ],
        "total_expenses": float(total_expenses),
        "net_profit": float(net_profit),
        "net_margin": float(net_margin)
    }

# =====================================
# Dashboard Metrics

@router.get("/dashboard/metrics")
async def get_dashboard_metrics(
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get key metrics for dashboard"""
    
    today = date.today()
    month_start = today.replace(day=1)
    
    # Today's metrics
    today_sales = db.query(
        func.count(Sale.id).label('bills'),
        func.sum(Sale.final_payable).label('amount')
    ).filter(
        func.date(Sale.bill_date) == today
    ).first()
    
    # Month metrics
    month_sales = db.query(
        func.count(Sale.id).label('bills'),
        func.sum(Sale.final_payable).label('amount')
    ).filter(
        Sale.bill_date >= month_start
    ).first()
    
    # Stock metrics
    low_stock_items = db.query(func.count(Stock.barcode)).filter(
        Stock.qty_on_hand < 10
    ).scalar()
    
    total_stock_value = db.query(
        func.sum(Stock.qty_on_hand * Item.purchase_rate_basic)
    ).join(Item).scalar() or Decimal('0')
    
    # Customer metrics
    total_customers = db.query(func.count(Customer.mobile)).scalar()
    new_customers_month = db.query(func.count(Customer.mobile)).filter(
        Customer.created_at >= month_start
    ).scalar()
    
    # Pending approvals
    pending_expenses = db.query(func.count(Expense.id)).filter(
        Expense.status == 'pending'
    ).scalar()
    
    # Top selling items today
    top_items = db.query(
        Item.style_code,
        func.sum(SaleItem.qty).label('qty')
    ).join(SaleItem, Sale).filter(
        func.date(Sale.bill_date) == today
    ).group_by(Item.style_code).order_by(
        func.sum(SaleItem.qty).desc()
    ).limit(5).all()
    
    return {
        "today": {
            "sales_count": today_sales.bills or 0,
            "sales_amount": float(today_sales.amount or 0),
            "date": today
        },
        "month": {
            "sales_count": month_sales.bills or 0,
            "sales_amount": float(month_sales.amount or 0),
            "month": today.strftime("%B %Y")
        },
        "inventory": {
            "low_stock_items": low_stock_items,
            "total_value": float(total_stock_value)
        },
        "customers": {
            "total": total_customers,
            "new_this_month": new_customers_month
        },
        "pending": {
            "expenses": pending_expenses
        },
        "top_selling_today": [
            {"style": item.style_code, "qty": item.qty}
            for item in top_items
        ]
    }

# =====================================
# Export All Reports

@router.get("/export/complete-report")
async def export_complete_report(
    from_date: date,
    to_date: date,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Export complete business report with multiple sheets"""
    
    output = io.BytesIO()
    
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        # Sales summary
        sales_summary = await get_sales_summary(from_date, to_date, "date", db, current_user)
        pd.DataFrame(sales_summary['summary']).to_excel(
            writer, sheet_name='Sales_Summary', index=False
        )
        
        # Stock summary
        stock_data = await get_current_stock_report(db=db, current_user=current_user)
        pd.DataFrame([{
            'Total Items': stock_data['total_items'],
            'Total Quantity': stock_data['total_quantity'],
            'Stock Value': stock_data['total_stock_value'],
            'Retail Value': stock_data['total_retail_value']
        }]).to_excel(writer, sheet_name='Stock_Summary', index=False)
        
        # Customer summary
        customer_data = await get_customer_analysis_report(from_date, to_date, db=db, current_user=current_user)
        pd.DataFrame(customer_data['top_customers']).to_excel(
            writer, sheet_name='Top_Customers', index=False
        )
        
        # Staff performance
        staff_data = await get_staff_performance_report(from_date, to_date, db=db, current_user=current_user)
        pd.DataFrame(staff_data['performance']).to_excel(
            writer, sheet_name='Staff_Performance', index=False
        )
        
        # P&L
        pl_data = await get_profit_loss_report(from_date, to_date, db, current_user)
        pl_df = pd.DataFrame([{
            'Net Sales': pl_data['revenue']['net_sales'],
            'COGS': pl_data['costs']['cogs'],
            'Gross Profit': pl_data['costs']['gross_profit'],
            'Total Expenses': pl_data['total_expenses'],
            'Net Profit': pl_data['net_profit'],
            'Net Margin %': pl_data['net_margin']
        }])
        pl_df.to_excel(writer, sheet_name='Profit_Loss', index=False)
    
    output.seek(0)
    
    return Response(
        content=output.read(),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={
            "Content-Disposition": f"attachment; filename=complete_report_{from_date}_{to_date}.xlsx"
        }
    )