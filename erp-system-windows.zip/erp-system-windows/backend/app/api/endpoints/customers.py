from fastapi import APIRouter, Depends, HTTPException, Query, UploadFile, File, Response
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, func, extract
from typing import List, Optional, Dict
from datetime import datetime, date, timedelta
from decimal import Decimal
import pandas as pd
import io
import uuid

from ...database import get_db
from ...models import (
    Customer, Sale, SaleReturn, ReturnCredit, LoyaltyGrade,
    PointTransaction, Coupon
)
from ...services.excel_service import ExcelService
from ...services.loyalty_service import LoyaltyService
from ...services.whatsapp_service import WhatsAppService
from ...core.security import get_current_user
from ...core.constants import ReturnCreditStatus
from ...schemas.customer_schema import (
    CustomerCreate, CustomerUpdate, CustomerResponse, CustomerDetailResponse,
    CustomerImportResponse, LoyaltyGradeCreate, LoyaltyGradeResponse,
    CustomerActivityResponse, CustomerBirthdayResponse
)

router = APIRouter()

@router.post("/", response_model=CustomerResponse)
async def create_customer(
    customer_data: CustomerCreate,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Create a new customer"""
    # Check if mobile already exists
    existing = db.query(Customer).filter(Customer.mobile == customer_data.mobile).first()
    if existing:
        raise HTTPException(status_code=400, detail="Mobile number already registered")
    
    # Get default loyalty grade
    default_grade = db.query(LoyaltyGrade).order_by(LoyaltyGrade.amount_from).first()
    
    customer = Customer(
        mobile=customer_data.mobile,
        name=customer_data.name,
        email=customer_data.email,
        kid1_name=customer_data.kid1_name,
        kid1_dob=customer_data.kid1_dob,
        kid2_name=customer_data.kid2_name,
        kid2_dob=customer_data.kid2_dob,
        kid3_name=customer_data.kid3_name,
        kid3_dob=customer_data.kid3_dob,
        address=customer_data.address,
        city=customer_data.city,
        lifetime_purchase=Decimal('0'),
        points_balance=0,
        grade=default_grade.name if default_grade else "Silver",
        created_at=datetime.utcnow()
    )
    
    db.add(customer)
    db.commit()
    db.refresh(customer)
    
    return customer

@router.get("/", response_model=List[CustomerResponse])
async def get_customers(
    skip: int = 0,
    limit: int = 100,
    search: Optional[str] = None,
    city: Optional[str] = None,
    grade: Optional[str] = None,
    inactive_months: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get all customers with filters"""
    query = db.query(Customer)
    
    # Search by mobile, name, or email
    if search:
        query = query.filter(
            or_(
                Customer.mobile.contains(search),
                Customer.name.ilike(f"%{search}%"),
                Customer.email.ilike(f"%{search}%")
            )
        )
    
    # Filter by city
    if city:
        query = query.filter(Customer.city.ilike(f"%{city}%"))
    
    # Filter by grade
    if grade:
        query = query.filter(Customer.grade == grade)
    
    # Filter inactive customers
    if inactive_months:
        cutoff_date = datetime.utcnow() - timedelta(days=inactive_months * 30)
        
        # Get customers with no recent purchases
        inactive_mobiles = db.query(Customer.mobile).outerjoin(
            Sale, Customer.mobile == Sale.customer_mobile
        ).group_by(Customer.mobile).having(
            or_(
                func.max(Sale.bill_date) < cutoff_date,
                func.max(Sale.bill_date).is_(None)
            )
        ).subquery()
        
        query = query.filter(Customer.mobile.in_(inactive_mobiles))
    
    customers = query.offset(skip).limit(limit).all()
    return customers

@router.get("/{mobile}", response_model=CustomerDetailResponse)
async def get_customer_details(
    mobile: str,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get detailed customer information"""
    if len(mobile) != 10:
        raise HTTPException(status_code=400, detail="Invalid mobile number")
    
    customer = db.query(Customer).filter(Customer.mobile == mobile).first()
    
    if not customer:
        raise HTTPException(status_code=404, detail="Customer not found")
    
    # Get purchase statistics
    purchase_stats = db.query(
        func.count(Sale.id).label('total_bills'),
        func.sum(Sale.final_payable).label('total_purchase'),
        func.max(Sale.bill_date).label('last_purchase')
    ).filter(Sale.customer_mobile == mobile).first()
    
    # Get return statistics
    return_stats = db.query(
        func.count(SaleReturn.id).label('total_returns'),
        func.sum(SaleReturn.total_incl).label('total_return_amount')
    ).filter(SaleReturn.customer_mobile == mobile).first()
    
    # Get open return credits
    open_credits = db.query(ReturnCredit).filter(
        ReturnCredit.customer_mobile == mobile,
        ReturnCredit.status.in_(['open', 'partial'])
    ).all()
    
    # Get loyalty transactions
    recent_points = db.query(PointTransaction).filter(
        PointTransaction.customer_mobile == mobile
    ).order_by(PointTransaction.created_at.desc()).limit(10).all()
    
    # Get active coupons
    active_coupons = db.query(Coupon).filter(
        Coupon.bound_mobile == mobile,
        Coupon.active == True,
        or_(
            Coupon.valid_to >= date.today(),
            Coupon.valid_to.is_(None)
        )
    ).all()
    
    # Calculate age of kids
    kids_info = []
    if customer.kid1_name and customer.kid1_dob:
        age = (date.today() - customer.kid1_dob).days // 365
        kids_info.append({
            "name": customer.kid1_name,
            "dob": customer.kid1_dob,
            "age": age
        })
    if customer.kid2_name and customer.kid2_dob:
        age = (date.today() - customer.kid2_dob).days // 365
        kids_info.append({
            "name": customer.kid2_name,
            "dob": customer.kid2_dob,
            "age": age
        })
    if customer.kid3_name and customer.kid3_dob:
        age = (date.today() - customer.kid3_dob).days // 365
        kids_info.append({
            "name": customer.kid3_name,
            "dob": customer.kid3_dob,
            "age": age
        })
    
    return CustomerDetailResponse(
        mobile=customer.mobile,
        name=customer.name,
        email=customer.email,
        address=customer.address,
        city=customer.city,
        kids_info=kids_info,
        lifetime_purchase=customer.lifetime_purchase,
        points_balance=customer.points_balance,
        grade=customer.grade,
        total_bills=purchase_stats.total_bills or 0,
        total_purchase=purchase_stats.total_purchase or Decimal('0'),
        last_purchase_date=purchase_stats.last_purchase,
        total_returns=return_stats.total_returns or 0,
        total_return_amount=return_stats.total_return_amount or Decimal('0'),
        open_return_credits=[{
            "rc_no": rc.rc_no,
            "amount": rc.rc_amount_incl,
            "created_date": rc.created_at
        } for rc in open_credits],
        recent_point_transactions=[{
            "date": pt.created_at,
            "type": pt.transaction_type,
            "points": pt.points,
            "reference": pt.reference_type
        } for pt in recent_points],
        active_coupons=[{
            "code": c.code,
            "type": c.type,
            "value": c.value,
            "valid_till": c.valid_to
        } for c in active_coupons],
        created_at=customer.created_at
    )

@router.put("/{mobile}", response_model=CustomerResponse)
async def update_customer(
    mobile: str,
    customer_update: CustomerUpdate,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Update customer information"""
    customer = db.query(Customer).filter(Customer.mobile == mobile).first()
    
    if not customer:
        raise HTTPException(status_code=404, detail="Customer not found")
    
    # Update fields
    for field, value in customer_update.dict(exclude_unset=True).items():
        setattr(customer, field, value)
    
    customer.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(customer)
    
    return customer

@router.get("/birthdays/today")
async def get_todays_birthdays(
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get customers with kids having birthday today"""
    today = date.today()
    
    customers = db.query(Customer).filter(
        or_(
            and_(
                extract('month', Customer.kid1_dob) == today.month,
                extract('day', Customer.kid1_dob) == today.day
            ),
            and_(
                extract('month', Customer.kid2_dob) == today.month,
                extract('day', Customer.kid2_dob) == today.day
            ),
            and_(
                extract('month', Customer.kid3_dob) == today.month,
                extract('day', Customer.kid3_dob) == today.day
            )
        )
    ).all()
    
    result = []
    for customer in customers:
        birthday_kids = []
        
        if customer.kid1_dob and customer.kid1_dob.month == today.month and customer.kid1_dob.day == today.day:
            age = today.year - customer.kid1_dob.year
            birthday_kids.append({"name": customer.kid1_name, "age": age})
        
        if customer.kid2_dob and customer.kid2_dob.month == today.month and customer.kid2_dob.day == today.day:
            age = today.year - customer.kid2_dob.year
            birthday_kids.append({"name": customer.kid2_name, "age": age})
        
        if customer.kid3_dob and customer.kid3_dob.month == today.month and customer.kid3_dob.day == today.day:
            age = today.year - customer.kid3_dob.year
            birthday_kids.append({"name": customer.kid3_name, "age": age})
        
        if birthday_kids:
            result.append({
                "customer_mobile": customer.mobile,
                "customer_name": customer.name,
                "email": customer.email,
                "birthday_kids": birthday_kids
            })
    
    return result

@router.get("/birthdays/upcoming")
async def get_upcoming_birthdays(
    days: int = 30,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get customers with kids having birthdays in next N days"""
    today = date.today()
    end_date = today + timedelta(days=days)
    
    # This query handles year boundary (e.g., December to January)
    customers = db.query(Customer).filter(
        or_(
            Customer.kid1_dob.isnot(None),
            Customer.kid2_dob.isnot(None),
            Customer.kid3_dob.isnot(None)
        )
    ).all()
    
    result = []
    for customer in customers:
        upcoming_birthdays = []
        
        # Check each kid's birthday
        for kid_name, kid_dob in [
            (customer.kid1_name, customer.kid1_dob),
            (customer.kid2_name, customer.kid2_dob),
            (customer.kid3_name, customer.kid3_dob)
        ]:
            if kid_dob:
                # Create birthday date for current/next year
                this_year_bday = date(today.year, kid_dob.month, kid_dob.day)
                if this_year_bday < today:
                    this_year_bday = date(today.year + 1, kid_dob.month, kid_dob.day)
                
                # Check if within range
                if today <= this_year_bday <= end_date:
                    age = this_year_bday.year - kid_dob.year
                    days_until = (this_year_bday - today).days
                    upcoming_birthdays.append({
                        "name": kid_name,
                        "date": this_year_bday,
                        "age": age,
                        "days_until": days_until
                    })
        
        if upcoming_birthdays:
            result.append({
                "customer_mobile": customer.mobile,
                "customer_name": customer.name,
                "email": customer.email,
                "upcoming_birthdays": upcoming_birthdays
            })
    
    # Sort by nearest birthday
    result.sort(key=lambda x: min(b['days_until'] for b in x['upcoming_birthdays']))
    
    return result

@router.get("/inactive/{months}")
async def get_inactive_customers(
    months: int,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get customers inactive for specified months"""
    cutoff_date = datetime.utcnow() - timedelta(days=months * 30)
    
    # Get all customers with their last purchase date
    customers_with_last_purchase = db.query(
        Customer,
        func.max(Sale.bill_date).label('last_purchase')
    ).outerjoin(
        Sale, Customer.mobile == Sale.customer_mobile
    ).group_by(Customer.mobile).all()
    
    inactive_customers = []
    for customer, last_purchase in customers_with_last_purchase:
        if not last_purchase or last_purchase < cutoff_date:
            days_inactive = (datetime.utcnow() - (last_purchase or customer.created_at)).days
            inactive_customers.append({
                "mobile": customer.mobile,
                "name": customer.name,
                "email": customer.email,
                "city": customer.city,
                "grade": customer.grade,
                "lifetime_purchase": float(customer.lifetime_purchase),
                "points_balance": customer.points_balance,
                "last_purchase_date": last_purchase,
                "days_inactive": days_inactive
            })
    
    return inactive_customers

@router.post("/import", response_model=CustomerImportResponse)
async def import_customers(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Import customers from Excel file"""
    if not file.filename.endswith(('.xlsx', '.xls')):
        raise HTTPException(status_code=400, detail="Only Excel files are allowed")
    
    content = await file.read()
    
    try:
        df = pd.read_excel(io.BytesIO(content))
        df.columns = df.columns.str.strip().str.upper()
        
        required_columns = ['MOBILE', 'NAME']
        missing_columns = [col for col in required_columns if col not in df.columns]
        
        if missing_columns:
            raise HTTPException(
                status_code=400,
                detail=f"Missing required columns: {', '.join(missing_columns)}"
            )
        
        imported = 0
        updated = 0
        errors = []
        
        # Get default grade
        default_grade = db.query(LoyaltyGrade).order_by(LoyaltyGrade.amount_from).first()
        
        for idx, row in df.iterrows():
            try:
                mobile = str(row['MOBILE']).strip()
                
                # Validate mobile
                if len(mobile) != 10 or not mobile.isdigit():
                    errors.append(f"Row {idx+2}: Invalid mobile number {mobile}")
                    continue
                
                existing = db.query(Customer).filter(Customer.mobile == mobile).first()
                
                if existing:
                    # Update existing customer
                    existing.name = str(row.get('NAME', '')).strip()
                    if 'EMAIL' in row and pd.notna(row['EMAIL']):
                        existing.email = str(row['EMAIL']).strip()
                    if 'ADDRESS' in row and pd.notna(row['ADDRESS']):
                        existing.address = str(row['ADDRESS']).strip()
                    if 'CITY' in row and pd.notna(row['CITY']):
                        existing.city = str(row['CITY']).strip()
                    
                    # Kids information
                    if 'KID1_NAME' in row and pd.notna(row['KID1_NAME']):
                        existing.kid1_name = str(row['KID1_NAME']).strip()
                    if 'KID1_DOB' in row and pd.notna(row['KID1_DOB']):
                        existing.kid1_dob = pd.to_datetime(row['KID1_DOB']).date()
                    
                    existing.updated_at = datetime.utcnow()
                    updated += 1
                else:
                    # Create new customer
                    new_customer = Customer(
                        mobile=mobile,
                        name=str(row.get('NAME', '')).strip(),
                        email=str(row.get('EMAIL', '')).strip() if 'EMAIL' in row and pd.notna(row['EMAIL']) else None,
                        address=str(row.get('ADDRESS', '')).strip() if 'ADDRESS' in row and pd.notna(row['ADDRESS']) else None,
                        city=str(row.get('CITY', '')).strip() if 'CITY' in row and pd.notna(row['CITY']) else None,
                        kid1_name=str(row.get('KID1_NAME', '')).strip() if 'KID1_NAME' in row and pd.notna(row['KID1_NAME']) else None,
                        kid1_dob=pd.to_datetime(row['KID1_DOB']).date() if 'KID1_DOB' in row and pd.notna(row['KID1_DOB']) else None,
                        kid2_name=str(row.get('KID2_NAME', '')).strip() if 'KID2_NAME' in row and pd.notna(row['KID2_NAME']) else None,
                        kid2_dob=pd.to_datetime(row['KID2_DOB']).date() if 'KID2_DOB' in row and pd.notna(row['KID2_DOB']) else None,
                        kid3_name=str(row.get('KID3_NAME', '')).strip() if 'KID3_NAME' in row and pd.notna(row['KID3_NAME']) else None,
                        kid3_dob=pd.to_datetime(row['KID3_DOB']).date() if 'KID3_DOB' in row and pd.notna(row['KID3_DOB']) else None,
                        lifetime_purchase=Decimal('0'),
                        points_balance=0,
                        grade=default_grade.name if default_grade else "Silver"
                    )
                    db.add(new_customer)
                    imported += 1
                    
            except Exception as e:
                errors.append(f"Row {idx+2}: {str(e)}")
        
        db.commit()
        
        return CustomerImportResponse(
            success=True,
            imported=imported,
            updated=updated,
            errors=errors
        )
        
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Error processing file: {str(e)}")

@router.get("/export/template")
async def export_customer_template():
    """Download Excel template for customer import"""
    columns = [
        'MOBILE', 'NAME', 'EMAIL', 'ADDRESS', 'CITY',
        'KID1_NAME', 'KID1_DOB', 'KID2_NAME', 'KID2_DOB',
        'KID3_NAME', 'KID3_DOB'
    ]
    
    sample_data = {
        'MOBILE': '9876543210',
        'NAME': 'John Doe',
        'EMAIL': 'john@example.com',
        'ADDRESS': '123 Main Street',
        'CITY': 'Mumbai',
        'KID1_NAME': 'Alice',
        'KID1_DOB': '2015-05-15',
        'KID2_NAME': 'Bob',
        'KID2_DOB': '2018-08-20',
        'KID3_NAME': '',
        'KID3_DOB': ''
    }
    
    df = pd.DataFrame([sample_data])
    
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, sheet_name='Customers', index=False)
    
    output.seek(0)
    
    return Response(
        content=output.read(),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={
            "Content-Disposition": f"attachment; filename=customer_template_{datetime.now().strftime('%Y%m%d')}.xlsx"
        }
    )

@router.post("/send-birthday-wishes")
async def send_birthday_wishes(
    mobile: str,
    kid_name: str,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Send birthday wishes via WhatsApp"""
    customer = db.query(Customer).filter(Customer.mobile == mobile).first()
    
    if not customer:
        raise HTTPException(status_code=404, detail="Customer not found")
    
    try:
        WhatsAppService.send_birthday_wishes(mobile, customer.name, kid_name)
        return {"success": True, "message": "Birthday wishes sent successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to send wishes: {str(e)}")