from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Query, Response
from sqlalchemy.orm import Session
from typing import List, Optional, Dict, Any
from datetime import datetime
import uuid

from ...database import get_db
from ...models import Item, Stock, Company
from ...services.excel_service import ExcelService
from ...services.stock_service import StockService
from ...core.security import get_current_user
from ...schemas.item_schema import ItemCreate, ItemUpdate, ItemResponse, ItemImportResponse, StockResponse, StockUpdate

router = APIRouter()

@router.post("/", response_model=ItemResponse)
async def create_item(
    item: ItemCreate,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Create a new item"""
    # Check if barcode already exists
    existing = db.query(Item).filter(Item.barcode == item.barcode).first()
    if existing:
        raise HTTPException(status_code=400, detail="Barcode already exists")
    
    db_item = Item(
        barcode=item.barcode,
        style_code=item.style_code,
        color=item.color,
        size=item.size,
        hsn=item.hsn,
        mrp_incl=item.mrp_incl,
        purchase_rate_basic=item.purchase_rate_basic,
        brand=item.brand,
        gender=item.gender,
        category=item.category,
        sub_category=item.sub_category,
        status=item.status,
        company_id=current_user.company_id
    )
    
    db.add(db_item)
    
    # Create stock entry
    stock = Stock(barcode=item.barcode, qty_on_hand=0)
    db.add(stock)
    
    db.commit()
    db.refresh(db_item)
    
    return db_item

@router.get("/", response_model=List[ItemResponse])
async def get_items(
    skip: int = 0,
    limit: int = 100,
    search: Optional[str] = None,
    status: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get all items with optional filters"""
    query = db.query(Item).filter(Item.company_id == current_user.company_id)
    
    if search:
        query = query.filter(
            (Item.barcode.contains(search)) |
            (Item.style_code.contains(search)) |
            (Item.brand.contains(search))
        )
    
    if status:
        query = query.filter(Item.status == status)
    
    items = query.offset(skip).limit(limit).all()
    return items

@router.get("/{barcode}", response_model=ItemResponse)
async def get_item(
    barcode: str,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get item by barcode"""
    item = db.query(Item).filter(
        Item.barcode == barcode,
        Item.company_id == current_user.company_id
    ).first()
    
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    
    return item

@router.put("/{barcode}", response_model=ItemResponse)
async def update_item(
    barcode: str,
    item_update: ItemUpdate,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Update item"""
    item = db.query(Item).filter(
        Item.barcode == barcode,
        Item.company_id == current_user.company_id
    ).first()
    
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    
    for field, value in item_update.dict(exclude_unset=True).items():
        setattr(item, field, value)
    
    item.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(item)
    
    return item

@router.get("/export/template")
async def export_item_template():
    """Download Excel template for item import"""
    excel_content = ExcelService.create_item_master_template()
    
    return Response(
        content=excel_content,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={
            "Content-Disposition": f"attachment; filename=item_master_template_{datetime.now().strftime('%Y%m%d')}.xlsx"
        }
    )

@router.post("/import", response_model=ItemImportResponse)
async def import_items(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Import items from Excel file"""
    if not file.filename.endswith(('.xlsx', '.xls')):
        raise HTTPException(status_code=400, detail="Only Excel files are allowed")
    
    content = await file.read()
    items, errors = ExcelService.import_items_from_excel(content)
    
    if errors and not items:
        return ItemImportResponse(
            success=False,
            imported=0,
            updated=0,
            errors=errors
        )
    
    imported = 0
    updated = 0
    
    for item_data in items:
        existing = db.query(Item).filter(Item.barcode == item_data['barcode']).first()
        
        if existing:
            # Update existing item
            for field, value in item_data.items():
                if value is not None:
                    setattr(existing, field, value)
            existing.updated_at = datetime.utcnow()
            updated += 1
        else:
            # Create new item
            new_item = Item(**item_data, company_id=current_user.company_id)
            db.add(new_item)
            
            # Create stock entry
            stock = Stock(barcode=item_data['barcode'], qty_on_hand=0)
            db.add(stock)
            
            imported += 1
    
    db.commit()
    
    return ItemImportResponse(
        success=True,
        imported=imported,
        updated=updated,
        errors=errors
    )

@router.get("/stock/{barcode}", response_model=StockResponse)
async def get_stock(
    barcode: str,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get stock for an item"""
    stock = db.query(Stock).filter(Stock.barcode == barcode).first()
    
    if not stock:
        raise HTTPException(status_code=404, detail="Stock information not found")
    
    return stock

@router.post("/stock/opening")
async def update_opening_stock(
    stock_data: List[StockUpdate],
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Update opening stock for multiple items"""
    stock_list = [{'barcode': item.barcode, 'qty': item.qty} for item in stock_data]
    result = StockService.bulk_update_opening_stock(db, stock_list)
    return result

@router.post("/stock/opening/import")
async def import_opening_stock(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Import opening stock from Excel (BARCODE, QTY)"""
    if not file.filename.endswith(('.xlsx', '.xls')):
        raise HTTPException(status_code=400, detail="Only Excel files are allowed")
    
    content = await file.read()
    items, errors = ExcelService.import_purchase_order(content)
    
    if errors and not items:
        return {"success": False, "errors": errors}
    
    result = StockService.bulk_update_opening_stock(db, items)
    result['errors'].extend(errors)
    
    return {
        "success": True,
        "updated": result['updated'],
        "errors": result['errors']
    }

@router.post("/stock/adjust/{barcode}")
async def adjust_stock(
    barcode: str,
    qty_change: int,
    operation: str = "add",  # add or subtract
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Manually adjust stock for an item"""
    try:
        stock = StockService.update_stock(db, barcode, abs(qty_change), operation)
        return {
            "success": True,
            "barcode": stock.barcode,
            "new_qty": stock.qty_on_hand,
            "last_updated": stock.last_updated
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))