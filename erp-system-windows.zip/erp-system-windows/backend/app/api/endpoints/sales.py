from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, func
from typing import List, Optional, Dict, Any
from datetime import datetime, date, timedelta
from decimal import Decimal
import uuid
import random
import string

from ...database import get_db
from ...models import (
    Sale, SaleItem, SalePayment, SaleReturn, SaleReturnItem, ReturnCredit,
    Customer, Item, Stock, BillSeries, PaymentMode, Coupon, LoyaltyGrade,
    PointTransaction, Staff
)
from ...services.gst_service import GSTService
from ...services.stock_service import StockService
from ...services.loyalty_service import LoyaltyService
from ...services.whatsapp_service import WhatsAppService
from ...core.security import get_current_user
from ...core.constants import TaxRegion, ReturnCreditStatus, CouponType
from ...schemas.sales_schema import (
    SaleCreate, SaleResponse, SaleItemCreate, PaymentSplit,
    SaleReturnCreate, SaleReturnResponse, ReturnCreditResponse,
    POSSearchResponse, CouponValidateRequest, LoyaltyRedeemRequest
)

router = APIRouter()

def get_next_bill_number(db: Session, series_code: str) -> str:
    """Generate next bill number"""
    series = db.query(BillSeries).filter(
        BillSeries.code == series_code,
        BillSeries.active == True
    ).first()
    
    if not series:
        raise HTTPException(status_code=404, detail=f"Bill series {series_code} not found")
    
    bill_no = f"{series.prefix}-{str(series.next_no).zfill(series.width)}"
    series.next_no += 1
    
    return bill_no

@router.post("/pos/search-item")
async def search_item_for_pos(
    barcode: Optional[str] = None,
    style_code: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Search item by barcode or style code for POS"""
    if not barcode and not style_code:
        raise HTTPException(status_code=400, detail="Provide barcode or style_code")
    
    query = db.query(Item).filter(Item.company_id == current_user.company_id)
    
    if barcode:
        item = query.filter(Item.barcode == barcode).first()
        if not item:
            raise HTTPException(status_code=404, detail="Item not found")
        
        # Get stock
        stock = db.query(Stock).filter(Stock.barcode == barcode).first()
        
        return {
            "barcode": item.barcode,
            "style_code": item.style_code,
            "color": item.color,
            "size": item.size,
            "mrp": float(item.mrp_incl) if item.mrp_incl else 0,
            "hsn": item.hsn,
            "available_qty": stock.qty_on_hand if stock else 0,
            "brand": item.brand,
            "category": item.category
        }
    
    # Search by style code - return multiple items
    items = query.filter(Item.style_code.ilike(f"%{style_code}%")).limit(20).all()
    
    result = []
    for item in items:
        stock = db.query(Stock).filter(Stock.barcode == item.barcode).first()
        result.append({
            "barcode": item.barcode,
            "style_code": item.style_code,
            "color": item.color,
            "size": item.size,
            "mrp": float(item.mrp_incl) if item.mrp_incl else 0,
            "hsn": item.hsn,
            "available_qty": stock.qty_on_hand if stock else 0
        })
    
    return result

@router.post("/pos/search-customer")
async def search_customer(
    mobile: str,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Search customer by mobile number"""
    if len(mobile) != 10:
        raise HTTPException(status_code=400, detail="Mobile number must be 10 digits")
    
    customer = db.query(Customer).filter(Customer.mobile == mobile).first()
    
    if not customer:
        return {
            "found": False,
            "mobile": mobile,
            "message": "Customer not found. You can create new customer."
        }
    
    # Get current loyalty grade
    loyalty_grade = None
    if customer.grade:
        loyalty_grade = db.query(LoyaltyGrade).filter(
            LoyaltyGrade.name == customer.grade
        ).first()
    
    return {
        "found": True,
        "mobile": customer.mobile,
        "name": customer.name,
        "email": customer.email,
        "kid1_name": customer.kid1_name,
        "kid1_dob": customer.kid1_dob,
        "kid2_name": customer.kid2_name,
        "kid2_dob": customer.kid2_dob,
        "kid3_name": customer.kid3_name,
        "kid3_dob": customer.kid3_dob,
        "address": customer.address,
        "city": customer.city,
        "lifetime_purchase": float(customer.lifetime_purchase) if customer.lifetime_purchase else 0,
        "points_balance": customer.points_balance or 0,
        "current_grade": customer.grade,
        "earn_rate": float(loyalty_grade.earn_pct) if loyalty_grade else 1.0
    }

@router.post("/pos/create-customer")
async def create_or_update_customer(
    mobile: str,
    name: str,
    email: Optional[str] = None,
    kid1_name: Optional[str] = None,
    kid1_dob: Optional[date] = None,
    kid2_name: Optional[str] = None,
    kid2_dob: Optional[date] = None,
    kid3_name: Optional[str] = None,
    kid3_dob: Optional[date] = None,
    address: Optional[str] = None,
    city: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Create or update customer"""
    if len(mobile) != 10:
        raise HTTPException(status_code=400, detail="Mobile number must be 10 digits")
    
    customer = db.query(Customer).filter(Customer.mobile == mobile).first()
    
    if customer:
        # Update existing
        customer.name = name
        if email: customer.email = email
        if kid1_name: customer.kid1_name = kid1_name
        if kid1_dob: customer.kid1_dob = kid1_dob
        if kid2_name: customer.kid2_name = kid2_name
        if kid2_dob: customer.kid2_dob = kid2_dob
        if kid3_name: customer.kid3_name = kid3_name
        if kid3_dob: customer.kid3_dob = kid3_dob
        if address: customer.address = address
        if city: customer.city = city
        customer.updated_at = datetime.utcnow()
        
        message = "Customer updated successfully"
    else:
        # Create new with default grade
        customer = Customer(
            mobile=mobile,
            name=name,
            email=email,
            kid1_name=kid1_name,
            kid1_dob=kid1_dob,
            kid2_name=kid2_name,
            kid2_dob=kid2_dob,
            kid3_name=kid3_name,
            kid3_dob=kid3_dob,
            address=address,
            city=city,
            lifetime_purchase=Decimal('0'),
            points_balance=0,
            grade="Silver"  # Default grade
        )
        db.add(customer)
        message = "Customer created successfully"
    
    db.commit()
    
    return {"success": True, "message": message, "mobile": mobile}

@router.post("/pos/validate-coupon")
async def validate_coupon(
    request: CouponValidateRequest,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Validate coupon for POS"""
    coupon = db.query(Coupon).filter(
        Coupon.code == request.coupon_code,
        Coupon.active == True
    ).first()
    
    if not coupon:
        return {"valid": False, "message": "Invalid coupon code"}
    
    # Check validity dates
    today = date.today()
    if coupon.valid_from and today < coupon.valid_from:
        return {"valid": False, "message": "Coupon not yet valid"}
    
    if coupon.valid_to and today > coupon.valid_to:
        return {"valid": False, "message": "Coupon expired"}
    
    # Check minimum bill amount
    if coupon.min_bill and request.bill_amount < coupon.min_bill:
        return {
            "valid": False, 
            "message": f"Minimum bill amount ₹{coupon.min_bill} required"
        }
    
    # Check if bound to mobile
    if coupon.bound_mobile and coupon.bound_mobile != request.customer_mobile:
        return {"valid": False, "message": "Coupon is not valid for this customer"}
    
    # Calculate discount
    if coupon.type == CouponType.PERCENT:
        discount = request.bill_amount * (coupon.value / 100)
        if coupon.max_cap:
            discount = min(discount, coupon.max_cap)
    else:  # FLAT
        discount = min(coupon.value, request.bill_amount)
    
    return {
        "valid": True,
        "coupon_code": coupon.code,
        "type": coupon.type,
        "value": float(coupon.value),
        "max_cap": float(coupon.max_cap) if coupon.max_cap else None,
        "discount_amount": float(discount),
        "message": f"Coupon applied: ₹{discount:.2f} off"
    }

@router.post("/pos/send-otp")
async def send_loyalty_otp(
    mobile: str,
    points_to_redeem: int,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Send OTP for loyalty points redemption"""
    customer = db.query(Customer).filter(Customer.mobile == mobile).first()
    
    if not customer:
        raise HTTPException(status_code=404, detail="Customer not found")
    
    if customer.points_balance < points_to_redeem:
        raise HTTPException(
            status_code=400, 
            detail=f"Insufficient points. Available: {customer.points_balance}"
        )
    
    # Generate OTP
    otp = ''.join(random.choices(string.digits, k=6))
    
    # Store OTP in cache/session (implement based on your caching strategy)
    # For now, we'll return it (in production, never return OTP in response)
    
    # Send via WhatsApp
    try:
        WhatsAppService.send_otp(mobile, otp)
        message = "OTP sent to WhatsApp"
    except:
        message = "OTP could not be sent to WhatsApp"
    
    return {
        "success": True,
        "message": message,
        "otp": otp if current_user.role == "admin" else None,  # Only for testing
        "points_to_redeem": points_to_redeem,
        "points_value": points_to_redeem  # 1 point = ₹1
    }

@router.post("/pos/verify-otp")
async def verify_loyalty_otp(
    mobile: str,
    otp: str,
    points_to_redeem: int,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Verify OTP and confirm points redemption"""
    # In production, verify OTP from cache/session
    # For now, accept any 6-digit OTP
    
    if len(otp) != 6:
        return {"valid": False, "message": "Invalid OTP"}
    
    customer = db.query(Customer).filter(Customer.mobile == mobile).first()
    
    if not customer:
        return {"valid": False, "message": "Customer not found"}
    
    if customer.points_balance < points_to_redeem:
        return {"valid": False, "message": "Insufficient points"}
    
    return {
        "valid": True,
        "message": "OTP verified successfully",
        "points_to_redeem": points_to_redeem,
        "redemption_value": points_to_redeem  # 1 point = ₹1
    }

@router.get("/pos/open-return-credits/{mobile}")
async def get_open_return_credits(
    mobile: str,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get open return credits for a customer"""
    credits = db.query(ReturnCredit).filter(
        ReturnCredit.customer_mobile == mobile,
        ReturnCredit.status.in_(['open', 'partial'])
    ).all()
    
    result = []
    for credit in credits:
        result.append({
            "id": credit.id,
            "rc_no": credit.rc_no,
            "amount": float(credit.rc_amount_incl),
            "status": credit.status,
            "created_date": credit.created_at.strftime("%d-%m-%Y")
        })
    
    return result

@router.post("/pos/sale")
async def create_sale(
    sale_data: SaleCreate,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Create POS sale with all calculations"""
    
    # Generate bill number
    bill_no = get_next_bill_number(db, "SALE")
    
    # Get tax region from company settings
    tax_region = sale_data.tax_region or TaxRegion.LOCAL
    
    # Create sale record
    sale = Sale(
        id=str(uuid.uuid4()),
        series_id=sale_data.series_id,
        bill_no=bill_no,
        bill_date=datetime.utcnow(),
        customer_mobile=sale_data.customer_mobile,
        staff_id=sale_data.staff_id,
        agent_id=sale_data.agent_id,
        tax_region=tax_region,
        created_by=current_user.id
    )
    
    # Process items and calculate GST (inclusive)
    gross_total = Decimal('0')
    discount_total = Decimal('0')
    base_total = Decimal('0')
    tax_total = Decimal('0')
    
    for item_data in sale_data.items:
        # Validate item and stock
        item = db.query(Item).filter(Item.barcode == item_data.barcode).first()
        if not item:
            raise HTTPException(status_code=404, detail=f"Item {item_data.barcode} not found")
        
        # Check stock availability
        if not StockService.check_availability(db, item_data.barcode, item_data.qty):
            stock = db.query(Stock).filter(Stock.barcode == item_data.barcode).first()
            available = stock.qty_on_hand if stock else 0
            raise HTTPException(
                status_code=400,
                detail=f"Insufficient stock for {item_data.barcode}. Available: {available}"
            )
        
        # Calculate GST from inclusive price
        gst_calc = GSTService.extract_gst_from_inclusive(
            mrp_incl=item.mrp_incl,
            qty=item_data.qty,
            discount_pct=item_data.discount_pct or Decimal('0'),
            tax_region=tax_region
        )
        
        # Create sale item
        sale_item = SaleItem(
            id=str(uuid.uuid4()),
            sale_id=sale.id,
            barcode=item_data.barcode,
            style_code=item.style_code,
            color=item.color,
            size=item.size,
            qty=item_data.qty,
            mrp_incl=item.mrp_incl,
            disc_pct=item_data.discount_pct or Decimal('0'),
            line_inclusive=gst_calc['line_inclusive'],
            gst_rate=gst_calc['gst_rate'],
            cgst_rate=gst_calc.get('cgst_rate', Decimal('0')),
            sgst_rate=gst_calc.get('sgst_rate', Decimal('0')),
            igst_rate=gst_calc.get('igst_rate', Decimal('0')),
            hsn=item.hsn,
            base_excl=gst_calc['base_excl'],
            tax_amt_info=gst_calc['tax_amount']
        )
        
        sale.items.append(sale_item)
        
        # Update totals
        line_gross = item.mrp_incl * item_data.qty
        line_discount = line_gross - gst_calc['line_inclusive']
        
        gross_total += line_gross
        discount_total += line_discount
        base_total += gst_calc['base_excl']
        tax_total += gst_calc['tax_amount']
    
    # Set sale totals before coupon
    sale.gross_incl = gross_total
    sale.discount_incl = discount_total
    net_amount = gross_total - discount_total
    
    # Apply coupon if provided
    coupon_discount = Decimal('0')
    if sale_data.coupon_code:
        coupon = db.query(Coupon).filter(
            Coupon.code == sale_data.coupon_code,
            Coupon.active == True
        ).first()
        
        if coupon:
            net_after_coupon, coupon_discount = GSTService.apply_coupon_to_bill(
                bill_total_incl=net_amount,
                coupon_type=coupon.type,
                coupon_value=coupon.value,
                max_cap=coupon.max_cap
            )
            sale.coupon_incl = coupon_discount
            net_amount = net_after_coupon
            
            # Recalculate base and tax after coupon
            # Proportionally reduce base and tax
            reduction_factor = net_after_coupon / (gross_total - discount_total)
            base_total = base_total * reduction_factor
            tax_total = tax_total * reduction_factor
    
    sale.base_excl = base_total
    sale.tax_amt_info = tax_total
    
    # Apply loyalty redemption
    redeem_value = Decimal('0')
    if sale_data.redeem_points and sale_data.redeem_points > 0:
        if not sale_data.customer_mobile:
            raise HTTPException(status_code=400, detail="Customer mobile required for points redemption")
        
        customer = db.query(Customer).filter(Customer.mobile == sale_data.customer_mobile).first()
        if not customer:
            raise HTTPException(status_code=404, detail="Customer not found")
        
        if customer.points_balance < sale_data.redeem_points:
            raise HTTPException(status_code=400, detail="Insufficient loyalty points")
        
        redeem_value = Decimal(str(sale_data.redeem_points))  # 1 point = ₹1
        sale.redeem_points = sale_data.redeem_points
        sale.redeem_value = redeem_value
    
    # Apply return credit
    return_credit_value = Decimal('0')
    if sale_data.return_credit_id:
        rc = db.query(ReturnCredit).filter(
            ReturnCredit.id == sale_data.return_credit_id,
            ReturnCredit.status.in_(['open', 'partial'])
        ).first()
        
        if not rc:
            raise HTTPException(status_code=404, detail="Return credit not found or already used")
        
        return_credit_value = min(rc.rc_amount_incl, net_amount)
        sale.return_credit_id = sale_data.return_credit_id
        sale.return_credit_used_value = return_credit_value
    
    # Calculate final payable
    final_payable = net_amount - redeem_value - return_credit_value
    
    # Apply rounding
    rounded_payable, round_off = GSTService.round_off_amount(
        final_payable,
        Decimal(str(sale_data.round_off or 0.01))
    )
    
    sale.final_payable = rounded_payable
    sale.round_off = round_off
    
    # Process payment splits
    if not sale_data.payments or len(sale_data.payments) == 0:
        raise HTTPException(status_code=400, detail="Payment information required")
    
    total_paid = Decimal('0')
    for payment in sale_data.payments:
        payment_mode = db.query(PaymentMode).filter(
            PaymentMode.id == payment.payment_mode_id
        ).first()
        
        if not payment_mode:
            raise HTTPException(status_code=404, detail=f"Payment mode {payment.payment_mode_id} not found")
        
        sale_payment = SalePayment(
            id=str(uuid.uuid4()),
            sale_id=sale.id,
            payment_mode_id=payment.payment_mode_id,
            amount=payment.amount,
            settlement_type=payment_mode.settlement_type,
            bank_account_id=payment_mode.bank_account_id,
            supplier_id=payment_mode.supplier_id
        )
        
        sale.payments.append(sale_payment)
        total_paid += payment.amount
    
    # Validate payment matches payable
    if abs(total_paid - rounded_payable) > Decimal('0.01'):
        raise HTTPException(
            status_code=400,
            detail=f"Payment mismatch. Payable: ₹{rounded_payable}, Paid: ₹{total_paid}"
        )
    
    # Update stock
    for item in sale.items:
        StockService.update_stock(db, item.barcode, item.qty, 'subtract')
    
    # Update customer loyalty
    if sale_data.customer_mobile:
        customer = db.query(Customer).filter(Customer.mobile == sale_data.customer_mobile).first()
        
        if customer:
            # Update lifetime purchase
            customer.lifetime_purchase = (customer.lifetime_purchase or Decimal('0')) + rounded_payable
            
            # Deduct redeemed points
            if sale_data.redeem_points:
                customer.points_balance -= sale_data.redeem_points
                
                # Create point transaction
                point_txn = PointTransaction(
                    id=str(uuid.uuid4()),
                    customer_mobile=customer.mobile,
                    transaction_type='redeemed',
                    points=-sale_data.redeem_points,
                    reference_type='sale',
                    reference_id=sale.id
                )
                db.add(point_txn)
            
            # Calculate and add earned points (on base amount after coupon/RC)
            points_earned = LoyaltyService.calculate_points_earned(
                base_amount=base_total,
                customer_grade=customer.grade
            )
            
            if points_earned > 0:
                customer.points_balance += points_earned
                
                # Create point transaction
                point_txn = PointTransaction(
                    id=str(uuid.uuid4()),
                    customer_mobile=customer.mobile,
                    transaction_type='earned',
                    points=points_earned,
                    reference_type='sale',
                    reference_id=sale.id
                )
                db.add(point_txn)
            
            # Check for grade upgrade
            new_grade = LoyaltyService.check_grade_upgrade(
                db,
                customer.lifetime_purchase
            )
            
            if new_grade and new_grade != customer.grade:
                customer.grade = new_grade
    
    # Update return credit status
    if sale_data.return_credit_id:
        rc.status = ReturnCreditStatus.CLOSED
        rc.closed_at = datetime.utcnow()
    
    # Save everything
    db.add(sale)
    db.commit()
    db.refresh(sale)
    
    # Send WhatsApp invoice if requested
    if sale_data.send_whatsapp and sale_data.customer_mobile:
        try:
            # Generate invoice PDF and send
            WhatsAppService.send_invoice(
                mobile=sale_data.customer_mobile,
                bill_no=bill_no,
                amount=rounded_payable,
                points_earned=points_earned if sale_data.customer_mobile else 0,
                points_balance=customer.points_balance if customer else 0
            )
        except:
            pass  # Don't fail sale if WhatsApp fails
    
    return {
        "success": True,
        "bill_no": bill_no,
        "bill_date": sale.bill_date,
        "gross_amount": float(gross_total),
        "discount_amount": float(discount_total),
        "coupon_discount": float(coupon_discount),
        "net_amount": float(net_amount),
        "redeemed_points": sale_data.redeem_points or 0,
        "redeemed_value": float(redeem_value),
        "return_credit_used": float(return_credit_value),
        "final_payable": float(rounded_payable),
        "round_off": float(round_off),
        "points_earned": points_earned if sale_data.customer_mobile else 0,
        "points_balance": customer.points_balance if customer else 0
    }