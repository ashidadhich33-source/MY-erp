from sqlalchemy import Column, String, Numeric, Integer, ForeignKey, DateTime, Date, Boolean
from sqlalchemy.orm import relationship
from ..database import Base
from datetime import datetime

class LoyaltyGrade(Base):
    __tablename__ = "loyalty_grades"
    
    id = Column(String(36), primary_key=True)
    name = Column(String(100), nullable=False)
    amount_from = Column(Numeric(12, 2), nullable=False)
    amount_to = Column(Numeric(12, 2), nullable=False)
    earn_pct = Column(Numeric(5, 2), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, onupdate=datetime.utcnow)

class Coupon(Base):
    __tablename__ = "coupons"
    
    id = Column(String(36), primary_key=True)
    code = Column(String(50), unique=True, nullable=False)
    type = Column(String(20))  # percent or flat
    value = Column(Numeric(10, 2), nullable=False)
    max_cap = Column(Numeric(10, 2))
    valid_from = Column(Date)
    valid_to = Column(Date)
    min_bill = Column(Numeric(10, 2))
    bound_mobile = Column(String(10), ForeignKey("customers.mobile"))
    active = Column(Boolean, default=True)
    sent_by_staff_id = Column(String(36), ForeignKey("staff.id"))
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    customer = relationship("Customer", back_populates="coupons")
    staff = relationship("Staff")

class PointTransaction(Base):
    __tablename__ = "point_transactions"
    
    id = Column(String(36), primary_key=True)
    customer_mobile = Column(String(10), ForeignKey("customers.mobile"), nullable=False)
    transaction_type = Column(String(20))  # earned, redeemed
    points = Column(Integer, nullable=False)
    reference_type = Column(String(20))  # sale, sale_return
    reference_id = Column(String(36))
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    customer = relationship("Customer")