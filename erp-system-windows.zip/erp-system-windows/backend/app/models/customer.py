from sqlalchemy import Column, String, Date, Numeric, Integer, DateTime
from sqlalchemy.orm import relationship
from ..database import Base
from datetime import datetime

class Customer(Base):
    __tablename__ = "customers"
    
    mobile = Column(String(10), primary_key=True)
    name = Column(String(255))
    email = Column(String(255))
    kid1_name = Column(String(100))
    kid1_dob = Column(Date)
    kid2_name = Column(String(100))
    kid2_dob = Column(Date)
    kid3_name = Column(String(100))
    kid3_dob = Column(Date)
    address = Column(String(500))
    city = Column(String(100))
    lifetime_purchase = Column(Numeric(12, 2), default=0)
    points_balance = Column(Integer, default=0)
    grade = Column(String(50))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, onupdate=datetime.utcnow)
    
    # Relationships
    sales = relationship("Sale", back_populates="customer")
    coupons = relationship("Coupon", back_populates="customer")
    return_credits = relationship("ReturnCredit", back_populates="customer")