from sqlalchemy import Column, String, Boolean, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from ..database import Base
from datetime import datetime

class User(Base):
    __tablename__ = "users"
    
    id = Column(String(36), primary_key=True)
    username = Column(String(100), unique=True, nullable=False, index=True)
    display_name = Column(String(255))
    mobile = Column(String(15))
    email = Column(String(255))
    password_hash = Column(String(255), nullable=False)
    role = Column(String(50))
    company_id = Column(String(36), ForeignKey("companies.id"))
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, onupdate=datetime.utcnow)
    
    # Relationships
    company = relationship("Company", backref="users")
    acl_permissions = relationship("UserACL", back_populates="user", cascade="all, delete-orphan")

class UserACL(Base):
    __tablename__ = "user_acl"
    
    id = Column(String(36), primary_key=True)
    user_id = Column(String(36), ForeignKey("users.id"), nullable=False)
    menu_key = Column(String(100), nullable=False)
    can_view = Column(Boolean, default=False)
    can_create = Column(Boolean, default=False)
    can_edit = Column(Boolean, default=False)
    can_import = Column(Boolean, default=False)
    can_export = Column(Boolean, default=False)
    can_print = Column(Boolean, default=False)
    can_modify_past = Column(Boolean, default=False)
    is_admin = Column(Boolean, default=False)
    
    # Relationships
    user = relationship("User", back_populates="acl_permissions")