from sqlalchemy import Column, String, Boolean, Integer, Numeric, ForeignKey
from sqlalchemy.orm import relationship
from ..database import Base

class PaymentMode(Base):
    __tablename__ = "payment_modes"
    
    id = Column(String(36), primary_key=True)
    name = Column(String(100), nullable=False)
    settlement_type = Column(String(20))  # cash, bank, supplier
    bank_account_id = Column(String(36))
    supplier_id = Column(String(36), ForeignKey("suppliers.id"))
    active = Column(Boolean, default=True)
    
    # Relationships
    supplier = relationship("Supplier")

class BillSeries(Base):
    __tablename__ = "bill_series"
    
    id = Column(String(36), primary_key=True)
    code = Column(String(20), unique=True, nullable=False)
    description = Column(String(255))
    prefix = Column(String(20), nullable=False)
    next_no = Column(Integer, default=1)
    width = Column(Integer, default=5)
    fy = Column(String(10))
    default_tax_region = Column(String(20))
    active = Column(Boolean, default=True)
