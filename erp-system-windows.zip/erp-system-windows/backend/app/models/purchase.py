from sqlalchemy import Column, String, Numeric, Integer, ForeignKey, DateTime, Boolean, Date
from sqlalchemy.orm import relationship
from ..database import Base
from datetime import datetime

class PurchaseBill(Base):
    __tablename__ = "purchase_bills"
    
    id = Column(String(36), primary_key=True)
    pb_series_id = Column(String(36), ForeignKey("bill_series.id"))
    pb_no = Column(String(50), unique=True, nullable=False)
    pb_date = Column(DateTime, default=datetime.utcnow)
    payment_mode = Column(String(20))  # cash or credit
    supplier_id = Column(String(36), ForeignKey("suppliers.id"))
    tax_region = Column(String(20))  # local or inter
    supplier_bill_no = Column(String(50))
    supplier_bill_date = Column(Date)
    reverse_charge = Column(Boolean, default=False)
    total_taxable = Column(Numeric(12, 2))
    total_cgst = Column(Numeric(12, 2))
    total_sgst = Column(Numeric(12, 2))
    total_igst = Column(Numeric(12, 2))
    grand_total = Column(Numeric(12, 2))
    created_by = Column(String(36))
    created_at = Column(DateTime, default=datetime.utcnow)
    modified_by = Column(String(36))
    modified_at = Column(DateTime)
    
    # Relationships
    supplier = relationship("Supplier", back_populates="purchase_bills")
    items = relationship("PurchaseBillItem", back_populates="purchase_bill", cascade="all, delete-orphan")
    series = relationship("BillSeries")

class PurchaseBillItem(Base):
    __tablename__ = "purchase_bill_items"
    
    id = Column(String(36), primary_key=True)
    purchase_bill_id = Column(String(36), ForeignKey("purchase_bills.id"), nullable=False)
    barcode = Column(String(50), ForeignKey("items.barcode"))
    style_code = Column(String(100))
    size = Column(String(20))
    hsn = Column(String(20))
    qty = Column(Integer, nullable=False)
    basic_rate = Column(Numeric(10, 2), nullable=False)
    gst_rate = Column(Numeric(5, 2))
    cgst_rate = Column(Numeric(5, 2))
    sgst_rate = Column(Numeric(5, 2))
    igst_rate = Column(Numeric(5, 2))
    line_taxable = Column(Numeric(12, 2))
    cgst_amount = Column(Numeric(12, 2))
    sgst_amount = Column(Numeric(12, 2))
    igst_amount = Column(Numeric(12, 2))
    line_total = Column(Numeric(12, 2))
    mrp = Column(Numeric(10, 2))
    
    # Relationships
    purchase_bill = relationship("PurchaseBill", back_populates="items")
    item = relationship("Item")

class PurchaseReturn(Base):
    __tablename__ = "purchase_returns"
    
    id = Column(String(36), primary_key=True)
    pr_series_id = Column(String(36), ForeignKey("bill_series.id"))
    pr_no = Column(String(50), unique=True, nullable=False)
    pr_date = Column(DateTime, default=datetime.utcnow)
    supplier_id = Column(String(36), ForeignKey("suppliers.id"))
    tax_region = Column(String(20))
    supplier_bill_no = Column(String(50))
    supplier_bill_date = Column(Date)
    reason = Column(Text)
    total_taxable = Column(Numeric(12, 2))
    total_cgst = Column(Numeric(12, 2))
    total_sgst = Column(Numeric(12, 2))
    total_igst = Column(Numeric(12, 2))
    grand_total = Column(Numeric(12, 2))
    created_by = Column(String(36))
    created_at = Column(DateTime, default=datetime.utcnow)
    modified_by = Column(String(36))
    modified_at = Column(DateTime)
    
    # Relationships
    supplier = relationship("Supplier", back_populates="purchase_returns")
    items = relationship("PurchaseReturnItem", back_populates="purchase_return", cascade="all, delete-orphan")
    series = relationship("BillSeries")

class PurchaseReturnItem(Base):
    __tablename__ = "purchase_return_items"
    
    id = Column(String(36), primary_key=True)
    purchase_return_id = Column(String(36), ForeignKey("purchase_returns.id"), nullable=False)
    barcode = Column(String(50), ForeignKey("items.barcode"))
    style_code = Column(String(100))
    size = Column(String(20))
    hsn = Column(String(20))
    qty = Column(Integer, nullable=False)
    basic_rate = Column(Numeric(10, 2), nullable=False)
    gst_rate = Column(Numeric(5, 2))
    cgst_rate = Column(Numeric(5, 2))
    sgst_rate = Column(Numeric(5, 2))
    igst_rate = Column(Numeric(5, 2))
    line_taxable = Column(Numeric(12, 2))
    cgst_amount = Column(Numeric(12, 2))
    sgst_amount = Column(Numeric(12, 2))
    igst_amount = Column(Numeric(12, 2))
    line_total = Column(Numeric(12, 2))
    mrp = Column(Numeric(10, 2))
    
    # Relationships
    purchase_return = relationship("PurchaseReturn", back_populates="items")
    item = relationship("Item")
