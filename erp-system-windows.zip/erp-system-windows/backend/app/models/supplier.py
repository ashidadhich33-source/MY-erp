from sqlalchemy import Column, String, DateTime
from sqlalchemy.orm import relationship
from ..database import Base
from datetime import datetime

class Supplier(Base):
    __tablename__ = "suppliers"
    
    id = Column(String(36), primary_key=True)
    name = Column(String(255), nullable=False)
    gstin = Column(String(15))
    email = Column(String(255))
    phone = Column(String(15))
    location_type = Column(String(20))  # local or inter
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, onupdate=datetime.utcnow)
    
    # Relationships
    purchase_bills = relationship("PurchaseBill", back_populates="supplier")
    purchase_returns = relationship("PurchaseReturn", back_populates="supplier")
