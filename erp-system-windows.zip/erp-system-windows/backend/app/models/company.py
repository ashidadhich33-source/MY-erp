from sqlalchemy import Column, String, Text
from ..database import Base

class Company(Base):
    __tablename__ = "companies"
    
    id = Column(String(36), primary_key=True)
    name = Column(String(255), nullable=False)
    gstin = Column(String(15))
    mobile = Column(String(15))
    logo_path = Column(Text)
    address = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, onupdate=datetime.utcnow)