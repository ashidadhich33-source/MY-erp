from sqlalchemy import Column, String, Numeric, Boolean, ForeignKey, Date
from sqlalchemy.orm import relationship
from ..database import Base

class Staff(Base):
    __tablename__ = "staff"
    
    id = Column(String(36), primary_key=True)
    code = Column(String(20), unique=True, nullable=False)
    name = Column(String(255), nullable=False)
    mobile = Column(String(15))
    role = Column(String(50))
    email = Column(String(255))
    address = Column(String(500))
    joining_date = Column(Date)
    basic_salary = Column(Numeric(12, 2))
    commission_enabled = Column(Boolean, default=False)
    user_id = Column(String(36), ForeignKey("users.id"))
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, onupdate=datetime.utcnow)
    
    # Relationships
    user = relationship("User")
    sales = relationship("Sale", back_populates="staff")
    targets = relationship("StaffTarget", back_populates="staff")

class StaffTarget(Base):
    __tablename__ = "staff_targets"
    
    id = Column(String(36), primary_key=True)
    staff_id = Column(String(36), ForeignKey("staff.id"), nullable=False)
    period_start = Column(Date, nullable=False)
    period_end = Column(Date, nullable=False)
    target_amount = Column(Numeric(12, 2), nullable=False)
    incentive_type = Column(String(20))  # percent or flat
    incentive_slabs = Column(JSON)  # Store slab details as JSON
    min_achievement_for_incentive = Column(Numeric(5, 2), default=80)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, onupdate=datetime.utcnow)
    
    # Relationships
    staff = relationship("Staff", back_populates="targets")