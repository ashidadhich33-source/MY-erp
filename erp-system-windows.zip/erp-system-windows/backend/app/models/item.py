from sqlalchemy import Column, String, Numeric, ForeignKey, DateTime, Index
from sqlalchemy.orm import relationship
from ..database import Base
from datetime import datetime

class Item(Base):
    __tablename__ = "items"
    
    barcode = Column(String(50), primary_key=True)
    style_code = Column(String(100), nullable=False, index=True)
    color = Column(String(50))
    size = Column(String(20))
    hsn = Column(String(20))
    mrp_incl = Column(Numeric(10, 2))
    purchase_rate_basic = Column(Numeric(10, 2))
    brand = Column(String(100))
    gender = Column(String(20))
    category = Column(String(100))
    sub_category = Column(String(100))
    status = Column(String(20), default='active')
    company_id = Column(String(36), ForeignKey("companies.id"))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, onupdate=datetime.utcnow)
    
    # Relationships
    company = relationship("Company", backref="items")
    stock = relationship("Stock", back_populates="item", uselist=False)
    
    # Indexes
    __table_args__ = (
        Index('idx_items_style_company', 'style_code', 'company_id'),
    )