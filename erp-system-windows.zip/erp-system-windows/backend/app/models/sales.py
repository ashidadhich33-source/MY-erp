from sqlalchemy import Column, String, Numeric, Integer, ForeignKey, DateTime, Boolean, Text
from sqlalchemy.orm import relationship
from ..database import Base
from datetime import datetime

class Sale(Base):
    __tablename__ = "sales"
    
    id = Column(String(36), primary_key=True)
    series_id = Column(String(36), ForeignKey("bill_series.id"))
    bill_no = Column(String(50), unique=True, nullable=False)
    bill_date = Column(DateTime, default=datetime.utcnow)
    customer_mobile = Column(String(10), ForeignKey("customers.mobile"))
    staff_id = Column(String(36), ForeignKey("staff.id"))
    agent_id = Column(String(36))
    tax_region = Column(String(20))  # local or inter
    gross_incl = Column(Numeric(12, 2))
    discount_incl = Column(Numeric(12, 2))
    coupon_incl = Column(Numeric(12, 2))
    base_excl = Column(Numeric(12, 2))
    tax_amt_info = Column(Numeric(12, 2))
    redeem_points = Column(Integer, default=0)
    redeem_value = Column(Numeric(12, 2), default=0)
    return_credit_id = Column(String(36), ForeignKey("return_credits.id"))
    return_credit_used_value = Column(Numeric(12, 2), default=0)
    final_payable = Column(Numeric(12, 2))
    round_off = Column(Numeric(5, 2))
    created_by = Column(String(36))
    created_at = Column(DateTime, default=datetime.utcnow)
    modified_by = Column(String(36))
    modified_at = Column(DateTime)
    
    # Relationships
    customer = relationship("Customer", back_populates="sales")
    staff = relationship("Staff", back_populates="sales")
    items = relationship("SaleItem", back_populates="sale", cascade="all, delete-orphan")
    payments = relationship("SalePayment", back_populates="sale", cascade="all, delete-orphan")
    series = relationship("BillSeries")
    return_credit_used = relationship("ReturnCredit", foreign_keys=[return_credit_id])

class SaleItem(Base):
    __tablename__ = "sales_items"
    
    id = Column(String(36), primary_key=True)
    sale_id = Column(String(36), ForeignKey("sales.id"), nullable=False)
    barcode = Column(String(50), ForeignKey("items.barcode"))
    style_code = Column(String(100))
    color = Column(String(50))
    size = Column(String(20))
    qty = Column(Integer, nullable=False)
    mrp_incl = Column(Numeric(10, 2))
    disc_pct = Column(Numeric(5, 2), default=0)
    line_inclusive = Column(Numeric(12, 2))
    gst_rate = Column(Numeric(5, 2))
    cgst_rate = Column(Numeric(5, 2))
    sgst_rate = Column(Numeric(5, 2))
    igst_rate = Column(Numeric(5, 2))
    hsn = Column(String(20))
    base_excl = Column(Numeric(12, 2))
    tax_amt_info = Column(Numeric(12, 2))
    
    # Relationships
    sale = relationship("Sale", back_populates="items")
    item = relationship("Item")

class SalePayment(Base):
    __tablename__ = "sales_payments"
    
    id = Column(String(36), primary_key=True)
    sale_id = Column(String(36), ForeignKey("sales.id"), nullable=False)
    payment_mode_id = Column(String(36), ForeignKey("payment_modes.id"))
    amount = Column(Numeric(12, 2), nullable=False)
    settlement_type = Column(String(20))  # cash, bank, supplier
    bank_account_id = Column(String(36))
    supplier_id = Column(String(36), ForeignKey("suppliers.id"))
    
    # Relationships
    sale = relationship("Sale", back_populates="payments")
    payment_mode = relationship("PaymentMode")
    supplier = relationship("Supplier")

class SaleReturn(Base):
    __tablename__ = "sales_returns"
    
    id = Column(String(36), primary_key=True)
    sr_series_id = Column(String(36), ForeignKey("bill_series.id"))
    sr_no = Column(String(50), unique=True, nullable=False)
    sr_date = Column(DateTime, default=datetime.utcnow)
    customer_mobile = Column(String(10), ForeignKey("customers.mobile"))
    tax_region = Column(String(20))
    total_incl = Column(Numeric(12, 2))
    reason = Column(Text)
    created_by = Column(String(36))
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    customer = relationship("Customer")
    items = relationship("SaleReturnItem", back_populates="sale_return", cascade="all, delete-orphan")
    series = relationship("BillSeries")
    return_credit = relationship("ReturnCredit", back_populates="sale_return", uselist=False)

class SaleReturnItem(Base):
    __tablename__ = "sales_return_items"
    
    id = Column(String(36), primary_key=True)
    sales_return_id = Column(String(36), ForeignKey("sales_returns.id"), nullable=False)
    sale_id = Column(String(36), ForeignKey("sales.id"))
    sale_item_id = Column(String(36), ForeignKey("sales_items.id"))
    barcode = Column(String(50), ForeignKey("items.barcode"))
    style_code = Column(String(100))
    color = Column(String(50))
    size = Column(String(20))
    hsn = Column(String(20))
    gst_rate = Column(Numeric(5, 2))
    unit_mrp_incl = Column(Numeric(10, 2))
    disc_pct_at_sale = Column(Numeric(5, 2))
    return_qty = Column(Integer, nullable=False)
    line_inclusive = Column(Numeric(12, 2))
    base_excl_info = Column(Numeric(12, 2))
    tax_info = Column(Numeric(12, 2))
    
    # Relationships
    sale_return = relationship("SaleReturn", back_populates="items")
    original_sale = relationship("Sale")
    original_sale_item = relationship("SaleItem")
    item = relationship("Item")

class ReturnCredit(Base):
    __tablename__ = "return_credits"
    
    id = Column(String(36), primary_key=True)
    rc_no = Column(String(50), unique=True, nullable=False)
    customer_mobile = Column(String(10), ForeignKey("customers.mobile"))
    sales_return_id = Column(String(36), ForeignKey("sales_returns.id"))
    rc_amount_incl = Column(Numeric(12, 2), nullable=False)
    status = Column(String(20), default='open')  # open, closed, partial
    created_at = Column(DateTime, default=datetime.utcnow)
    closed_at = Column(DateTime)
    
    # Relationships
    customer = relationship("Customer", back_populates="return_credits")
    sale_return = relationship("SaleReturn", back_populates="return_credit")