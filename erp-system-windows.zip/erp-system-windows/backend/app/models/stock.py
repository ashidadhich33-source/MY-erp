from sqlalchemy import Column, String, Integer, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from ..database import Base
from datetime import datetime

class Stock(Base):
    __tablename__ = "stock"
    
    barcode = Column(String(50), ForeignKey("items.barcode"), primary_key=True)
    qty_on_hand = Column(Integer, default=0)
    last_updated = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    item = relationship("Item", back_populates="stock")