// frontend/src/App.jsx
import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';

// Layout Components
import Layout from './components/Layout/Layout';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';

// Master Data Pages
import Items from './pages/Items/Items';
import Customers from './pages/Customers/Customers';
import Suppliers from './pages/Suppliers/Suppliers';
import Staff from './pages/Staff/Staff';

// Transaction Pages
import POS from './pages/Sales/POS';
import SalesList from './pages/Sales/SalesList';
import SaleReturns from './pages/Sales/SaleReturns';
import PurchaseBills from './pages/Purchases/PurchaseBills';
import PurchaseReturns from './pages/Purchases/PurchaseReturns';
import Expenses from './pages/Expenses/Expenses';

// Reports Pages
import Reports from './pages/Reports/Reports';
import StockReport from './pages/Reports/StockReport';
import SalesReport from './pages/Reports/SalesReport';
import CustomerAnalytics from './pages/Reports/CustomerAnalytics';
import GSTReport from './pages/Reports/GSTReport';

// System Pages
import SystemSettings from './components/SystemSettings';
import BackupDashboard from './components/BackupDashboard';
import UserManagement from './pages/UserManagement';

// Utility
import PrivateRoute from './components/PrivateRoute';
import { AuthProvider } from './contexts/AuthContext';
import { ThemeProvider } from './contexts/ThemeContext';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    // Check if user is authenticated
    const token = localStorage.getItem('token');
    setIsAuthenticated(!!token);
  }, []);

  return (
    <Router>
      <AuthProvider>
        <ThemeProvider>
          <div className="App">
            <Toaster 
              position="top-right"
              toastOptions={{
                duration: 4000,
                style: {
                  background: '#363636',
                  color: '#fff',
                },
                success: {
                  duration: 3000,
                  style: {
                    background: '#10b981',
                  },
                },
                error: {
                  duration: 4000,
                  style: {
                    background: '#ef4444',
                  },
                },
              }}
            />
            
            <Routes>
              {/* Public Routes */}
              <Route path="/login" element={<Login />} />
              
              {/* Protected Routes */}
              <Route path="/" element={
                <PrivateRoute>
                  <Layout />
                </PrivateRoute>
              }>
                {/* Dashboard */}
                <Route index element={<Dashboard />} />
                
                {/* Master Data */}
                <Route path="items" element={<Items />} />
                <Route path="customers" element={<Customers />} />
                <Route path="suppliers" element={<Suppliers />} />
                <Route path="staff" element={<Staff />} />
                
                {/* Sales */}
                <Route path="pos" element={<POS />} />
                <Route path="sales" element={<SalesList />} />
                <Route path="sale-returns" element={<SaleReturns />} />
                
                {/* Purchases */}
                <Route path="purchases" element={<PurchaseBills />} />
                <Route path="purchase-returns" element={<PurchaseReturns />} />
                
                {/* Expenses */}
                <Route path="expenses" element={<Expenses />} />
                
                {/* Reports */}
                <Route path="reports" element={<Reports />} />
                <Route path="reports/stock" element={<StockReport />} />
                <Route path="reports/sales" element={<SalesReport />} />
                <Route path="reports/customers" element={<CustomerAnalytics />} />
                <Route path="reports/gst" element={<GSTReport />} />
                
                {/* System */}
                <Route path="settings" element={<SystemSettings />} />
                <Route path="backup" element={<BackupDashboard />} />
                <Route path="users" element={<UserManagement />} />
              </Route>
              
              {/* Fallback */}
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </div>
        </ThemeProvider>
      </AuthProvider>
    </Router>
  );
}

export default App;