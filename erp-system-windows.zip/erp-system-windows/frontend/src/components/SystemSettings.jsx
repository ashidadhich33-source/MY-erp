import React, { useState, useEffect } from 'react';
import { Settings, Building2, Printer, Mail, MessageSquare, Shield, Calculator, Gift, Database, Save, RefreshCw, Upload, Download, Check, X, AlertCircle, Edit2, Eye, EyeOff } from 'lucide-react';

const SystemSettings = () => {
  const [activeTab, setActiveTab] = useState('company');
  const [settings, setSettings] = useState({});
  const [companyData, setCompanyData] = useState({});
  const [templates, setTemplates] = useState([]);
  const [loading, setLoading] = useState(false);
  const [notification, setNotification] = useState(null);
  const [editMode, setEditMode] = useState({});
  const [showPasswords, setShowPasswords] = useState({});
  const [validationErrors, setValidationErrors] = useState({});

  const API_BASE = window.electronAPI ? '/api' : 'http://localhost:8000/api';

  const tabs = [
    { id: 'company', label: 'Company Info', icon: Building2 },
    { id: 'business', label: 'Business Rules', icon: Calculator },
    { id: 'gst', label: 'GST Settings', icon: Calculator },
    { id: 'loyalty', label: 'Loyalty System', icon: Gift },
    { id: 'whatsapp', label: 'WhatsApp', icon: MessageSquare },
    { id: 'email', label: 'Email', icon: Mail },
    { id: 'print', label: 'Print Settings', icon: Printer },
    { id: 'security', label: 'Security', icon: Shield },
    { id: 'backup', label: 'Backup', icon: Database },
    { id: 'templates', label: 'Templates', icon: Printer }
  ];

  useEffect(() => {
    fetchSettings();
    fetchCompanyData();
    fetchTemplates();
  }, []);

  const fetchSettings = async () => {
    setLoading(true);
    try {
      const response = await fetch(`${API_BASE}/settings`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        setSettings(data);
      }
    } catch (error) {
      showNotification('Failed to load settings', 'error');
    } finally {
      setLoading(false);
    }
  };

  const fetchCompanyData = async () => {
    try {
      const response = await fetch(`${API_BASE}/company`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        setCompanyData(data);
      }
    } catch (error) {
      console.error('Failed to load company data:', error);
    }
  };

  const fetchTemplates = async () => {
    try {
      const response = await fetch(`${API_BASE}/templates`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        setTemplates(data);
      }
    } catch (error) {
      console.error('Failed to load templates:', error);
    }
  };

  const showNotification = (message, type = 'info') => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 5000);
  };

  const saveSettings = async (section, sectionSettings) => {
    try {
      const response = await fetch(`${API_BASE}/settings/update-section`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          section,
          settings: sectionSettings
        })
      });

      if (response.ok) {
        showNotification(`${section} settings saved successfully`, 'success');
        setEditMode({ ...editMode, [section]: false });
        fetchSettings();
      } else {
        showNotification(`Failed to save ${section} settings`, 'error');
      }
    } catch (error) {
      showNotification('Error saving settings', 'error');
    }
  };

  const saveCompanyData = async () => {
    try {
      const response = await fetch(`${API_BASE}/company`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(companyData)
      });

      if (response.ok) {
        showNotification('Company information saved successfully', 'success');
        setEditMode({ ...editMode, company: false });
      } else {
        showNotification('Failed to save company information', 'error');
      }
    } catch (error) {
      showNotification('Error saving company information', 'error');
    }
  };

  const validateSettings = async () => {
    try {
      const response = await fetch(`${API_BASE}/settings/validate`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        setValidationErrors(data.errors || {});
        
        if (data.valid) {
          showNotification('All settings are valid', 'success');
        } else {
          showNotification('Some settings have validation errors', 'error');
        }
      }
    } catch (error) {
      showNotification('Error validating settings', 'error');
    }
  };

  const exportSettings = async () => {
    try {
      const token = localStorage.getItem('token');
      window.open(`${API_BASE}/settings/export?token=${token}`, '_blank');
      showNotification('Settings exported successfully', 'success');
    } catch (error) {
      showNotification('Error exporting settings', 'error');
    }
  };

  const handleImportSettings = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await fetch(`${API_BASE}/settings/import`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: formData
      });

      if (response.ok) {
        showNotification('Settings imported successfully', 'success');
        fetchSettings();
      } else {
        showNotification('Failed to import settings', 'error');
      }
    } catch (error) {
      showNotification('Error importing settings', 'error');
    }
  };

  const toggleFeature = async (feature, enable) => {
    try {
      const response = await fetch(`${API_BASE}/quick-settings/toggle-${feature}`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ enable })
      });

      if (response.ok) {
        showNotification(`${feature} ${enable ? 'enabled' : 'disabled'}`, 'success');
        fetchSettings();
      }
    } catch (error) {
      showNotification(`Error toggling ${feature}`, 'error');
    }
  };

  const renderCompanyTab = () => (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-lg font-semibold text-gray-900">Company Information</h3>
        {!editMode.company ? (
          <button
            onClick={() => setEditMode({ ...editMode, company: true })}
            className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 flex items-center gap-2"
          >
            <Edit2 className="w-4 h-4" />
            Edit
          </button>
        ) : (
          <div className="flex gap-2">
            <button
              onClick={() => setEditMode({ ...editMode, company: false })}
              className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"
            >
              Cancel
            </button>
            <button
              onClick={saveCompanyData}
              className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 flex items-center gap-2"
            >
              <Save className="w-4 h-4" />
              Save
            </button>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Company Name</label>
          <input
            type="text"
            value={companyData.name || ''}
            onChange={(e) => setCompanyData({ ...companyData, name: e.target.value })}
            disabled={!editMode.company}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 disabled:bg-gray-50"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
          <input
            type="email"
            value={companyData.email || ''}
            onChange={(e) => setCompanyData({ ...companyData, email: e.target.value })}
            disabled={!editMode.company}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 disabled:bg-gray-50"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
          <input
            type="text"
            value={companyData.phone || ''}
            onChange={(e) => setCompanyData({ ...companyData, phone: e.target.value })}
            disabled={!editMode.company}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 disabled:bg-gray-50"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">GSTIN</label>
          <input
            type="text"
            value={companyData.gstin || ''}
            onChange={(e) => setCompanyData({ ...companyData, gstin: e.target.value })}
            disabled={!editMode.company}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 disabled:bg-gray-50"
          />
        </div>

        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-gray-700 mb-1">Address</label>
          <textarea
            value={companyData.address || ''}
            onChange={(e) => setCompanyData({ ...companyData, address: e.target.value })}
            disabled={!editMode.company}
            rows="3"
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 disabled:bg-gray-50"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">City</label>
          <input
            type="text"
            value={companyData.city || ''}
            onChange={(e) => setCompanyData({ ...companyData, city: e.target.value })}
            disabled={!editMode.company}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 disabled:bg-gray-50"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">State</label>
          <input
            type="text"
            value={companyData.state || ''}
            onChange={(e) => setCompanyData({ ...companyData, state: e.target.value })}
            disabled={!editMode.company}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 disabled:bg-gray-50"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Pincode</label>
          <input
            type="text"
            value={companyData.pincode || ''}
            onChange={(e) => setCompanyData({ ...companyData, pincode: e.target.value })}
            disabled={!editMode.company}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 disabled:bg-gray-50"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">PAN</label>
          <input
            type="text"
            value={companyData.pan || ''}
            onChange={(e) => setCompanyData({ ...companyData, pan: e.target.value })}
            disabled={!editMode.company}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 disabled:bg-gray-50"
          />
        </div>
      </div>

      <div className="mt-6 pt-6 border-t border-gray-200">
        <h4 className="font-medium text-gray-900 mb-4">Bank Details</h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Bank Name</label>
            <input
              type="text"
              value={companyData.bank_name || ''}
              onChange={(e) => setCompanyData({ ...companyData, bank_name: e.target.value })}
              disabled={!editMode.company}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 disabled:bg-gray-50"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Account Number</label>
            <input
              type="text"
              value={companyData.bank_account || ''}
              onChange={(e) => setCompanyData({ ...companyData, bank_account: e.target.value })}
              disabled={!editMode.company}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 disabled:bg-gray-50"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">IFSC Code</label>
            <input
              type="text"
              value={companyData.bank_ifsc || ''}
              onChange={(e) => setCompanyData({ ...companyData, bank_ifsc: e.target.value })}
              disabled={!editMode.company}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 disabled:bg-gray-50"
            />
          </div>
        </div>
      </div>
    </div>
  );

  const renderGSTTab = () => {
    const gstSettings = settings.gst || {};
    
    return (
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-lg font-semibold text-gray-900">GST Configuration</h3>
          <div className="flex items-center gap-4">
            <label className="flex items-center gap-2 cursor-pointer">
              <span className="text-sm font-medium">GST Enabled</span>
              <div className="relative">
                <input
                  type="checkbox"
                  checked={gstSettings.enable === 'true'}
                  onChange={(e) => toggleFeature('gst', e.target.checked)}
                  className="sr-only"
                />
                <div className={`w-10 h-6 rounded-full transition-colors ${
                  gstSettings.enable === 'true' ? 'bg-green-500' : 'bg-gray-300'
                }`}>
                  <div className={`w-4 h-4 bg-white rounded-full transition-transform transform ${
                    gstSettings.enable === 'true' ? 'translate-x-5' : 'translate-x-1'
                  } mt-1`} />
                </div>
              </div>
            </label>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">5% GST Rate</label>
            <input
              type="number"
              value={gstSettings.gst_5_rate || '5'}
              onChange={(e) => setSettings({
                ...settings,
                gst: { ...gstSettings, gst_5_rate: e.target.value }
              })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
            />
            <p className="text-xs text-gray-500 mt-1">Applied to items with MRP ≤ ₹{gstSettings.gst_5_max_price || '999'}</p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">12% GST Rate</label>
            <input
              type="number"
              value={gstSettings.gst_12_rate || '12'}
              onChange={(e) => setSettings({
                ...settings,
                gst: { ...gstSettings, gst_12_rate: e.target.value }
              })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
            />
            <p className="text-xs text-gray-500 mt-1">Applied to items with MRP > ₹{gstSettings.gst_5_max_price || '999'}</p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">5% GST Max Price Threshold</label>
            <input
              type="number"
              value={gstSettings.gst_5_max_price || '999'}
              onChange={(e) => setSettings({
                ...settings,
                gst: { ...gstSettings, gst_5_max_price: e.target.value }
              })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Round Off Value</label>
            <input
              type="number"
              step="0.01"
              value={gstSettings.round_off || '0.01'}
              onChange={(e) => setSettings({
                ...settings,
                gst: { ...gstSettings, round_off: e.target.value }
              })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Default Tax Type</label>
            <select
              value={gstSettings.default_tax_type || 'local'}
              onChange={(e) => setSettings({
                ...settings,
                gst: { ...gstSettings, default_tax_type: e.target.value }
              })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
            >
              <option value="local">Local (CGST + SGST)</option>
              <option value="interstate">Interstate (IGST)</option>
            </select>
          </div>

          <div>
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={gstSettings.hsn_code_mandatory === 'true'}
                onChange={(e) => setSettings({
                  ...settings,
                  gst: { ...gstSettings, hsn_code_mandatory: e.target.checked ? 'true' : 'false' }
                })}
                className="rounded text-indigo-600"
              />
              <span className="text-sm font-medium text-gray-700">HSN Code Mandatory</span>
            </label>
          </div>
        </div>

        <div className="mt-6 flex justify-end">
          <button
            onClick={() => saveSettings('gst', gstSettings)}
            className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            Save GST Settings
          </button>
        </div>
      </div>
    );
  };

  const renderSettingsSection = (section) => {
    const sectionSettings = settings[section] || {};
    
    return (
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-lg font-semibold text-gray-900 capitalize">{section} Settings</h3>
          {!editMode[section] ? (
            <button
              onClick={() => setEditMode({ ...editMode, [section]: true })}
              className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 flex items-center gap-2"
            >
              <Edit2 className="w-4 h-4" />
              Edit
            </button>
          ) : (
            <div className="flex gap-2">
              <button
                onClick={() => setEditMode({ ...editMode, [section]: false })}
                className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"
              >
                Cancel
              </button>
              <button
                onClick={() => saveSettings(section, sectionSettings)}
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 flex items-center gap-2"
              >
                <Save className="w-4 h-4" />
                Save
              </button>
            </div>
          )}
        </div>

        <div className="space-y-4">
          {Object.entries(sectionSettings).map(([key, value]) => (
            <div key={key}>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
              </label>
              {key.includes('password') ? (
                <div className="relative">
                  <input
                    type={showPasswords[key] ? 'text' : 'password'}
                    value={value || ''}
                    onChange={(e) => setSettings({
                      ...settings,
                      [section]: { ...sectionSettings, [key]: e.target.value }
                    })}
                    disabled={!editMode[section]}
                    className="w-full px-3 py-2 pr-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 disabled:bg-gray-50"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPasswords({ ...showPasswords, [key]: !showPasswords[key] })}
                    className="absolute right-2 top-2 text-gray-500 hover:text-gray-700"
                  >
                    {showPasswords[key] ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              ) : value === 'true' || value === 'false' ? (
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={value === 'true'}
                    onChange={(e) => setSettings({
                      ...settings,
                      [section]: { ...sectionSettings, [key]: e.target.checked ? 'true' : 'false' }
                    })}
                    disabled={!editMode[section]}
                    className="rounded text-indigo-600 disabled:opacity-50"
                  />
                  <span className="text-sm text-gray-600">{value === 'true' ? 'Enabled' : 'Disabled'}</span>
                </label>
              ) : (
                <input
                  type="text"
                  value={value || ''}
                  onChange={(e) => setSettings({
                    ...settings,
                    [section]: { ...sectionSettings, [key]: e.target.value }
                  })}
                  disabled={!editMode[section]}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 disabled:bg-gray-50"
                />
              )}
              {validationErrors[section]?.[key] && (
                <p className="text-xs text-red-600 mt-1">{validationErrors[section][key]}</p>
              )}
            </div>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
          <Settings className="w-8 h-8 text-indigo-600" />
          System Settings
        </h1>
        <p className="text-gray-600 mt-2">Configure your ERP system settings and preferences</p>
      </div>

      {/* Notification */}
      {notification && (
        <div className={`mb-6 p-4 rounded-lg flex items-center gap-3 ${
          notification.type === 'success' ? 'bg-green-100 text-green-800' :
          notification.type === 'error' ? 'bg-red-100 text-red-800' :
          'bg-blue-100 text-blue-800'
        }`}>
          {notification.type === 'success' ? <Check className="w-5 h-5" /> :
           notification.type === 'error' ? <X className="w-5 h-5" /> :
           <AlertCircle className="w-5 h-5" />}
          {notification.message}
        </div>
      )}

      {/* Action Buttons */}
      <div className="mb-6 flex gap-4">
        <button
          onClick={validateSettings}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2"
        >
          <Check className="w-4 h-4" />
          Validate Settings
        </button>
        <button
          onClick={exportSettings}
          className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 flex items-center gap-2"
        >
          <Download className="w-4 h-4" />
          Export Settings
        </button>
        <label className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 flex items-center gap-2 cursor-pointer">
          <Upload className="w-4 h-4" />
          Import Settings
          <input
            type="file"
            accept=".json"
            onChange={handleImportSettings}
            className="hidden"
          />
        </label>
        <button
          onClick={fetchSettings}
          disabled={loading}
          className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 flex items-center gap-2"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          Refresh
        </button>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2 rounded-lg flex items-center gap-2 whitespace-nowrap transition-colors ${
              activeTab === tab.id
                ? 'bg-indigo-600 text-white'
                : 'bg-white text-gray-700 hover:bg-gray-100'
            }`}
          >
            <tab.icon className="w-4 h-4" />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div>
        {loading ? (
          <div className="bg-white rounded-lg shadow-sm p-12 text-center">
            <RefreshCw className="w-8 h-8 animate-spin mx-auto text-gray-400 mb-4" />
            <p className="text-gray-500">Loading settings...</p>
          </div>
        ) : (
          <>
            {activeTab === 'company' && renderCompanyTab()}
            {activeTab === 'gst' && renderGSTTab()}
            {activeTab === 'loyalty' && renderLoyaltyTab()}
            {activeTab === 'whatsapp' && renderWhatsAppTab()}
            {activeTab === 'email' && renderEmailTab()}
            {activeTab === 'templates' && renderTemplatesTab()}
            {activeTab === 'business' && renderSettingsSection('business')}
            {activeTab === 'print' && renderSettingsSection('print')}
            {activeTab === 'security' && renderSettingsSection('security')}
            {activeTab === 'backup' && renderSettingsSection('backup')}
          </>
        )}
      </div>
    </div>
  );

  function renderLoyaltyTab() {
    const loyaltySettings = settings.loyalty || {};
    
    return (
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-lg font-semibold text-gray-900">Loyalty System Configuration</h3>
          <label className="flex items-center gap-2 cursor-pointer">
            <span className="text-sm font-medium">Loyalty Enabled</span>
            <div className="relative">
              <input
                type="checkbox"
                checked={loyaltySettings.enable === 'true'}
                onChange={(e) => toggleFeature('loyalty', e.target.checked)}
                className="sr-only"
              />
              <div className={`w-10 h-6 rounded-full transition-colors ${
                loyaltySettings.enable === 'true' ? 'bg-green-500' : 'bg-gray-300'
              }`}>
                <div className={`w-4 h-4 bg-white rounded-full transition-transform transform ${
                  loyaltySettings.enable === 'true' ? 'translate-x-5' : 'translate-x-1'
                } mt-1`} />
              </div>
            </div>
          </label>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Points per ₹100</label>
            <input
              type="number"
              value={loyaltySettings.points_per_100 || '1'}
              onChange={(e) => setSettings({
                ...settings,
                loyalty: { ...loyaltySettings, points_per_100: e.target.value }
              })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Point Value (₹)</label>
            <input
              type="number"
              step="0.01"
              value={loyaltySettings.points_value || '0.25'}
              onChange={(e) => setSettings({
                ...settings,
                loyalty: { ...loyaltySettings, points_value: e.target.value }
              })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
            />
            <p className="text-xs text-gray-500 mt-1">1 point = ₹{loyaltySettings.points_value || '0.25'}</p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Min Redemption Points</label>
            <input
              type="number"
              value={loyaltySettings.min_redemption_points || '100'}
              onChange={(e) => setSettings({
                ...settings,
                loyalty: { ...loyaltySettings, min_redemption_points: e.target.value }
              })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Points Expiry (Days)</label>
            <input
              type="number"
              value={loyaltySettings.points_expiry_days || '365'}
              onChange={(e) => setSettings({
                ...settings,
                loyalty: { ...loyaltySettings, points_expiry_days: e.target.value }
              })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="md:col-span-2">
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={loyaltySettings.auto_upgrade_grades === 'true'}
                onChange={(e) => setSettings({
                  ...settings,
                  loyalty: { ...loyaltySettings, auto_upgrade_grades: e.target.checked ? 'true' : 'false' }
                })}
                className="rounded text-indigo-600"
              />
              <span className="text-sm font-medium text-gray-700">Auto-upgrade customer grades based on purchase history</span>
            </label>
          </div>
        </div>

        <div className="mt-6 flex justify-end">
          <button
            onClick={() => saveSettings('loyalty', loyaltySettings)}
            className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            Save Loyalty Settings
          </button>
        </div>
      </div>
    );
  }

  function renderWhatsAppTab() {
    const whatsappSettings = settings.whatsapp || {};
    
    return (
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-lg font-semibold text-gray-900">WhatsApp Integration</h3>
          <label className="flex items-center gap-2 cursor-pointer">
            <span className="text-sm font-medium">WhatsApp Enabled</span>
            <div className="relative">
              <input
                type="checkbox"
                checked={whatsappSettings.enable === 'true'}
                onChange={(e) => toggleFeature('whatsapp', e.target.checked)}
                className="sr-only"
              />
              <div className={`w-10 h-6 rounded-full transition-colors ${
                whatsappSettings.enable === 'true' ? 'bg-green-500' : 'bg-gray-300'
              }`}>
                <div className={`w-4 h-4 bg-white rounded-full transition-transform transform ${
                  whatsappSettings.enable === 'true' ? 'translate-x-5' : 'translate-x-1'
                } mt-1`} />
              </div>
            </div>
          </label>
        </div>

        {whatsappSettings.enable === 'true' && (
          <>
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mb-6">
              <p className="text-sm text-amber-800">
                <strong>Note:</strong> WhatsApp Cloud API requires a Meta Business account and approved WhatsApp Business API access.
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Access Token</label>
                <div className="relative">
                  <input
                    type={showPasswords.whatsapp_token ? 'text' : 'password'}
                    value={whatsappSettings.access_token || ''}
                    onChange={(e) => setSettings({
                      ...settings,
                      whatsapp: { ...whatsappSettings, access_token: e.target.value }
                    })}
                    placeholder="Enter your WhatsApp Cloud API access token"
                    className="w-full px-3 py-2 pr-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPasswords({ ...showPasswords, whatsapp_token: !showPasswords.whatsapp_token })}
                    className="absolute right-2 top-2 text-gray-500 hover:text-gray-700"
                  >
                    {showPasswords.whatsapp_token ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number ID</label>
                <input
                  type="text"
                  value={whatsappSettings.phone_number_id || ''}
                  onChange={(e) => setSettings({
                    ...settings,
                    whatsapp: { ...whatsappSettings, phone_number_id: e.target.value }
                  })}
                  placeholder="Your WhatsApp phone number ID"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Business Account ID</label>
                <input
                  type="text"
                  value={whatsappSettings.business_account_id || ''}
                  onChange={(e) => setSettings({
                    ...settings,
                    whatsapp: { ...whatsappSettings, business_account_id: e.target.value }
                  })}
                  placeholder="Your WhatsApp Business account ID"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="space-y-2 pt-4">
                <h4 className="font-medium text-gray-900">Automated Messages</h4>
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={whatsappSettings.send_invoice === 'true'}
                    onChange={(e) => setSettings({
                      ...settings,
                      whatsapp: { ...whatsappSettings, send_invoice: e.target.checked ? 'true' : 'false' }
                    })}
                    className="rounded text-indigo-600"
                  />
                  <span className="text-sm text-gray-700">Send invoice after sale</span>
                </label>
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={whatsappSettings.send_birthday_wishes === 'true'}
                    onChange={(e) => setSettings({
                      ...settings,
                      whatsapp: { ...whatsappSettings, send_birthday_wishes: e.target.checked ? 'true' : 'false' }
                    })}
                    className="rounded text-indigo-600"
                  />
                  <span className="text-sm text-gray-700">Send birthday wishes</span>
                </label>
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={whatsappSettings.send_promotional === 'true'}
                    onChange={(e) => setSettings({
                      ...settings,
                      whatsapp: { ...whatsappSettings, send_promotional: e.target.checked ? 'true' : 'false' }
                    })}
                    className="rounded text-indigo-600"
                  />
                  <span className="text-sm text-gray-700">Send promotional messages</span>
                </label>
              </div>
            </div>

            <div className="mt-6 flex justify-end">
              <button
                onClick={() => saveSettings('whatsapp', whatsappSettings)}
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 flex items-center gap-2"
              >
                <Save className="w-4 h-4" />
                Save WhatsApp Settings
              </button>
            </div>
          </>
        )}
      </div>
    );
  }

  function renderEmailTab() {
    const emailSettings = settings.email || {};
    
    return (
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-lg font-semibold text-gray-900">Email Configuration</h3>
          <label className="flex items-center gap-2 cursor-pointer">
            <span className="text-sm font-medium">Email Enabled</span>
            <div className="relative">
              <input
                type="checkbox"
                checked={emailSettings.enable === 'true'}
                onChange={(e) => setSettings({
                  ...settings,
                  email: { ...emailSettings, enable: e.target.checked ? 'true' : 'false' }
                })}
                className="sr-only"
              />
              <div className={`w-10 h-6 rounded-full transition-colors ${
                emailSettings.enable === 'true' ? 'bg-green-500' : 'bg-gray-300'
              }`}>
                <div className={`w-4 h-4 bg-white rounded-full transition-transform transform ${
                  emailSettings.enable === 'true' ? 'translate-x-5' : 'translate-x-1'
                } mt-1`} />
              </div>
            </div>
          </label>
        </div>

        {emailSettings.enable === 'true' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">SMTP Host</label>
              <input
                type="text"
                value={emailSettings.smtp_host || ''}
                onChange={(e) => setSettings({
                  ...settings,
                  email: { ...emailSettings, smtp_host: e.target.value }
                })}
                placeholder="smtp.gmail.com"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">SMTP Port</label>
              <input
                type="text"
                value={emailSettings.smtp_port || ''}
                onChange={(e) => setSettings({
                  ...settings,
                  email: { ...emailSettings, smtp_port: e.target.value }
                })}
                placeholder="587"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">SMTP Username</label>
              <input
                type="text"
                value={emailSettings.smtp_user || ''}
                onChange={(e) => setSettings({
                  ...settings,
                  email: { ...emailSettings, smtp_user: e.target.value }
                })}
                placeholder="your-email@gmail.com"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">SMTP Password</label>
              <div className="relative">
                <input
                  type={showPasswords.smtp_password ? 'text' : 'password'}
                  value={emailSettings.smtp_password || ''}
                  onChange={(e) => setSettings({
                    ...settings,
                    email: { ...emailSettings, smtp_password: e.target.value }
                  })}
                  placeholder="Your app password"
                  className="w-full px-3 py-2 pr-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                />
                <button
                  type="button"
                  onClick={() => setShowPasswords({ ...showPasswords, smtp_password: !showPasswords.smtp_password })}
                  className="absolute right-2 top-2 text-gray-500 hover:text-gray-700"
                >
                  {showPasswords.smtp_password ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">From Email</label>
              <input
                type="email"
                value={emailSettings.from_email || ''}
                onChange={(e) => setSettings({
                  ...settings,
                  email: { ...emailSettings, from_email: e.target.value }
                })}
                placeholder="noreply@yourcompany.com"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">From Name</label>
              <input
                type="text"
                value={emailSettings.from_name || ''}
                onChange={(e) => setSettings({
                  ...settings,
                  email: { ...emailSettings, from_name: e.target.value }
                })}
                placeholder="Your Company Name"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div className="md:col-span-2 mt-4 flex justify-end">
              <button
                onClick={() => saveSettings('email', emailSettings)}
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 flex items-center gap-2"
              >
                <Save className="w-4 h-4" />
                Save Email Settings
              </button>
            </div>
          </div>
        )}
      </div>
    );
  }

  function renderTemplatesTab() {
    return (
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="mb-6">
          <h3 className="text-lg font-semibold text-gray-900">Print Templates</h3>
          <p className="text-sm text-gray-600 mt-1">Customize templates for invoices, receipts, and reports</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {templates.map((template) => (
            <div key={template.type} className="border border-gray-200 rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-medium text-gray-900 capitalize">{template.type} Template</h4>
                {template.customized && (
                  <span className="px-2 py-1 text-xs bg-green-100 text-green-800 rounded-full">Customized</span>
                )}
              </div>
              <p className="text-sm text-gray-600 mb-4">
                {template.type === 'invoice' && 'Used for sales invoices and bills'}
                {template.type === 'purchase' && 'Used for purchase bills'}
                {template.type === 'return' && 'Used for return notes'}
                {template.type === 'receipt' && 'Used for payment receipts'}
              </p>
              <div className="flex gap-2">
                <button
                  onClick={() => window.open(`/template-editor/${template.type}`, '_blank')}
                  className="px-3 py-1 text-sm bg-indigo-600 text-white rounded hover:bg-indigo-700"
                >
                  Edit
                </button>
                {template.customized && (
                  <button
                    onClick={() => {
                      if (window.confirm('Reset to default template?')) {
                        // Reset template logic
                      }
                    }}
                    className="px-3 py-1 text-sm bg-gray-200 text-gray-700 rounded hover:bg-gray-300"
                  >
                    Reset
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }
};

export default SystemSettings;