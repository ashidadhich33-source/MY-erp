import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, TrendingDown, ShoppingCart, Package, 
  Users, DollarSign, AlertCircle, ArrowUpRight,
  Calendar, BarChart3, PieChart, Activity
} from 'lucide-react';
import { LineChart, Line, BarChart, Bar, PieChart as RePieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const Dashboard = () => {
  const [stats, setStats] = useState({
    todaySales: 0,
    monthSales: 0,
    totalCustomers: 0,
    lowStockItems: 0,
    pendingBills: 0,
    totalExpenses: 0
  });
  
  const [salesData, setSalesData] = useState([]);
  const [categoryData, setCategoryData] = useState([]);
  const [recentTransactions, setRecentTransactions] = useState([]);
  const [topProducts, setTopProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dateRange, setDateRange] = useState('today');

  useEffect(() => {
    fetchDashboardData();
  }, [dateRange]);

  const fetchDashboardData = async () => {
    setLoading(true);
    try {
      // Fetch dashboard stats
      const response = await fetch(`http://localhost:8000/api/reports/dashboard-stats?range=${dateRange}`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        setStats(data.stats || {});
        setSalesData(data.salesChart || generateMockSalesData());
        setCategoryData(data.categoryChart || generateMockCategoryData());
        setRecentTransactions(data.recentTransactions || generateMockTransactions());
        setTopProducts(data.topProducts || generateMockTopProducts());
      } else {
        // Use mock data if API fails
        loadMockData();
      }
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
      loadMockData();
    } finally {
      setLoading(false);
    }
  };

  const loadMockData = () => {
    setStats({
      todaySales: 45280,
      monthSales: 1425600,
      totalCustomers: 342,
      lowStockItems: 8,
      pendingBills: 12,
      totalExpenses: 85000
    });
    setSalesData(generateMockSalesData());
    setCategoryData(generateMockCategoryData());
    setRecentTransactions(generateMockTransactions());
    setTopProducts(generateMockTopProducts());
  };

  const generateMockSalesData = () => {
    return [
      { name: 'Mon', sales: 12000, returns: 400 },
      { name: 'Tue', sales: 19000, returns: 600 },
      { name: 'Wed', sales: 15000, returns: 200 },
      { name: 'Thu', sales: 25000, returns: 800 },
      { name: 'Fri', sales: 32000, returns: 500 },
      { name: 'Sat', sales: 28000, returns: 300 },
      { name: 'Sun', sales: 35000, returns: 700 }
    ];
  };

  const generateMockCategoryData = () => {
    return [
      { name: 'Clothing', value: 45, color: '#8884d8' },
      { name: 'Footwear', value: 25, color: '#82ca9d' },
      { name: 'Accessories', value: 20, color: '#ffc658' },
      { name: 'Others', value: 10, color: '#ff8042' }
    ];
  };

  const generateMockTransactions = () => {
    return [
      { id: 'INV001', customer: 'John Doe', amount: 1250, status: 'completed', time: '2 mins ago' },
      { id: 'INV002', customer: 'Jane Smith', amount: 890, status: 'pending', time: '15 mins ago' },
      { id: 'INV003', customer: 'Bob Johnson', amount: 2100, status: 'completed', time: '1 hour ago' },
      { id: 'INV004', customer: 'Alice Brown', amount: 560, status: 'completed', time: '2 hours ago' },
      { id: 'INV005', customer: 'Charlie Wilson', amount: 3200, status: 'pending', time: '3 hours ago' }
    ];
  };

  const generateMockTopProducts = () => {
    return [
      { name: 'Premium T-Shirt', sales: 145, revenue: 21750, trend: 'up' },
      { name: 'Casual Jeans', sales: 98, revenue: 19600, trend: 'up' },
      { name: 'Sports Shoes', sales: 76, revenue: 15200, trend: 'down' },
      { name: 'Leather Wallet', sales: 234, revenue: 11700, trend: 'up' },
      { name: 'Summer Cap', sales: 189, revenue: 9450, trend: 'down' }
    ];
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 0
    }).format(amount);
  };

  const StatCard = ({ title, value, icon: Icon, change, changeType, color }) => (
    <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-gray-600 mb-1">{title}</p>
          <h3 className="text-2xl font-bold text-gray-900">{value}</h3>
          {change && (
            <div className="flex items-center mt-2">
              {changeType === 'increase' ? (
                <TrendingUp className="w-4 h-4 text-green-500 mr-1" />
              ) : (
                <TrendingDown className="w-4 h-4 text-red-500 mr-1" />
              )}
              <span className={`text-sm ${changeType === 'increase' ? 'text-green-500' : 'text-red-500'}`}>
                {change}
              </span>
            </div>
          )}
        </div>
        <div className={`p-3 rounded-lg ${color}`}>
          <Icon className="w-6 h-6 text-white" />
        </div>
      </div>
    </div>
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600 mt-1">Welcome back! Here's what's happening with your store today.</p>
        </div>
        <div className="mt-4 sm:mt-0 flex items-center gap-2">
          <select
            value={dateRange}
            onChange={(e) => setDateRange(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
          >
            <option value="today">Today</option>
            <option value="week">This Week</option>
            <option value="month">This Month</option>
            <option value="year">This Year</option>
          </select>
          <button className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 flex items-center gap-2">
            <Calendar className="w-4 h-4" />
            Custom Range
          </button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        <StatCard
          title="Today's Sales"
          value={formatCurrency(stats.todaySales)}
          icon={ShoppingCart}
          change="+12.5%"
          changeType="increase"
          color="bg-blue-500"
        />
        <StatCard
          title="Month Sales"
          value={formatCurrency(stats.monthSales)}
          icon={DollarSign}
          change="+8.2%"
          changeType="increase"
          color="bg-green-500"
        />
        <StatCard
          title="Total Customers"
          value={stats.totalCustomers}
          icon={Users}
          change="+5.3%"
          changeType="increase"
          color="bg-purple-500"
        />
        <StatCard
          title="Low Stock Items"
          value={stats.lowStockItems}
          icon={Package}
          change="-2"
          changeType="decrease"
          color="bg-orange-500"
        />
        <StatCard
          title="Pending Bills"
          value={stats.pendingBills}
          icon={AlertCircle}
          change="+3"
          changeType="increase"
          color="bg-red-500"
        />
        <StatCard
          title="Total Expenses"
          value={formatCurrency(stats.totalExpenses)}
          icon={Activity}
          change="-5.1%"
          changeType="decrease"
          color="bg-indigo-500"
        />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Sales Chart */}
        <div className="lg:col-span-2 bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Sales Overview</h3>
            <BarChart3 className="w-5 h-5 text-gray-400" />
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={salesData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="sales" stroke="#6366f1" strokeWidth={2} />
              <Line type="monotone" dataKey="returns" stroke="#ef4444" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Category Distribution */}
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Sales by Category</h3>
            <PieChart className="w-5 h-5 text-gray-400" />
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <RePieChart>
              <Pie
                data={categoryData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, value }) => `${name}: ${value}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {categoryData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </RePieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Tables Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Transactions */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100">
          <div className="p-6 border-b border-gray-100">
            <h3 className="text-lg font-semibold text-gray-900">Recent Transactions</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Invoice</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Customer</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Amount</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {recentTransactions.map((transaction) => (
                  <tr key={transaction.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 text-sm font-medium text-gray-900">{transaction.id}</td>
                    <td className="px-6 py-4 text-sm text-gray-600">{transaction.customer}</td>
                    <td className="px-6 py-4 text-sm text-gray-900">{formatCurrency(transaction.amount)}</td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${
                        transaction.status === 'completed' 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-yellow-100 text-yellow-800'
                      }`}>
                        {transaction.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="p-4 border-t border-gray-100">
            <button className="text-sm text-indigo-600 hover:text-indigo-700 font-medium">
              View all transactions →
            </button>
          </div>
        </div>

        {/* Top Products */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100">
          <div className="p-6 border-b border-gray-100">
            <h3 className="text-lg font-semibold text-gray-900">Top Products</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Product</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Sales</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Revenue</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Trend</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {topProducts.map((product, index) => (
                  <tr key={index} className="hover:bg-gray-50">
                    <td className="px-6 py-4 text-sm font-medium text-gray-900">{product.name}</td>
                    <td className="px-6 py-4 text-sm text-gray-600">{product.sales}</td>
                    <td className="px-6 py-4 text-sm text-gray-900">{formatCurrency(product.revenue)}</td>
                    <td className="px-6 py-4">
                      {product.trend === 'up' ? (
                        <ArrowUpRight className="w-4 h-4 text-green-500" />
                      ) : (
                        <TrendingDown className="w-4 h-4 text-red-500" />
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="p-4 border-t border-gray-100">
            <button className="text-sm text-indigo-600 hover:text-indigo-700 font-medium">
              View all products →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;