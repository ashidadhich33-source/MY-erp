// frontend/src/components/Layout/Header.jsx
import React, { useState, useEffect } from 'react';
import { Layout, Button, Dropdown, Avatar, Typography, Space, Badge, Tooltip } from 'antd';
import {
  MenuUnfoldOutlined,
  MenuFoldOutlined,
  UserOutlined,
  LogoutOutlined,
  SettingOutlined,
  BellOutlined,
  MoonOutlined,
  SunOutlined,
  FullscreenOutlined,
  FullscreenExitOutlined,
} from '@ant-design/icons';
import { useAuth } from '../../contexts/AuthContext';
import { useTheme } from '../../contexts/ThemeContext';

const { Header: AntHeader } = Layout;
const { Text } = Typography;

const Header = ({ collapsed, onToggle }) => {
  const { user, logout } = useAuth();
  const { isDarkMode, toggleTheme } = useTheme();
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [notifications, setNotifications] = useState([]);

  // Check fullscreen status
  useEffect(() => {
    const checkFullscreen = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener('fullscreenchange', checkFullscreen);
    return () => document.removeEventListener('fullscreenchange', checkFullscreen);
  }, []);

  // Mock notifications - in real app, fetch from API
  useEffect(() => {
    setNotifications([
      { id: 1, title: 'Low Stock Alert', message: '5 items are running low', type: 'warning' },
      { id: 2, title: 'Payment Due', message: '3 invoices are overdue', type: 'error' },
    ]);
  }, []);

  // Toggle fullscreen
  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
    } else {
      document.exitFullscreen();
    }
  };

  // User menu items
  const userMenuItems = [
    {
      key: 'profile',
      icon: <UserOutlined />,
      label: 'Profile Settings',
      onClick: () => {
        // Navigate to profile settings
        console.log('Open profile settings');
      },
    },
    {
      key: 'settings',
      icon: <SettingOutlined />,
      label: 'System Settings',
      onClick: () => {
        // Navigate to settings
        console.log('Open system settings');
      },
    },
    {
      type: 'divider',
    },
    {
      key: 'logout',
      icon: <LogoutOutlined />,
      label: 'Logout',
      onClick: logout,
    },
  ];

  // Notification menu items
  const notificationMenuItems = notifications.length > 0 ? [
    ...notifications.map(notification => ({
      key: notification.id,
      label: (
        <div style={{ maxWidth: '280px', padding: '8px 0' }}>
          <div style={{ fontWeight: 'bold', marginBottom: '4px' }}>
            {notification.title}
          </div>
          <div style={{ color: '#666', fontSize: '12px' }}>
            {notification.message}
          </div>
        </div>
      ),
    })),
    {
      type: 'divider',
    },
    {
      key: 'view-all',
      label: 'View All Notifications',
      onClick: () => {
        console.log('View all notifications');
      },
    },
  ] : [
    {
      key: 'empty',
      label: 'No notifications',
      disabled: true,
    },
  ];

  return (
    <AntHeader
      style={{
        padding: '0 16px',
        background: isDarkMode ? '#001529' : '#fff',
        borderBottom: `1px solid ${isDarkMode ? '#303030' : '#f0f0f0'}`,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        position: 'sticky',
        top: 0,
        zIndex: 99,
        marginLeft: collapsed ? '80px' : '260px',
        width: `calc(100% - ${collapsed ? '80px' : '260px'})`,
        transition: 'all 0.2s',
      }}
    >
      {/* Left side */}
      <Space align="center">
        <Button
          type="text"
          icon={collapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />}
          onClick={onToggle}
          style={{
            fontSize: '16px',
            width: 40,
            height: 40,
          }}
        />
        
        <div style={{ marginLeft: '16px' }}>
          <Text strong style={{ fontSize: '16px' }}>
            Welcome back, {user?.full_name || user?.username}
          </Text>
          <br />
          <Text type="secondary" style={{ fontSize: '12px' }}>
            {new Date().toLocaleDateString('en-US', { 
              weekday: 'long', 
              year: 'numeric', 
              month: 'long', 
              day: 'numeric' 
            })}
          </Text>
        </div>
      </Space>

      {/* Right side */}
      <Space align="center" size="middle">
        {/* Theme Toggle */}
        <Tooltip title={isDarkMode ? 'Light Mode' : 'Dark Mode'}>
          <Button
            type="text"
            icon={isDarkMode ? <SunOutlined /> : <MoonOutlined />}
            onClick={toggleTheme}
            style={{ width: 40, height: 40 }}
          />
        </Tooltip>

        {/* Fullscreen Toggle */}
        <Tooltip title={isFullscreen ? 'Exit Fullscreen' : 'Enter Fullscreen'}>
          <Button
            type="text"
            icon={isFullscreen ? <FullscreenExitOutlined /> : <FullscreenOutlined />}
            onClick={toggleFullscreen}
            style={{ width: 40, height: 40 }}
          />
        </Tooltip>

        {/* Notifications */}
        <Dropdown
          menu={{ items: notificationMenuItems }}
          trigger={['click']}
          placement="bottomRight"
        >
          <Button
            type="text"
            style={{ width: 40, height: 40 }}
          >
            <Badge count={notifications.length} size="small">
              <BellOutlined style={{ fontSize: '16px' }} />
            </Badge>
          </Button>
        </Dropdown>

        {/* User Menu */}
        <Dropdown
          menu={{ items: userMenuItems }}
          trigger={['click']}
          placement="bottomRight"
        >
          <Button
            type="text"
            style={{
              height: 40,
              padding: '0 8px',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
            }}
          >
            <Avatar 
              size={32} 
              icon={<UserOutlined />}
              style={{ 
                backgroundColor: '#1890ff',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              {user?.full_name?.charAt(0) || user?.username?.charAt(0) || 'U'}
            </Avatar>
            <div style={{ textAlign: 'left', lineHeight: 1.2 }}>
              <div style={{ fontSize: '14px', fontWeight: 500 }}>
                {user?.full_name || user?.username}
              </div>
              <div style={{ fontSize: '12px', color: '#666' }}>
                {user?.roles?.[0]?.display_name || 'User'}
              </div>
            </div>
          </Button>
        </Dropdown>
      </Space>
    </AntHeader>
  );
};

export default Header;