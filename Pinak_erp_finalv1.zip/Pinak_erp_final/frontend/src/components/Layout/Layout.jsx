import React, { useState, useEffect } from 'react';
import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, Package, Users, UserCheck, ShoppingCart, 
  FileText, TrendingUp, Settings, Database, LogOut, Menu, X,
  DollarSign, RotateCcw, Receipt, Truck, CreditCard,
  ChevronDown, ChevronRight, Bell, Search, Sun, Moon,
  Building2, Gift, BarChart3
} from 'lucide-react';

const Layout = () => {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [expandedMenus, setExpandedMenus] = useState({});
  const [darkMode, setDarkMode] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const [userInfo, setUserInfo] = useState({ name: 'Admin User', role: 'Administrator' });
  
  const location = useLocation();
  const navigate = useNavigate();

  const menuItems = [
    {
      title: 'Dashboard',
      icon: LayoutDashboard,
      path: '/',
      badge: null
    },
    {
      title: 'Sales',
      icon: ShoppingCart,
      submenu: [
        { title: 'POS', path: '/pos', icon: CreditCard },
        { title: 'Sales List', path: '/sales', icon: FileText },
        { title: 'Sale Returns', path: '/sale-returns', icon: RotateCcw }
      ]
    },
    {
      title: 'Purchases',
      icon: Truck,
      submenu: [
        { title: 'Purchase Bills', path: '/purchases', icon: Receipt },
        { title: 'Purchase Returns', path: '/purchase-returns', icon: RotateCcw }
      ]
    },
    {
      title: 'Inventory',
      icon: Package,
      submenu: [
        { title: 'Items', path: '/items', icon: Package },
        { title: 'Stock Report', path: '/reports/stock', icon: BarChart3 }
      ]
    },
    {
      title: 'Parties',
      icon: Users,
      submenu: [
        { title: 'Customers', path: '/customers', icon: Users },
        { title: 'Suppliers', path: '/suppliers', icon: Truck },
        { title: 'Staff', path: '/staff', icon: UserCheck }
      ]
    },
    {
      title: 'Finance',
      icon: DollarSign,
      submenu: [
        { title: 'Expenses', path: '/expenses', icon: Receipt },
        { title: 'GST Report', path: '/reports/gst', icon: FileText }
      ]
    },
    {
      title: 'Reports',
      icon: TrendingUp,
      submenu: [
        { title: 'All Reports', path: '/reports', icon: BarChart3 },
        { title: 'Sales Report', path: '/reports/sales', icon: TrendingUp },
        { title: 'Customer Analytics', path: '/reports/customers', icon: Users }
      ]
    },
    {
      title: 'System',
      icon: Settings,
      submenu: [
        { title: 'Settings', path: '/settings', icon: Settings },
        { title: 'Backup & Restore', path: '/backup', icon: Database },
        { title: 'User Management', path: '/users', icon: UserCheck }
      ]
    }
  ];

  useEffect(() => {
    // Check localStorage for theme preference
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark') {
      setDarkMode(true);
      document.documentElement.classList.add('dark');
    }

    // Load user info
    const userData = JSON.parse(localStorage.getItem('user') || '{}');
    if (userData.name) {
      setUserInfo(userData);
    }

    // Simulate notifications
    fetchNotifications();
  }, []);

  const fetchNotifications = async () => {
    // Simulated notifications - replace with API call
    setNotifications([
      { id: 1, type: 'info', message: 'Low stock alert: 5 items below threshold' },
      { id: 2, type: 'success', message: 'Backup completed successfully' }
    ]);
  };

  const toggleMenu = (title) => {
    setExpandedMenus(prev => ({
      ...prev,
      [title]: !prev[title]
    }));
  };

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    if (!darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    navigate('/login');
  };

  const isActive = (path) => {
    return location.pathname === path;
  };

  const isParentActive = (submenu) => {
    return submenu?.some(item => location.pathname === item.path);
  };

  return (
    <div className={`flex h-screen bg-gray-50 ${darkMode ? 'dark' : ''}`}>
      {/* Sidebar */}
      <aside className={`${sidebarOpen ? 'w-64' : 'w-20'} ${mobileMenuOpen ? 'translate-x-0' : '-translate-x-full'} 
        lg:translate-x-0 fixed lg:static inset-y-0 left-0 z-50 transition-all duration-300 
        bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700`}>
        
        {/* Logo Section */}
        <div className="flex items-center justify-between h-16 px-4 border-b border-gray-200 dark:border-gray-700">
          <div className={`flex items-center ${!sidebarOpen && 'lg:justify-center'}`}>
            <Building2 className="w-8 h-8 text-indigo-600" />
            {sidebarOpen && (
              <span className="ml-2 text-xl font-bold text-gray-900 dark:text-white">
                ERP System
              </span>
            )}
          </div>
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="hidden lg:block p-1 rounded hover:bg-gray-100 dark:hover:bg-gray-700"
          >
            {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

        {/* Navigation Menu */}
        <nav className="flex-1 px-2 py-4 space-y-1 overflow-y-auto">
          {menuItems.map((item) => (
            <div key={item.title}>
              {item.submenu ? (
                <>
                  <button
                    onClick={() => toggleMenu(item.title)}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-lg
                      transition-colors group hover:bg-gray-100 dark:hover:bg-gray-700
                      ${isParentActive(item.submenu) ? 'bg-indigo-50 dark:bg-gray-700' : ''}`}
                  >
                    <div className="flex items-center">
                      <item.icon className={`w-5 h-5 ${isParentActive(item.submenu) ? 'text-indigo-600' : 'text-gray-500'}`} />
                      {sidebarOpen && (
                        <span className={`ml-3 ${isParentActive(item.submenu) ? 'text-indigo-600 font-medium' : 'text-gray-700 dark:text-gray-300'}`}>
                          {item.title}
                        </span>
                      )}
                    </div>
                    {sidebarOpen && (
                      expandedMenus[item.title] ? 
                        <ChevronDown className="w-4 h-4 text-gray-400" /> : 
                        <ChevronRight className="w-4 h-4 text-gray-400" />
                    )}
                  </button>
                  
                  {sidebarOpen && expandedMenus[item.title] && (
                    <div className="ml-4 mt-1 space-y-1">
                      {item.submenu.map((subItem) => (
                        <Link
                          key={subItem.path}
                          to={subItem.path}
                          className={`flex items-center px-3 py-2 rounded-lg transition-colors
                            ${isActive(subItem.path) 
                              ? 'bg-indigo-100 text-indigo-600 dark:bg-indigo-900 dark:text-indigo-300' 
                              : 'text-gray-600 hover:bg-gray-50 dark:text-gray-400 dark:hover:bg-gray-700'}`}
                        >
                          <subItem.icon className="w-4 h-4" />
                          <span className="ml-3 text-sm">{subItem.title}</span>
                        </Link>
                      ))}
                    </div>
                  )}
                </>
              ) : (
                <Link
                  to={item.path}
                  className={`flex items-center px-3 py-2 rounded-lg transition-colors
                    ${isActive(item.path) 
                      ? 'bg-indigo-100 text-indigo-600 dark:bg-indigo-900 dark:text-indigo-300' 
                      : 'text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700'}`}
                >
                  <item.icon className="w-5 h-5" />
                  {sidebarOpen && (
                    <span className="ml-3">{item.title}</span>
                  )}
                  {item.badge && sidebarOpen && (
                    <span className="ml-auto px-2 py-0.5 text-xs bg-red-500 text-white rounded-full">
                      {item.badge}
                    </span>
                  )}
                </Link>
              )}
            </div>
          ))}
        </nav>

        {/* User Section */}
        {sidebarOpen && (
          <div className="p-4 border-t border-gray-200 dark:border-gray-700">
            <div className="flex items-center">
              <div className="w-10 h-10 rounded-full bg-indigo-500 flex items-center justify-center text-white font-bold">
                {userInfo.name.charAt(0)}
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-700 dark:text-gray-200">{userInfo.name}</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">{userInfo.role}</p>
              </div>
            </div>
          </div>
        )}
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Header */}
        <header className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between h-16 px-4 lg:px-6">
            <div className="flex items-center flex-1">
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="lg:hidden p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                <Menu className="w-6 h-6" />
              </button>
              
              {/* Search Bar */}
              <div className="ml-4 flex-1 max-w-md">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search..."
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                  />
                </div>
              </div>
            </div>

            {/* Right Section */}
            <div className="flex items-center space-x-4">
              {/* Dark Mode Toggle */}
              <button
                onClick={toggleDarkMode}
                className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                {darkMode ? 
                  <Sun className="w-5 h-5 text-yellow-500" /> : 
                  <Moon className="w-5 h-5 text-gray-500" />
                }
              </button>

              {/* Notifications */}
              <div className="relative">
                <button className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 relative">
                  <Bell className="w-5 h-5 text-gray-500" />
                  {notifications.length > 0 && (
                    <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
                  )}
                </button>
              </div>

              {/* Logout */}
              <button
                onClick={handleLogout}
                className="flex items-center px-3 py-2 text-sm bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition-colors"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </button>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-y-auto bg-gray-50 dark:bg-gray-900">
          <div className="container mx-auto px-4 lg:px-6 py-6">
            <Outlet />
          </div>
        </main>
      </div>

      {/* Mobile Menu Overlay */}
      {mobileMenuOpen && (
        <div 
          className="lg:hidden fixed inset-0 bg-black bg-opacity-50 z-40"
          onClick={() => setMobileMenuOpen(false)}
        />
      )}
    </div>
  );
};

export default Layout;