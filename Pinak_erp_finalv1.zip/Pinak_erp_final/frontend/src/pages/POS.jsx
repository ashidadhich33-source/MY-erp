// frontend/src/pages/POS.jsx
import React, { useState } from 'react';
import { ShoppingCart, Search, Plus, Minus, CreditCard, X } from 'lucide-react';
import toast from 'react-hot-toast';

export const POS = () => {
  const [cart, setCart] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [customer, setCustomer] = useState(null);
  const [paymentMode, setPaymentMode] = useState('cash');

  const addToCart = (item) => {
    const existing = cart.find(i => i.barcode === item.barcode);
    if (existing) {
      setCart(cart.map(i => 
        i.barcode === item.barcode 
          ? { ...i, quantity: i.quantity + 1 }
          : i
      ));
    } else {
      setCart([...cart, { ...item, quantity: 1 }]);
    }
    toast.success('Item added to cart');
  };

  const calculateTotal = () => {
    return cart.reduce((sum, item) => sum + (item.mrp * item.quantity), 0);
  };

  return (
    <div className="flex h-[calc(100vh-8rem)] gap-4">
      {/* Left: Product Search */}
      <div className="flex-1 bg-white rounded-lg shadow-sm border border-gray-200 p-4">
        <div className="mb-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search by barcode or product name..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
              autoFocus
            />
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {/* Sample Products */}
          {[
            { barcode: '123456', name: 'T-Shirt Blue', mrp: 999, stock: 50 },
            { barcode: '123457', name: 'Jeans Black', mrp: 1999, stock: 30 },
            { barcode: '123458', name: 'Sneakers White', mrp: 2999, stock: 20 },
            { barcode: '123459', name: 'Cap Red', mrp: 499, stock: 100 }
          ].map((product) => (
            <div 
              key={product.barcode}
              onClick={() => addToCart(product)}
              className="border border-gray-200 rounded-lg p-3 hover:shadow-md cursor-pointer transition-shadow"
            >
              <div className="aspect-square bg-gray-100 rounded mb-2"></div>
              <p className="text-sm font-medium text-gray-900">{product.name}</p>
              <p className="text-lg font-bold text-indigo-600">₹{product.mrp}</p>
              <p className="text-xs text-gray-500">Stock: {product.stock}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Right: Cart */}
      <div className="w-96 bg-white rounded-lg shadow-sm border border-gray-200 flex flex-col">
        <div className="p-4 border-b border-gray-200">
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <ShoppingCart className="w-5 h-5" />
            Shopping Cart
          </h2>
        </div>

        <div className="flex-1 overflow-y-auto p-4">
          {cart.length === 0 ? (
            <p className="text-center text-gray-500 py-8">Cart is empty</p>
          ) : (
            <div className="space-y-3">
              {cart.map((item) => (
                <div key={item.barcode} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">{item.name}</p>
                    <p className="text-sm text-gray-600">₹{item.mrp} × {item.quantity}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button className="p-1 hover:bg-gray-200 rounded">
                      <Minus className="w-4 h-4" />
                    </button>
                    <span className="w-8 text-center">{item.quantity}</span>
                    <button className="p-1 hover:bg-gray-200 rounded">
                      <Plus className="w-4 h-4" />
                    </button>
                    <button className="p-1 hover:bg-red-100 text-red-600 rounded ml-2">
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="border-t border-gray-200 p-4">
          <div className="space-y-2 mb-4">
            <div className="flex justify-between">
              <span className="text-gray-600">Subtotal</span>
              <span className="font-medium">₹{calculateTotal()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">GST</span>
              <span className="font-medium">Included</span>
            </div>
            <div className="flex justify-between text-lg font-bold">
              <span>Total</span>
              <span className="text-indigo-600">₹{calculateTotal()}</span>
            </div>
          </div>

          <button className="w-full py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 flex items-center justify-center gap-2">
            <CreditCard className="w-5 h-5" />
            Process Payment
          </button>
        </div>
      </div>
    </div>
  );
};