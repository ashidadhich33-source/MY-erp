// frontend/src/pages/Items/ItemsPage.jsx
import React, { useState, useEffect } from 'react';
import {
  Table,
  Button,
  Input,
  Space,
  Modal,
  Form,
  Select,
  InputNumber,
  Switch,
  Upload,
  message,
  Popconfirm,
  Tag,
  Badge,
  Card,
  Row,
  Col,
  Statistic,
  Drawer,
  Tabs,
  Typography,
  Alert,
} from 'antd';
import {
  PlusOutlined,
  EditOutlined,
  DeleteOutlined,
  UploadOutlined,
  DownloadOutlined,
  SearchOutlined,
  BarcodeOutlined,
  InboxOutlined,
  WarningOutlined,
} from '@ant-design/icons';
import { itemService } from '../../services/apiClient';
import { useAuth } from '../../contexts/AuthContext';

const { Search } = Input;
const { Option } = Select;
const { Text, Title } = Typography;
const { TabPane } = Tabs;

const ItemsPage = () => {
  const { hasPermission } = useAuth();
  const [items, setItems] = useState([]);
  const [categories, setCategories] = useState([]);
  const [brands, setBrands] = useState([]);
  const [loading, setLoading] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [drawerVisible, setDrawerVisible] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [selectedItem, setSelectedItem] = useState(null);
  const [searchText, setSearchText] = useState('');
  const [filters, setFilters] = useState({
    category_id: null,
    brand: null,
    status: 'active',
    low_stock: false,
  });
  const [stats, setStats] = useState({
    total_items: 0,
    low_stock_count: 0,
    total_value: 0,
  });
  const [form] = Form.useForm();

  useEffect(() => {
    loadItems();
    loadCategories();
    loadBrands();
    loadStats();
  }, []);

  useEffect(() => {
    loadItems();
  }, [searchText, filters]);

  const loadItems = async () => {
    try {
      setLoading(true);
      const params = {
        search: searchText,
        limit: 100,
        ...filters,
      };

      const response = await itemService.getItems(params);
      setItems(response.data);
    } catch (error) {
      message.error('Failed to load items');
    } finally {
      setLoading(false);
    }
  };

  const loadCategories = async () => {
    try {
      const response = await itemService.getCategories();
      setCategories(response.data);
    } catch (error) {
      console.error('Failed to load categories:', error);
    }
  };

  const loadBrands = async () => {
    try {
      const response = await itemService.getBrands();
      setBrands(response.data);
    } catch (error) {
      console.error('Failed to load brands:', error);
    }
  };

  const loadStats = async () => {
    try {
      const lowStockResponse = await itemService.getLowStockItems();
      const totalItems = await itemService.getItems({ limit: 1 });
      
      setStats({
        total_items: totalItems.data.length,
        low_stock_count: lowStockResponse.data.total_count,
        total_value: 0, // Calculate from stock valuation API
      });
    } catch (error) {
      console.error('Failed to load stats:', error);
    }
  };

  const handleCreate = () => {
    setEditingItem(null);
    form.resetFields();
    setModalVisible(true);
  };

  const handleEdit = (record) => {
    setEditingItem(record);
    form.setFieldsValue(record);
    setModalVisible(true);
  };

  const handleDelete = async (id) => {
    try {
      await itemService.deleteItem(id);
      message.success('Item deleted successfully');
      loadItems();
    } catch (error) {
      message.error('Failed to delete item');
    }
  };

  const handleSave = async (values) => {
    try {
      if (editingItem) {
        await itemService.updateItem(editingItem.id, values);
        message.success('Item updated successfully');
      } else {
        await itemService.createItem(values);
        message.success('Item created successfully');
      }
      setModalVisible(false);
      loadItems();
      loadStats();
    } catch (error) {
      message.error('Failed to save item');
    }
  };

  const handleImport = async (file) => {
    try {
      await itemService.importFromExcel(file);
      message.success('Items imported successfully');
      loadItems();
      loadStats();
    } catch (error) {
      message.error('Failed to import items');
    }
    return false; // Prevent auto upload
  };

  const handleExport = async () => {
    try {
      const response = await itemService.exportToExcel();
      
      // Create blob and download
      const blob = new Blob([response.data], {
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
      });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'items_export.xlsx';
      document.body.appendChild(link);
      link.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(link);
      
      message.success('Items exported successfully');
    } catch (error) {
      message.error('Failed to export items');
    }
  };

  const columns = [
    {
      title: 'Barcode',
      dataIndex: 'barcode',
      key: 'barcode',
      width: 120,
      render: (text) => <Text code>{text}</Text>,
    },
    {
      title: 'Item Details',
      key: 'details',
      render: (_, record) => (
        <div>
          <div style={{ fontWeight: 'bold' }}>{record.name}</div>
          <Text type="secondary" style={{ fontSize: '12px' }}>
            {record.style_code}
          </Text>
          {record.color && (
            <Tag size="small" style={{ marginLeft: '4px' }}>
              {record.color}
            </Tag>
          )}
          {record.size && (
            <Tag size="small">{record.size}</Tag>
          )}
        </div>
      ),
    },
    {
      title: 'Category',
      dataIndex: 'category_name',
      key: 'category',
      render: (text) => text || '-',
    },
    {
      title: 'Brand',
      dataIndex: 'brand_name',
      key: 'brand',
      render: (text) => text || '-',
    },
    {
      title: 'MRP',
      dataIndex: 'mrp',
      key: 'mrp',
      render: (value) => value ? `₹${value}` : '-',
      align: 'right',
    },
    {
      title: 'Stock',
      key: 'stock',
      render: (_, record) => {
        const stock = record.current_stock;
        const minLevel = record.min_stock_level;
        const isLowStock = stock <= minLevel;
        
        return (
          <div>
            <Badge
              count={stock}
              showZero
              style={{
                backgroundColor: isLowStock ? '#f5222d' : stock > 0 ? '#52c41a' : '#d9d9d9'
              }}
            />
            {isLowStock && <WarningOutlined style={{ color: '#f5222d', marginLeft: '4px' }} />}
          </div>
        );
      },
      align: 'center',
    },
    {
      title: 'Status',
      dataIndex: 'status',
      key: 'status',
      render: (status) => (
        <Tag color={status === 'active' ? 'green' : 'red'}>
          {status.toUpperCase()}
        </Tag>
      ),
    },
    {
      title: 'Actions',
      key: 'actions',
      render: (_, record) => (
        <Space>
          <Button
            size="small"
            icon={<SearchOutlined />}
            onClick={() => {
              setSelectedItem(record);
              setDrawerVisible(true);
            }}
          >
            View
          </Button>
          {hasPermission('items.edit') && (
            <Button
              size="small"
              icon={<EditOutlined />}
              onClick={() => handleEdit(record)}
            />
          )}
          {hasPermission('items.delete') && (
            <Popconfirm
              title="Are you sure you want to delete this item?"
              onConfirm={() => handleDelete(record.id)}
            >
              <Button size="small" icon={<DeleteOutlined />} danger />
            </Popconfirm>
          )}
        </Space>
      ),
    },
  ];

  return (
    <div>
      {/* Page Header */}
      <div style={{ marginBottom: '24px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
          <div>
            <Title level={2} style={{ margin: 0 }}>Items Management</Title>
            <Text type="secondary">Manage your product inventory</Text>
          </div>
          <Space>
            {hasPermission('items.import') && (
              <Upload
                accept=".xlsx,.xls"
                beforeUpload={handleImport}
                showUploadList={false}
              >
                <Button icon={<UploadOutlined />}>Import Excel</Button>
              </Upload>
            )}
            {hasPermission('items.export') && (
              <Button icon={<DownloadOutlined />} onClick={handleExport}>
                Export Excel
              </Button>
            )}
            {hasPermission('items.create') && (
              <Button type="primary" icon={<PlusOutlined />} onClick={handleCreate}>
                Add Item
              </Button>
            )}
          </Space>
        </div>

        {/* Stats Cards */}
        <Row gutter={16} style={{ marginBottom: '24px' }}>
          <Col xs={24} sm={8}>
            <Card>
              <Statistic
                title="Total Items"
                value={stats.total_items}
                prefix={<InboxOutlined />}
              />
            </Card>
          </Col>
          <Col xs={24} sm={8}>
            <Card>
              <Statistic
                title="Low Stock Items"
                value={stats.low_stock_count}
                prefix={<WarningOutlined />}
                valueStyle={{ color: stats.low_stock_count > 0 ? '#f5222d' : '#52c41a' }}
              />
            </Card>
          </Col>
          <Col xs={24} sm={8}>
            <Card>
              <Statistic
                title="Total Stock Value"
                value={stats.total_value}
                prefix="₹"
                precision={0}
              />
            </Card>
          </Col>
        </Row>

        {/* Filters */}
        <Card style={{ marginBottom: '16px' }}>
          <Row gutter={16} align="middle">
            <Col flex="auto">
              <Search
                placeholder="Search items by name, barcode, or style code"
                allowClear
                size="large"
                value={searchText}
                onChange={(e) => setSearchText(e.target.value)}
                style={{ width: '100%' }}
              />
            </Col>
            <Col>
              <Select
                placeholder="Category"
                style={{ width: 150 }}
                value={filters.category_id}
                onChange={(value) => setFilters({ ...filters, category_id: value })}
                allowClear
              >
                {categories.map(cat => (
                  <Option key={cat.id} value={cat.id}>{cat.display_name}</Option>
                ))}
              </Select>
            </Col>
            <Col>
              <Select
                placeholder="Brand"
                style={{ width: 120 }}
                value={filters.brand}
                onChange={(value) => setFilters({ ...filters, brand: value })}
                allowClear
              >
                {brands.map(brand => (
                  <Option key={brand.id} value={brand.name}>{brand.display_name}</Option>
                ))}
              </Select>
            </Col>
            <Col>
              <Select
                style={{ width: 120 }}
                value={filters.status}
                onChange={(value) => setFilters({ ...filters, status: value })}
              >
                <Option value="active">Active</Option>
                <Option value="inactive">Inactive</Option>
              </Select>
            </Col>
            <Col>
              <Button
                type={filters.low_stock ? 'primary' : 'default'}
                icon={<WarningOutlined />}
                onClick={() => setFilters({ ...filters, low_stock: !filters.low_stock })}
              >
                Low Stock
              </Button>
            </Col>
          </Row>
        </Card>
      </div>

      {/* Low Stock Alert */}
      {stats.low_stock_count > 0 && !filters.low_stock && (
        <Alert
          message={`${stats.low_stock_count} items are running low on stock`}
          type="warning"
          action={
            <Button
              size="small"
              onClick={() => setFilters({ ...filters, low_stock: true })}
            >
              View Low Stock Items
            </Button>
          }
          showIcon
          style={{ marginBottom: '16px' }}
        />
      )}

      {/* Items Table */}
      <Card>
        <Table
          dataSource={items}
          columns={columns}
          rowKey="id"
          loading={loading}
          pagination={{
            showSizeChanger: true,
            showQuickJumper: true,
            showTotal: (total, range) => `${range[0]}-${range[1]} of ${total} items`,
          }}
        />
      </Card>

      {/* Add/Edit Modal */}
      <Modal
        title={editingItem ? 'Edit Item' : 'Add New Item'}
        open={modalVisible}
        onCancel={() => setModalVisible(false)}
        footer={null}
        width={800}
        destroyOnClose
      >
        <Form
          form={form}
          layout="vertical"
          onFinish={handleSave}
          initialValues={{
            status: 'active',
            is_stockable: true,
            track_inventory: true,
            uom: 'PCS',
            gst_rate: 18,
          }}
        >
          <Row gutter={16}>
            <Col span={12}>
              <Form.Item
                name="barcode"
                label="Barcode"
                rules={[{ required: true, message: 'Please enter barcode' }]}
              >
                <Input prefix={<BarcodeOutlined />} placeholder="Enter barcode" />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                name="style_code"
                label="Style Code"
                rules={[{ required: true, message: 'Please enter style code' }]}
              >
                <Input placeholder="Enter style code" />
              </Form.Item>
            </Col>
          </Row>

          <Form.Item
            name="name"
            label="Item Name"
            rules={[{ required: true, message: 'Please enter item name' }]}
          >
            <Input placeholder="Enter item name" />
          </Form.Item>

          <Form.Item name="description" label="Description">
            <Input.TextArea rows={2} placeholder="Enter description" />
          </Form.Item>

          <Row gutter={16}>
            <Col span={8}>
              <Form.Item name="color" label="Color">
                <Input placeholder="Enter color" />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name="size" label="Size">
                <Input placeholder="Enter size" />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name="brand" label="Brand">
                <Input placeholder="Enter brand" />
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={16}>
            <Col span={12}>
              <Form.Item name="category_id" label="Category">
                <Select placeholder="Select category">
                  {categories.map(cat => (
                    <Option key={cat.id} value={cat.id}>{cat.display_name}</Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item name="hsn_code" label="HSN Code">
                <Input placeholder="Enter HSN code" />
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={16}>
            <Col span={8}>
              <Form.Item name="mrp" label="MRP">
                <InputNumber
                  style={{ width: '100%' }}
                  placeholder="0.00"
                  formatter={value => `₹ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
                  parser={value => value.replace(/₹\s?|(,*)/g, '')}
                />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name="purchase_rate" label="Purchase Rate">
                <InputNumber
                  style={{ width: '100%' }}
                  placeholder="0.00"
                  formatter={value => `₹ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
                  parser={value => value.replace(/₹\s?|(,*)/g, '')}
                />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name="selling_price" label="Selling Price">
                <InputNumber
                  style={{ width: '100%' }}
                  placeholder="0.00"
                  formatter={value => `₹ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
                  parser={value => value.replace(/₹\s?|(,*)/g, '')}
                />
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={16}>
            <Col span={8}>
              <Form.Item name="min_stock_level" label="Min Stock Level">
                <InputNumber style={{ width: '100%' }} min={0} placeholder="0" />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name="uom" label="Unit">
                <Select>
                  <Option value="PCS">PCS</Option>
                  <Option value="KG">KG</Option>
                  <Option value="LTR">LTR</Option>
                  <Option value="MTR">MTR</Option>
                </Select>
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name="gst_rate" label="GST Rate (%)">
                <Select>
                  <Option value={0}>0%</Option>
                  <Option value={5}>5%</Option>
                  <Option value={12}>12%</Option>
                  <Option value={18}>18%</Option>
                  <Option value={28}>28%</Option>
                </Select>
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={16}>
            <Col span={8}>
              <Form.Item name="track_inventory" valuePropName="checked" label="Track Inventory">
                <Switch />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name="is_service" valuePropName="checked" label="Is Service">
                <Switch />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name="status" label="Status">
                <Select>
                  <Option value="active">Active</Option>
                  <Option value="inactive">Inactive</Option>
                </Select>
              </Form.Item>
            </Col>
          </Row>

          <Form.Item style={{ textAlign: 'right', marginBottom: 0 }}>
            <Space>
              <Button onClick={() => setModalVisible(false)}>Cancel</Button>
              <Button type="primary" htmlType="submit">
                {editingItem ? 'Update' : 'Create'} Item
              </Button>
            </Space>
          </Form.Item>
        </Form>
      </Modal>

      {/* Item Details Drawer */}
      <Drawer
        title="Item Details"
        placement="right"
        onClose={() => setDrawerVisible(false)}
        open={drawerVisible}
        width={500}
      >
        {selectedItem && (
          <div>
            <Card title="Basic Information" style={{ marginBottom: '16px' }}>
              <Row gutter={[16, 8]}>
                <Col span={8}><Text strong>Barcode:</Text></Col>
                <Col span={16}><Text code>{selectedItem.barcode}</Text></Col>
                
                <Col span={8}><Text strong>Name:</Text></Col>
                <Col span={16}><Text>{selectedItem.name}</Text></Col>
                
                <Col span={8}><Text strong>Style Code:</Text></Col>
                <Col span={16}><Text>{selectedItem.style_code}</Text></Col>
                
                <Col span={8}><Text strong>Status:</Text></Col>
                <Col span={16}>
                  <Tag color={selectedItem.status === 'active' ? 'green' : 'red'}>
                    {selectedItem.status.toUpperCase()}
                  </Tag>
                </Col>
              </Row>
            </Card>

            <Card title="Pricing" style={{ marginBottom: '16px' }}>
              <Row gutter={[16, 8]}>
                <Col span={8}><Text strong>MRP:</Text></Col>
                <Col span={16}><Text>₹{selectedItem.mrp || 0}</Text></Col>
                
                <Col span={8}><Text strong>Purchase Rate:</Text></Col>
                <Col span={16}><Text>₹{selectedItem.purchase_rate || 0}</Text></Col>
                
                <Col span={8}><Text strong>Selling Price:</Text></Col>
                <Col span={16}><Text>₹{selectedItem.selling_price || 0}</Text></Col>
              </Row>
            </Card>

            <Card title="Stock Information">
              <Row gutter={[16, 8]}>
                <Col span={8}><Text strong>Current Stock:</Text></Col>
                <Col span={16}>
                  <Badge
                    count={selectedItem.current_stock || 0}
                    style={{
                      backgroundColor: selectedItem.current_stock > selectedItem.min_stock_level 
                        ? '#52c41a' : '#f5222d'
                    }}
                  />
                </Col>
                
                <Col span={8}><Text strong>Min Level:</Text></Col>
                <Col span={16}><Text>{selectedItem.min_stock_level}</Text></Col>
                
                <Col span={8}><Text strong>Stock Value:</Text></Col>
                <Col span={16}><Text>₹{selectedItem.stock_value || 0}</Text></Col>
              </Row>
            </Card>
          </div>
        )}
      </Drawer>
    </div>
  );
};

export default ItemsPage;