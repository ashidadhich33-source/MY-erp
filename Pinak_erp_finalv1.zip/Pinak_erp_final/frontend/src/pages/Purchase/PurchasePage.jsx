// frontend/src/pages/Purchase/PurchasePage.jsx
import React, { useState, useEffect } from 'react';
import {
  Table,
  Button,
  Input,
  Space,
  Modal,
  Form,
  Select,
  DatePicker,
  InputNumber,
  Card,
  Row,
  Col,
  Statistic,
  Tag,
  Drawer,
  Steps,
  Typography,
  Divider,
  message,
  Popconfirm,
  Badge,
  Tabs,
  Alert,
  Progress,
} from 'antd';
import {
  PlusOutlined,
  EditOutlined,
  DeleteOutlined,
  EyeOutlined,
  SearchOutlined,
  ShoppingOutlined,
  FileTextOutlined,
  CheckOutlined,
  ClockCircleOutlined,
  PrinterOutlined,
  InboxOutlined,
  DollarOutlined,
  TruckOutlined,
} from '@ant-design/icons';
import { purchaseService, itemService } from '../../services/apiClient';
import { useAuth } from '../../contexts/AuthContext';
import dayjs from 'dayjs';

const { Search } = Input;
const { Option } = Select;
const { Text, Title } = Typography;
const { Step } = Steps;
const { TabPane } = Tabs;
const { RangePicker } = DatePicker;

const PurchasePage = () => {
  const { hasPermission } = useAuth();
  const [activeTab, setActiveTab] = useState('orders');
  const [orders, setOrders] = useState([]);
  const [invoices, setInvoices] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [orderModalVisible, setOrderModalVisible] = useState(false);
  const [invoiceModalVisible, setInvoiceModalVisible] = useState(false);
  const [orderDrawerVisible, setOrderDrawerVisible] = useState(false);
  const [invoiceDrawerVisible, setInvoiceDrawerVisible] = useState(false);
  const [editingOrder, setEditingOrder] = useState(null);
  const [editingInvoice, setEditingInvoice] = useState(null);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [selectedInvoice, setSelectedInvoice] = useState(null);
  const [orderForm] = Form.useForm();
  const [invoiceForm] = Form.useForm();
  const [searchText, setSearchText] = useState('');
  const [dateRange, setDateRange] = useState([]);
  const [stats, setStats] = useState({
    total_orders: 0,
    total_invoices: 0,
    total_amount: 0,
    pending_orders: 0,
  });

  useEffect(() => {
    loadOrders();
    loadInvoices();
    loadSuppliers();
    loadItems();
    loadStats();
  }, []);

  useEffect(() => {
    if (activeTab === 'orders') {
      loadOrders();
    } else {
      loadInvoices();
    }
  }, [activeTab, searchText, dateRange]);

  const loadOrders = async () => {
    try {
      setLoading(true);
      const params = {
        search: searchText,
        limit: 100,
      };
      
      if (dateRange.length === 2) {
        params.date_from = dateRange[0].format('YYYY-MM-DD');
        params.date_to = dateRange[1].format('YYYY-MM-DD');
      }

      const response = await purchaseService.getOrders(params);
      setOrders(response.data);
    } catch (error) {
      message.error('Failed to load purchase orders');
    } finally {
      setLoading(false);
    }
  };

  const loadInvoices = async () => {
    try {
      setLoading(true);
      const params = {
        search: searchText,
        limit: 100,
      };
      
      if (dateRange.length === 2) {
        params.date_from = dateRange[0].format('YYYY-MM-DD');
        params.date_to = dateRange[1].format('YYYY-MM-DD');
      }

      const response = await purchaseService.getInvoices(params);
      setInvoices(response.data);
    } catch (error) {
      message.error('Failed to load purchase invoices');
    } finally {
      setLoading(false);
    }
  };

  const loadSuppliers = async () => {
    try {
      const response = await purchaseService.getSuppliers({ limit: 500 });
      setSuppliers(response.data);
    } catch (error) {
      console.error('Failed to load suppliers:', error);
    }
  };

  const loadItems = async () => {
    try {
      const response = await itemService.getItems({ limit: 500 });
      setItems(response.data);
    } catch (error) {
      console.error('Failed to load items:', error);
    }
  };

  const loadStats = async () => {
    try {
      const [ordersRes, invoicesRes] = await Promise.all([
        purchaseService.getOrders({ limit: 1000 }),
        purchaseService.getInvoices({ limit: 1000 }),
      ]);

      const orders = ordersRes.data;
      const invoices = invoicesRes.data;

      setStats({
        total_orders: orders.length,
        total_invoices: invoices.length,
        total_amount: invoices.reduce((sum, inv) => sum + inv.total_amount, 0),
        pending_orders: orders.filter(o => o.status === 'pending').length,
      });
    } catch (error) {
      console.error('Failed to load stats:', error);
    }
  };

  const handleCreateOrder = () => {
    setEditingOrder(null);
    orderForm.resetFields();
    orderForm.setFieldsValue({
      order_date: dayjs(),
      items: [{ item_id: null, quantity: 1, unit_price: 0 }],
    });
    setOrderModalVisible(true);
  };

  const handleEditOrder = (record) => {
    setEditingOrder(record);
    orderForm.setFieldsValue({
      ...record,
      order_date: dayjs(record.order_date),
      expected_date: record.expected_date ? dayjs(record.expected_date) : null,
    });
    setOrderModalVisible(true);
  };

  const handleCreateInvoice = (order = null) => {
    setEditingInvoice(null);
    invoiceForm.resetFields();
    
    if (order) {
      invoiceForm.setFieldsValue({
        supplier_id: order.supplier_id,
        order_id: order.id,
        items: order.items?.map(item => ({
          item_id: item.item_id,
          quantity: item.quantity,
          unit_price: item.unit_price,
        })) || [],
      });
    } else {
      invoiceForm.setFieldsValue({
        invoice_date: dayjs(),
        items: [{ item_id: null, quantity: 1, unit_price: 0 }],
      });
    }
    
    setInvoiceModalVisible(true);
  };

  const handleSaveOrder = async (values) => {
    try {
      const orderData = {
        ...values,
        expected_date: values.expected_date?.format('YYYY-MM-DD') || null,
      };

      if (editingOrder) {
        await purchaseService.updateOrder(editingOrder.id, orderData);
        message.success('Purchase order updated successfully');
      } else {
        await purchaseService.createOrder(orderData);
        message.success('Purchase order created successfully');
      }
      
      setOrderModalVisible(false);
      loadOrders();
      loadStats();
    } catch (error) {
      message.error('Failed to save purchase order');
    }
  };

  const handleSaveInvoice = async (values) => {
    try {
      const invoiceData = {
        ...values,
        due_date: values.due_date?.format('YYYY-MM-DD') || null,
      };

      if (editingInvoice) {
        await purchaseService.updateInvoice(editingInvoice.id, invoiceData);
        message.success('Purchase invoice updated successfully');
      } else {
        await purchaseService.createInvoice(invoiceData);
        message.success('Purchase invoice created successfully');
      }
      
      setInvoiceModalVisible(false);
      loadInvoices();
      loadStats();
    } catch (error) {
      message.error('Failed to save purchase invoice');
    }
  };

  const handleUpdateOrderStatus = async (id, status) => {
    try {
      await purchaseService.updateOrderStatus(id, status);
      message.success(`Order ${status} successfully`);
      loadOrders();
    } catch (error) {
      message.error(`Failed to ${status} order`);
    }
  };

  const handleUpdatePaymentStatus = async (id, amount) => {
    try {
      await purchaseService.updateInvoicePaymentStatus(id, amount);
      message.success('Payment status updated successfully');
      loadInvoices();
    } catch (error) {
      message.error('Failed to update payment status');
    }
  };

  // Purchase Orders columns
  const orderColumns = [
    {
      title: 'Order #',
      dataIndex: 'order_number',
      key: 'order_number',
      render: (text) => <Text code>{text}</Text>,
    },
    {
      title: 'Date',
      dataIndex: 'order_date',
      key: 'order_date',
      render: (date) => dayjs(date).format('DD MMM YYYY'),
    },
    {
      title: 'Supplier',
      dataIndex: 'supplier_name',
      key: 'supplier_name',
      render: (text) => <Text strong>{text}</Text>,
    },
    {
      title: 'Expected Date',
      dataIndex: 'expected_date',
      key: 'expected_date',
      render: (date) => date ? dayjs(date).format('DD MMM YYYY') : '-',
    },
    {
      title: 'Items',
      dataIndex: 'items',
      key: 'items',
      render: (items) => (
        <Badge count={items?.length || 0} showZero style={{ backgroundColor: '#1890ff' }} />
      ),
    },
    {
      title: 'Amount',
      dataIndex: 'total_amount',
      key: 'total_amount',
      render: (amount) => `₹${amount?.toLocaleString()}`,
      align: 'right',
    },
    {
      title: 'Status',
      dataIndex: 'status',
      key: 'status',
      render: (status) => {
        const colors = {
          pending: 'orange',
          confirmed: 'blue',
          received: 'green',
          cancelled: 'red',
        };
        return <Tag color={colors[status]}>{status.toUpperCase()}</Tag>;
      },
    },
    {
      title: 'Fulfillment',
      key: 'fulfillment',
      render: (_, record) => {
        const totalItems = record.items?.reduce((sum, item) => sum + item.quantity, 0) || 0;
        const receivedItems = record.items?.reduce((sum, item) => sum + (item.received_quantity || 0), 0) || 0;
        const percentage = totalItems > 0 ? (receivedItems / totalItems) * 100 : 0;
        
        return (
          <Progress
            percent={Math.round(percentage)}
            size="small"
            status={percentage === 100 ? 'success' : 'active'}
            format={percent => `${percent}%`}
          />
        );
      },
    },
    {
      title: 'Actions',
      key: 'actions',
      render: (_, record) => (
        <Space>
          <Button
            size="small"
            icon={<EyeOutlined />}
            onClick={() => {
              setSelectedOrder(record);
              setOrderDrawerVisible(true);
            }}
          />
          {hasPermission('purchases.edit') && record.status === 'pending' && (
            <Button
              size="small"
              icon={<EditOutlined />}
              onClick={() => handleEditOrder(record)}
            />
          )}
          {hasPermission('purchases.create') && record.status === 'confirmed' && (
            <Button
              size="small"
              icon={<FileTextOutlined />}
              onClick={() => handleCreateInvoice(record)}
              type="primary"
            >
              GRN
            </Button>
          )}
          {hasPermission('purchases.edit') && (
            <Select
              size="small"
              value={record.status}
              style={{ width: 100 }}
              onChange={(value) => handleUpdateOrderStatus(record.id, value)}
            >
              <Option value="pending">Pending</Option>
              <Option value="confirmed">Confirmed</Option>
              <Option value="received">Received</Option>
              <Option value="cancelled">Cancelled</Option>
            </Select>
          )}
        </Space>
      ),
    },
  ];

  // Purchase Invoices columns
  const invoiceColumns = [
    {
      title: 'Invoice #',
      dataIndex: 'invoice_number',
      key: 'invoice_number',
      render: (text) => <Text code>{text}</Text>,
    },
    {
      title: 'Supplier Invoice',
      dataIndex: 'supplier_invoice_number',
      key: 'supplier_invoice_number',
      render: (text) => text || '-',
    },
    {
      title: 'Date',
      dataIndex: 'invoice_date',
      key: 'invoice_date',
      render: (date) => dayjs(date).format('DD MMM YYYY'),
    },
    {
      title: 'Supplier',
      dataIndex: 'supplier_name',
      key: 'supplier_name',
      render: (text) => <Text strong>{text}</Text>,
    },
    {
      title: 'Due Date',
      dataIndex: 'due_date',
      key: 'due_date',
      render: (date) => {
        if (!date) return '-';
        const dueDate = dayjs(date);
        const today = dayjs();
        const isOverdue = dueDate.isBefore(today);
        return (
          <Text style={{ color: isOverdue ? '#f5222d' : undefined }}>
            {dueDate.format('DD MMM YYYY')}
            {isOverdue && ' (Overdue)'}
          </Text>
        );
      },
    },
    {
      title: 'Amount',
      dataIndex: 'total_amount',
      key: 'total_amount',
      render: (amount) => `₹${amount?.toLocaleString()}`,
      align: 'right',
    },
    {
      title: 'Paid',
      dataIndex: 'paid_amount',
      key: 'paid_amount',
      render: (amount) => `₹${amount?.toLocaleString()}`,
      align: 'right',
    },
    {
      title: 'Balance',
      dataIndex: 'balance_amount',
      key: 'balance_amount',
      render: (amount) => (
        <Text style={{ color: amount > 0 ? '#f5222d' : '#52c41a' }}>
          ₹{amount?.toLocaleString()}
        </Text>
      ),
      align: 'right',
    },
    {
      title: 'Status',
      dataIndex: 'status',
      key: 'status',
      render: (status) => {
        const colors = {
          pending: 'red',
          partial: 'orange',
          paid: 'green',
        };
        return <Tag color={colors[status]}>{status.toUpperCase()}</Tag>;
      },
    },
    {
      title: 'Actions',
      key: 'actions',
      render: (_, record) => (
        <Space>
          <Button
            size="small"
            icon={<EyeOutlined />}
            onClick={() => {
              setSelectedInvoice(record);
              setInvoiceDrawerVisible(true);
            }}
          />
          <Button
            size="small"
            icon={<PrinterOutlined />}
            onClick={() => printInvoice(record)}
          />
          {record.status !== 'paid' && (
            <Button
              size="small"
              icon={<DollarOutlined />}
              onClick={() => {
                Modal.confirm({
                  title: 'Record Payment',
                  content: (
                    <div>
                      <p>Invoice Amount: ₹{record.total_amount}</p>
                      <p>Balance: ₹{record.balance_amount}</p>
                      <Input
                        placeholder="Enter payment amount"
                        type="number"
                        id="payment-amount"
                        defaultValue={record.balance_amount}
                      />
                    </div>
                  ),
                  onOk: () => {
                    const amount = document.getElementById('payment-amount').value;
                    if (amount) {
                      handleUpdatePaymentStatus(record.id, parseFloat(amount));
                    }
                  },
                });
              }}
            >
              Pay
            </Button>
          )}
        </Space>
      ),
    },
  ];

  const printInvoice = (invoice) => {
    const printContent = `
      <div style="max-width: 800px; margin: 0 auto; padding: 20px; font-family: Arial, sans-serif;">
        <div style="text-align: center; margin-bottom: 30px;">
          <h1>GOODS RECEIVED NOTE</h1>
          <p>GRN No: ${invoice.invoice_number}</p>
          <p>Date: ${dayjs(invoice.invoice_date).format('DD MMM YYYY')}</p>
        </div>
        
        <div style="margin-bottom: 20px;">
          <strong>Supplier:</strong><br>
          ${invoice.supplier_name}<br>
          ${invoice.supplier_invoice_number ? `Supplier Invoice: ${invoice.supplier_invoice_number}` : ''}
        </div>
        
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
          <thead>
            <tr style="background-color: #f5f5f5;">
              <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Item</th>
              <th style="border: 1px solid #ddd; padding: 8px; text-align: right;">Qty</th>
              <th style="border: 1px solid #ddd; padding: 8px; text-align: right;">Rate</th>
              <th style="border: 1px solid #ddd; padding: 8px; text-align: right;">Amount</th>
            </tr>
          </thead>
          <tbody>
            ${invoice.items?.map(item => `
              <tr>
                <td style="border: 1px solid #ddd; padding: 8px;">${item.item_name}</td>
                <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">${item.quantity}</td>
                <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">₹${item.unit_price}</td>
                <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">₹${item.line_total}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
        
        <div style="text-align: right;">
          <p>Subtotal: ₹${invoice.subtotal}</p>
          <p>Tax: ₹${invoice.tax_amount}</p>
          <p><strong>Total: ₹${invoice.total_amount}</strong></p>
        </div>
      </div>
    `;
    
    const printWindow = window.open('', '', 'width=800,height=600');
    printWindow.document.write(printContent);
    printWindow.document.close();
    printWindow.print();
    printWindow.close();
  };

  return (
    <div>
      {/* Page Header */}
      <div style={{ marginBottom: '24px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
          <div>
            <Title level={2} style={{ margin: 0 }}>Purchase Management</Title>
            <Text type="secondary">Manage purchase orders and supplier invoices</Text>
          </div>
          <Space>
            {hasPermission('purchases.create') && (
              <Button 
                type="primary" 
                icon={<PlusOutlined />} 
                onClick={activeTab === 'orders' ? handleCreateOrder : () => handleCreateInvoice()}
              >
                {activeTab === 'orders' ? 'New Purchase Order' : 'New GRN'}
              </Button>
            )}
          </Space>
        </div>

        {/* Stats Cards */}
        <Row gutter={16} style={{ marginBottom: '24px' }}>
          <Col xs={24} sm={6}>
            <Card>
              <Statistic
                title="Total Orders"
                value={stats.total_orders}
                prefix={<ShoppingOutlined />}
              />
            </Card>
          </Col>
          <Col xs={24} sm={6}>
            <Card>
              <Statistic
                title="Pending Orders"
                value={stats.pending_orders}
                prefix={<ClockCircleOutlined />}
                valueStyle={{ color: '#fa8c16' }}
              />
            </Card>
          </Col>
          <Col xs={24} sm={6}>
            <Card>
              <Statistic
                title="Total GRNs"
                value={stats.total_invoices}
                prefix={<InboxOutlined />}
              />
            </Card>
          </Col>
          <Col xs={24} sm={6}>
            <Card>
              <Statistic
                title="Purchase Amount"
                value={stats.total_amount}
                prefix="₹"
                precision={0}
                valueStyle={{ color: '#3f8600' }}
              />
            </Card>
          </Col>
        </Row>

        {/* Filters */}
        <Card style={{ marginBottom: '16px' }}>
          <Row gutter={16} align="middle">
            <Col flex="auto">
              <Search
                placeholder={`Search ${activeTab}...`}
                allowClear
                size="large"
                value={searchText}
                onChange={(e) => setSearchText(e.target.value)}
              />
            </Col>
            <Col>
              <RangePicker
                value={dateRange}
                onChange={setDateRange}
                format="DD MMM YYYY"
              />
            </Col>
          </Row>
        </Card>
      </div>

      {/* Main Content */}
      <Card>
        <Tabs activeKey={activeTab} onChange={setActiveTab}>
          <TabPane tab="Purchase Orders" key="orders">
            <Table
              dataSource={orders}
              columns={orderColumns}
              rowKey="id"
              loading={loading}
              pagination={{
                showSizeChanger: true,
                showQuickJumper: true,
                showTotal: (total, range) => `${range[0]}-${range[1]} of ${total} GRNs`,
              }}
            />
          </TabPane>
        </Tabs>
      </Card>

      {/* Purchase Order Modal */}
      <Modal
        title={editingOrder ? 'Edit Purchase Order' : 'New Purchase Order'}
        open={orderModalVisible}
        onCancel={() => setOrderModalVisible(false)}
        footer={null}
        width={1000}
        destroyOnClose
      >
        <PurchaseOrderForm
          form={orderForm}
          onFinish={handleSaveOrder}
          suppliers={suppliers}
          items={items}
          editingOrder={editingOrder}
        />
      </Modal>

      {/* Purchase Invoice Modal */}
      <Modal
        title={editingInvoice ? 'Edit GRN' : 'New Goods Received Note'}
        open={invoiceModalVisible}
        onCancel={() => setInvoiceModalVisible(false)}
        footer={null}
        width={1000}
        destroyOnClose
      >
        <PurchaseInvoiceForm
          form={invoiceForm}
          onFinish={handleSaveInvoice}
          suppliers={suppliers}
          items={items}
          editingInvoice={editingInvoice}
        />
      </Modal>

      {/* Purchase Order Details Drawer */}
      <Drawer
        title="Purchase Order Details"
        placement="right"
        onClose={() => setOrderDrawerVisible(false)}
        open={orderDrawerVisible}
        width={600}
      >
        {selectedOrder && <PurchaseOrderDetails order={selectedOrder} />}
      </Drawer>

      {/* Purchase Invoice Details Drawer */}
      <Drawer
        title="GRN Details"
        placement="right"
        onClose={() => setInvoiceDrawerVisible(false)}
        open={invoiceDrawerVisible}
        width={600}
      >
        {selectedInvoice && <PurchaseInvoiceDetails invoice={selectedInvoice} />}
      </Drawer>
    </div>
  );
};

// Purchase Order Form Component
const PurchaseOrderForm = ({ form, onFinish, suppliers, items, editingOrder }) => {
  const [selectedSupplier, setSelectedSupplier] = useState(null);

  const calculateOrderTotal = () => {
    const items = form.getFieldValue('items') || [];
    const subtotal = items.reduce((sum, item) => {
      if (item && item.quantity && item.unit_price) {
        return sum + (item.quantity * item.unit_price);
      }
      return sum;
    }, 0);
    
    const discount = form.getFieldValue('discount_amount') || 0;
    return subtotal - discount;
  };

  const handleSupplierChange = (supplierId) => {
    const supplier = suppliers.find(s => s.id === supplierId);
    setSelectedSupplier(supplier);
    
    if (supplier && supplier.payment_terms) {
      form.setFieldsValue({
        payment_terms: supplier.payment_terms,
      });
    }
  };

  return (
    <Form form={form} layout="vertical" onFinish={onFinish}>
      <Row gutter={16}>
        <Col span={12}>
          <Form.Item
            name="supplier_id"
            label="Supplier"
            rules={[{ required: true, message: 'Please select supplier' }]}
          >
            <Select
              showSearch
              placeholder="Select supplier"
              optionFilterProp="children"
              onChange={handleSupplierChange}
              filterOption={(input, option) =>
                option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
              }
            >
              {suppliers.map(supplier => (
                <Option key={supplier.id} value={supplier.id}>
                  {supplier.name} - {supplier.contact_person}
                </Option>
              ))}
            </Select>
          </Form.Item>
        </Col>
        <Col span={12}>
          <Form.Item name="expected_date" label="Expected Delivery Date">
            <DatePicker style={{ width: '100%' }} />
          </Form.Item>
        </Col>
      </Row>

      {selectedSupplier && (
        <Alert
          message={`Supplier: ${selectedSupplier.name}`}
          description={`Contact: ${selectedSupplier.contact_person} | Phone: ${selectedSupplier.mobile} | Payment Terms: ${selectedSupplier.payment_terms || 'N/A'}`}
          type="info"
          style={{ marginBottom: '16px' }}
        />
      )}

      <Form.Item name="remarks" label="Remarks">
        <Input.TextArea rows={2} placeholder="Purchase order remarks..." />
      </Form.Item>

      {/* Purchase Order Items */}
      <Form.List name="items">
        {(fields, { add, remove }) => (
          <>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <Title level={5}>Order Items</Title>
              <Button type="dashed" onClick={() => add()} icon={<PlusOutlined />}>
                Add Item
              </Button>
            </div>

            {fields.map(({ key, name, ...restField }) => (
              <Row key={key} gutter={16} align="middle" style={{ marginBottom: '12px' }}>
                <Col span={8}>
                  <Form.Item
                    {...restField}
                    name={[name, 'item_id']}
                    rules={[{ required: true, message: 'Select item' }]}
                  >
                    <Select
                      placeholder="Select item"
                      showSearch
                      optionFilterProp="children"
                      onChange={(itemId) => {
                        const item = items.find(i => i.id === itemId);
                        if (item) {
                          form.setFieldsValue({
                            items: form.getFieldValue('items').map((orderItem, index) =>
                              index === name ? { 
                                ...orderItem, 
                                unit_price: item.purchase_rate || item.mrp || 0,
                                item_name: item.name 
                              } : orderItem
                            )
                          });
                        }
                      }}
                    >
                      {items.map(item => (
                        <Option key={item.id} value={item.id}>
                          {item.name} - {item.barcode}
                        </Option>
                      ))}
                    </Select>
                  </Form.Item>
                </Col>
                <Col span={4}>
                  <Form.Item
                    {...restField}
                    name={[name, 'quantity']}
                    rules={[{ required: true, message: 'Enter quantity' }]}
                  >
                    <InputNumber
                      placeholder="Qty"
                      min={1}
                      style={{ width: '100%' }}
                    />
                  </Form.Item>
                </Col>
                <Col span={4}>
                  <Form.Item
                    {...restField}
                    name={[name, 'unit_price']}
                    rules={[{ required: true, message: 'Enter price' }]}
                  >
                    <InputNumber
                      placeholder="Price"
                      min={0}
                      style={{ width: '100%' }}
                      formatter={value => `₹ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
                      parser={value => value.replace(/₹\s?|(,*)/g, '')}
                    />
                  </Form.Item>
                </Col>
                <Col span={3}>
                  <Text strong>
                    ₹{(() => {
                      const items = form.getFieldValue('items') || [];
                      const item = items[name] || {};
                      if (item.quantity && item.unit_price) {
                        return (item.quantity * item.unit_price).toFixed(2);
                      }
                      return '0.00';
                    })()}
                  </Text>
                </Col>
                <Col span={4}>
                  <Form.Item {...restField} name={[name, 'remarks']}>
                    <Input placeholder="Item remarks" />
                  </Form.Item>
                </Col>
                <Col span={1}>
                  <Button type="text" danger icon={<DeleteOutlined />} onClick={() => remove(name)} />
                </Col>
              </Row>
            ))}

            <Row style={{ marginTop: '16px' }}>
              <Col span={16}>
                <Form.Item name="discount_amount" label="Discount Amount">
                  <InputNumber
                    style={{ width: '200px' }}
                    placeholder="0.00"
                    min={0}
                    formatter={value => `₹ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
                    parser={value => value.replace(/₹\s?|(,*)/g, '')}
                  />
                </Form.Item>
              </Col>
              <Col span={8} style={{ textAlign: 'right' }}>
                <Title level={4}>Total: ₹{calculateOrderTotal().toFixed(2)}</Title>
              </Col>
            </Row>
          </>
        )}
      </Form.List>

      <Form.Item style={{ textAlign: 'right', marginTop: '24px' }}>
        <Space>
          <Button onClick={() => form.resetFields()}>Reset</Button>
          <Button type="primary" htmlType="submit">
            {editingOrder ? 'Update Order' : 'Create Order'}
          </Button>
        </Space>
      </Form.Item>
    </Form>
  );
};

// Purchase Invoice Form Component
const PurchaseInvoiceForm = ({ form, onFinish, suppliers, items, editingInvoice }) => {
  const [selectedSupplier, setSelectedSupplier] = useState(null);

  const calculateInvoiceTotal = () => {
    const items = form.getFieldValue('items') || [];
    const subtotal = items.reduce((sum, item) => {
      if (item && item.quantity && item.unit_price) {
        return sum + (item.quantity * item.unit_price);
      }
      return sum;
    }, 0);
    
    const discount = form.getFieldValue('discount_amount') || 0;
    const taxAmount = (subtotal - discount) * 0.18; // 18% GST
    return subtotal - discount + taxAmount;
  };

  const handleSupplierChange = (supplierId) => {
    const supplier = suppliers.find(s => s.id === supplierId);
    setSelectedSupplier(supplier);
  };

  return (
    <Form form={form} layout="vertical" onFinish={onFinish}>
      <Row gutter={16}>
        <Col span={8}>
          <Form.Item
            name="supplier_id"
            label="Supplier"
            rules={[{ required: true, message: 'Please select supplier' }]}
          >
            <Select
              showSearch
              placeholder="Select supplier"
              optionFilterProp="children"
              onChange={handleSupplierChange}
            >
              {suppliers.map(supplier => (
                <Option key={supplier.id} value={supplier.id}>
                  {supplier.name}
                </Option>
              ))}
            </Select>
          </Form.Item>
        </Col>
        <Col span={8}>
          <Form.Item name="supplier_invoice_number" label="Supplier Invoice #">
            <Input placeholder="Supplier invoice number" />
          </Form.Item>
        </Col>
        <Col span={8}>
          <Form.Item name="due_date" label="Payment Due Date">
            <DatePicker style={{ width: '100%' }} />
          </Form.Item>
        </Col>
      </Row>

      {selectedSupplier && (
        <Alert
          message={`Supplier: ${selectedSupplier.name}`}
          description={`GST: ${selectedSupplier.gst_number || 'N/A'} | Payment Terms: ${selectedSupplier.payment_terms || 'N/A'}`}
          type="info"
          style={{ marginBottom: '16px' }}
        />
      )}

      {/* GRN Items */}
      <Form.List name="items">
        {(fields, { add, remove }) => (
          <>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <Title level={5}>Received Items</Title>
              <Button type="dashed" onClick={() => add()} icon={<PlusOutlined />}>
                Add Item
              </Button>
            </div>

            {fields.map(({ key, name, ...restField }) => (
              <Row key={key} gutter={16} align="middle" style={{ marginBottom: '12px' }}>
                <Col span={7}>
                  <Form.Item
                    {...restField}
                    name={[name, 'item_id']}
                    rules={[{ required: true, message: 'Select item' }]}
                  >
                    <Select
                      placeholder="Select item"
                      showSearch
                      optionFilterProp="children"
                      onChange={(itemId) => {
                        const item = items.find(i => i.id === itemId);
                        if (item) {
                          form.setFieldsValue({
                            items: form.getFieldValue('items').map((invoiceItem, index) =>
                              index === name ? { 
                                ...invoiceItem, 
                                unit_price: item.purchase_rate || 0,
                                item_name: item.name 
                              } : invoiceItem
                            )
                          });
                        }
                      }}
                    >
                      {items.map(item => (
                        <Option key={item.id} value={item.id}>
                          {item.name} - {item.barcode}
                        </Option>
                      ))}
                    </Select>
                  </Form.Item>
                </Col>
                <Col span={3}>
                  <Form.Item
                    {...restField}
                    name={[name, 'quantity']}
                    rules={[{ required: true, message: 'Enter quantity' }]}
                  >
                    <InputNumber
                      placeholder="Qty"
                      min={1}
                      style={{ width: '100%' }}
                    />
                  </Form.Item>
                </Col>
                <Col span={4}>
                  <Form.Item
                    {...restField}
                    name={[name, 'unit_price']}
                    rules={[{ required: true, message: 'Enter price' }]}
                  >
                    <InputNumber
                      placeholder="Price"
                      min={0}
                      style={{ width: '100%' }}
                      formatter={value => `₹ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
                      parser={value => value.replace(/₹\s?|(,*)/g, '')}
                    />
                  </Form.Item>
                </Col>
                <Col span={3}>
                  <Form.Item {...restField} name={[name, 'batch_number']}>
                    <Input placeholder="Batch #" />
                  </Form.Item>
                </Col>
                <Col span={3}>
                  <Text strong>
                    ₹{(() => {
                      const items = form.getFieldValue('items') || [];
                      const item = items[name] || {};
                      if (item.quantity && item.unit_price) {
                        return (item.quantity * item.unit_price).toFixed(2);
                      }
                      return '0.00';
                    })()}
                  </Text>
                </Col>
                <Col span={1}>
                  <Button type="text" danger icon={<DeleteOutlined />} onClick={() => remove(name)} />
                </Col>
              </Row>
            ))}

            <Row style={{ marginTop: '16px' }}>
              <Col span={16}>
                <Form.Item name="discount_amount" label="Discount Amount">
                  <InputNumber
                    style={{ width: '200px' }}
                    placeholder="0.00"
                    min={0}
                    formatter={value => `₹ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
                    parser={value => value.replace(/₹\s?|(,*)/g, '')}
                  />
                </Form.Item>
              </Col>
              <Col span={8} style={{ textAlign: 'right' }}>
                <Title level={4}>Total: ₹{calculateInvoiceTotal().toFixed(2)}</Title>
                <Text type="secondary">* Including 18% GST</Text>
              </Col>
            </Row>
          </>
        )}
      </Form.List>

      <Form.Item name="remarks" label="Remarks">
        <Input.TextArea rows={2} placeholder="GRN remarks..." />
      </Form.Item>

      <Form.Item style={{ textAlign: 'right', marginTop: '24px' }}>
        <Space>
          <Button onClick={() => form.resetFields()}>Reset</Button>
          <Button type="primary" htmlType="submit">
            {editingInvoice ? 'Update GRN' : 'Create GRN'}
          </Button>
        </Space>
      </Form.Item>
    </Form>
  );
};

// Purchase Order Details Component
const PurchaseOrderDetails = ({ order }) => {
  const getStatusStep = (status) => {
    const steps = ['pending', 'confirmed', 'received'];
    return steps.indexOf(status);
  };

  return (
    <div>
      <Card title="Order Information" style={{ marginBottom: '16px' }}>
        <Row gutter={[16, 8]}>
          <Col span={8}><Text strong>Order #:</Text></Col>
          <Col span={16}><Text code>{order.order_number}</Text></Col>
          
          <Col span={8}><Text strong>Supplier:</Text></Col>
          <Col span={16}><Text>{order.supplier_name}</Text></Col>
          
          <Col span={8}><Text strong>Order Date:</Text></Col>
          <Col span={16}><Text>{dayjs(order.order_date).format('DD MMM YYYY')}</Text></Col>
          
          <Col span={8}><Text strong>Expected Date:</Text></Col>
          <Col span={16}>
            <Text>{order.expected_date ? dayjs(order.expected_date).format('DD MMM YYYY') : 'Not specified'}</Text>
          </Col>
          
          <Col span={8}><Text strong>Total:</Text></Col>
          <Col span={16}><Text strong>₹{order.total_amount?.toLocaleString()}</Text></Col>
        </Row>
      </Card>

      <Card title="Order Status" style={{ marginBottom: '16px' }}>
        <Steps current={getStatusStep(order.status)} size="small">
          <Step title="Pending" icon={<ClockCircleOutlined />} />
          <Step title="Confirmed" icon={<CheckOutlined />} />
          <Step title="Received" icon={<TruckOutlined />} />
        </Steps>
      </Card>

      <Card title="Order Items">
        <Table
          dataSource={order.items || []}
          rowKey="id"
          pagination={false}
          size="small"
          columns={[
            { title: 'Item', dataIndex: 'item_name', key: 'item_name' },
            { title: 'Ordered', dataIndex: 'quantity', key: 'quantity' },
            { title: 'Received', dataIndex: 'received_quantity', key: 'received_quantity', render: (qty) => qty || 0 },
            { title: 'Pending', key: 'pending', render: (_, record) => (record.quantity - (record.received_quantity || 0)) },
            { title: 'Price', dataIndex: 'unit_price', key: 'unit_price', render: (price) => `₹${price}` },
            { title: 'Total', dataIndex: 'line_total', key: 'line_total', render: (total) => `₹${total}` },
          ]}
        />
      </Card>
    </div>
  );
};

// Purchase Invoice Details Component
const PurchaseInvoiceDetails = ({ invoice }) => {
  return (
    <div>
      <Card title="GRN Information" style={{ marginBottom: '16px' }}>
        <Row gutter={[16, 8]}>
          <Col span={8}><Text strong>GRN #:</Text></Col>
          <Col span={16}><Text code>{invoice.invoice_number}</Text></Col>
          
          <Col span={8}><Text strong>Supplier Invoice:</Text></Col>
          <Col span={16}><Text>{invoice.supplier_invoice_number || 'N/A'}</Text></Col>
          
          <Col span={8}><Text strong>Supplier:</Text></Col>
          <Col span={16}><Text>{invoice.supplier_name}</Text></Col>
          
          <Col span={8}><Text strong>Date:</Text></Col>
          <Col span={16}><Text>{dayjs(invoice.invoice_date).format('DD MMM YYYY')}</Text></Col>
          
          <Col span={8}><Text strong>Due Date:</Text></Col>
          <Col span={16}>
            <Text>{invoice.due_date ? dayjs(invoice.due_date).format('DD MMM YYYY') : 'N/A'}</Text>
          </Col>
          
          <Col span={8}><Text strong>Total:</Text></Col>
          <Col span={16}><Text strong>₹{invoice.total_amount?.toLocaleString()}</Text></Col>
          
          <Col span={8}><Text strong>Balance:</Text></Col>
          <Col span={16}>
            <Text style={{ color: invoice.balance_amount > 0 ? '#f5222d' : '#52c41a' }}>
              ₹{invoice.balance_amount?.toLocaleString()}
            </Text>
          </Col>
        </Row>
      </Card>

      <Card title="Received Items">
        <Table
          dataSource={invoice.items || []}
          rowKey="id"
          pagination={false}
          size="small"
          columns={[
            { title: 'Item', dataIndex: 'item_name', key: 'item_name' },
            { title: 'Quantity', dataIndex: 'quantity', key: 'quantity' },
            { title: 'Price', dataIndex: 'unit_price', key: 'unit_price', render: (price) => `₹${price}` },
            { title: 'Tax', dataIndex: 'tax_amount', key: 'tax_amount', render: (tax) => `₹${tax}` },
            { title: 'Total', dataIndex: 'line_total', key: 'line_total', render: (total) => `₹${total}` },
          ]}
        />
        
        <div style={{ marginTop: '16px', textAlign: 'right' }}>
          <Row justify="end">
            <Col span={8}>
              <div>Subtotal: ₹{invoice.subtotal}</div>
              <div>Tax: ₹{invoice.tax_amount}</div>
              <div style={{ fontSize: '16px', fontWeight: 'bold' }}>
                Total: ₹{invoice.total_amount}
              </div>
            </Col>
          </Row>
        </div>
      </Card>
    </div>
  );
};

export default PurchasePage;]} of ${total} orders`,
              }}
            />
          </TabPane>
          
          <TabPane tab="Goods Received Notes" key="invoices">
            <Table
              dataSource={invoices}
              columns={invoiceColumns}
              rowKey="id"
              loading={loading}
              pagination={{
                showSizeChanger: true,
                showQuickJumper: true,
                showTotal: (total, range) => `${range[0]}-${range[1