// frontend/src/pages/Sales/SalesPage.jsx
import React, { useState, useEffect } from 'react';
import {
  Table,
  Button,
  Input,
  Space,
  Modal,
  Form,
  Select,
  DatePicker,
  InputNumber,
  Card,
  Row,
  Col,
  Statistic,
  Tag,
  Drawer,
  Steps,
  Typography,
  Divider,
  message,
  Popconfirm,
  Badge,
  Tabs,
  Alert,
} from 'antd';
import {
  PlusOutlined,
  EditOutlined,
  DeleteOutlined,
  EyeOutlined,
  SearchOutlined,
  ShoppingCartOutlined,
  FileTextOutlined,
  CheckOutlined,
  ClockCircleOutlined,
  PrinterOutlined,
  WhatsAppOutlined,
  DollarOutlined,
} from '@ant-design/icons';
import { salesService, itemService } from '../../services/apiClient';
import { useAuth } from '../../contexts/AuthContext';
import dayjs from 'dayjs';

const { Search } = Input;
const { Option } = Select;
const { Text, Title } = Typography;
const { Step } = Steps;
const { TabPane } = Tabs;
const { RangePicker } = DatePicker;

const SalesPage = () => {
  const { hasPermission } = useAuth();
  const [activeTab, setActiveTab] = useState('orders');
  const [orders, setOrders] = useState([]);
  const [invoices, setInvoices] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [orderModalVisible, setOrderModalVisible] = useState(false);
  const [invoiceModalVisible, setInvoiceModalVisible] = useState(false);
  const [orderDrawerVisible, setOrderDrawerVisible] = useState(false);
  const [invoiceDrawerVisible, setInvoiceDrawerVisible] = useState(false);
  const [editingOrder, setEditingOrder] = useState(null);
  const [editingInvoice, setEditingInvoice] = useState(null);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [selectedInvoice, setSelectedInvoice] = useState(null);
  const [orderForm] = Form.useForm();
  const [invoiceForm] = Form.useForm();
  const [searchText, setSearchText] = useState('');
  const [dateRange, setDateRange] = useState([]);
  const [stats, setStats] = useState({
    total_orders: 0,
    total_invoices: 0,
    total_amount: 0,
    pending_orders: 0,
  });

  useEffect(() => {
    loadOrders();
    loadInvoices();
    loadCustomers();
    loadItems();
    loadStats();
  }, []);

  useEffect(() => {
    if (activeTab === 'orders') {
      loadOrders();
    } else {
      loadInvoices();
    }
  }, [activeTab, searchText, dateRange]);

  const loadOrders = async () => {
    try {
      setLoading(true);
      const params = {
        search: searchText,
        limit: 100,
      };
      
      if (dateRange.length === 2) {
        params.date_from = dateRange[0].format('YYYY-MM-DD');
        params.date_to = dateRange[1].format('YYYY-MM-DD');
      }

      const response = await salesService.getOrders(params);
      setOrders(response.data);
    } catch (error) {
      message.error('Failed to load sales orders');
    } finally {
      setLoading(false);
    }
  };

  const loadInvoices = async () => {
    try {
      setLoading(true);
      const params = {
        search: searchText,
        limit: 100,
      };
      
      if (dateRange.length === 2) {
        params.date_from = dateRange[0].format('YYYY-MM-DD');
        params.date_to = dateRange[1].format('YYYY-MM-DD');
      }

      const response = await salesService.getInvoices(params);
      setInvoices(response.data);
    } catch (error) {
      message.error('Failed to load sales invoices');
    } finally {
      setLoading(false);
    }
  };

  const loadCustomers = async () => {
    try {
      const response = await salesService.getCustomers({ limit: 500 });
      setCustomers(response.data);
    } catch (error) {
      console.error('Failed to load customers:', error);
    }
  };

  const loadItems = async () => {
    try {
      const response = await itemService.getItems({ limit: 500 });
      setItems(response.data);
    } catch (error) {
      console.error('Failed to load items:', error);
    }
  };

  const loadStats = async () => {
    try {
      const [ordersRes, invoicesRes] = await Promise.all([
        salesService.getOrders({ limit: 1000 }),
        salesService.getInvoices({ limit: 1000 }),
      ]);

      const orders = ordersRes.data;
      const invoices = invoicesRes.data;

      setStats({
        total_orders: orders.length,
        total_invoices: invoices.length,
        total_amount: invoices.reduce((sum, inv) => sum + inv.total_amount, 0),
        pending_orders: orders.filter(o => o.status === 'pending').length,
      });
    } catch (error) {
      console.error('Failed to load stats:', error);
    }
  };

  const handleCreateOrder = () => {
    setEditingOrder(null);
    orderForm.resetFields();
    orderForm.setFieldsValue({
      order_date: dayjs(),
      items: [{ item_id: null, quantity: 1, unit_price: 0 }],
    });
    setOrderModalVisible(true);
  };

  const handleEditOrder = (record) => {
    setEditingOrder(record);
    orderForm.setFieldsValue({
      ...record,
      order_date: dayjs(record.order_date),
      delivery_date: record.delivery_date ? dayjs(record.delivery_date) : null,
    });
    setOrderModalVisible(true);
  };

  const handleCreateInvoice = (order = null) => {
    setEditingInvoice(null);
    invoiceForm.resetFields();
    
    if (order) {
      invoiceForm.setFieldsValue({
        customer_id: order.customer_id,
        order_id: order.id,
        items: order.items?.map(item => ({
          item_id: item.item_id,
          quantity: item.quantity,
          unit_price: item.unit_price,
        })) || [],
      });
    } else {
      invoiceForm.setFieldsValue({
        invoice_date: dayjs(),
        items: [{ item_id: null, quantity: 1, unit_price: 0 }],
      });
    }
    
    setInvoiceModalVisible(true);
  };

  const handleSaveOrder = async (values) => {
    try {
      const orderData = {
        ...values,
        delivery_date: values.delivery_date?.format('YYYY-MM-DD') || null,
      };

      if (editingOrder) {
        await salesService.updateOrder(editingOrder.id, orderData);
        message.success('Order updated successfully');
      } else {
        await salesService.createOrder(orderData);
        message.success('Order created successfully');
      }
      
      setOrderModalVisible(false);
      loadOrders();
      loadStats();
    } catch (error) {
      message.error('Failed to save order');
    }
  };

  const handleSaveInvoice = async (values) => {
    try {
      const invoiceData = {
        ...values,
        due_date: values.due_date?.format('YYYY-MM-DD') || null,
      };

      if (editingInvoice) {
        await salesService.updateInvoice(editingInvoice.id, invoiceData);
        message.success('Invoice updated successfully');
      } else {
        await salesService.createInvoice(invoiceData);
        message.success('Invoice created successfully');
      }
      
      setInvoiceModalVisible(false);
      loadInvoices();
      loadStats();
    } catch (error) {
      message.error('Failed to save invoice');
    }
  };

  const handleUpdateOrderStatus = async (id, status) => {
    try {
      await salesService.updateOrderStatus(id, status);
      message.success(`Order ${status} successfully`);
      loadOrders();
    } catch (error) {
      message.error(`Failed to ${status} order`);
    }
  };

  const handleUpdatePaymentStatus = async (id, status, amount) => {
    try {
      await salesService.updateInvoicePaymentStatus(id, status, amount);
      message.success('Payment status updated successfully');
      loadInvoices();
    } catch (error) {
      message.error('Failed to update payment status');
    }
  };

  // Sales Orders columns
  const orderColumns = [
    {
      title: 'Order #',
      dataIndex: 'order_number',
      key: 'order_number',
      render: (text) => <Text code>{text}</Text>,
    },
    {
      title: 'Date',
      dataIndex: 'order_date',
      key: 'order_date',
      render: (date) => dayjs(date).format('DD MMM YYYY'),
    },
    {
      title: 'Customer',
      key: 'customer',
      render: (_, record) => (
        <div>
          <div style={{ fontWeight: 'bold' }}>{record.customer_name}</div>
          {record.customer_mobile && (
            <Text type="secondary" style={{ fontSize: '12px' }}>
              {record.customer_mobile}
            </Text>
          )}
        </div>
      ),
    },
    {
      title: 'Items',
      dataIndex: 'items',
      key: 'items',
      render: (items) => (
        <Badge count={items?.length || 0} showZero style={{ backgroundColor: '#52c41a' }} />
      ),
    },
    {
      title: 'Amount',
      dataIndex: 'total_amount',
      key: 'total_amount',
      render: (amount) => `₹${amount?.toLocaleString()}`,
      align: 'right',
    },
    {
      title: 'Status',
      dataIndex: 'status',
      key: 'status',
      render: (status) => {
        const colors = {
          pending: 'orange',
          confirmed: 'blue',
          shipped: 'purple',
          delivered: 'green',
          cancelled: 'red',
        };
        return <Tag color={colors[status]}>{status.toUpperCase()}</Tag>;
      },
    },
    {
      title: 'Actions',
      key: 'actions',
      render: (_, record) => (
        <Space>
          <Button
            size="small"
            icon={<EyeOutlined />}
            onClick={() => {
              setSelectedOrder(record);
              setOrderDrawerVisible(true);
            }}
          />
          {hasPermission('sales.edit') && record.status === 'pending' && (
            <Button
              size="small"
              icon={<EditOutlined />}
              onClick={() => handleEditOrder(record)}
            />
          )}
          {hasPermission('sales.create') && record.status === 'confirmed' && (
            <Button
              size="small"
              icon={<FileTextOutlined />}
              onClick={() => handleCreateInvoice(record)}
              type="primary"
            >
              Invoice
            </Button>
          )}
          {hasPermission('sales.edit') && (
            <Select
              size="small"
              value={record.status}
              style={{ width: 100 }}
              onChange={(value) => handleUpdateOrderStatus(record.id, value)}
            >
              <Option value="pending">Pending</Option>
              <Option value="confirmed">Confirmed</Option>
              <Option value="shipped">Shipped</Option>
              <Option value="delivered">Delivered</Option>
              <Option value="cancelled">Cancelled</Option>
            </Select>
          )}
        </Space>
      ),
    },
  ];

  // Sales Invoices columns
  const invoiceColumns = [
    {
      title: 'Invoice #',
      dataIndex: 'invoice_number',
      key: 'invoice_number',
      render: (text) => <Text code>{text}</Text>,
    },
    {
      title: 'Date',
      dataIndex: 'invoice_date',
      key: 'invoice_date',
      render: (date) => dayjs(date).format('DD MMM YYYY'),
    },
    {
      title: 'Customer',
      key: 'customer',
      render: (_, record) => (
        <div>
          <div style={{ fontWeight: 'bold' }}>{record.customer_name}</div>
          {record.customer_mobile && (
            <Text type="secondary" style={{ fontSize: '12px' }}>
              {record.customer_mobile}
            </Text>
          )}
        </div>
      ),
    },
    {
      title: 'Amount',
      dataIndex: 'total_amount',
      key: 'total_amount',
      render: (amount) => `₹${amount?.toLocaleString()}`,
      align: 'right',
    },
    {
      title: 'Paid',
      dataIndex: 'paid_amount',
      key: 'paid_amount',
      render: (amount) => `₹${amount?.toLocaleString()}`,
      align: 'right',
    },
    {
      title: 'Balance',
      dataIndex: 'balance_amount',
      key: 'balance_amount',
      render: (amount) => (
        <Text style={{ color: amount > 0 ? '#f5222d' : '#52c41a' }}>
          ₹{amount?.toLocaleString()}
        </Text>
      ),
      align: 'right',
    },
    {
      title: 'Payment',
      dataIndex: 'payment_status',
      key: 'payment_status',
      render: (status) => {
        const colors = {
          pending: 'red',
          partial: 'orange',
          paid: 'green',
        };
        return <Tag color={colors[status]}>{status.toUpperCase()}</Tag>;
      },
    },
    {
      title: 'Type',
      dataIndex: 'is_pos_sale',
      key: 'is_pos_sale',
      render: (isPOS) => (
        <Tag color={isPOS ? 'blue' : 'default'}>
          {isPOS ? 'POS' : 'Regular'}
        </Tag>
      ),
    },
    {
      title: 'Actions',
      key: 'actions',
      render: (_, record) => (
        <Space>
          <Button
            size="small"
            icon={<EyeOutlined />}
            onClick={() => {
              setSelectedInvoice(record);
              setInvoiceDrawerVisible(true);
            }}
          />
          <Button
            size="small"
            icon={<PrinterOutlined />}
            onClick={() => printInvoice(record)}
          />
          {record.customer_mobile && (
            <Button
              size="small"
              icon={<WhatsAppOutlined />}
              onClick={() => sendWhatsApp(record)}
              style={{ color: '#25d366' }}
            />
          )}
          {record.payment_status !== 'paid' && (
            <Button
              size="small"
              icon={<DollarOutlined />}
              onClick={() => {
                Modal.confirm({
                  title: 'Record Payment',
                  content: (
                    <div>
                      <p>Invoice Amount: ₹{record.total_amount}</p>
                      <p>Balance: ₹{record.balance_amount}</p>
                      <Input
                        placeholder="Enter payment amount"
                        type="number"
                        id="payment-amount"
                        defaultValue={record.balance_amount}
                      />
                    </div>
                  ),
                  onOk: () => {
                    const amount = document.getElementById('payment-amount').value;
                    if (amount) {
                      const status = parseFloat(amount) >= record.balance_amount ? 'paid' : 'partial';
                      handleUpdatePaymentStatus(record.id, status, parseFloat(amount));
                    }
                  },
                });
              }}
            >
              Pay
            </Button>
          )}
        </Space>
      ),
    },
  ];

  const printInvoice = (invoice) => {
    const printContent = `
      <div style="max-width: 800px; margin: 0 auto; padding: 20px; font-family: Arial, sans-serif;">
        <div style="text-align: center; margin-bottom: 30px;">
          <h1>SALES INVOICE</h1>
          <p>Invoice No: ${invoice.invoice_number}</p>
          <p>Date: ${dayjs(invoice.invoice_date).format('DD MMM YYYY')}</p>
        </div>
        
        <div style="margin-bottom: 20px;">
          <strong>Bill To:</strong><br>
          ${invoice.customer_name}<br>
          ${invoice.customer_address || ''}<br>
          ${invoice.customer_mobile || ''}
        </div>
        
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
          <thead>
            <tr style="background-color: #f5f5f5;">
              <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Item</th>
              <th style="border: 1px solid #ddd; padding: 8px; text-align: right;">Qty</th>
              <th style="border: 1px solid #ddd; padding: 8px; text-align: right;">Rate</th>
              <th style="border: 1px solid #ddd; padding: 8px; text-align: right;">Amount</th>
            </tr>
          </thead>
          <tbody>
            ${invoice.items?.map(item => `
              <tr>
                <td style="border: 1px solid #ddd; padding: 8px;">${item.item_name}</td>
                <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">${item.quantity}</td>
                <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">₹${item.unit_price}</td>
                <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">₹${item.line_total}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
        
        <div style="text-align: right;">
          <p>Subtotal: ₹${invoice.subtotal}</p>
          <p>Tax: ₹${invoice.tax_amount}</p>
          <p><strong>Total: ₹${invoice.total_amount}</strong></p>
        </div>
      </div>
    `;
    
    const printWindow = window.open('', '', 'width=800,height=600');
    printWindow.document.write(printContent);
    printWindow.document.close();
    printWindow.print();
    printWindow.close();
  };

  const sendWhatsApp = (invoice) => {
    const message = `Invoice ${invoice.invoice_number} for ₹${invoice.total_amount} has been generated. Thank you for your business!`;
    const url = `https://wa.me/${invoice.customer_mobile}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  return (
    <div>
      {/* Page Header */}
      <div style={{ marginBottom: '24px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
          <div>
            <Title level={2} style={{ margin: 0 }}>Sales Management</Title>
            <Text type="secondary">Manage sales orders and invoices</Text>
          </div>
          <Space>
            {hasPermission('sales.create') && (
              <Button 
                type="primary" 
                icon={<PlusOutlined />} 
                onClick={activeTab === 'orders' ? handleCreateOrder : () => handleCreateInvoice()}
              >
                {activeTab === 'orders' ? 'New Order' : 'New Invoice'}
              </Button>
            )}
          </Space>
        </div>

        {/* Stats Cards */}
        <Row gutter={16} style={{ marginBottom: '24px' }}>
          <Col xs={24} sm={6}>
            <Card>
              <Statistic
                title="Total Orders"
                value={stats.total_orders}
                prefix={<ShoppingCartOutlined />}
              />
            </Card>
          </Col>
          <Col xs={24} sm={6}>
            <Card>
              <Statistic
                title="Pending Orders"
                value={stats.pending_orders}
                prefix={<ClockCircleOutlined />}
                valueStyle={{ color: '#fa8c16' }}
              />
            </Card>
          </Col>
          <Col xs={24} sm={6}>
            <Card>
              <Statistic
                title="Total Invoices"
                value={stats.total_invoices}
                prefix={<FileTextOutlined />}
              />
            </Card>
          </Col>
          <Col xs={24} sm={6}>
            <Card>
              <Statistic
                title="Sales Amount"
                value={stats.total_amount}
                prefix="₹"
                precision={0}
                valueStyle={{ color: '#3f8600' }}
              />
            </Card>
          </Col>
        </Row>

        {/* Filters */}
        <Card style={{ marginBottom: '16px' }}>
          <Row gutter={16} align="middle">
            <Col flex="auto">
              <Search
                placeholder={`Search ${activeTab}...`}
                allowClear
                size="large"
                value={searchText}
                onChange={(e) => setSearchText(e.target.value)}
              />
            </Col>
            <Col>
              <RangePicker
                value={dateRange}
                onChange={setDateRange}
                format="DD MMM YYYY"
              />
            </Col>
          </Row>
        </Card>
      </div>

      {/* Main Content */}
      <Card>
        <Tabs activeKey={activeTab} onChange={setActiveTab}>
          <TabPane tab="Sales Orders" key="orders">
            <Table
              dataSource={orders}
              columns={orderColumns}
              rowKey="id"
              loading={loading}
              pagination={{
                showSizeChanger: true,
                showQuickJumper: true,
                showTotal: (total, range) => `${range[0]}-${range[1]} of ${total} orders`,
              }}
            />
          </TabPane>
          
          <TabPane tab="Sales Invoices" key="invoices">
            <Table
              dataSource={invoices}
              columns={invoiceColumns}
              rowKey="id"
              loading={loading}
              pagination={{
                showSizeChanger: true,
                showQuickJumper: true,
                showTotal: (total, range) => `${range[0]}-${range[1]} of ${total} invoices`,
              }}
            />
          </TabPane>
        </Tabs>
      </Card>

      {/* Order Modal */}
      <Modal
        title={editingOrder ? 'Edit Sales Order' : 'New Sales Order'}
        open={orderModalVisible}
        onCancel={() => setOrderModalVisible(false)}
        footer={null}
        width={1000}
        destroyOnClose
      >
        <OrderForm
          form={orderForm}
          onFinish={handleSaveOrder}
          customers={customers}
          items={items}
          editingOrder={editingOrder}
        />
      </Modal>

      {/* Invoice Modal */}
      <Modal
        title={editingInvoice ? 'Edit Sales Invoice' : 'New Sales Invoice'}
        open={invoiceModalVisible}
        onCancel={() => setInvoiceModalVisible(false)}
        footer={null}
        width={1000}
        destroyOnClose
      >
        <InvoiceForm
          form={invoiceForm}
          onFinish={handleSaveInvoice}
          customers={customers}
          items={items}
          editingInvoice={editingInvoice}
        />
      </Modal>

      {/* Order Details Drawer */}
      <Drawer
        title="Order Details"
        placement="right"
        onClose={() => setOrderDrawerVisible(false)}
        open={orderDrawerVisible}
        width={600}
      >
        {selectedOrder && <OrderDetails order={selectedOrder} />}
      </Drawer>

      {/* Invoice Details Drawer */}
      <Drawer
        title="Invoice Details"
        placement="right"
        onClose={() => setInvoiceDrawerVisible(false)}
        open={invoiceDrawerVisible}
        width={600}
      >
        {selectedInvoice && <InvoiceDetails invoice={selectedInvoice} />}
      </Drawer>
    </div>
  );
};

// Order Form Component
const OrderForm = ({ form, onFinish, customers, items, editingOrder }) => {
  const calculateOrderTotal = () => {
    const items = form.getFieldValue('items') || [];
    const subtotal = items.reduce((sum, item) => {
      if (item && item.quantity && item.unit_price) {
        const discount = (item.discount_percent || 0) / 100;
        const lineTotal = item.quantity * item.unit_price * (1 - discount);
        return sum + lineTotal;
      }
      return sum;
    }, 0);
    
    return subtotal;
  };

  return (
    <Form form={form} layout="vertical" onFinish={onFinish}>
      <Row gutter={16}>
        <Col span={12}>
          <Form.Item
            name="customer_id"
            label="Customer"
            rules={[{ required: true, message: 'Please select customer' }]}
          >
            <Select
              showSearch
              placeholder="Select customer"
              optionFilterProp="children"
              filterOption={(input, option) =>
                option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
              }
            >
              {customers.map(customer => (
                <Option key={customer.id} value={customer.id}>
                  {customer.name} - {customer.mobile}
                </Option>
              ))}
            </Select>
          </Form.Item>
        </Col>
        <Col span={12}>
          <Form.Item name="delivery_date" label="Delivery Date">
            <DatePicker style={{ width: '100%' }} />
          </Form.Item>
        </Col>
      </Row>

      <Form.Item name="remarks" label="Remarks">
        <Input.TextArea rows={2} placeholder="Order remarks..." />
      </Form.Item>

      {/* Order Items */}
      <Form.List name="items">
        {(fields, { add, remove }) => (
          <>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <Title level={5}>Order Items</Title>
              <Button type="dashed" onClick={() => add()} icon={<PlusOutlined />}>
                Add Item
              </Button>
            </div>

            {fields.map(({ key, name, ...restField }) => (
              <Row key={key} gutter={16} align="middle" style={{ marginBottom: '12px' }}>
                <Col span={8}>
                  <Form.Item
                    {...restField}
                    name={[name, 'item_id']}
                    rules={[{ required: true, message: 'Select item' }]}
                  >
                    <Select
                      placeholder="Select item"
                      showSearch
                      optionFilterProp="children"
                      onChange={(itemId) => {
                        const item = items.find(i => i.id === itemId);
                        if (item) {
                          form.setFieldsValue({
                            items: form.getFieldValue('items').map((orderItem, index) =>
                              index === name ? { ...orderItem, unit_price: item.selling_price || item.mrp || 0 } : orderItem
                            )
                          });
                        }
                      }}
                    >
                      {items.map(item => (
                        <Option key={item.id} value={item.id}>
                          {item.name} - ₹{item.selling_price || item.mrp || 0}
                        </Option>
                      ))}
                    </Select>
                  </Form.Item>
                </Col>
                <Col span={4}>
                  <Form.Item
                    {...restField}
                    name={[name, 'quantity']}
                    rules={[{ required: true, message: 'Enter quantity' }]}
                  >
                    <InputNumber
                      placeholder="Qty"
                      min={1}
                      style={{ width: '100%' }}
                    />
                  </Form.Item>
                </Col>
                <Col span={4}>
                  <Form.Item
                    {...restField}
                    name={[name, 'unit_price']}
                    rules={[{ required: true, message: 'Enter price' }]}
                  >
                    <InputNumber
                      placeholder="Price"
                      min={0}
                      style={{ width: '100%' }}
                      formatter={value => `₹ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
                      parser={value => value.replace(/₹\s?|(,*)/g, '')}
                    />
                  </Form.Item>
                </Col>
                <Col span={4}>
                  <Form.Item
                    {...restField}
                    name={[name, 'discount_percent']}
                  >
                    <InputNumber
                      placeholder="Discount %"
                      min={0}
                      max={100}
                      style={{ width: '100%' }}
                    />
                  </Form.Item>
                </Col>
                <Col span={3}>
                  <Text strong>
                    ₹{(() => {
                      const items = form.getFieldValue('items') || [];
                      const item = items[name] || {};
                      if (item.quantity && item.unit_price) {
                        const discount = (item.discount_percent || 0) / 100;
                        return (item.quantity * item.unit_price * (1 - discount)).toFixed(2);
                      }
                      return '0.00';
                    })()}
                  </Text>
                </Col>
                <Col span={1}>
                  <Button type="text" danger icon={<DeleteOutlined />} onClick={() => remove(name)} />
                </Col>
              </Row>
            ))}

            <div style={{ textAlign: 'right', marginTop: '16px' }}>
              <Title level={4}>Total: ₹{calculateOrderTotal().toFixed(2)}</Title>
            </div>
          </>
        )}
      </Form.List>

      <Form.Item style={{ textAlign: 'right', marginTop: '24px' }}>
        <Space>
          <Button onClick={() => form.resetFields()}>Reset</Button>
          <Button type="primary" htmlType="submit">
            {editingOrder ? 'Update Order' : 'Create Order'}
          </Button>
        </Space>
      </Form.Item>
    </Form>
  );
};

// Invoice Form Component (similar to OrderForm)
const InvoiceForm = ({ form, onFinish, customers, items, editingInvoice }) => {
  // Similar implementation to OrderForm but for invoices
  return (
    <Form form={form} layout="vertical" onFinish={onFinish}>
      {/* Similar fields as OrderForm but for invoice-specific data */}
      <p>Invoice form implementation similar to OrderForm...</p>
    </Form>
  );
};

// Order Details Component
const OrderDetails = ({ order }) => {
  const getStatusStep = (status) => {
    const steps = ['pending', 'confirmed', 'shipped', 'delivered'];
    return steps.indexOf(status);
  };

  return (
    <div>
      <Card title="Order Information" style={{ marginBottom: '16px' }}>
        <Row gutter={[16, 8]}>
          <Col span={8}><Text strong>Order #:</Text></Col>
          <Col span={16}><Text code>{order.order_number}</Text></Col>
          
          <Col span={8}><Text strong>Customer:</Text></Col>
          <Col span={16}><Text>{order.customer_name}</Text></Col>
          
          <Col span={8}><Text strong>Date:</Text></Col>
          <Col span={16}><Text>{dayjs(order.order_date).format('DD MMM YYYY')}</Text></Col>
          
          <Col span={8}><Text strong>Total:</Text></Col>
          <Col span={16}><Text strong>₹{order.total_amount?.toLocaleString()}</Text></Col>
        </Row>
      </Card>

      <Card title="Order Status" style={{ marginBottom: '16px' }}>
        <Steps current={getStatusStep(order.status)} size="small">
          <Step title="Pending" icon={<ClockCircleOutlined />} />
          <Step title="Confirmed" icon={<CheckOutlined />} />
          <Step title="Shipped" />
          <Step title="Delivered" />
        </Steps>
      </Card>

      <Card title="Order Items">
        <Table
          dataSource={order.items || []}
          rowKey="id"
          pagination={false}
          size="small"
          columns={[
            { title: 'Item', dataIndex: 'item_name', key: 'item_name' },
            { title: 'Qty', dataIndex: 'quantity', key: 'quantity' },
            { title: 'Price', dataIndex: 'unit_price', key: 'unit_price', render: (price) => `₹${price}` },
            { title: 'Total', dataIndex: 'line_total', key: 'line_total', render: (total) => `₹${total}` },
          ]}
        />
      </Card>
    </div>
  );
};

// Invoice Details Component
const InvoiceDetails = ({ invoice }) => {
  return (
    <div>
      <Card title="Invoice Information" style={{ marginBottom: '16px' }}>
        <Row gutter={[16, 8]}>
          <Col span={8}><Text strong>Invoice #:</Text></Col>
          <Col span={16}><Text code>{invoice.invoice_number}</Text></Col>
          
          <Col span={8}><Text strong>Customer:</Text></Col>
          <Col span={16}><Text>{invoice.customer_name}</Text></Col>
          
          <Col span={8}><Text strong>Date:</Text></Col>
          <Col span={16}><Text>{dayjs(invoice.invoice_date).format('DD MMM YYYY')}</Text></Col>
          
          <Col span={8}><Text strong>Total:</Text></Col>
          <Col span={16}><Text strong>₹{invoice.total_amount?.toLocaleString()}</Text></Col>
          
          <Col span={8}><Text strong>Balance:</Text></Col>
          <Col span={16}>
            <Text style={{ color: invoice.balance_amount > 0 ? '#f5222d' : '#52c41a' }}>
              ₹{invoice.balance_amount?.toLocaleString()}
            </Text>
          </Col>
        </Row>
      </Card>

      <Card title="Invoice Items">
        <Table
          dataSource={invoice.items || []}
          rowKey="id"
          pagination={false}
          size="small"
          columns={[
            { title: 'Item', dataIndex: 'item_name', key: 'item_name' },
            { title: 'HSN', dataIndex: 'hsn_code', key: 'hsn_code' },
            { title: 'Qty', dataIndex: 'quantity', key: 'quantity' },
            { title: 'Price', dataIndex: 'unit_price', key: 'unit_price', render: (price) => `₹${price}` },
            { title: 'Tax', dataIndex: 'tax_amount', key: 'tax_amount', render: (tax) => `₹${tax}` },
            { title: 'Total', dataIndex: 'line_total', key: 'line_total', render: (total) => `₹${total}` },
          ]}
        />
        
        <div style={{ marginTop: '16px', textAlign: 'right' }}>
          <Row justify="end">
            <Col span={8}>
              <div>Subtotal: ₹{invoice.subtotal}</div>
              <div>Tax: ₹{invoice.tax_amount}</div>
              <div style={{ fontSize: '16px', fontWeight: 'bold' }}>
                Total: ₹{invoice.total_amount}
              </div>
            </Col>
          </Row>
        </div>
      </Card>
    </div>
  );
};

export default SalesPage;