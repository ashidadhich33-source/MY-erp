// frontend/src/pages/POS/POSPage.jsx
import React, { useState, useEffect, useRef } from 'react';
import {
  Row,
  Col,
  Card,
  Input,
  Button,
  Table,
  Typography,
  Space,
  Select,
  Modal,
  Form,
  InputNumber,
  message,
  Divider,
  Tag,
  Badge,
  Drawer,
} from 'antd';
import {
  ShoppingCartOutlined,
  DeleteOutlined,
  PlusOutlined,
  MinusOutlined,
  SearchOutlined,
  BarcodeOutlined,
  PrinterOutlined,
  CreditCardOutlined,
  DollarOutlined,
  UserOutlined,
  PhoneOutlined,
} from '@ant-design/icons';
import { itemService, salesService } from '../../services/apiClient';

const { Title, Text } = Typography;
const { Search } = Input;
const { Option } = Select;

const POSPage = () => {
  const [cartItems, setCartItems] = useState([]);
  const [searchResults, setSearchResults] = useState([]);
  const [searching, setSearching] = useState(false);
  const [customerInfo, setCustomerInfo] = useState(null);
  const [paymentModalVisible, setPaymentModalVisible] = useState(false);
  const [customerDrawerVisible, setCustomerDrawerVisible] = useState(false);
  const [currentInvoice, setCurrentInvoice] = useState(null);
  const [todaySummary, setTodaySummary] = useState(null);
  const barcodeInputRef = useRef(null);
  const [form] = Form.useForm();
  const [customerForm] = Form.useForm();

  useEffect(() => {
    loadTodaySummary();
    // Focus on barcode input
    if (barcodeInputRef.current) {
      barcodeInputRef.current.focus();
    }
  }, []);

  const loadTodaySummary = async () => {
    try {
      const response = await salesService.getDailySummary();
      setTodaySummary(response.data);
    } catch (error) {
      console.error('Failed to load today summary:', error);
    }
  };

  // Search items
  const handleItemSearch = async (value) => {
    if (!value.trim()) {
      setSearchResults([]);
      return;
    }

    try {
      setSearching(true);
      const response = await itemService.getItems({
        search: value,
        limit: 20
      });
      setSearchResults(response.data);
    } catch (error) {
      message.error('Failed to search items');
    } finally {
      setSearching(false);
    }
  };

  // Barcode scan/search
  const handleBarcodeInput = async (e) => {
    if (e.key === 'Enter') {
      const barcode = e.target.value.trim();
      if (barcode) {
        try {
          const response = await itemService.getItem(`barcode/${barcode}`);
          addToCart(response.data);
          e.target.value = '';
        } catch (error) {
          message.error('Item not found');
          e.target.value = '';
        }
      }
    }
  };

  // Add item to cart
  const addToCart = (item, quantity = 1) => {
    const existingIndex = cartItems.findIndex(cartItem => cartItem.id === item.id);
    
    if (existingIndex >= 0) {
      const updatedItems = [...cartItems];
      updatedItems[existingIndex].quantity += quantity;
      updatedItems[existingIndex].line_total = 
        updatedItems[existingIndex].quantity * updatedItems[existingIndex].selling_price;
      setCartItems(updatedItems);
    } else {
      const cartItem = {
        id: item.id,
        barcode: item.barcode,
        name: item.name,
        selling_price: item.selling_price || item.mrp || 0,
        quantity: quantity,
        line_total: quantity * (item.selling_price || item.mrp || 0),
        stock: item.current_stock || 0,
      };
      setCartItems([...cartItems, cartItem]);
    }
    
    message.success(`${item.name} added to cart`);
  };

  // Update cart item quantity
  const updateCartQuantity = (itemId, newQuantity) => {
    if (newQuantity <= 0) {
      removeFromCart(itemId);
      return;
    }

    const updatedItems = cartItems.map(item => 
      item.id === itemId 
        ? { ...item, quantity: newQuantity, line_total: newQuantity * item.selling_price }
        : item
    );
    setCartItems(updatedItems);
  };

  // Remove item from cart
  const removeFromCart = (itemId) => {
    setCartItems(cartItems.filter(item => item.id !== itemId));
  };

  // Clear cart
  const clearCart = () => {
    setCartItems([]);
    setCustomerInfo(null);
  };

  // Calculate totals
  const calculateTotals = () => {
    const subtotal = cartItems.reduce((sum, item) => sum + item.line_total, 0);
    const taxAmount = subtotal * 0.18; // 18% GST
    const total = subtotal + taxAmount;
    
    return { subtotal, taxAmount, total };
  };

  // Process payment
  const handlePayment = async (paymentData) => {
    try {
      const { subtotal, taxAmount, total } = calculateTotals();
      
      const saleData = {
        customer_mobile: customerInfo?.mobile || null,
        items: cartItems.map(item => ({
          item_id: item.id,
          quantity: item.quantity,
          unit_price: item.selling_price,
          discount_percent: 0
        })),
        payment_amount: paymentData.amount
      };

      const response = await salesService.createPOSSale(saleData);
      
      setCurrentInvoice(response.data);
      setPaymentModalVisible(false);
      
      message.success('Sale completed successfully!');
      
      // Print receipt if needed
      if (paymentData.printReceipt) {
        printReceipt(response.data);
      }
      
      // Clear cart and reload summary
      clearCart();
      loadTodaySummary();
      
    } catch (error) {
      message.error('Payment processing failed');
    }
  };

  // Print receipt
  const printReceipt = (invoice) => {
    const printContent = `
      <div style="width: 300px; font-family: monospace;">
        <h3 style="text-align: center;">RECEIPT</h3>
        <p>Invoice: ${invoice.invoice_number}</p>
        <p>Date: ${new Date(invoice.invoice_date).toLocaleString()}</p>
        <p>Customer: ${invoice.customer_name}</p>
        <hr>
        ${invoice.items.map(item => `
          <p>${item.item_name}<br>
          ${item.quantity} x ₹${item.unit_price} = ₹${item.line_total}</p>
        `).join('')}
        <hr>
        <p><strong>Total: ₹${invoice.total_amount}</strong></p>
        <p style="text-align: center;">Thank you for your business!</p>
      </div>
    `;
    
    const printWindow = window.open('', '', 'width=400,height=600');
    printWindow.document.write(printContent);
    printWindow.document.close();
    printWindow.print();
    printWindow.close();
  };

  // Cart table columns
  const cartColumns = [
    {
      title: 'Item',
      dataIndex: 'name',
      key: 'name',
      render: (text, record) => (
        <div>
          <div style={{ fontWeight: 'bold' }}>{text}</div>
          <Text type="secondary" style={{ fontSize: '12px' }}>
            {record.barcode}
          </Text>
        </div>
      ),
    },
    {
      title: 'Price',
      dataIndex: 'selling_price',
      key: 'selling_price',
      render: (price) => `₹${price}`,
      width: 80,
    },
    {
      title: 'Qty',
      dataIndex: 'quantity',
      key: 'quantity',
      width: 120,
      render: (quantity, record) => (
        <Space>
          <Button 
            size="small" 
            icon={<MinusOutlined />} 
            onClick={() => updateCartQuantity(record.id, quantity - 1)}
          />
          <InputNumber
            size="small"
            min={0}
            value={quantity}
            onChange={(value) => updateCartQuantity(record.id, value)}
            style={{ width: 60 }}
          />
          <Button 
            size="small" 
            icon={<PlusOutlined />} 
            onClick={() => updateCartQuantity(record.id, quantity + 1)}
          />
        </Space>
      ),
    },
    {
      title: 'Total',
      dataIndex: 'line_total',
      key: 'line_total',
      render: (total) => `₹${total.toFixed(2)}`,
      width: 80,
    },
    {
      title: 'Action',
      key: 'action',
      width: 60,
      render: (_, record) => (
        <Button
          size="small"
          type="text"
          danger
          icon={<DeleteOutlined />}
          onClick={() => removeFromCart(record.id)}
        />
      ),
    },
  ];

  const { subtotal, taxAmount, total } = calculateTotals();

  return (
    <div style={{ height: 'calc(100vh - 120px)', display: 'flex', gap: '16px' }}>
      {/* Left Panel - Product Search */}
      <div style={{ flex: 1 }}>
        <Card style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
          <div style={{ marginBottom: '16px' }}>
            <Title level={4}>Product Search</Title>
            
            {/* Barcode Input */}
            <Input
              ref={barcodeInputRef}
              placeholder="Scan barcode or type to search"
              prefix={<BarcodeOutlined />}
              size="large"
              onKeyPress={handleBarcodeInput}
              style={{ marginBottom: '12px' }}
            />
            
            {/* Search Input */}
            <Search
              placeholder="Search products by name or code"
              onSearch={handleItemSearch}
              loading={searching}
              enterButton
              size="large"
            />
          </div>

          {/* Search Results */}
          <div style={{ flex: 1, overflow: 'auto' }}>
            <Row gutter={[8, 8]}>
              {searchResults.map(item => (
                <Col span={8} key={item.id}>
                  <Card
                    hoverable
                    size="small"
                    onClick={() => addToCart(item)}
                    style={{ cursor: 'pointer', height: '100px' }}
                    bodyStyle={{ padding: '8px' }}
                  >
                    <div style={{ textAlign: 'center' }}>
                      <div style={{ fontWeight: 'bold', fontSize: '12px', marginBottom: '4px' }}>
                        {item.name.substring(0, 20)}
                        {item.name.length > 20 && '...'}
                      </div>
                      <div style={{ color: '#1890ff', fontSize: '14px', fontWeight: 'bold' }}>
                        ₹{item.selling_price || item.mrp || 0}
                      </div>
                      {item.current_stock !== null && (
                        <Badge
                          count={`Stock: ${item.current_stock}`}
                          style={{ 
                            backgroundColor: item.current_stock > 0 ? '#52c41a' : '#f5222d',
                            fontSize: '10px'
                          }}
                        />
                      )}
                    </div>
                  </Card>
                </Col>
              ))}
            </Row>
          </div>
        </Card>
      </div>

      {/* Right Panel - Cart */}
      <div style={{ width: '500px' }}>
        <Card style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
          {/* Header */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
            <Title level={4} style={{ margin: 0 }}>
              <ShoppingCartOutlined /> Cart ({cartItems.length})
            </Title>
            <Space>
              <Button
                icon={<UserOutlined />}
                onClick={() => setCustomerDrawerVisible(true)}
                type={customerInfo ? 'primary' : 'default'}
              >
                {customerInfo ? customerInfo.name : 'Customer'}
              </Button>
              <Button icon={<DeleteOutlined />} onClick={clearCart} danger>
                Clear
              </Button>
            </Space>
          </div>

          {/* Customer Info */}
          {customerInfo && (
            <div style={{ 
              background: '#f6ffed', 
              padding: '8px', 
              borderRadius: '6px', 
              marginBottom: '16px',
              border: '1px solid #b7eb8f'
            }}>
              <Text strong>{customerInfo.name}</Text>
              {customerInfo.mobile && (
                <div style={{ fontSize: '12px', color: '#666' }}>
                  <PhoneOutlined /> {customerInfo.mobile}
                </div>
              )}
            </div>
          )}

          {/* Cart Items */}
          <div style={{ flex: 1, overflow: 'auto', marginBottom: '16px' }}>
            {cartItems.length === 0 ? (
              <div style={{ 
                textAlign: 'center', 
                color: '#999', 
                padding: '40px 0',
                fontSize: '16px'
              }}>
                Cart is empty<br />
                <small>Scan or search for items to add</small>
              </div>
            ) : (
              <Table
                dataSource={cartItems}
                columns={cartColumns}
                pagination={false}
                size="small"
                scroll={{ y: 300 }}
                rowKey="id"
              />
            )}
          </div>

          {/* Totals */}
          {cartItems.length > 0 && (
            <div style={{ 
              background: '#fafafa', 
              padding: '16px', 
              borderRadius: '8px',
              marginBottom: '16px'
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                <Text>Subtotal:</Text>
                <Text>₹{subtotal.toFixed(2)}</Text>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                <Text>Tax (18%):</Text>
                <Text>₹{taxAmount.toFixed(2)}</Text>
              </div>
              <Divider style={{ margin: '8px 0' }} />
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <Text strong style={{ fontSize: '18px' }}>Total:</Text>
                <Text strong style={{ fontSize: '18px', color: '#1890ff' }}>
                  ₹{total.toFixed(2)}
                </Text>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <Space style={{ width: '100%' }}>
            <Button
              type="primary"
              size="large"
              icon={<CreditCardOutlined />}
              onClick={() => setPaymentModalVisible(true)}
              disabled={cartItems.length === 0}
              style={{ flex: 1 }}
            >
              Pay ₹{total.toFixed(2)}
            </Button>
            <Button
              size="large"
              icon={<PrinterOutlined />}
              disabled={!currentInvoice}
              onClick={() => printReceipt(currentInvoice)}
            >
              Print
            </Button>
          </Space>

          {/* Today's Summary */}
          {todaySummary && (
            <div style={{ 
              marginTop: '16px', 
              padding: '12px', 
              background: '#e6f7ff', 
              borderRadius: '6px',
              border: '1px solid #91d5ff'
            }}>
              <div style={{ fontSize: '12px', color: '#666', marginBottom: '4px' }}>
                Today's Summary
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <Text>Sales: {todaySummary.total_transactions}</Text>
                <Text strong>₹{todaySummary.total_sales?.toFixed(2)}</Text>
              </div>
            </div>
          )}
        </Card>
      </div>

      {/* Payment Modal */}
      <Modal
        title="Process Payment"
        open={paymentModalVisible}
        onCancel={() => setPaymentModalVisible(false)}
        footer={null}
        width={400}
      >
        <Form
          form={form}
          layout="vertical"
          onFinish={handlePayment}
          initialValues={{
            amount: total,
            method: 'cash',
            printReceipt: true
          }}
        >
          <div style={{ 
            background: '#f6ffed', 
            padding: '12px', 
            borderRadius: '6px', 
            marginBottom: '16px',
            textAlign: 'center'
          }}>
            <Text strong style={{ fontSize: '18px' }}>
              Amount to Pay: ₹{total.toFixed(2)}
            </Text>
          </div>

          <Form.Item
            label="Payment Method"
            name="method"
            rules={[{ required: true }]}
          >
            <Select size="large">
              <Option value="cash">
                <DollarOutlined /> Cash
              </Option>
              <Option value="card">
                <CreditCardOutlined /> Card
              </Option>
              <Option value="upi">UPI</Option>
            </Select>
          </Form.Item>

          <Form.Item
            label="Amount Received"
            name="amount"
            rules={[
              { required: true, message: 'Please enter amount' },
              { type: 'number', min: total, message: `Amount must be at least ₹${total.toFixed(2)}` }
            ]}
          >
            <InputNumber
              size="large"
              style={{ width: '100%' }}
              formatter={value => `₹ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
              parser={value => value.replace(/₹\s?|(,*)/g, '')}
              precision={2}
            />
          </Form.Item>

          <Form.Item name="printReceipt" valuePropName="checked">
            <Button type="dashed" style={{ width: '100%' }}>
              <PrinterOutlined /> Print Receipt After Payment
            </Button>
          </Form.Item>

          <div style={{ display: 'flex', gap: '8px' }}>
            <Button onClick={() => setPaymentModalVisible(false)} style={{ flex: 1 }}>
              Cancel
            </Button>
            <Button type="primary" htmlType="submit" style={{ flex: 1 }}>
              Complete Sale
            </Button>
          </div>
        </Form>
      </Modal>

      {/* Customer Drawer */}
      <Drawer
        title="Customer Information"
        placement="right"
        onClose={() => setCustomerDrawerVisible(false)}
        open={customerDrawerVisible}
        width={400}
      >
        <Form
          form={customerForm}
          layout="vertical"
          onFinish={(values) => {
            setCustomerInfo(values);
            setCustomerDrawerVisible(false);
            message.success('Customer information saved');
          }}
          initialValues={customerInfo}
        >
          <Form.Item
            label="Customer Name"
            name="name"
            rules={[{ required: true, message: 'Please enter customer name' }]}
          >
            <Input placeholder="Enter customer name" />
          </Form.Item>

          <Form.Item
            label="Mobile Number"
            name="mobile"
            rules={[
              { pattern: /^[0-9]{10}$/, message: 'Please enter valid mobile number' }
            ]}
          >
            <Input placeholder="Enter 10-digit mobile number" maxLength={10} />
          </Form.Item>

          <Form.Item
            label="Email (Optional)"
            name="email"
            rules={[{ type: 'email', message: 'Please enter valid email' }]}
          >
            <Input placeholder="Enter email address" />
          </Form.Item>

          <div style={{ display: 'flex', gap: '8px' }}>
            <Button onClick={() => setCustomerDrawerVisible(false)} style={{ flex: 1 }}>
              Cancel
            </Button>
            <Button type="primary" htmlType="submit" style={{ flex: 1 }}>
              Save Customer
            </Button>
          </div>
        </Form>
      </Drawer>
    </div>
  );
};

export default POSPage;