// frontend/src/services/apiClient.js
import axios from 'axios';
import { message } from 'antd';

// API Configuration
const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000/api';
const REQUEST_TIMEOUT = 10000; // 10 seconds

class ApiClient {
  constructor() {
    this.client = axios.create({
      baseURL: API_BASE_URL,
      timeout: REQUEST_TIMEOUT,
      headers: {
        'Content-Type': 'application/json',
      },
    });

    this.setupInterceptors();
  }

  setupInterceptors() {
    // Request interceptor
    this.client.interceptors.request.use(
      (config) => {
        // Add timestamp to prevent caching
        config.params = {
          ...config.params,
          _t: Date.now(),
        };

        // Log requests in development
        if (process.env.NODE_ENV === 'development') {
          console.log(`🚀 ${config.method?.toUpperCase()} ${config.url}`, {
            data: config.data,
            params: config.params,
          });
        }

        return config;
      },
      (error) => {
        console.error('Request interceptor error:', error);
        return Promise.reject(error);
      }
    );

    // Response interceptor
    this.client.interceptors.response.use(
      (response) => {
        // Log responses in development
        if (process.env.NODE_ENV === 'development') {
          console.log(`✅ ${response.config.method?.toUpperCase()} ${response.config.url}`, {
            status: response.status,
            data: response.data,
          });
        }

        return response;
      },
      (error) => {
        // Handle common errors
        this.handleError(error);
        return Promise.reject(error);
      }
    );
  }

  handleError(error) {
    const { response, message: errorMessage } = error;

    // Network errors
    if (!response) {
      message.error('Network error. Please check your connection.');
      console.error('Network error:', errorMessage);
      return;
    }

    const { status, data } = response;

    // Log errors in development
    if (process.env.NODE_ENV === 'development') {
      console.error(`❌ ${error.config?.method?.toUpperCase()} ${error.config?.url}`, {
        status,
        data,
      });
    }

    // Handle specific HTTP status codes
    switch (status) {
      case 401:
        // Unauthorized - clear token and redirect to login
        this.clearAuthToken();
        localStorage.removeItem('token');
        window.location.href = '/login';
        message.error('Session expired. Please login again.');
        break;

      case 403:
        message.error('You do not have permission to perform this action.');
        break;

      case 404:
        message.error('Resource not found.');
        break;

      case 422:
        // Validation errors
        if (data?.detail) {
          if (Array.isArray(data.detail)) {
            data.detail.forEach(err => {
              message.error(`${err.loc?.join(' ')} - ${err.msg}`);
            });
          } else {
            message.error(data.detail);
          }
        }
        break;

      case 429:
        message.error('Too many requests. Please try again later.');
        break;

      case 500:
        message.error('Server error. Please try again later.');
        break;

      default:
        const errorMsg = data?.detail || data?.message || 'An unexpected error occurred';
        message.error(errorMsg);
        break;
    }
  }

  // Set authentication token
  setAuthToken(token) {
    if (token) {
      this.client.defaults.headers.common['Authorization'] = `Bearer ${token}`;
    }
  }

  // Clear authentication token
  clearAuthToken() {
    delete this.client.defaults.headers.common['Authorization'];
  }

  // HTTP Methods
  async get(url, config = {}) {
    return this.client.get(url, config);
  }

  async post(url, data = {}, config = {}) {
    return this.client.post(url, data, config);
  }

  async put(url, data = {}, config = {}) {
    return this.client.put(url, data, config);
  }

  async patch(url, data = {}, config = {}) {
    return this.client.patch(url, data, config);
  }

  async delete(url, config = {}) {
    return this.client.delete(url, config);
  }

  // File upload
  async upload(url, formData, config = {}) {
    return this.client.post(url, formData, {
      ...config,
      headers: {
        'Content-Type': 'multipart/form-data',
        ...config.headers,
      },
    });
  }

  // File download
  async download(url, config = {}) {
    return this.client.get(url, {
      ...config,
      responseType: 'blob',
    });
  }
}

// API Endpoints organized by module
export const API_ENDPOINTS = {
  // Authentication
  AUTH: {
    LOGIN: '/auth/login',
    LOGOUT: '/auth/logout',
    ME: '/auth/me',
    CHANGE_PASSWORD: '/auth/change-password',
    USERS: '/auth/users',
    ROLES: '/auth/roles',
  },

  // Items
  ITEMS: {
    BASE: '/items',
    CATEGORIES: '/items/categories',
    BRANDS: '/items/brands',
    IMPORT: '/items/import-excel',
    EXPORT: '/items/export-excel',
    LOW_STOCK: '/items/low-stock',
    VALUATION: '/items/stock-valuation',
  },

  // Customers
  CUSTOMERS: {
    BASE: '/customers',
    GROUPS: '/customers/groups',
  },

  // Suppliers
  SUPPLIERS: {
    BASE: '/suppliers',
    GROUPS: '/suppliers/groups',
  },

  // Sales
  SALES: {
    ORDERS: '/sales/orders',
    INVOICES: '/sales/invoices',
    POS: '/sales/pos',
    ANALYTICS: '/sales/analytics',
  },

  // Purchase
  PURCHASE: {
    ORDERS: '/purchases/orders',
    INVOICES: '/purchases/invoices',
    ANALYTICS: '/purchases/analytics',
  },

  // Stock
  STOCK: {
    MOVEMENTS: '/stock/movements',
    ADJUSTMENTS: '/stock/adjustments',
    TRANSFERS: '/stock/transfers',
    LOCATIONS: '/stock/locations',
  },

  // Payments
  PAYMENTS: {
    BASE: '/payments',
    METHODS: '/payments/methods',
    ANALYTICS: '/payments/analytics',
  },

  // Reports
  REPORTS: {
    SALES: '/reports/sales',
    STOCK: '/reports/stock',
    FINANCIAL: '/reports/financial',
    DASHBOARD: '/reports/dashboard',
  },
};

// Service classes for different modules
export class AuthService {
  constructor(apiClient) {
    this.api = apiClient;
  }

  login(credentials) {
    return this.api.post(API_ENDPOINTS.AUTH.LOGIN, credentials);
  }

  logout() {
    return this.api.post(API_ENDPOINTS.AUTH.LOGOUT);
  }

  getProfile() {
    return this.api.get(API_ENDPOINTS.AUTH.ME);
  }

  changePassword(data) {
    return this.api.post(API_ENDPOINTS.AUTH.CHANGE_PASSWORD, data);
  }

  getUsers(params = {}) {
    return this.api.get(API_ENDPOINTS.AUTH.USERS, { params });
  }

  getRoles() {
    return this.api.get(API_ENDPOINTS.AUTH.ROLES);
  }
}

export class ItemService {
  constructor(apiClient) {
    this.api = apiClient;
  }

  getItems(params = {}) {
    return this.api.get(API_ENDPOINTS.ITEMS.BASE, { params });
  }

  getItem(id) {
    return this.api.get(`${API_ENDPOINTS.ITEMS.BASE}/${id}`);
  }

  createItem(data) {
    return this.api.post(API_ENDPOINTS.ITEMS.BASE, data);
  }

  updateItem(id, data) {
    return this.api.put(`${API_ENDPOINTS.ITEMS.BASE}/${id}`, data);
  }

  deleteItem(id) {
    return this.api.delete(`${API_ENDPOINTS.ITEMS.BASE}/${id}`);
  }

  getCategories() {
    return this.api.get(API_ENDPOINTS.ITEMS.CATEGORIES);
  }

  getBrands() {
    return this.api.get(API_ENDPOINTS.ITEMS.BRANDS);
  }

  importFromExcel(file) {
    const formData = new FormData();
    formData.append('file', file);
    return this.api.upload(API_ENDPOINTS.ITEMS.IMPORT, formData);
  }

  exportToExcel() {
    return this.api.download(API_ENDPOINTS.ITEMS.EXPORT);
  }

  getLowStockItems() {
    return this.api.get(API_ENDPOINTS.ITEMS.LOW_STOCK);
  }
}

export class SalesService {
  constructor(apiClient) {
    this.api = apiClient;
  }

  // Sales Orders
  getOrders(params = {}) {
    return this.api.get(API_ENDPOINTS.SALES.ORDERS, { params });
  }

  getOrder(id) {
    return this.api.get(`${API_ENDPOINTS.SALES.ORDERS}/${id}`);
  }

  createOrder(data) {
    return this.api.post(API_ENDPOINTS.SALES.ORDERS, data);
  }

  updateOrder(id, data) {
    return this.api.put(`${API_ENDPOINTS.SALES.ORDERS}/${id}`, data);
  }

  updateOrderStatus(id, status) {
    return this.api.put(`${API_ENDPOINTS.SALES.ORDERS}/${id}/status`, null, {
      params: { new_status: status }
    });
  }

  // Sales Invoices
  getInvoices(params = {}) {
    return this.api.get(API_ENDPOINTS.SALES.INVOICES, { params });
  }

  getInvoice(id) {
    return this.api.get(`${API_ENDPOINTS.SALES.INVOICES}/${id}`);
  }

  createInvoice(data) {
    return this.api.post(API_ENDPOINTS.SALES.INVOICES, data);
  }

  updateInvoice(id, data) {
    return this.api.put(`${API_ENDPOINTS.SALES.INVOICES}/${id}`, data);
  }

  updateInvoicePaymentStatus(id, status, amount) {
    return this.api.put(`${API_ENDPOINTS.SALES.INVOICES}/${id}/payment-status`, null, {
      params: { payment_status: status, paid_amount: amount }
    });
  }

  // POS Sales
  createPOSSale(data) {
    return this.api.post(`${API_ENDPOINTS.SALES.POS}/quick-sale`, data);
  }

  getDailySummary() {
    return this.api.get(`${API_ENDPOINTS.SALES.POS}/today-summary`);
  }

  // Analytics
  getDailySales(params = {}) {
    return this.api.get(`${API_ENDPOINTS.SALES.ANALYTICS}/daily-sales`, { params });
  }

  getTopCustomers(params = {}) {
    return this.api.get(`${API_ENDPOINTS.SALES.ANALYTICS}/top-customers`, { params });
  }

  getTopItems(params = {}) {
    return this.api.get(`${API_ENDPOINTS.SALES.ANALYTICS}/top-items`, { params });
  }

  getPaymentStatusSummary() {
    return this.api.get(`${API_ENDPOINTS.SALES.ANALYTICS}/payment-status-summary`);
  }

  // Customers (if not separate service)
  getCustomers(params = {}) {
    return this.api.get(API_ENDPOINTS.CUSTOMERS.BASE, { params });
  }

  getCustomer(id) {
    return this.api.get(`${API_ENDPOINTS.CUSTOMERS.BASE}/${id}`);
  }

  createCustomer(data) {
    return this.api.post(API_ENDPOINTS.CUSTOMERS.BASE, data);
  }

  updateCustomer(id, data) {
    return this.api.put(`${API_ENDPOINTS.CUSTOMERS.BASE}/${id}`, data);
  }
}

export class PurchaseService {
  constructor(apiClient) {
    this.api = apiClient;
  }

  // Purchase Orders
  getOrders(params = {}) {
    return this.api.get(API_ENDPOINTS.PURCHASE.ORDERS, { params });
  }

  getOrder(id) {
    return this.api.get(`${API_ENDPOINTS.PURCHASE.ORDERS}/${id}`);
  }

  createOrder(data) {
    return this.api.post(API_ENDPOINTS.PURCHASE.ORDERS, data);
  }

  updateOrder(id, data) {
    return this.api.put(`${API_ENDPOINTS.PURCHASE.ORDERS}/${id}`, data);
  }

  updateOrderStatus(id, status) {
    return this.api.put(`${API_ENDPOINTS.PURCHASE.ORDERS}/${id}/status`, null, {
      params: { new_status: status }
    });
  }

  // Purchase Invoices (GRN)
  getInvoices(params = {}) {
    return this.api.get(API_ENDPOINTS.PURCHASE.INVOICES, { params });
  }

  getInvoice(id) {
    return this.api.get(`${API_ENDPOINTS.PURCHASE.INVOICES}/${id}`);
  }

  createInvoice(data) {
    return this.api.post(API_ENDPOINTS.PURCHASE.INVOICES, data);
  }

  updateInvoice(id, data) {
    return this.api.put(`${API_ENDPOINTS.PURCHASE.INVOICES}/${id}`, data);
  }

  updateInvoicePaymentStatus(id, amount) {
    return this.api.put(`${API_ENDPOINTS.PURCHASE.INVOICES}/${id}/payment-status`, null, {
      params: { paid_amount: amount }
    });
  }

  // Analytics
  getSupplierPerformance(params = {}) {
    return this.api.get(`${API_ENDPOINTS.PURCHASE.ANALYTICS}/supplier-performance`, { params });
  }

  getMonthlyTrends(params = {}) {
    return this.api.get(`${API_ENDPOINTS.PURCHASE.ANALYTICS}/monthly-trends`, { params });
  }

  getPendingPayments() {
    return this.api.get(`${API_ENDPOINTS.PURCHASE.ANALYTICS}/pending-payments`);
  }

  // Suppliers
  getSuppliers(params = {}) {
    return this.api.get(API_ENDPOINTS.SUPPLIERS.BASE, { params });
  }

  getSupplier(id) {
    return this.api.get(`${API_ENDPOINTS.SUPPLIERS.BASE}/${id}`);
  }

  createSupplier(data) {
    return this.api.post(API_ENDPOINTS.SUPPLIERS.BASE, data);
  }

  updateSupplier(id, data) {
    return this.api.put(`${API_ENDPOINTS.SUPPLIERS.BASE}/${id}`, data);
  }
}

export class CustomerService {
  constructor(apiClient) {
    this.api = apiClient;
  }

  getCustomers(params = {}) {
    return this.api.get(API_ENDPOINTS.CUSTOMERS.BASE, { params });
  }

  getCustomer(id) {
    return this.api.get(`${API_ENDPOINTS.CUSTOMERS.BASE}/${id}`);
  }

  getCustomerByCode(code) {
    return this.api.get(`${API_ENDPOINTS.CUSTOMERS.BASE}/code/${code}`);
  }

  getCustomerByMobile(mobile) {
    return this.api.get(`${API_ENDPOINTS.CUSTOMERS.BASE}/mobile/${mobile}`);
  }

  createCustomer(data) {
    return this.api.post(API_ENDPOINTS.CUSTOMERS.BASE, data);
  }

  updateCustomer(id, data) {
    return this.api.put(`${API_ENDPOINTS.CUSTOMERS.BASE}/${id}`, data);
  }

  toggleCustomerStatus(id) {
    return this.api.put(`${API_ENDPOINTS.CUSTOMERS.BASE}/${id}/toggle-status`);
  }

  toggleLoyaltyMembership(id) {
    return this.api.put(`${API_ENDPOINTS.CUSTOMERS.BASE}/${id}/loyalty`);
  }

  getBalanceSummary(id) {
    return this.api.get(`${API_ENDPOINTS.CUSTOMERS.BASE}/${id}/balance-summary`);
  }

  // Customer Groups
  getCustomerGroups() {
    return this.api.get(API_ENDPOINTS.CUSTOMERS.GROUPS);
  }

  createCustomerGroup(data) {
    return this.api.post(API_ENDPOINTS.CUSTOMERS.GROUPS, data);
  }
}

export class SupplierService {
  constructor(apiClient) {
    this.api = apiClient;
  }

  getSuppliers(params = {}) {
    return this.api.get(API_ENDPOINTS.SUPPLIERS.BASE, { params });
  }

  getSupplier(id) {
    return this.api.get(`${API_ENDPOINTS.SUPPLIERS.BASE}/${id}`);
  }

  getSupplierByCode(code) {
    return this.api.get(`${API_ENDPOINTS.SUPPLIERS.BASE}/code/${code}`);
  }

  createSupplier(data) {
    return this.api.post(API_ENDPOINTS.SUPPLIERS.BASE, data);
  }

  updateSupplier(id, data) {
    return this.api.put(`${API_ENDPOINTS.SUPPLIERS.BASE}/${id}`, data);
  }

  toggleSupplierStatus(id) {
    return this.api.put(`${API_ENDPOINTS.SUPPLIERS.BASE}/${id}/toggle-status`);
  }

  updateSupplierRating(id, rating) {
    return this.api.put(`${API_ENDPOINTS.SUPPLIERS.BASE}/${id}/rating`, null, {
      params: { rating }
    });
  }

  getBalanceSummary(id) {
    return this.api.get(`${API_ENDPOINTS.SUPPLIERS.BASE}/${id}/balance-summary`);
  }

  getSupplierItems(id) {
    return this.api.get(`${API_ENDPOINTS.SUPPLIERS.BASE}/${id}/items`);
  }

  // Supplier Groups
  getSupplierGroups() {
    return this.api.get(API_ENDPOINTS.SUPPLIERS.GROUPS);
  }

  createSupplierGroup(data) {
    return this.api.post(API_ENDPOINTS.SUPPLIERS.GROUPS, data);
  }
}

export class PaymentService {
  constructor(apiClient) {
    this.api = apiClient;
  }

  getPayments(params = {}) {
    return this.api.get(API_ENDPOINTS.PAYMENTS.BASE, { params });
  }

  getPayment(id) {
    return this.api.get(`${API_ENDPOINTS.PAYMENTS.BASE}/${id}`);
  }

  createPayment(data) {
    return this.api.post(API_ENDPOINTS.PAYMENTS.BASE, data);
  }

  updatePaymentStatus(id, status) {
    return this.api.put(`${API_ENDPOINTS.PAYMENTS.BASE}/${id}/status`, null, {
      params: { new_status: status }
    });
  }

  // Payment Methods
  getPaymentMethods() {
    return this.api.get(API_ENDPOINTS.PAYMENTS.METHODS);
  }

  // Analytics
  getDailyCollections(params = {}) {
    return this.api.get(`${API_ENDPOINTS.PAYMENTS.ANALYTICS}/daily-collections`, { params });
  }

  getPaymentMethodAnalytics(params = {}) {
    return this.api.get(`${API_ENDPOINTS.PAYMENTS.ANALYTICS}/payment-methods`, { params });
  }

  getOutstandingSummary() {
    return this.api.get(`${API_ENDPOINTS.PAYMENTS.ANALYTICS}/outstanding-summary`);
  }
}

export class ReportsService {
  constructor(apiClient) {
    this.api = apiClient;
  }

  // Sales Reports
  getSalesSummary(params = {}) {
    return this.api.get(`${API_ENDPOINTS.REPORTS.SALES}/summary`, { params });
  }

  getDetailedSales(params = {}) {
    return this.api.get(`${API_ENDPOINTS.REPORTS.SALES}/detailed`, { params });
  }

  getTopCustomers(params = {}) {
    return this.api.get(`${API_ENDPOINTS.REPORTS.SALES}/top-customers`, { params });
  }

  getTopItems(params = {}) {
    return this.api.get(`${API_ENDPOINTS.REPORTS.SALES}/top-items`, { params });
  }

  // Stock Reports
  getStockValuation(params = {}) {
    return this.api.get(`${API_ENDPOINTS.REPORTS.STOCK}/valuation`, { params });
  }

  getStockMovements(params = {}) {
    return this.api.get(`${API_ENDPOINTS.REPORTS.STOCK}/movements`, { params });
  }

  getLowStockReport() {
    return this.api.get(`${API_ENDPOINTS.REPORTS.STOCK}/low-stock`);
  }

  // Financial Reports
  getGSTSummary(params = {}) {
    return this.api.get(`${API_ENDPOINTS.REPORTS.FINANCIAL}/gst-summary`, { params });
  }

  getProfitLoss(params = {}) {
    return this.api.get(`${API_ENDPOINTS.REPORTS.FINANCIAL}/profit-loss`, { params });
  }

  // Dashboard
  getDashboardSummary() {
    return this.api.get(`${API_ENDPOINTS.REPORTS.DASHBOARD}/summary`);
  }

  // Export functions
  exportSalesReport(params = {}) {
    return this.api.download(`${API_ENDPOINTS.REPORTS.SALES}/detailed`, { 
      params: { ...params, export_format: 'excel' } 
    });
  }

  exportStockValuation(params = {}) {
    return this.api.download(`${API_ENDPOINTS.REPORTS.STOCK}/valuation`, {
      params: { ...params, export_format: 'excel' }
    });
  }

  exportStockMovements(params = {}) {
    return this.api.download(`${API_ENDPOINTS.REPORTS.STOCK}/movements`, {
      params: { ...params, export_format: 'excel' }
    });
  }
}

// Update the exports at the end of your apiClient.js file
export const salesService = new SalesService(apiClient);
export const purchaseService = new PurchaseService(apiClient);
export const customerService = new CustomerService(apiClient);
export const supplierService = new SupplierService(apiClient);
export const paymentService = new PaymentService(apiClient);
export const reportsService = new ReportsService(apiClient);

// Additional utility functions for common operations
export const ApiUtils = {
  // Format currency
  formatCurrency: (amount) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 2,
    }).format(amount);
  },

  // Format date
  formatDate: (date, format = 'DD MMM YYYY') => {
    return dayjs(date).format(format);
  },

  // Download file from blob response
  downloadFile: (response, filename) => {
    const blob = new Blob([response.data], {
      type: response.headers['content-type'] || 'application/octet-stream'
    });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(link);
  },

  // Handle API errors consistently
  handleApiError: (error, defaultMessage = 'Operation failed') => {
    if (error.response?.data?.detail) {
      return error.response.data.detail;
    }
    return defaultMessage;
  },

  // Calculate GST amounts
  calculateGST: (amount, rate = 18, isInclusive = false) => {
    if (isInclusive) {
      const baseAmount = amount / (1 + rate / 100);
      const taxAmount = amount - baseAmount;
      return { baseAmount, taxAmount, totalAmount: amount };
    } else {
      const taxAmount = amount * (rate / 100);
      const totalAmount = amount + taxAmount;
      return { baseAmount: amount, taxAmount, totalAmount };
    }
  },

  // Generate invoice/order numbers
  generateDocumentNumber: (prefix = 'DOC', date = new Date()) => {
    const dateStr = date.toISOString().slice(0, 10).replace(/-/g, '');
    const randomStr = Math.random().toString(36).substring(2, 6).toUpperCase();
    return `${prefix}${dateStr}${randomStr}`;
  },
};

// Export everything as default
export default {
  apiClient,
  authService,
  itemService,
  salesService,
  purchaseService,
  customerService,
  supplierService,
  paymentService,
  reportsService,
  ApiUtils,
};

