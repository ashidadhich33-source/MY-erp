# backend/app/core/init_data.py
from sqlalchemy.orm import Session
from ..database import SessionLocal
from ..models.user import User, Role, Permission, user_roles, role_permissions
from ..models.company import Company, SystemSettings, FinancialYear
from ..models.stock import StockLocation
from ..models.payment import PaymentMethod
from ..models.loyalty import LoyaltyProgram, LoyaltyGrade
from ..core.security import SecurityService
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

async def initialize_default_data():
    """Initialize default data for the system"""
    db = SessionLocal()
    try:
        await create_default_permissions(db)
        await create_default_roles(db)
        await create_default_admin_user(db)
        await create_default_company(db)
        await create_default_settings(db)
        await create_default_stock_locations(db)
        await create_default_payment_methods(db)
        await create_default_loyalty_program(db)
        await create_default_financial_year(db)
        
        db.commit()
        logger.info("Default data initialized successfully")
        
    except Exception as e:
        logger.error(f"Error initializing default data: {e}")
        db.rollback()
    finally:
        db.close()

async def create_default_permissions(db: Session):
    """Create default permissions"""
    permissions_data = [
        # User Management
        {"name": "users.view", "display_name": "View Users", "module": "users"},
        {"name": "users.create", "display_name": "Create Users", "module": "users"},
        {"name": "users.edit", "display_name": "Edit Users", "module": "users"},
        {"name": "users.delete", "display_name": "Delete Users", "module": "users"},
        
        # Item Management
        {"name": "items.view", "display_name": "View Items", "module": "items"},
        {"name": "items.create", "display_name": "Create Items", "module": "items"},
        {"name": "items.edit", "display_name": "Edit Items", "module": "items"},
        {"name": "items.delete", "display_name": "Delete Items", "module": "items"},
        {"name": "items.import", "display_name": "Import Items", "module": "items"},
        {"name": "items.export", "display_name": "Export Items", "module": "items"},
        
        # Stock Management
        {"name": "stock.view", "display_name": "View Stock", "module": "stock"},
        {"name": "stock.adjust", "display_name": "Adjust Stock", "module": "stock"},
        {"name": "stock.transfer", "display_name": "Transfer Stock", "module": "stock"},
        
        # Sales
        {"name": "sales.view", "display_name": "View Sales", "module": "sales"},
        {"name": "sales.create", "display_name": "Create Sales", "module": "sales"},
        {"name": "sales.edit", "display_name": "Edit Sales", "module": "sales"},
        {"name": "sales.delete", "display_name": "Delete Sales", "module": "sales"},
        
        # Purchases
        {"name": "purchases.view", "display_name": "View Purchases", "module": "purchases"},
        {"name": "purchases.create", "display_name": "Create Purchases", "module": "purchases"},
        {"name": "purchases.edit", "display_name": "Edit Purchases", "module": "purchases"},
        {"name": "purchases.delete", "display_name": "Delete Purchases", "module": "purchases"},
        
        # Customers
        {"name": "customers.view", "display_name": "View Customers", "module": "customers"},
        {"name": "customers.create", "display_name": "Create Customers", "module": "customers"},
        {"name": "customers.edit", "display_name": "Edit Customers", "module": "customers"},
        {"name": "customers.delete", "display_name": "Delete Customers", "module": "customers"},
        
        # Suppliers
        {"name": "suppliers.view", "display_name": "View Suppliers", "module": "suppliers"},
        {"name": "suppliers.create", "display_name": "Create Suppliers", "module": "suppliers"},
        {"name": "suppliers.edit", "display_name": "Edit Suppliers", "module": "suppliers"},
        {"name": "suppliers.delete", "display_name": "Delete Suppliers", "module": "suppliers"},
        
        # Reports
        {"name": "reports.sales", "display_name": "Sales Reports", "module": "reports"},
        {"name": "reports.stock", "display_name": "Stock Reports", "module": "reports"},
        {"name": "reports.financial", "display_name": "Financial Reports", "module": "reports"},
        
        # Settings
        {"name": "settings.view", "display_name": "View Settings", "module": "settings"},
        {"name": "settings.edit", "display_name": "Edit Settings", "module": "settings"},
        {"name": "settings.backup", "display_name": "Backup System", "module": "settings"},
    ]
    
    for perm_data in permissions_data:
        existing = db.query(Permission).filter(Permission.name == perm_data["name"]).first()
        if not existing:
            permission = Permission(**perm_data)
            db.add(permission)
            logger.info(f"Created permission: {perm_data['name']}")

async def create_default_roles(db: Session):
    """Create default roles"""
    roles_data = [
        {
            "name": "admin",
            "display_name": "Administrator",
            "description": "Full system access",
            "permissions": [
                "users.view", "users.create", "users.edit", "users.delete",
                "items.view", "items.create", "items.edit", "items.delete", "items.import", "items.export",
                "stock.view", "stock.adjust", "stock.transfer",
                "sales.view", "sales.create", "sales.edit", "sales.delete",
                "purchases.view", "purchases.create", "purchases.edit", "purchases.delete",
                "customers.view", "customers.create", "customers.edit", "customers.delete",
                "suppliers.view", "suppliers.create", "suppliers.edit", "suppliers.delete",
                "reports.sales", "reports.stock", "reports.financial",
                "settings.view", "settings.edit", "settings.backup"
            ]
        },
        {
            "name": "manager",
            "display_name": "Manager",
            "description": "Management level access",
            "permissions": [
                "items.view", "items.create", "items.edit",
                "stock.view", "stock.adjust",
                "sales.view", "sales.create", "sales.edit",
                "purchases.view", "purchases.create", "purchases.edit",
                "customers.view", "customers.create", "customers.edit",
                "suppliers.view", "suppliers.create", "suppliers.edit",
                "reports.sales", "reports.stock", "reports.financial"
            ]
        },
        {
            "name": "cashier",
            "display_name": "Cashier",
            "description": "Point of sale access",
            "permissions": [
                "items.view",
                "sales.view", "sales.create",
                "customers.view", "customers.create", "customers.edit",
                "reports.sales"
            ]
        },
        {
            "name": "stockkeeper",
            "display_name": "Stock Keeper",
            "description": "Inventory management access",
            "permissions": [
                "items.view", "items.create", "items.edit",
                "stock.view", "stock.adjust", "stock.transfer",
                "purchases.view", "purchases.create",
                "suppliers.view",
                "reports.stock"
            ]
        }
    ]
    
    for role_data in roles_data:
        existing_role = db.query(Role).filter(Role.name == role_data["name"]).first()
        if not existing_role:
            role = Role(
                name=role_data["name"],
                display_name=role_data["display_name"],
                description=role_data["description"]
            )
            db.add(role)
            db.flush()  # Get the role ID
            
            # Add permissions to role
            for perm_name in role_data["permissions"]:
                permission = db.query(Permission).filter(Permission.name == perm_name).first()
                if permission:
                    role.permissions.append(permission)
            
            logger.info(f"Created role: {role_data['name']}")

async def create_default_admin_user(db: Session):
    """Create default admin user"""
    admin_user = db.query(User).filter(User.username == "admin").first()
    if not admin_user:
        hashed_password = SecurityService.get_password_hash("admin123")
        admin_user = User(
            username="admin",
            email="admin@company.com",
            full_name="System Administrator",
            hashed_password=hashed_password,
            is_superuser=True
        )
        db.add(admin_user)
        db.flush()
        
        # Assign admin role
        admin_role = db.query(Role).filter(Role.name == "admin").first()
        if admin_role:
            admin_user.roles.append(admin_role)
        
        logger.info("Created default admin user (username: admin, password: admin123)")

async def create_default_company(db: Session):
    """Create default company"""
    company = db.query(Company).first()
    if not company:
        company = Company(
            name="Your Company Name",
            display_name="Your Company",
            address_line1="123 Business Street",
            city="Your City",
            state="Your State",
            country="India",
            postal_code="123456",
            phone="1234567890",
            email="info@company.com",
            currency="INR",
            financial_year_start="04-01"
        )
        db.add(company)
        logger.info("Created default company")

async def create_default_settings(db: Session):
    """Create default system settings"""
    default_settings = [
        {"setting_key": "auto_generate_item_codes", "setting_value": "true", "setting_type": "boolean", "module": "items", "display_name": "Auto Generate Item Codes"},
        {"setting_key": "default_tax_rate", "setting_value": "18", "setting_type": "float", "module": "tax", "display_name": "Default Tax Rate"},
        {"setting_key": "low_stock_threshold", "setting_value": "10", "setting_type": "integer", "module": "stock", "display_name": "Low Stock Threshold"},
        {"setting_key": "invoice_prefix", "setting_value": "INV", "setting_type": "string", "module": "sales", "display_name": "Invoice Prefix"},
        {"setting_key": "pos_print_receipt", "setting_value": "true", "setting_type": "boolean", "module": "pos", "display_name": "Print Receipt After Sale"},
        {"setting_key": "loyalty_points_per_rupee", "setting_value": "1", "setting_type": "float", "module": "loyalty", "display_name": "Loyalty Points per Rupee"},
        {"setting_key": "backup_frequency", "setting_value": "daily", "setting_type": "string", "module": "backup", "display_name": "Backup Frequency"},
    ]
    
    for setting_data in default_settings:
        existing = db.query(SystemSettings).filter(SystemSettings.setting_key == setting_data["setting_key"]).first()
        if not existing:
            setting = SystemSettings(**setting_data)
            db.add(setting)

async def create_default_stock_locations(db: Session):
    """Create default stock locations"""
    main_location = db.query(StockLocation).filter(StockLocation.code == "MAIN").first()
    if not main_location:
        main_location = StockLocation(
            code="MAIN",
            name="Main Store",
            description="Primary stock location",
            is_main_location=True
        )
        db.add(main_location)
        logger.info("Created main stock location")

async def create_default_payment_methods(db: Session):
    """Create default payment methods"""
    payment_methods = [
        {"name": "cash", "display_name": "Cash", "method_type": "cash"},
        {"name": "card", "display_name": "Card", "method_type": "card", "charge_percent": 2.0},
        {"name": "upi", "display_name": "UPI", "method_type": "upi"},
        {"name": "bank_transfer", "display_name": "Bank Transfer", "method_type": "bank_transfer", "requires_reference": True},
        {"name": "cheque", "display_name": "Cheque", "method_type": "cheque", "requires_reference": True},
    ]
    
    for method_data in payment_methods:
        existing = db.query(PaymentMethod).filter(PaymentMethod.name == method_data["name"]).first()
        if not existing:
            method = PaymentMethod(**method_data)
            db.add(method)

async def create_default_loyalty_program(db: Session):
    """Create default loyalty program"""
    program = db.query(LoyaltyProgram).filter(LoyaltyProgram.name == "default").first()
    if not program:
        program = LoyaltyProgram(
            name="default",
            display_name="Customer Loyalty Program",
            description="Earn points on every purchase",
            points_per_rupee=1.0,
            rupees_per_point=1.0,
            minimum_transaction=100.0,
            is_active=True
        )
        db.add(program)
        db.flush()
        
        # Create loyalty grades
        grades = [
            {"name": "bronze", "display_name": "Bronze", "minimum_points": 0, "points_multiplier": 1.0},
            {"name": "silver", "display_name": "Silver", "minimum_points": 1000, "points_multiplier": 1.2, "discount_percent": 2.0},
            {"name": "gold", "display_name": "Gold", "minimum_points": 5000, "points_multiplier": 1.5, "discount_percent": 5.0},
            {"name": "platinum", "display_name": "Platinum", "minimum_points": 10000, "points_multiplier": 2.0, "discount_percent": 10.0},
        ]
        
        for grade_data in grades:
            grade = LoyaltyGrade(program_id=program.id, **grade_data)
            db.add(grade)
        
        logger.info("Created default loyalty program with grades")

async def create_default_financial_year(db: Session):
    """Create current financial year"""
    current_year = "2024-25"
    fy = db.query(FinancialYear).filter(FinancialYear.year_name == current_year).first()
    if not fy:
        fy = FinancialYear(
            year_name=current_year,
            start_date="2024-04-01",
            end_date="2025-03-31",
            is_current=True
        )
        db.add(fy)
        logger.info(f"Created financial year: {current_year}")