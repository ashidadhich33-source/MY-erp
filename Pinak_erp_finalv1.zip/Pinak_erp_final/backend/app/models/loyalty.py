from sqlalchemy import Column, String, Numeric, Integer, ForeignKey, DateTime, Date, Boolean
from sqlalchemy.orm import relationship
from ..database import Base
from datetime import datetime

class LoyaltyProgram(BaseModel):
    __tablename__ = "loyalty_program"
    
    name = Column(String(100), unique=True, nullable=False)
    display_name = Column(String(100), nullable=False)
    description = Column(Text, nullable=True)
    
    # Program Settings
    points_per_rupee = Column(Numeric(10, 4), default=1)  # Points earned per rupee spent
    rupees_per_point = Column(Numeric(10, 4), default=1)  # Rupees value per point
    minimum_transaction = Column(Numeric(10, 2), default=0)  # Minimum amount to earn points
    maximum_points_per_transaction = Column(Integer, nullable=True)
    
    # Validity
    points_validity_days = Column(Integer, default=365)  # Days before points expire
    
    # Status
    is_active = Column(Boolean, default=True)
    start_date = Column(DateTime, nullable=True)
    end_date = Column(DateTime, nullable=True)
    
    # Relationships
    grades = relationship("LoyaltyGrade", back_populates="program")
    transactions = relationship("LoyaltyTransaction", back_populates="program")
    
    def __repr__(self):
        return f"<LoyaltyProgram(name='{self.name}')>"

class LoyaltyGrade(BaseModel):
    __tablename__ = "loyalty_grade"
    
    program_id = Column(Integer, ForeignKey('loyalty_program.id'), nullable=False)
    name = Column(String(50), nullable=False)
    display_name = Column(String(100), nullable=False)
    
    # Grade Requirements
    minimum_points = Column(Integer, default=0)
    minimum_transactions = Column(Integer, default=0)
    minimum_amount = Column(Numeric(12, 2), default=0)
    
    # Benefits
    points_multiplier = Column(Numeric(5, 2), default=1.0)  # Multiply base points by this
    discount_percent = Column(Numeric(5, 2), default=0)
    special_offers = Column(Text, nullable=True)  # JSON data
    
    # Relationships
    program = relationship("LoyaltyProgram", back_populates="grades")
    customers = relationship("Customer")
    
    def __repr__(self):
        return f"<LoyaltyGrade(name='{self.name}')>"

class LoyaltyTransaction(BaseModel):
    __tablename__ = "loyalty_transaction"
    
    # Program and Customer
    program_id = Column(Integer, ForeignKey('loyalty_program.id'), nullable=False)
    customer_id = Column(Integer, ForeignKey('customer.id'), nullable=False)
    
    # Transaction Details
    transaction_type = Column(String(20), nullable=False)  # earn, redeem, adjust, expire
    points = Column(Integer, nullable=False)  # Positive for earn, negative for redeem
    
    # Reference Information
    reference_type = Column(String(30), nullable=True)  # sales_invoice, manual_adjustment
    reference_id = Column(Integer, nullable=True)
    reference_number = Column(String(50), nullable=True)
    transaction_amount = Column(Numeric(12, 2), nullable=True)  # Sale amount that generated points
    
    # Point Details
    points_earned = Column(Integer, default=0)
    points_redeemed = Column(Integer, default=0)
    points_balance = Column(Integer, default=0)  # Running balance
    expiry_date = Column(DateTime, nullable=True)
    
    # Additional Information
    description = Column(String(200), nullable=True)
    remarks = Column(Text, nullable=True)
    
    # Relationships
    program = relationship("LoyaltyProgram", back_populates="transactions")
    customer = relationship("Customer", back_populates="loyalty_transactions")
    
    def __repr__(self):
        return f"<LoyaltyTransaction(customer_id={self.customer_id}, points={self.points})>"

class Coupon(BaseModel):
    __tablename__ = "coupon"
    
    # Coupon Details
    code = Column(String(50), unique=True, nullable=False, index=True)
    name = Column(String(100), nullable=False)
    description = Column(Text, nullable=True)
    
    # Discount Details
    discount_type = Column(String(20), nullable=False)  # percent, fixed_amount
    discount_value = Column(Numeric(10, 2), nullable=False)
    maximum_discount = Column(Numeric(10, 2), nullable=True)  # Max discount for percent type
    minimum_amount = Column(Numeric(10, 2), default=0)  # Minimum cart value
    
    # Usage Limits
    usage_limit = Column(Integer, nullable=True)  # Total usage limit
    usage_limit_per_customer = Column(Integer, default=1)
    current_usage = Column(Integer, default=0)
    
    # Validity
    valid_from = Column(DateTime, nullable=False)
    valid_until = Column(DateTime, nullable=False)
    
    # Applicability
    applicable_to = Column(String(20), default='all')  # all, specific_items, categories
    applicable_items = Column(Text, nullable=True)  # JSON array of item IDs
    applicable_categories = Column(Text, nullable=True)  # JSON array of category IDs
    
    # Customer Restrictions
    customer_type = Column(String(20), default='all')  # all, specific_customers, loyalty_members
    allowed_customers = Column(Text, nullable=True)  # JSON array of customer IDs
    minimum_loyalty_points = Column(Integer, nullable=True)
    
    # Status
    is_active = Column(Boolean, default=True)
    
    # Relationships
    coupon_usage = relationship("CouponUsage", back_populates="coupon")
    
    def is_valid(self, customer_id=None, cart_amount=0):
        """Check if coupon is valid for usage"""
        now = datetime.utcnow()
        if not self.is_active:
            return False, "Coupon is inactive"
        if now < self.valid_from:
            return False, "Coupon is not yet valid"
        if now > self.valid_until:
            return False, "Coupon has expired"
        if self.usage_limit and self.current_usage >= self.usage_limit:
            return False, "Coupon usage limit exceeded"
        if cart_amount < self.minimum_amount:
            return False, f"Minimum amount required: {self.minimum_amount}"
        
        # Check customer-specific usage
        if customer_id and self.usage_limit_per_customer:
            customer_usage = sum(1 for usage in self.coupon_usage 
                               if usage.customer_id == customer_id)
            if customer_usage >= self.usage_limit_per_customer:
                return False, "Customer usage limit exceeded"
        
        return True, "Valid"
    
    def calculate_discount(self, amount):
        """Calculate discount amount"""
        if self.discount_type == 'percent':
            discount = amount * (self.discount_value / 100)
            if self.maximum_discount:
                discount = min(discount, self.maximum_discount)
        else:  # fixed_amount
            discount = min(self.discount_value, amount)
        return discount
    
    def __repr__(self):
        return f"<Coupon(code='{self.code}', discount={self.discount_value})>"

class CouponUsage(BaseModel):
    __tablename__ = "coupon_usage"
    
    coupon_id = Column(Integer, ForeignKey('coupon.id'), nullable=False)
    customer_id = Column(Integer, ForeignKey('customer.id'), nullable=False)
    
    # Usage Details
    invoice_id = Column(Integer, ForeignKey('sales_invoice.id'), nullable=True)
    invoice_number = Column(String(50), nullable=True)
    usage_date = Column(DateTime, default=datetime.utcnow, nullable=False)
    
    # Discount Applied
    original_amount = Column(Numeric(12, 2), nullable=False)
    discount_amount = Column(Numeric(10, 2), nullable=False)
    final_amount = Column(Numeric(12, 2), nullable=False)
    
    # Relationships
    coupon = relationship("Coupon", back_populates="coupon_usage")
    customer = relationship("Customer")
    invoice = relationship("SalesInvoice")
    
    def __repr__(self):
        return f"<CouponUsage(coupon_id={self.coupon_id}, customer_id={self.customer_id})>"